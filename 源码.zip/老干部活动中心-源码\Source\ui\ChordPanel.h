#pragma once

#include <juce_gui_basics/juce_gui_basics.h>
#include <juce_dsp/juce_dsp.h>
#include "practice/ChordLibrary.h"

class AudioEngine;

// “吉他和弦”页：选根音和和弦类型，看几种指法（开放 / 横按 E 型 / A 型 / D 型），点一下试听；
// 下面是选定调的顺阶和弦；打开“听我弹”时，按着和弦扫一下，显示哪根弦没响。
class ChordPanel : public juce::Component, private juce::Timer
{
public:
    ChordPanel (AudioEngine& engine, juce::PropertiesFile& settings);
    ~ChordPanel() override;

    void select (int root, Chords::Quality q);
    void selectVoicing (int index);
    void strum (bool arpeggio);
    bool keyPressed (const juce::KeyPress&) override;
    void setListening (bool on);
    std::function<void (int event, int combo)> onPetEvent;     // 给桌宠：PetView::Event 的序号

    // 测试 / 截图用：直接喂一段干信号，算出每根弦响没响
    static std::array<uint8_t, 6> analyse (const float* samples, int n, double sampleRate, const Chords::Voicing& v,
                                           juce::dsp::FFT& fft, std::vector<float>& work);
    const std::vector<Chords::Voicing>& getVoicings() const { return voicings; }
    void setStatusForSnapshot (std::array<uint8_t, 6> s)    { status = s; statusValid = true; repaint(); }

    void paint (juce::Graphics&) override;
    void resized() override;
    void mouseDown (const juce::MouseEvent&) override;
    void visibilityChanged() override;

private:
    void timerCallback() override;
    void refresh();
    void save();

    AudioEngine& engine;
    juce::PropertiesFile& settings;
    int root = 0;
    Chords::Quality quality = Chords::Quality::major;
    std::vector<Chords::Voicing> voicings;
    int selected = 0;
    bool flats = false;

    std::array<juce::TextButton, 12> rootButtons;
    std::array<juce::TextButton, Chords::numQualities> qualityButtons;
    juce::TextButton strumButton, arpButton;
    juce::ToggleButton listenToggle, flatsToggle, seventhsToggle;
    juce::ComboBox keyBox;
    juce::TextButton keyMajorButton, keyMinorButton;
    juce::Label diatonicLabel;

    std::vector<juce::Rectangle<float>> cardAreas;
    std::vector<juce::Rectangle<float>> diatonicAreas;
    std::vector<Chords::Diatonic> diatonicChords;
    juce::Rectangle<int> infoArea, cardsArea, diatonicArea;

    // 试听：扫弦时一根根弦错开一点
    struct Pending { double at; int midi; };
    std::vector<Pending> pending;

    // 听音
    bool listening = false;
    std::unique_ptr<juce::dsp::FFT> fft;
    std::vector<float> dry, work;
    std::array<uint8_t, 6> status {};
    bool statusValid = false;
    double lastLoudMs = 0.0, lastPetMs = 0.0;
    int framesSinceAnalysis = 0;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (ChordPanel)
};
