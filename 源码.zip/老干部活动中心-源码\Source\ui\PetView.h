#pragma once

#include <juce_gui_basics/juce_gui_basics.h>
#include <array>
#include <random>

// 桌宠：左下角的戴贝雷帽的猫。
//   待机：呼吸、轻轻摇晃、咖啡冒热气，时不时歪头 / 抬一下杯子；等久了会看表、托腮发呆。
//   弹琴时（有输入信号）跟着点头；鼓机在走时跟着拍子晃。
//   弹奏判定：Perfect / Good / 错音 / 漏弹 / 抢拍 / 拖拍 / 连击 各有一个动作和一句话。
// 动作之间是交叉淡化 + 弹簧缓动，不会一下子跳过去；判定来得很快时会合并，不会抽风一样乱换。
class PetView : public juce::Component, private juce::Timer
{
public:
    enum class Pose { normal, miss, good, perfect, wrong, early, late, combo };
    enum class Event { perfect, good, wrong, miss, early, late, combo, cheer };

    PetView();
    ~PetView() override;

    // 弹奏判定 / 练习反馈（combo = 当前连击数，0 = 不知道）
    void react (Event e, int combo = 0, const juce::String& detail = {});
    // 每帧喂：吉他输入电平（0..1）、鼓机是否在走、鼓机现在第几拍、BPM
    void setActivity (float inputPeak, bool drumsPlaying, int drumBeat, float bpm);

    void setEnabled (bool on);
    bool isPetEnabled() const                { return enabled; }
    std::function<void (bool)> onEnabledChanged;

    // 截图 / 测试用
    void setClockForSnapshot (double seconds) { frozenTime = seconds; }
    void timerTick()                         { timerCallback(); }
    void setFadeColour (juce::Colour c)      { fadeColour = c; }     // 身体下沿渐隐成的颜色（透明 = 不渐隐）
    Pose getPose() const                     { return current; }
    static const char* poseName (Pose p);

    void paint (juce::Graphics&) override;
    void mouseDown (const juce::MouseEvent&) override;
    void visibilityChanged() override;

private:
    void timerCallback() override;
    double now() const;
    void setPose (Pose p, double holdSeconds, const juce::String& bubble, int priority);
    void kick (float scale, float rotation, float jumpY);
    juce::Image& image (Pose p);

    std::array<juce::Image, 8> images;
    juce::Colour fadeColour { 0xff222222 };
    bool enabled = true;
    double frozenTime = -1.0;

    // 当前 / 上一个姿势（交叉淡化）
    Pose current = Pose::normal, previous = Pose::normal;
    double poseSince = 0.0, holdUntil = 0.0;
    int currentPriority = 0;

    // 弹簧：缩放、转角、上下
    struct Spring { float value = 0.0f, velocity = 0.0f, target = 0.0f; void step (float dt, float k, float damping); };
    Spring scale, rotation, lift;

    // 待机小动作
    double nextIdleAction = 4.0, lastActivity = 0.0;
    int idleStage = 0;                  // 0 喝咖啡，1 看表，2 托腮
    float headBob = 0.0f, bobEnv = 0.0f;
    int lastDrumBeat = -1;
    double lastBeatTime = -10.0;
    float beatInterval = 0.5f;

    // 气泡
    juce::String bubble;
    double bubbleUntil = 0.0;
    juce::Colour bubbleColour { 0xffffffff };

    // 粒子：咖啡热气、星星、音符
    struct Particle { float x, y, vx, vy, life, maxLife, size; int kind; float spin; };
    std::vector<Particle> particles;
    std::mt19937 rng { 7 };
    float rand01() { return std::uniform_real_distribution<float> (0.0f, 1.0f) (rng); }
    double lastFrame = 0.0, lastSteam = 0.0;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (PetView)
};
