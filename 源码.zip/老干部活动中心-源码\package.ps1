﻿# 老干部活动中心 打包脚本（由 package.bat 调用）
# 生成：
#   发布\老干部活动中心-v<版本>.zip       给别人用的：程序 + 音色库 + 你的音色预设和设置 + 使用说明 + 分离模型说明 + 许可证 + 源码.zip
#   别人解压后第一次打开，看到的音色、效果器、鼓机和练习设置都和你打包时一样（声卡要他自己选）
#   同一个版本号已经打过包：不覆盖，新包名后面加 -2、-3……
#   发布\老干部活动中心-分离模型-htdemucs6s.zip  AI 扒谱进阶用的乐器分离模型（单独下载；已经有了就不重复打）
#   谱库不再打包。
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.IO.Compression.FileSystem

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$cmake = Get-Content (Join-Path $root 'CMakeLists.txt') -Raw -Encoding UTF8
$ver = if ($cmake -match 'project\(LianqinHost VERSION ([0-9.]+)') { $Matches[1] } else { '0.0.0' }

$outDir  = Join-Path $root '发布'
# 不覆盖以前打的包：同一个版本号已经打过，就在后面加 -2、-3……
$name = "老干部活动中心-v$ver"
$n = 2
while ((Test-Path (Join-Path $outDir "$name.zip")) -or (Test-Path (Join-Path $outDir $name))) {
    $name = "老干部活动中心-v$ver-$n"; $n++
}
$stage   = Join-Path $outDir $name
$tmp     = Join-Path $outDir '_tmp'
$zipFile = Join-Path $outDir "$name.zip"

if (Test-Path $tmp) { Remove-Item $tmp -Recurse -Force }
New-Item -ItemType Directory -Force $stage | Out-Null
New-Item -ItemType Directory -Force $tmp | Out-Null
Write-Host "打包：$name"

Write-Host "[1/4] 复制程序和音色库..."
Copy-Item (Join-Path $root 'LianqinHost.exe') $stage
# AI 扒谱（Basic Pitch）用的 ONNX Runtime
$ort = Join-Path $root 'third_party\onnxruntime\win-x64\onnxruntime.dll'
if (Test-Path $ort) { Copy-Item $ort $stage } else { Write-Host "  注意：没有 onnxruntime.dll，别人那边扒谱只能用单音算法" -ForegroundColor Yellow }
$lib = Join-Path $root '音色库'
if (Test-Path $lib) { Copy-Item $lib (Join-Path $stage '音色库') -Recurse }
else { New-Item -ItemType Directory (Join-Path $stage '音色库') | Out-Null }
$gvDir = Join-Path $root '音色库\Gervana'
$gvCount = if (Test-Path $gvDir) { (Get-ChildItem $gvDir -Include *.png,*.jpg -Recurse).Count } else { 0 }
if ($gvCount -lt 7) { Write-Host "  注意：音色库\Gervana 里只有 $gvCount 张效果器图片（应该有 7 张），别人那边会显示“图片待替换”" -ForegroundColor Yellow }

Write-Host "      你的音色预设和设置（让别人打开后和你看到的一样）..."
# 音色预设：我的文档\LianqinHost\音色预设
$myPresets = Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'LianqinHost\音色预设'
if (Test-Path $myPresets) {
    Copy-Item $myPresets (Join-Path $stage '音色预设') -Recurse
    Write-Host ("        音色预设 {0} 个" -f (Get-ChildItem (Join-Path $stage '音色预设') -Filter *.xml).Count)
}
# 设置：%APPDATA%\LianqinHost\LianqinHost.settings，去掉只对你这台电脑有效的项（声卡、插件路径、最近打开、延迟校准）
$mySettings = Join-Path $env:APPDATA 'LianqinHost\LianqinHost.settings'
if (Test-Path $mySettings) {
    [xml]$x = Get-Content $mySettings -Raw -Encoding UTF8
    $drop = @('audioDevice', 'guitarChannel', 'knownPlugins', 'tabRecent', 'tabLastFile', 'tabLastFolder',
              'tabWatchFolder', 'judgeCalibrationMs', 'defaultPresetsVersion', 'bundledPresetsStamp')
    foreach ($v in @($x.PROPERTIES.VALUE)) { if ($drop -contains $v.GetAttribute('name')) { [void]$x.PROPERTIES.RemoveChild($v) } }
    $setDir = New-Item -ItemType Directory (Join-Path $stage '默认设置')
    $x.Save((Join-Path $setDir.FullName 'LianqinHost.settings'))
    $cur = @($x.PROPERTIES.VALUE | Where-Object { $_.GetAttribute('name') -eq 'currentPreset' })
    if ($cur.Count -gt 0) { Write-Host ("        打开时的音色：{0}" -f $cur[0].GetAttribute('val')) }
}

$tabs = New-Item -ItemType Directory (Join-Path $stage '吉他谱')
Set-Content (Join-Path $tabs.FullName '把吉他谱放这里.txt') -Encoding UTF8 -Value @(
    '把 Guitar Pro 谱子（.gp3 .gp4 .gp5 .gpx .gp）放在这个文件夹，',
    '在“练习谱面”里点“打开谱子…”时会默认打开这里，“谱库…”里也能按文件夹分类、搜索歌名打开。',
    '“扒谱…”生成的谱子在这里的“扒谱”文件夹，改谱另存的在原谱旁边（文件名带“（改）”）。')
Copy-Item (Join-Path $root '使用说明.txt') $stage
Set-Content (Join-Path $stage 'AI扒谱进阶·分离模型说明.txt') -Encoding UTF8 -Value @(
    'AI 扒谱进阶：乐器分离模型（可选，单独下载）',
    '',
    '这个压缩包里的程序已经能用 AI 扒谱（和弦扒成和弦、自动分出节奏 / 主音 / 贝斯）。',
    '再装上“分离模型”，扒谱前会先把歌分成 鼓 / 贝斯 / 吉他 / 钢琴 / 人声 / 其他，只拿吉他去扒、贝斯单独扒、按鼓找拍子，',
    '节奏和贝斯会准不少。模型约 130 MB，所以没放进主程序，单独一个压缩包：',
    '    老干部活动中心-分离模型-htdemucs6s.zip',
    '',
    '安装：',
    '  1. 把它解压到程序所在的文件夹（和 LianqinHost.exe 同一层）。',
    '  2. 解压后程序旁边会多一个 models 文件夹，里面是 htdemucs_6s_fp16weights.onnx。',
    '  3. 重新打开程序 → 练习谱面 → 扒谱… → “乐器分离”选“先分离乐器”。',
    '',
    '说明：',
    '  - 全部在本机计算，不联网，不收费。一首 3 分钟的歌大约 1–3 分钟（电脑越新越快）。',
    '  - 没装模型时“乐器分离”那一栏是灰的，扒谱照样能用，只是不分离。',
    '  - 扒谱目前还在实验阶段，准确率还在提高，扒出来的谱需要对着原曲用“✎ 改谱”修正一部分。',
    '  - 模型：Meta 开源的 HT-Demucs 6 声部（MIT 许可证），见“许可证”文件夹。')
Copy-Item (Join-Path $root 'licenses') (Join-Path $stage '许可证') -Recurse

Write-Host "[2/4] 打包源码（AGPLv3 要求随程序提供源码）..."
$src = Join-Path $tmp '老干部活动中心-源码'
New-Item -ItemType Directory $src | Out-Null
foreach ($item in @('Source', 'Resources', 'tests', 'licenses', 'CMakeLists.txt', 'build.bat', 'package.bat', 'package.ps1',
                    'README.md', 'LICENSE', '使用说明.txt', '.gitignore', 'build_mac.sh')) {
    $p = Join-Path $root $item
    if (Test-Path $p) { Copy-Item $p (Join-Path $src $item) -Recurse }
}
New-Item -ItemType Directory (Join-Path $src 'third_party') | Out-Null
foreach ($z in @('JUCE-9.0.4.zip', 'NAM-core.zip')) {
    $p = Join-Path $root "third_party\$z"
    if (Test-Path $p) { Copy-Item $p (Join-Path $src 'third_party') }
}
$ortInc = Join-Path $root 'third_party\onnxruntime\include'
if (Test-Path $ortInc) {
    New-Item -ItemType Directory -Force (Join-Path $src 'third_party\onnxruntime') | Out-Null
    Copy-Item $ortInc (Join-Path $src 'third_party\onnxruntime\include') -Recurse
}
[IO.Compression.ZipFile]::CreateFromDirectory($src, (Join-Path $stage '源码.zip'),
    [IO.Compression.CompressionLevel]::Optimal, $true, [Text.Encoding]::UTF8)

Write-Host "[3/4] 生成压缩包..."
[IO.Compression.ZipFile]::CreateFromDirectory($stage, $zipFile,
    [IO.Compression.CompressionLevel]::Optimal, $true, [Text.Encoding]::UTF8)

Write-Host "[4/4] 乐器分离模型（单独的压缩包，AI 扒谱进阶用）..."
$demucs = Join-Path $root 'third_party\demucs\htdemucs_6s_fp16weights.onnx'
$sepZip = Join-Path $outDir "老干部活动中心-分离模型-htdemucs6s.zip"
if (Test-Path $sepZip) {
    Write-Host "  已经有了（模型没变，不用重新打）：$sepZip"
} elseif (Test-Path $demucs) {
    $sepStage = Join-Path $tmp '分离模型'
    $sepModels = Join-Path $sepStage 'models'
    New-Item -ItemType Directory -Force $sepModels | Out-Null
    Copy-Item $demucs $sepModels
    Set-Content (Join-Path $sepModels '分离模型说明.txt') -Encoding UTF8 -Value @(
        'HT-Demucs 6 声部乐器分离模型（Meta 开源，MIT 许可证；ONNX 版来自 Hugging Face adowu/htdemucs-6s-onnx）。',
        '用法：把这个压缩包解压到程序所在的文件夹（和 LianqinHost.exe 同一层），程序旁边会多一个 models 文件夹。',
        '有了它，“扒谱…”会先把整首歌分成 鼓 / 贝斯 / 吉他 / 钢琴 / 人声 / 其他，再只拿吉他和贝斯去扒，节奏和分轨准很多。',
        '全部在本机计算，不联网；一首 3 分钟的歌大约要 1–3 分钟。')
    [IO.Compression.ZipFile]::CreateFromDirectory($sepStage, $sepZip,
        [IO.Compression.CompressionLevel]::Optimal, $false, [Text.Encoding]::UTF8)
    Write-Host ("  分离模型：{0} MB" -f [math]::Round((Get-Item $sepZip).Length / 1MB, 1))
} else {
    Write-Host "  没有 third_party\demucs\htdemucs_6s_fp16weights.onnx，跳过分离模型" -ForegroundColor Yellow
}

Write-Host "      清理临时文件..."
Remove-Item $tmp -Recurse -Force

$mb = [math]::Round((Get-Item $zipFile).Length / 1MB, 1)
Write-Host ""
Write-Host "生成：$zipFile （$mb MB）"
if (Test-Path $sepZip) { Write-Host ("分离模型：$sepZip （{0} MB，想要更准的 AI 扒谱就下载）" -f [math]::Round((Get-Item $sepZip).Length / 1MB, 1)) }
Write-Host "解压后的文件夹（可以直接试运行）：$stage"
