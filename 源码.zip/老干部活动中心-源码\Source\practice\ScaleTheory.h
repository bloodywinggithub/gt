#pragma once

#include <juce_core/juce_core.h>
#include <vector>
#include <algorithm>
#include <array>

// 指板音阶：音阶定义、音名 / 级数、把位计算。纯计算，不碰界面和音频。
namespace ScaleTheory
{
    // 乐器：吉他 6 弦 / 7 弦、贝斯 4 弦 / 5 弦。open[0] = 最粗的弦（音最低）
    struct Instrument
    {
        juce::String name;
        int strings = 6;
        std::array<int, 7> open { 40, 45, 50, 55, 59, 64, 0 };
        bool bass = false;
    };
    inline const std::vector<Instrument>& instruments()
    {
        static const std::vector<Instrument> v {
            { juce::String::fromUTF8 ("吉他 6 弦"), 6, { 40, 45, 50, 55, 59, 64, 0 }, false },
            { juce::String::fromUTF8 ("贝斯 4 弦"), 4, { 28, 33, 38, 43, 0, 0, 0 }, true },
            { juce::String::fromUTF8 ("贝斯 5 弦"), 5, { 23, 28, 33, 38, 43, 0, 0 }, true },
            { juce::String::fromUTF8 ("吉他 7 弦"), 7, { 35, 40, 45, 50, 55, 59, 64 }, false },
        };
        return v;
    }
    // 现在用的乐器（指板音阶页选的）；所有把位计算都按它来
    inline Instrument& currentInstrument() { static Instrument i = instruments()[0]; return i; }
    inline int numStrings() { return currentInstrument().strings; }
    // openMidi[s]：第 s 根弦（0 = 最粗）的空弦音高
    struct OpenMidi { int operator[] (int s) const { return currentInstrument().open[(size_t) juce::jlimit (0, 6, s)]; } };
    inline const OpenMidi openMidi {};
    constexpr int maxFret = 22;

    enum class Family { pentatonic, blues, sevenNote, modes };
    enum class MinorType { natural, harmonic, melodic };
    // 教会调式（以 C 大调为母调时的起点：1 2 3 4 5 6 7）
    enum class Mode { ionian, dorian, phrygian, lydian, mixolydian, aeolian, locrian };

    struct Selection
    {
        int root = 9;                 // 0 = C … 11 = B（默认 A）
        Family family = Family::pentatonic;
        bool minor = true;            // 五声 / 布鲁斯 / 七声：大调还是小调
        MinorType minorType = MinorType::natural;
        Mode mode = Mode::dorian;
    };

    struct Scale
    {
        juce::String name;            // 例如 “A 小调五声音阶”
        std::vector<int> intervals;   // 相对根音的半音数，升序，含 0
        std::vector<int> blueNotes;   // 布鲁斯音（单独标色）
        juce::String description;
    };

    inline const juce::StringArray& rootNames()
    {
        static const juce::StringArray n { "C", "C# / Db", "D", "Eb", "E", "F", "F# / Gb", "G", "Ab", "A", "Bb", "B" };
        return n;
    }

    inline juce::String modeName (Mode m)
    {
        static const char* n[] = { "伊奥尼亚 Ionian", "多利亚 Dorian", "弗里几亚 Phrygian", "利底亚 Lydian",
                                   "混合利底亚 Mixolydian", "爱奥利亚 Aeolian", "洛克里亚 Locrian" };
        return juce::String::fromUTF8 (n[(int) m]);
    }

    inline Scale build (const Selection& s)
    {
        auto u = [] (const char* t) { return juce::String::fromUTF8 (t); };
        const juce::String key = rootNames()[s.root].upToFirstOccurrenceOf (" ", false, false);
        Scale sc;
        switch (s.family)
        {
            case Family::pentatonic:
                sc.intervals = s.minor ? std::vector<int> { 0, 3, 5, 7, 10 } : std::vector<int> { 0, 2, 4, 7, 9 };
                sc.name = key + (s.minor ? u (" 小调五声音阶") : u (" 大调五声音阶"));
                sc.description = s.minor ? u ("摇滚、布鲁斯 Solo 最常用的一组音，五个把位连起来就是整个指板")
                                         : u ("明亮、乡村和流行味，和同名小调五声差一个把位");
                break;
            case Family::blues:
                if (s.minor) { sc.intervals = { 0, 3, 5, 6, 7, 10 }; sc.blueNotes = { 6 }; }
                else         { sc.intervals = { 0, 2, 3, 4, 7, 9 };  sc.blueNotes = { 3 }; }
                sc.name = key + (s.minor ? u (" 小调布鲁斯音阶") : u (" 大调布鲁斯音阶"));
                sc.description = s.minor ? u ("小调五声加一个降五级（蓝调音），经过时一带而过，别停在上面")
                                         : u ("大调五声加一个降三级，从 b3 滑到 3 就是标准的布鲁斯味");
                break;
            case Family::sevenNote:
                if (! s.minor)
                {
                    sc.intervals = { 0, 2, 4, 5, 7, 9, 11 };
                    sc.name = key + u (" 自然大调");
                    sc.description = u ("do re mi fa sol la si，所有调式的母体");
                }
                else if (s.minorType == MinorType::natural)
                {
                    sc.intervals = { 0, 2, 3, 5, 7, 8, 10 };
                    sc.name = key + u (" 自然小调");
                    sc.description = u ("和关系大调同一组音，从第 6 音开始");
                }
                else if (s.minorType == MinorType::harmonic)
                {
                    sc.intervals = { 0, 2, 3, 5, 7, 8, 11 };
                    sc.name = key + u (" 和声小调");
                    sc.description = u ("自然小调把 7 级升高半音：b6 到 7 是增二度，古典、金属、新古典常用");
                }
                else
                {
                    sc.intervals = { 0, 2, 3, 5, 7, 9, 11 };
                    sc.name = key + u (" 旋律小调");
                    sc.description = u ("6、7 级都升高（爵士里上下行都这样用；古典下行还原成自然小调）");
                }
                break;
            case Family::modes:
            {
                static const int major[] = { 0, 2, 4, 5, 7, 9, 11 };
                const int m = (int) s.mode;
                for (int i = 0; i < 7; ++i)
                    sc.intervals.push_back ((major[(m + i) % 7] - major[m] + 12) % 12);
                std::sort (sc.intervals.begin(), sc.intervals.end());
                sc.name = key + " " + modeName (s.mode);
                static const char* d[] = {
                    "就是自然大调",
                    "小调色彩里有一个明亮的大六度，放克、融合、Santana 常用",
                    "小调加 b2，西班牙、弗拉门戈、金属味",
                    "大调里升四级，飘、梦幻，电影配乐常用",
                    "大调里降七级，属七和弦上用，摇滚、布鲁斯、放克",
                    "就是自然小调",
                    "b2 加 b5，最暗、最不稳定，半减七和弦上用",
                };
                sc.description = u (d[m]);
                break;
            }
        }
        return sc;
    }

    // 关系调提示
    inline juce::String relativeHint (const Selection& s)
    {
        auto u = [] (const char* t) { return juce::String::fromUTF8 (t); };
        auto nameOf = [] (int pc) { return rootNames()[(pc % 12 + 12) % 12].upToFirstOccurrenceOf (" ", false, false); };
        switch (s.family)
        {
            case Family::pentatonic:
            case Family::blues:
                return s.minor ? u ("和 ") + nameOf (s.root + 3) + u (" 大调五声是同一组音")
                               : u ("和 ") + nameOf (s.root + 9) + u (" 小调五声是同一组音");
            case Family::sevenNote:
                if (! s.minor) return u ("关系小调：") + nameOf (s.root + 9) + u (" 自然小调");
                if (s.minorType == MinorType::natural) return u ("关系大调：") + nameOf (s.root + 3) + u (" 大调");
                return u ("和 ") + nameOf (s.root) + u (" 自然小调比，升高了 ") + (s.minorType == MinorType::harmonic ? u ("7 级") : u ("6、7 级"));
            case Family::modes:
            default:
            {
                static const int major[] = { 0, 2, 4, 5, 7, 9, 11 };
                const int parent = s.root - major[(int) s.mode];
                return u ("和 ") + nameOf (parent) + u (" 大调同一组音，从第 ") + juce::String ((int) s.mode + 1) + u (" 个音开始");
            }
        }
    }

    // 用升号还是降号写音名
    inline bool preferFlats (const Selection& s)
    {
        // 母大调的调号：F Bb Eb Ab Db Gb 用降号
        int majorRoot = s.root;
        if (s.family == Family::modes)
        {
            static const int major[] = { 0, 2, 4, 5, 7, 9, 11 };
            majorRoot = s.root - major[(int) s.mode];
        }
        else if (s.minor)
            majorRoot = s.root + 3;
        majorRoot = (majorRoot % 12 + 12) % 12;
        return majorRoot == 5 || majorRoot == 10 || majorRoot == 3 || majorRoot == 8 || majorRoot == 1 || majorRoot == 6;
    }

    inline juce::String noteName (int midi, bool flats, bool withOctave = false)
    {
        static const char* sharp[] = { "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B" };
        static const char* flat[]  = { "C", "Db", "D", "Eb", "E", "F", "Gb", "G", "Ab", "A", "Bb", "B" };
        const int pc = (midi % 12 + 12) % 12;
        juce::String n (flats ? flat[pc] : sharp[pc]);
        if (withOctave) n << (midi / 12 - 1);
        return n;
    }

    // 级数：b3、#4 之类
    inline juce::String degreeName (int interval, const Scale& sc)
    {
        static const char* d[] = { "1", "b2", "2", "b3", "3", "4", "b5", "5", "b6", "6", "b7", "7" };
        const auto has = [&sc] (int i) { return std::find (sc.intervals.begin(), sc.intervals.end(), i) != sc.intervals.end(); };
        interval = (interval % 12 + 12) % 12;
        if (interval == 6 && ! has (5)) return "#4";   // 没有纯四度（利底亚）：这个音是 #4，不是 b5
        return d[interval];
    }

    inline bool inScale (int midi, int root, const Scale& sc)
    {
        const int iv = ((midi - root) % 12 + 12) % 12;
        return std::find (sc.intervals.begin(), sc.intervals.end(), iv) != sc.intervals.end();
    }

    // 蓝调音（b3 / b5）按习惯写降号：A 布鲁斯里是 Eb，不是 D#
    inline bool isBlueNote (int midi, int root, const Scale& sc)
    {
        const int iv = ((midi - root) % 12 + 12) % 12;
        return std::find (sc.blueNotes.begin(), sc.blueNotes.end(), iv) != sc.blueNotes.end();
    }
    inline juce::String spell (int midi, int root, const Scale& sc, bool flats, bool withOctave = false)
    {
        return noteName (midi, flats || isBlueNote (midi, root, sc), withOctave);
    }

    struct Spot { int string = 0; int fret = 0; int midi = 0; };   // string 0 = 6 弦（低 E）

    inline int numPositions (const Scale& sc) { return (int) (sc.intervals.size() - sc.blueNotes.size()); }

    // 第 k 个把位（0 起）：从音阶第 k 个音在最粗的弦上的位置开始。
    //   五声 / 布鲁斯：一个五品宽的“框”（起点前一品到后三品），每根弦两三个音；
    //   七声音阶：每根弦三个音（3NPS），沿着音阶一路往上排。
    inline std::vector<Spot> position (int root, const Scale& sc, int k);

    // 布鲁斯：用五声的 5 个框，框里够得着的蓝调音补进去（常见的 A 弦 6 品、G 弦 8 品那种）
    inline std::vector<Spot> bluesPosition (int root, const Scale& sc, int k)
    {
        Scale penta = sc;
        penta.blueNotes.clear();
        penta.intervals.erase (std::remove_if (penta.intervals.begin(), penta.intervals.end(), [&sc] (int i)
            { return std::find (sc.blueNotes.begin(), sc.blueNotes.end(), i) != sc.blueNotes.end(); }), penta.intervals.end());
        auto box = position (root, penta, k);
        if (box.empty()) return box;
        int lo = 99, hi = -1;
        for (auto& p : box) { lo = juce::jmin (lo, p.fret); hi = juce::jmax (hi, p.fret); }
        for (int s = 0; s < numStrings(); ++s)
            for (int f = lo; f <= hi; ++f)
            {
                const int iv = ((openMidi[s] + f - root) % 12 + 12) % 12;
                if (std::find (sc.blueNotes.begin(), sc.blueNotes.end(), iv) != sc.blueNotes.end())
                    box.push_back ({ s, f, openMidi[s] + f });
            }
        std::sort (box.begin(), box.end(), [] (const Spot& a, const Spot& b) { return a.midi != b.midi ? a.midi < b.midi : a.string < b.string; });
        return box;
    }

    inline std::vector<Spot> position (int root, const Scale& sc, int k)
    {
        if (! sc.blueNotes.empty())
            return bluesPosition (root, sc, k);
        std::vector<Spot> out;
        const int n = (int) sc.intervals.size();
        if (n == 0) return out;
        k = ((k % n) + n) % n;

        // 起始音在 6 弦上的品位（尽量在 0–11 品）
        const int startPc = (root + sc.intervals[(size_t) k]) % 12;
        int start = ((startPc - openMidi[0] % 12) % 12 + 12) % 12;
        if (start == 0 && k != 0) start = 12;                 // 只有第一把位用空弦

        if (n == 7)
        {
            int midi = openMidi[0] + start;
            int deg = k, string = 0, onString = 0;
            while (string < numStrings())
            {
                out.push_back ({ string, midi - openMidi[string], midi });
                deg = (deg + 1) % n;
                const int step = (sc.intervals[(size_t) deg] - sc.intervals[(size_t) ((deg + n - 1) % n)] + 12) % 12;
                midi += step;
                if (++onString == 3) { ++string; onString = 0; }
            }
        }
        else
        {
            const int lo = juce::jmax (0, start - 1), hi = lo + 4;     // 五品宽；空弦把位往上多算一品
            int lastMidi = -1;
            for (int s = 0; s < numStrings(); ++s)
                for (int f = lo; f <= hi; ++f)
                {
                    const int midi = openMidi[s] + f;
                    // 同一个音在下一根弦上也够得着时，只留低弦那一个（每弦 2–3 个音）
                    if (midi <= lastMidi || ! inScale (midi, root, sc)) continue;
                    if (s < numStrings() - 1 && f >= lo + (openMidi[s + 1] - openMidi[s]) && inScale (midi, root, sc)
                        && midi - openMidi[s + 1] >= lo)
                        continue;
                    out.push_back ({ s, f, midi });
                    lastMidi = midi;
                }
        }

        // 太高就整体降一个八度
        int maxF = 0;
        for (auto& p : out) maxF = juce::jmax (maxF, p.fret);
        if (maxF > maxFret)
            for (auto& p : out) { p.fret -= 12; p.midi -= 12; }
        return out;
    }

    // 把位的品格范围，菜单里显示用
    inline juce::Range<int> fretSpan (const std::vector<Spot>& spots)
    {
        if (spots.empty()) return {};
        int lo = 99, hi = 0;
        for (auto& p : spots) { lo = juce::jmin (lo, p.fret); hi = juce::jmax (hi, p.fret); }
        return { lo, hi };
    }
}
