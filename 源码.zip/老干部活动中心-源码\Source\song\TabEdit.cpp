#include "TabEdit.h"
#include "practice/ChordLibrary.h"
#include <algorithm>
#include <cmath>
#include <map>
#include <set>

namespace
{
    constexpr double ticksPerBeat = 48.0;
    int64_t toTick (double beat) { return (int64_t) std::llround (beat * ticksPerBeat); }
    double toBeat (int64_t tick) { return (double) tick / ticksPerBeat; }
}

// =============================================================================
RawScore songToRaw (const Song& song)
{
    RawScore raw;
    raw.title = song.title;
    raw.artist = song.artist;
    raw.format = "TabEdit";
    raw.initialTempo = song.tempos.empty() ? 120.0 : song.tempos.front().bpm;

    // 总小节：拍号、段落、速度变化
    for (const auto& bar : song.bars)
    {
        RawMasterBar mb;
        mb.numerator = bar.numerator;
        mb.denominator = bar.denominator;
        mb.section = bar.section;
        for (const auto& tp : song.tempos)
            if (tp.beat >= bar.start - 1.0e-6 && tp.beat < bar.start + bar.length - 1.0e-6)
                mb.tempos.push_back ({ juce::jlimit (0.0, 1.0, (tp.beat - bar.start) / juce::jmax (1.0e-6, bar.length)), tp.bpm });
        raw.masterBars.push_back (mb);
    }

    for (const auto& st : song.tracks)
    {
        RawTrack rt;
        rt.name = st.name;
        rt.percussion = st.percussion;
        rt.tuning = st.tuning;
        rt.capo = st.capo;
        rt.program = st.program;
        rt.chordDiagrams = st.chordDiagrams;

        // 击弦 / 勾弦：Song 里标在被弹出来的音上，GP 里标在起点音上
        const auto& ns = st.notes;
        std::vector<bool> hopoOrigin (ns.size(), false);
        for (size_t q = 0; q < ns.size(); ++q)
        {
            if (! ns[q].hammerPull) continue;
            for (int p = (int) q - 1; p >= 0; --p)
                if (ns[(size_t) p].string == ns[q].string && ns[(size_t) p].start < ns[q].start - 1.0e-6) { hopoOrigin[(size_t) p] = true; break; }
        }

        struct Q { int64_t a, b; size_t i; };
        std::vector<Q> qs;
        for (size_t i = 0; i < ns.size(); ++i)
        {
            const int64_t a = toTick (ns[i].start);
            const int64_t b = juce::jmax (a + 1, toTick (ns[i].start + ns[i].length));
            qs.push_back ({ a, b, i });
        }
        std::set<int64_t> cuts;
        for (auto& q : qs) { cuts.insert (q.a); cuts.insert (q.b); }
        for (auto& c : st.chords) cuts.insert (toTick (c.beat));
        for (auto& tp : song.tempos) cuts.insert (toTick (tp.beat));
        for (auto& bar : song.bars) { cuts.insert (toTick (bar.start)); cuts.insert (toTick (bar.start + bar.length)); }

        std::map<int64_t, int> chordAtTick;
        for (auto& c : st.chords) chordAtTick[toTick (c.beat)] = c.diagram;

        for (const auto& bar : song.bars)
        {
            RawBar rb;
            RawVoice voice;
            const int64_t b0 = toTick (bar.start), b1 = toTick (bar.start + bar.length);
            std::vector<int64_t> pts { b0 };
            for (auto c = cuts.upper_bound (b0); c != cuts.end() && *c < b1; ++c) pts.push_back (*c);
            pts.push_back (b1);
            for (size_t k = 0; k + 1 < pts.size(); ++k)
            {
                const int64_t s = pts[k], e = pts[k + 1];
                RawBeat beat;
                beat.duration = toBeat (e - s);
                if (auto c = chordAtTick.find (s); c != chordAtTick.end()) beat.chord = c->second;
                std::set<int> usedStrings;
                for (auto& q : qs)
                {
                    if (q.a > s || q.b <= s) continue;
                    const auto& n = ns[q.i];
                    if (st.percussion ? usedStrings.count (n.midi) > 0 : usedStrings.count (n.string) > 0) continue;
                    RawNote rn;
                    rn.string = n.string;
                    rn.fret = st.percussion ? n.midi : n.fret;
                    rn.tieDestination = q.a < s && ! st.percussion;
                    if (st.percussion && q.a < s) continue;       // 鼓：只写起音
                    rn.dead = n.dead;
                    rn.palmMute = n.palmMute;
                    rn.harmonic = n.harmonic;
                    rn.vibrato = n.vibrato;
                    rn.letRing = n.letRing;
                    rn.accent = n.accent;
                    rn.tapped = n.tapped;
                    const bool last = q.b <= e;          // 这个音在这一段结束
                    if (! rn.tieDestination)
                    {
                        rn.hammerPull = hopoOrigin[q.i];       // 标在第一段上（导入时连音线合并后再找下一个音）
                        rn.slideIn = n.slideIn;
                        if (n.bend > 0.0f)
                        {
                            // 推弦曲线按这一段的长短换算（音被切开时，曲线放在第一段上）
                            const double whole = juce::jmax (1.0e-6, n.length), part = juce::jmax (1.0e-6, toBeat (e - s));
                            auto rescale = [&] (float pos) { return (float) juce::jlimit (0.0, 1.0, pos * whole / part); };
                            rn.bend = n.bend;
                            rn.bendStart = n.bendStart;
                            rn.bendEnd = n.bendEnd;
                            rn.bendPeakPos = rescale (n.bendPeakPos);
                            rn.bendReleasePos = rescale (n.bendReleasePos);
                            rn.bendEndPos = rescale (n.bendEndPos);
                        }
                    }
                    if (last)
                    {
                        rn.slideOut = n.slideOut;
                        rn.slideLegato = n.slideLegato;
                        rn.slideOff = n.slideOff;
                    }
                    usedStrings.insert (st.percussion ? n.midi : n.string);
                    beat.notes.push_back (rn);
                }
                voice.beats.push_back (beat);
            }
            rb.voices.push_back (voice);
            rt.bars.push_back (rb);
        }
        raw.tracks.push_back (std::move (rt));
    }
    return raw;
}

// =============================================================================
void TabEditor::begin (std::shared_ptr<const Song> song, int t)
{
    active = song != nullptr && juce::isPositiveAndBelow (t, (int) song->tracks.size());
    if (! active) return;
    work = std::make_unique<Song> (*song);
    published = song;
    track = t;
    undoStack.clear();
    redoStack.clear();
    selection.clear();
    dirty = false;
    cursor = {};
    lastMessage = {};
    if (! tr().notes.empty()) cursor = { tr().notes.front().start, tr().notes.front().string };
}

int TabEditor::midiOf (int string, int fret) const
{
    const auto& t = tr();
    if (! juce::isPositiveAndBelow (string, (int) t.tuning.size())) return 60;
    return t.tuning[(size_t) string] + t.capo + fret;
}

double TabEditor::snap (double beat) const
{
    return std::round (beat / grid) * grid;
}

int TabEditor::noteAt (double beat, int string, double tol) const
{
    if (work == nullptr) return -1;
    const auto& ns = tr().notes;
    for (int i = 0; i < (int) ns.size(); ++i)
        if (ns[(size_t) i].string == string && std::abs (ns[(size_t) i].start - beat) <= tol)
            return i;
    return -1;
}

std::vector<int> TabEditor::selectedIndices() const
{
    std::vector<int> out;
    for (auto& p : selection)
    {
        const int i = noteAt (p.beat, p.string);
        if (i >= 0) out.push_back (i);
    }
    return out;
}

void TabEditor::select (double beat, int string, bool add)
{
    if (! add) selection.clear();
    cursor = { beat, string };
    const int i = noteAt (beat, string, 1.0e-3);
    if (i < 0) return;
    const auto& n = tr().notes[(size_t) i];
    for (auto it = selection.begin(); it != selection.end(); ++it)
        if (it->string == n.string && std::abs (it->beat - n.start) < 1.0e-6) { if (add) selection.erase (it); return; }
    selection.push_back ({ n.start, n.string });
    cursor = { n.start, n.string };
}

void TabEditor::selectRange (double a, double b, int sa, int sb, bool add)
{
    if (! add) selection.clear();
    if (a > b) std::swap (a, b);
    if (sa > sb) std::swap (sa, sb);
    for (auto& n : tr().notes)
        if (n.start >= a - 1.0e-6 && n.start <= b + 1.0e-6 && n.string >= sa && n.string <= sb)
            selection.push_back ({ n.start, n.string });
}

TabEditor::Snapshot TabEditor::snapshot() const
{
    return { tr().notes, tr().chordDiagrams, tr().chords, selection, cursor };
}

void TabEditor::restore (const Snapshot& s)
{
    tr().notes = s.notes;
    tr().chordDiagrams = s.diagrams;
    tr().chords = s.chords;
    selection = s.selection;
    cursor = s.cursor;
}

void TabEditor::pushUndo()
{
    undoStack.push_back (snapshot());
    if (undoStack.size() > 200) undoStack.erase (undoStack.begin());
    redoStack.clear();
}

void TabEditor::commit()
{
    auto& ns = tr().notes;
    for (auto& n : ns)
        if (! tr().percussion) n.midi = midiOf (n.string, n.fret);
    std::stable_sort (ns.begin(), ns.end(), [] (const SongNote& a, const SongNote& b)
    {
        if (std::abs (a.start - b.start) > 1.0e-9) return a.start < b.start;
        return a.string < b.string;
    });
    std::stable_sort (tr().chords.begin(), tr().chords.end(), [] (const SongChord& a, const SongChord& b) { return a.beat < b.beat; });
    // 歌变长了（在最后一小节后面加音）：不加小节，截到结尾
    for (auto& n : ns)
        n.length = juce::jmax (1.0 / ticksPerBeat, juce::jmin (n.length, work->lengthBeats - n.start));
    published = std::make_shared<const Song> (*work);
    dirty = true;
}

void TabEditor::fixOverlaps (int keep)
{
    auto& ns = tr().notes;
    const auto& k = ns[(size_t) keep];
    for (int i = 0; i < (int) ns.size(); ++i)
    {
        if (i == keep) continue;
        auto& n = ns[(size_t) i];
        if (n.string != k.string) continue;
        if (n.start < k.start - 1.0e-6 && n.start + n.length > k.start + 1.0e-6)
            n.length = k.start - n.start;                     // 前面的音到这里为止
    }
    // 被新音完全盖住的（同一根弦、同一时刻开始的）去掉
    for (int i = (int) ns.size() - 1; i >= 0; --i)
        if (i != keep && ns[(size_t) i].string == k.string && std::abs (ns[(size_t) i].start - k.start) < 1.0e-6)
        {
            ns.erase (ns.begin() + i);
            if (i < keep) --keep;
        }
}

bool TabEditor::typeDigit (int digit, double nowMs)
{
    if (! isActive() || digit < 0 || digit > 9) return false;
    // 两位数：0.9 秒内的第二个数字，前一个是 1 或 2
    int fret = digit;
    const bool twoDigit = nowMs - lastDigitMs < 900.0 && (lastDigitValue == 1 || lastDigitValue == 2);
    if (twoDigit) fret = lastDigitValue * 10 + digit;
    lastDigitMs = twoDigit ? -1.0e9 : nowMs;
    lastDigitValue = twoDigit ? -1 : digit;
    fret = juce::jlimit (0, 24, fret);

    auto idx = selectedIndices();
    if (twoDigit)
    {
        // 第二位数字：改的是刚才那一个（还没提交第二个撤销点，直接改）
        for (int i : idx) tr().notes[(size_t) i].fret = fret;
        commit();
        lastMessage = juce::String::fromUTF8 ("品位 ") + juce::String (fret);
        return true;
    }
    pushUndo();
    if (idx.empty())
    {
        // 光标处加一个新音
        const double beat = snap (cursor.beat);
        if (beat < 0.0 || beat >= work->lengthBeats) { undoStack.pop_back(); return false; }
        SongNote n;
        n.start = beat;
        n.length = juce::jmin (newLength, work->lengthBeats - beat);
        n.string = juce::jlimit (0, juce::jmax (0, tr().stringCount() - 1), cursor.string);
        n.fret = fret;
        n.midi = midiOf (n.string, fret);
        tr().notes.push_back (n);
        fixOverlaps ((int) tr().notes.size() - 1);
        selection = { { n.start, n.string } };
        lastMessage = juce::String::fromUTF8 ("加了一个音：") + juce::String (n.string + 1) + juce::String::fromUTF8 (" 弦 ") + juce::String (fret) + juce::String::fromUTF8 (" 品");
    }
    else
    {
        for (int i : idx) { tr().notes[(size_t) i].fret = fret; tr().notes[(size_t) i].dead = false; }
        lastMessage = juce::String::fromUTF8 ("品位 ") + juce::String (fret);
    }
    commit();
    return true;
}

bool TabEditor::deleteSelected()
{
    if (! isActive()) return false;
    auto idx = selectedIndices();
    if (idx.empty()) return false;
    pushUndo();
    std::sort (idx.rbegin(), idx.rend());
    for (int i : idx) tr().notes.erase (tr().notes.begin() + i);
    lastMessage = juce::String::fromUTF8 ("删了 ") + juce::String ((int) idx.size()) + juce::String::fromUTF8 (" 个音");
    selection.clear();
    commit();
    return true;
}

bool TabEditor::moveCursorString (int delta)
{
    if (! isActive()) return false;
    cursor.string = juce::jlimit (0, juce::jmax (0, tr().stringCount() - 1), cursor.string + delta);
    selection.clear();
    const int i = noteAt (cursor.beat, cursor.string, 1.0e-3);
    if (i >= 0) selection.push_back ({ tr().notes[(size_t) i].start, cursor.string });
    return false;
}

bool TabEditor::moveSelectedToString (int delta)
{
    if (! isActive()) return false;
    auto idx = selectedIndices();
    if (idx.empty()) return false;
    const int strings = tr().stringCount();
    // 先检查都能换
    for (int i : idx)
    {
        const auto& n = tr().notes[(size_t) i];
        const int s2 = n.string + delta;
        if (! juce::isPositiveAndBelow (s2, strings)) { lastMessage = juce::String::fromUTF8 ("没有更多的弦了"); return false; }
        const int f2 = n.midi - tr().capo - tr().tuning[(size_t) s2];
        if (f2 < 0 || f2 > 24) { lastMessage = juce::String::fromUTF8 ("那根弦上弹不到这个音"); return false; }
        const int other = noteAt (n.start, s2);
        if (other >= 0 && std::find (idx.begin(), idx.end(), other) == idx.end()) { lastMessage = juce::String::fromUTF8 ("那根弦这里已经有音了"); return false; }
    }
    pushUndo();
    selection.clear();
    for (int i : idx)
    {
        auto& n = tr().notes[(size_t) i];
        const int s2 = n.string + delta;
        n.fret = n.midi - tr().capo - tr().tuning[(size_t) s2];
        n.string = s2;
        selection.push_back ({ n.start, s2 });
    }
    cursor.string = juce::jlimit (0, strings - 1, cursor.string + delta);
    lastMessage = juce::String::fromUTF8 ("换弦（音高不变）");
    commit();
    return true;
}

bool TabEditor::transposeSelected (int semis)
{
    if (! isActive()) return false;
    auto idx = selectedIndices();
    if (idx.empty()) return false;
    for (int i : idx) { const int f = tr().notes[(size_t) i].fret + semis; if (f < 0 || f > 24) return false; }
    pushUndo();
    for (int i : idx) tr().notes[(size_t) i].fret += semis;
    lastMessage = semis > 0 ? juce::String::fromUTF8 ("升半音") : juce::String::fromUTF8 ("降半音");
    commit();
    return true;
}

bool TabEditor::setLength (double beats)
{
    if (! isActive()) return false;
    auto idx = selectedIndices();
    beats = juce::jlimit (1.0 / 12.0, 8.0, beats);
    newLength = beats;
    if (idx.empty()) return false;
    pushUndo();
    for (int i : idx)
    {
        auto& n = tr().notes[(size_t) i];
        n.length = beats;
        // 不盖住同一根弦上的下一个音
        for (auto& m : tr().notes)
            if (&m != &n && m.string == n.string && m.start > n.start + 1.0e-6 && m.start < n.start + n.length - 1.0e-6)
                n.length = m.start - n.start;
    }
    auto fmt = [] (double b)
    {
        if (std::abs (b - 4.0) < 1.0e-6) return juce::String::fromUTF8 ("全音符");
        if (std::abs (b - 2.0) < 1.0e-6) return juce::String::fromUTF8 ("二分音符");
        if (std::abs (b - 1.0) < 1.0e-6) return juce::String::fromUTF8 ("四分音符");
        if (std::abs (b - 0.5) < 1.0e-6) return juce::String::fromUTF8 ("八分音符");
        if (std::abs (b - 0.25) < 1.0e-6) return juce::String::fromUTF8 ("十六分音符");
        return juce::String (b, 3) + juce::String::fromUTF8 (" 拍");
    };
    lastMessage = juce::String::fromUTF8 ("时值：") + fmt (beats);
    commit();
    return true;
}

bool TabEditor::scaleLength (double factor)
{
    auto idx = selectedIndices();
    if (idx.empty()) { newLength = juce::jlimit (1.0 / 12.0, 8.0, newLength * factor); return false; }
    return setLength (tr().notes[(size_t) idx.front()].length * factor);
}

bool TabEditor::shiftTime (int steps)
{
    if (! isActive()) return false;
    auto idx = selectedIndices();
    if (idx.empty()) { cursor.beat = juce::jlimit (0.0, work->lengthBeats - grid, snap (cursor.beat) + steps * grid); return false; }
    const double d = steps * grid;
    for (int i : idx)
    {
        const auto& n = tr().notes[(size_t) i];
        if (n.start + d < -1.0e-6 || n.start + d >= work->lengthBeats) return false;
    }
    pushUndo();
    selection.clear();
    for (int i : idx)
    {
        auto& n = tr().notes[(size_t) i];
        n.start = std::max (0.0, n.start + d);
        selection.push_back ({ n.start, n.string });
    }
    // 挪到别的音上面：被盖住的那个去掉
    for (auto& p : std::vector<Pos> (selection))
    {
        const int keep = noteAt (p.beat, p.string);
        if (keep < 0) continue;
        auto& ns = tr().notes;
        for (int i = (int) ns.size() - 1; i >= 0; --i)
            if (i != keep && ns[(size_t) i].string == p.string && std::abs (ns[(size_t) i].start - p.beat) < 1.0e-6
                && std::find (idx.begin(), idx.end(), i) == idx.end())
                ns.erase (ns.begin() + i);
    }
    cursor.beat = selection.front().beat;
    lastMessage = steps > 0 ? juce::String::fromUTF8 ("往后挪") : juce::String::fromUTF8 ("往前挪");
    commit();
    return true;
}

bool TabEditor::toggleHammer()
{
    auto idx = selectedIndices();
    if (! isActive() || idx.empty()) return false;
    const bool on = ! tr().notes[(size_t) idx.front()].hammerPull;
    // 击弦 / 勾弦要从同一根弦上的前一个音连过来：前一个音太早结束就把它拉长到这里
    std::vector<int> prevOf;
    if (on)
        for (int i : idx)
        {
            const auto& n = tr().notes[(size_t) i];
            int prev = -1;
            for (int j = 0; j < (int) tr().notes.size(); ++j)
            {
                const auto& m = tr().notes[(size_t) j];
                if (m.string == n.string && m.start < n.start - 1.0e-6 && (prev < 0 || m.start > tr().notes[(size_t) prev].start)) prev = j;
            }
            if (prev < 0) { lastMessage = juce::String::fromUTF8 ("这根弦前面没有音，标不了击弦 / 勾弦"); return false; }
            prevOf.push_back (prev);
        }
    pushUndo();
    for (size_t k = 0; k < idx.size(); ++k)
    {
        auto& n = tr().notes[(size_t) idx[k]];
        n.hammerPull = on;
        if (on)
        {
            auto& p = tr().notes[(size_t) prevOf[k]];
            if (p.start + p.length < n.start - 1.0e-6 && n.start - p.start <= 4.0) p.length = n.start - p.start;
        }
    }
    lastMessage = on ? juce::String::fromUTF8 ("击弦 / 勾弦（这个音不用拨）") : juce::String::fromUTF8 ("取消击勾弦");
    commit();
    return true;
}

bool TabEditor::toggleDead()
{
    auto idx = selectedIndices();
    if (! isActive() || idx.empty()) return false;
    pushUndo();
    const bool on = ! tr().notes[(size_t) idx.front()].dead;
    for (int i : idx) tr().notes[(size_t) i].dead = on;
    lastMessage = on ? juce::String::fromUTF8 ("闷音 ×") : juce::String::fromUTF8 ("取消闷音");
    commit();
    return true;
}

bool TabEditor::toggleBend()
{
    auto idx = selectedIndices();
    if (! isActive() || idx.empty()) return false;
    pushUndo();
    const float cur = tr().notes[(size_t) idx.front()].bend;
    const float next = cur <= 0.0f ? 2.0f : (cur > 1.5f ? 1.0f : 0.0f);
    for (int i : idx)
    {
        auto& n = tr().notes[(size_t) i];
        n.bend = next;
        n.bendStart = 0.0f;
        n.bendEnd = next;
        n.bendPeakPos = 0.35f;
        n.bendReleasePos = n.bendEndPos = 1.0f;
    }
    lastMessage = next <= 0.0f ? juce::String::fromUTF8 ("取消推弦") : (next > 1.5f ? juce::String::fromUTF8 ("推弦：全音") : juce::String::fromUTF8 ("推弦：半音"));
    commit();
    return true;
}

int TabEditor::chordAt (double beat) const
{
    if (work == nullptr) return -1;
    const auto& cs = tr().chords;
    for (int i = 0; i < (int) cs.size(); ++i)
        if (std::abs (cs[(size_t) i].beat - beat) < 1.0e-4) return i;
    return -1;
}

bool TabEditor::setChordAt (double beat, int root, int quality)
{
    if (! isActive()) return false;
    pushUndo();
    const auto q = (Chords::Quality) juce::jlimit (0, Chords::numQualities - 1, quality);
    ChordDiagram d;
    d.name = Chords::name ((root % 12 + 12) % 12, q, false);
    const auto vs = Chords::voicings ((root % 12 + 12) % 12, q);
    if (! vs.empty() && tr().stringCount() == 6)
        for (int s = 5; s >= 0; --s) d.frets.push_back (vs.front().frets[(size_t) s]);   // 和弦图：[0] = 最细的弦
    int di = -1;
    for (int i = 0; i < (int) tr().chordDiagrams.size(); ++i)
        if (tr().chordDiagrams[(size_t) i].name == d.name) { di = i; break; }
    if (di < 0) { tr().chordDiagrams.push_back (d); di = (int) tr().chordDiagrams.size() - 1; }
    const int existing = chordAt (beat);
    if (existing >= 0) tr().chords[(size_t) existing].diagram = di;
    else tr().chords.push_back ({ beat, di });
    lastMessage = juce::String::fromUTF8 ("和弦：") + d.name;
    commit();
    return true;
}

bool TabEditor::clearChordAt (double beat)
{
    const int i = chordAt (beat);
    if (! isActive() || i < 0) return false;
    pushUndo();
    tr().chords.erase (tr().chords.begin() + i);
    lastMessage = juce::String::fromUTF8 ("去掉和弦");
    commit();
    return true;
}

bool TabEditor::stepCursor (int dir)
{
    if (! isActive()) return false;
    const auto& ns = tr().notes;
    if (ns.empty()) return false;
    // 下一个 / 上一个“开始时间”（同一时刻几个音算一个），优先停在光标所在的弦上
    std::vector<double> starts;
    for (auto& n : ns) if (starts.empty() || std::abs (starts.back() - n.start) > 1.0e-6) starts.push_back (n.start);
    double target = cursor.beat;
    if (dir > 0) { for (double s : starts) if (s > cursor.beat + 1.0e-6) { target = s; break; } }
    else { for (auto it = starts.rbegin(); it != starts.rend(); ++it) if (*it < cursor.beat - 1.0e-6) { target = *it; break; } }
    cursor.beat = target;
    selection.clear();
    int best = -1;
    for (int i = 0; i < (int) ns.size(); ++i)
        if (std::abs (ns[(size_t) i].start - target) < 1.0e-6 && (best < 0 || std::abs (ns[(size_t) i].string - cursor.string) < std::abs (ns[(size_t) best].string - cursor.string)))
            best = i;
    if (best >= 0) { cursor.string = ns[(size_t) best].string; selection.push_back ({ target, cursor.string }); }
    return false;
}

bool TabEditor::undo()
{
    if (! isActive() || undoStack.empty()) return false;
    redoStack.push_back (snapshot());
    restore (undoStack.back());
    undoStack.pop_back();
    lastMessage = juce::String::fromUTF8 ("撤销");
    commit();
    return true;
}

bool TabEditor::redo()
{
    if (! isActive() || redoStack.empty()) return false;
    undoStack.push_back (snapshot());
    restore (redoStack.back());
    redoStack.pop_back();
    lastMessage = juce::String::fromUTF8 ("重做");
    commit();
    return true;
}
