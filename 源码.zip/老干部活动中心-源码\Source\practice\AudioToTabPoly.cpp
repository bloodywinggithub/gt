// 音频扒谱 · 复音 + 分轨：Basic Pitch 识别出所有音（和弦也是和弦），再按声道 / 音域 / 和弦程度
// 分成 节奏吉他、主音吉他、贝斯 几条音轨，每条排指法、量化成谱。
#include "AudioToTab.h"
#include "BasicPitch.h"
#include "Demucs.h"
#include <juce_dsp/juce_dsp.h>
#include "ChordLibrary.h"
#include "Text.h"
#include <cmath>
#include <map>
#include <numeric>
#include <set>

namespace
{
    using Note = BasicPitch::Note;

    bool report (const AudioToTab::Options& o, float p, const juce::String& stage)
    {
        return ! o.progress || o.progress (p, stage);
    }

    double rms (const std::vector<float>& v)
    {
        double s = 0.0;
        for (auto x : v) s += (double) x * x;
        return v.empty() ? 0.0 : std::sqrt (s / (double) v.size());
    }

    // 两组音有多少能对上（同音高、起音 60 ms 内）
    float matchRate (const std::vector<Note>& a, const std::vector<Note>& b)
    {
        if (a.empty()) return 1.0f;
        int hit = 0;
        size_t j0 = 0;
        for (auto& n : a)
        {
            while (j0 < b.size() && b[j0].start < n.start - 0.06) ++j0;
            for (size_t j = j0; j < b.size() && b[j].start <= n.start + 0.06; ++j)
                if (b[j].midi == n.midi) { ++hit; break; }
        }
        return (float) hit / (float) a.size();
    }

    std::vector<Note> onlyIn (const std::vector<Note>& a, const std::vector<Note>& b)
    {
        std::vector<Note> out;
        size_t j0 = 0;
        for (auto& n : a)
        {
            while (j0 < b.size() && b[j0].start < n.start - 0.06) ++j0;
            bool found = false;
            for (size_t j = j0; j < b.size() && b[j].start <= n.start + 0.06 && ! found; ++j)
                found = b[j].midi == n.midi && b[j].amplitude > n.amplitude * 0.6f;
            if (! found) out.push_back (n);
        }
        return out;
    }

    // 同时开始（45 ms 内）的音分成一组
    std::vector<std::vector<int>> clusters (const std::vector<Note>& ns)
    {
        std::vector<std::vector<int>> out;
        for (int i = 0; i < (int) ns.size(); ++i)
        {
            if (out.empty() || ns[(size_t) i].start - ns[(size_t) out.back().front()].start > 0.045)
                out.push_back ({});
            out.back().push_back (i);
        }
        return out;
    }

    struct TrackPlan
    {
        juce::String name;
        std::vector<Note> notes;
        bool bass = false, chordal = false;
    };
}

// =============================================================================
std::vector<AudioToTab::Fingered> AudioToTab::fingerGroup (const std::vector<int>& midis, const std::vector<int>& tuning,
                                                           const std::vector<bool>& blocked, float& hand, int maxFret)
{
    const int strings = (int) tuning.size();
    std::vector<Fingered> best (midis.size(), { -1, 0 });
    float bestCost = 1.0e9f;
    // 从高音到低音排，每个音挑一根弦
    std::vector<int> order (midis.size());
    std::iota (order.begin(), order.end(), 0);
    std::sort (order.begin(), order.end(), [&] (int a, int b) { return midis[(size_t) a] > midis[(size_t) b]; });
    std::vector<Fingered> cur (midis.size(), { -1, 0 });
    std::vector<bool> used ((size_t) strings, false);
    for (int s = 0; s < strings; ++s) used[(size_t) s] = s < (int) blocked.size() && blocked[(size_t) s];

    std::function<void (size_t)> rec = [&] (size_t idx)
    {
        if (idx == order.size())
        {
            int lo = 99, hi = 0, cnt = 0; float sum = 0.0f;
            float cost = 0.0f;
            for (auto& f : cur)
            {
                if (f.fret > 0) { lo = juce::jmin (lo, f.fret); hi = juce::jmax (hi, f.fret); sum += (float) f.fret; ++cnt; }
                if (f.fret > 12) cost += 0.25f * (float) (f.fret - 12);
            }
            if (cnt > 0 && hi - lo > 4) return;             // 手按不过来
            const float centre = cnt > 0 ? sum / (float) cnt : hand;
            cost += 0.3f * std::abs (centre - hand) + (cnt > 0 ? 0.4f * (float) (hi - lo) : 0.0f);
            if (cnt > 0 && lo < 5) cost -= 0.15f;
            if (cost < bestCost) { bestCost = cost; best = cur; }
            return;
        }
        const int i = order[idx];
        for (int s = 0; s < strings; ++s)
        {
            if (used[(size_t) s]) continue;
            const int f = midis[(size_t) i] - tuning[(size_t) s];
            if (f < 0 || f > maxFret) continue;
            used[(size_t) s] = true;
            cur[(size_t) i] = { s, f };
            rec (idx + 1);
            cur[(size_t) i] = { -1, 0 };
            used[(size_t) s] = false;
        }
    };
    rec (0);
    if (bestCost < 1.0e8f)
    {
        int cnt = 0; float sum = 0.0f;
        for (auto& f : best) if (f.fret > 0) { sum += (float) f.fret; ++cnt; }
        if (cnt > 0) hand = hand * 0.3f + 0.7f * sum / (float) cnt;
    }
    return best;
}

// =============================================================================
AudioToTab::Result AudioToTab::transcribePoly (const juce::AudioBuffer<float>& audio, double sr, const Options& opt)
{
    Result res;
    juce::String why;
    if (! BasicPitch::isAvailable (why))
    {
        res.error = "#fallback " + why;
        return res;
    }
    if (audio.getNumSamples() < (int) (sr * 1.0))
    {
        res.error = T ("音频太短了（至少要 1 秒）");
        return res;
    }
    res.usedAi = true;
    const double offset = juce::jmax (0.0, opt.startSeconds);
    if (! report (opt, 0.02f, T ("准备音频…"))) { res.cancelled = true; return res; }

    // ---- 乐器分离（有 Demucs 模型时）：吉他、贝斯、鼓分开 ------------------------------------
    juce::AudioBuffer<float> stems[Demucs::numStems];
    juce::AudioBuffer<float> guitarMix;
    bool separated = false;
    const juce::AudioBuffer<float>* srcBuf = &audio;
    double srcSr = sr, segA = opt.startSeconds, segB = opt.endSeconds;
    double drumsShare = 0.0, bassShare = 0.0;
    if (opt.separate && opt.source == Source::mix)
    {
        juce::String why2;
        if (Demucs::isAvailable (why2))
        {
            const int a = juce::jlimit (0, audio.getNumSamples(), (int) (juce::jmax (0.0, opt.startSeconds) * sr));
            const int b = opt.endSeconds > opt.startSeconds ? juce::jlimit (a, audio.getNumSamples(), (int) (opt.endSeconds * sr)) : audio.getNumSamples();
            juce::AudioBuffer<float> seg (2, juce::jmax (1, b - a));
            for (int c = 0; c < 2; ++c) seg.copyFrom (c, 0, audio, juce::jmin (c, audio.getNumChannels() - 1), a, b - a);
            juce::String err;
            if (Demucs::separate (seg, sr, stems, err, [&] (float p) { return report (opt, 0.02f + 0.4f * p, T ("分离乐器（吉他 / 贝斯 / 鼓）…")); }))
            {
                separated = true;
                auto bufRms = [] (const juce::AudioBuffer<float>& x)
                {
                    double acc = 0.0;
                    for (int c = 0; c < x.getNumChannels(); ++c) { const double r = x.getRMSLevel (c, 0, x.getNumSamples()); acc += r * r; }
                    return std::sqrt (acc / juce::jmax (1, x.getNumChannels()));
                };
                double total = 0.0;
                for (auto& st : stems) total += bufRms (st);
                total = juce::jmax (1.0e-9, total);
                const double g = bufRms (stems[Demucs::guitar]), o = bufRms (stems[Demucs::other]);
                drumsShare = bufRms (stems[Demucs::drums]) / total;
                bassShare = bufRms (stems[Demucs::bass]) / total;
                guitarMix.makeCopyOf (stems[Demucs::guitar]);
                // 吉他声部很弱、“其他”很强：多半是失真吉他 / 特殊音色被分到“其他”里了，一起算
                if (g < 0.5 * o)
                    for (int c = 0; c < 2; ++c) guitarMix.addFrom (c, 0, stems[Demucs::other], c, 0, guitarMix.getNumSamples());
                if (std::getenv ("A2T_DUMPRAW")) std::printf ("STEMS g %.4f o %.4f p %.4f d %.3f b %.3f\n", g, o, bufRms (stems[Demucs::piano]), drumsShare, bassShare);
                srcBuf = &guitarMix;
                srcSr = Demucs::sampleRate;
                segA = segB = 0.0;
            }
            else if (err == "cancelled") { res.cancelled = true; return res; }
        }
    }
    res.separated = separated;
    const float aiBase = separated ? 0.44f : 0.05f, aiSpan = separated ? 0.3f : 0.7f;
    const auto& audioIn = *srcBuf;
    const bool stereo = audioIn.getNumChannels() > 1;
    auto mid = mixdown (audioIn, srcSr, Source::mix, BasicPitch::sampleRate, segA, segB);
    std::vector<float> left, right;
    if (stereo)
    {
        left = mixdown (audioIn, srcSr, Source::left, BasicPitch::sampleRate, segA, segB);
        right = mixdown (audioIn, srcSr, Source::right, BasicPitch::sampleRate, segA, segB);
    }
    // 用户指定了某个声道：就只扒那一路
    std::vector<float>* main = &mid;
    std::vector<float> side;
    if (opt.source == Source::left && stereo) main = &left;
    if (opt.source == Source::right && stereo) main = &right;
    if (opt.source == Source::side && stereo)
    {
        side = mixdown (audioIn, srcSr, Source::side, BasicPitch::sampleRate, segA, segB);
        main = &side;
    }
    const double peakLevel = rms (*main);
    if (peakLevel < 1.0e-4) { res.error = T ("这一段几乎没有声音"); return res; }
    // 音量太小的录音先放大一点（模型对很小的声音不敏感）
    const float norm = (float) juce::jlimit (1.0, 8.0, 0.1 / juce::jmax (1.0e-6, peakLevel));
    for (auto* v : { &mid, &left, &right, &side }) for (auto& x : *v) x *= norm;

    if (stereo && side.empty())
    {
        side = mixdown (audioIn, srcSr, Source::side, BasicPitch::sampleRate, segA, segB);
        for (auto& x : side) x *= norm;
    }
    const double sideRatio = stereo ? rms (side) / juce::jmax (1.0e-9, rms (mid)) : 0.0;
    const bool checkPanning = stereo && opt.source == Source::mix && opt.mode == Options::Mode::autoTracks && sideRatio > 0.22;
    const int passes = checkPanning ? 3 : 1;    // 识别进度条：主声道（+ 左、右）

    auto infer = [&] (const std::vector<float>& x, int pass, BasicPitch::Output& out)
    {
        juce::String err;
        const bool ok = BasicPitch::run (x, out, err, [&] (float p)
        {
            return report (opt, aiBase + aiSpan * ((float) pass + p) / (float) passes, T ("AI 识别音符…"));
        });
        if (! ok) { if (err == "cancelled") res.cancelled = true; else res.error = T ("AI 识别出错：") + err; }
        return ok;
    };

    BasicPitch::Output outMain;
    if (! infer (*main, 0, outMain)) return res;
    BasicPitch::NoteParams np;
    np.lowestMidi = 26;
    np.highestMidi = 96;
    auto notesMain = BasicPitch::notes (outMain, np);
    for (auto& n : notesMain) { n.start += offset; n.end += offset; }

    std::vector<Note> notesL, notesR;
    if (checkPanning)
    {
        BasicPitch::Output oL, oR;
        if (! infer (left, 1, oL)) return res;
        if (! infer (right, 2, oR)) return res;
        notesL = BasicPitch::notes (oL, np);
        notesR = BasicPitch::notes (oR, np);
        for (auto* v : { &notesL, &notesR }) for (auto& n : *v) { n.start += offset; n.end += offset; }
    }
    // 贝斯：单独把 220 Hz 以下滤出来再识别一遍（混在吉他里时模型容易漏掉低音），音高折回贝斯的音域
    std::vector<Note> lowNotes;
    double lowRatio = 0.0;
    if (separated && opt.mode == Options::Mode::autoTracks && bassShare > 0.04)
    {
        // 分离出来的贝斯：直接识别，同一时刻只留一个音
        auto low = mixdown (stems[Demucs::bass], Demucs::sampleRate, Source::mix, BasicPitch::sampleRate, 0.0, 0.0);
        const float g = (float) juce::jlimit (1.0, 30.0, 0.1 / juce::jmax (1.0e-6, rms (low)));
        for (auto& x : low) x *= g;
        BasicPitch::Output oLow;
        juce::String err;
        if (BasicPitch::run (low, oLow, err, [&] (float pr) { return report (opt, 0.74f + 0.04f * pr, T ("识别贝斯…")); }))
        {
            BasicPitch::NoteParams lp = np;
            lp.lowestMidi = 23;
            lp.highestMidi = 67;
            lp.onsetThreshold = 0.45f;
            auto raw = BasicPitch::notes (oLow, lp);
            std::sort (raw.begin(), raw.end(), [] (const Note& a, const Note& b) { return a.start < b.start; });
            for (auto n : raw)
            {
                n.start += offset; n.end += offset;
                while (n.midi >= 48) n.midi -= 12;          // 贝斯线基本都在 C3 以下：高了就是听成了高八度
                n.bend = 0.0f;
                if (! lowNotes.empty() && n.start - lowNotes.back().start < 0.05)
                {
                    // 同时出来两个：留低的那个（高八度多半是泛音），一样低就留响的
                    auto& m = lowNotes.back();
                    if (n.midi < m.midi - 6 || (std::abs (n.midi - m.midi) <= 6 && n.amplitude > m.amplitude)) m = n;
                    continue;
                }
                if (! lowNotes.empty() && lowNotes.back().end > n.start) lowNotes.back().end = n.start;
                lowNotes.push_back (n);
            }
            // 八度检查：模型常把贝斯听成高八度（二次谐波最响）。看低八度的基音（和它的三次谐波）有没有能量
            auto power = [&] (double t0, double t1, double hz)
            {
                const int a = juce::jmax (0, (int) ((t0 - offset) * BasicPitch::sampleRate));
                const int b = juce::jmin ((int) low.size(), (int) ((t1 - offset) * BasicPitch::sampleRate));
                if (b - a < 256) return 0.0;
                const double w = juce::MathConstants<double>::twoPi * hz / BasicPitch::sampleRate;
                double re = 0.0, im = 0.0;
                for (int i = a; i < b; ++i)
                {
                    const double win = 0.5 - 0.5 * std::cos (juce::MathConstants<double>::twoPi * (i - a) / (b - a));
                    re += low[(size_t) i] * win * std::cos (w * i);
                    im -= low[(size_t) i] * win * std::sin (w * i);
                }
                return (re * re + im * im) / ((double) (b - a) * (b - a));
            };
            auto hzOf = [] (int m) { return 440.0 * std::pow (2.0, (m - 69) / 12.0); };
            for (auto& n : lowNotes)
            {
                if (n.midi - 12 < 28) continue;
                const double t0 = n.start + 0.03, t1 = juce::jmin (n.end, n.start + 0.4);
                if (t1 - t0 < 0.08) continue;
                const double here = power (t0, t1, hzOf (n.midi));
                const double below = power (t0, t1, hzOf (n.midi - 12)) + power (t0, t1, hzOf (n.midi - 12) * 3.0);
                if (below > 0.12 * here) n.midi -= 12;
            }
        }
        else if (err == "cancelled") { res.cancelled = true; return res; }
    }
    else if (opt.mode == Options::Mode::autoTracks && ! separated)
    {
        std::vector<float> low (*main);
        juce::IIRFilter f1, f2, f3;
        const auto c = juce::IIRCoefficients::makeLowPass (BasicPitch::sampleRate, 220.0, 0.707);
        f1.setCoefficients (c); f2.setCoefficients (c); f3.setCoefficients (c);
        f1.processSamples (low.data(), (int) low.size());
        f2.processSamples (low.data(), (int) low.size());
        lowRatio = rms (low) / juce::jmax (1.0e-9, rms (*main));
        if (lowRatio > 0.2)
        {
            const float g = (float) juce::jlimit (1.0, 20.0, 0.1 / juce::jmax (1.0e-6, rms (low)));
            for (auto& x : low) x *= g;
            BasicPitch::Output oLow;
            juce::String err;
            if (BasicPitch::run (low, oLow, err, [&] (float pr) { return report (opt, 0.72f + 0.05f * pr, T ("找贝斯…")); }))
            {
                BasicPitch::NoteParams lp = np;
                lp.highestMidi = 55;
                lowNotes = BasicPitch::notes (oLow, lp);
                // 低通以后吉他和弦最低的几根弦（E3、A3 一带）也还在：混音里同一时刻、同一个音高有的，是吉他，不是贝斯
                std::vector<int> origMidi;
                std::vector<Note> kept;
                for (auto n : lowNotes)
                {
                    n.start += offset; n.end += offset;
                    if (n.midi >= 40)
                    {
                        bool guitar = false;
                        for (auto& gn : notesMain)
                            if (gn.midi == n.midi && std::abs (gn.start - n.start) < 0.06) { guitar = true; break; }
                        bool lowerToo = false, bassBusy = false;     // 同一时刻低八度也有：这个是泛音；贝斯正响着别的低音：这个是吉他
                        for (auto& l : lowNotes)
                        {
                            if (l.midi <= n.midi - 12 && std::abs (l.start + offset - n.start) < 0.06) lowerToo = true;
                            if (l.midi < 40 && l.start < n.start - offset + 0.03 && l.end > n.start - offset + 0.05) bassBusy = true;
                        }
                        if ((guitar && bassBusy) || lowerToo) continue;
                    }
                    origMidi.push_back (n.midi);
                    while (n.midi >= 40) n.midi -= 12;     // 模型常把贝斯听高一个八度：折回 E1–D#2 一带
                    while (n.midi < 28) n.midi += 12;
                    n.bend = 0.0f;
                    kept.push_back (n);
                }
                // 同一时刻只留一个（贝斯基本是单音）：本来就在低音区的优先，再看响度
                std::vector<Note> mono;
                int lastOrig = 0;
                for (size_t i = 0; i < kept.size(); ++i)
                {
                    const auto& n = kept[i];
                    if (! mono.empty() && n.start - mono.back().start < 0.05)
                    {
                        const bool nLow = origMidi[i] < 40, mLow = lastOrig < 40;
                        if ((nLow && ! mLow) || (nLow == mLow && n.amplitude > mono.back().amplitude)) { mono.back() = n; lastOrig = origMidi[i]; }
                        continue;
                    }
                    mono.push_back (n);
                    lastOrig = origMidi[i];
                }
                lowNotes = mono;
            }
            else if (err == "cancelled") { res.cancelled = true; return res; }
        }
    }

    if (notesMain.empty())
    {
        res.error = T ("没识别出音符。换个声道或者选一段吉他比较清楚的地方再试");
        return res;
    }

    // ---- 速度和拍点 ---------------------------------------------------------------------
    // 起音曲线：模型的起音概率（+ 分离出来的鼓的频谱变化，鼓最能说明拍子在哪）
    if (! report (opt, 0.78f, T ("找拍子…"))) { res.cancelled = true; return res; }
    const double fps = BasicPitch::sampleRate / BasicPitch::hop;
    // 模型的帧每 2 秒窗会偏一点点（frameToSeconds），这里换成均匀的真实时间轴，不然拍子会越走越偏
    std::vector<float> env ((size_t) outMain.frames, 0.0f);
    {
        std::vector<float> raw ((size_t) outMain.frames, 0.0f);
        for (int t = 0; t < outMain.frames; ++t)
            for (int k = 0; k < BasicPitch::keys; ++k) raw[(size_t) t] += outMain.onsetAt (t, k);
        int f = 0;
        for (int i = 0; i < outMain.frames; ++i)
        {
            const double want = i / fps;
            while (f + 1 < outMain.frames && BasicPitch::frameToSeconds (f + 1) <= want) ++f;
            env[(size_t) i] = raw[(size_t) f];
        }
    }
    auto normalise = [] (std::vector<float>& v)
    {
        float mx = 0.0f; for (auto x : v) mx = juce::jmax (mx, x);
        if (mx > 0.0f) for (auto& x : v) x /= mx;
    };
    normalise (env);
    if (separated && drumsShare > 0.06)
    {
        auto dr = mixdown (stems[Demucs::drums], Demucs::sampleRate, Source::mix, BasicPitch::sampleRate, 0.0, 0.0);
        const int N = 1024, H = BasicPitch::hop;
        juce::dsp::FFT fft (10);
        std::vector<float> win ((size_t) N), buf ((size_t) N * 2), prev ((size_t) N / 2 + 1, 0.0f);
        for (int i = 0; i < N; ++i) win[(size_t) i] = 0.5f - 0.5f * std::cos (juce::MathConstants<float>::twoPi * (float) i / (float) N);
        std::vector<float> flux ((size_t) outMain.frames, 0.0f);
        for (int t = 0; t < outMain.frames; ++t)
        {
            std::fill (buf.begin(), buf.end(), 0.0f);
            const int c = t * H - N / 2;
            for (int i = 0; i < N; ++i) { const int j = c + i; buf[(size_t) i] = j >= 0 && j < (int) dr.size() ? dr[(size_t) j] * win[(size_t) i] : 0.0f; }
            fft.performFrequencyOnlyForwardTransform (buf.data());
            float f = 0.0f;
            for (int k = 1; k <= N / 2; ++k)
            {
                const float m = std::log1p (100.0f * buf[(size_t) k]);
                f += juce::jmax (0.0f, m - prev[(size_t) k]);
                prev[(size_t) k] = m;
            }
            flux[(size_t) t] = f;
        }
        normalise (flux);
        for (size_t t = 0; t < env.size(); ++t) env[t] = 0.4f * env[t] + flux[t];
    }
    double firstBeatGuess = 0.0;
    double bpm = opt.bpm > 0.0 ? opt.bpm : estimateTempo (env, fps, firstBeatGuess);
    std::vector<double> beatT;                    // 每一拍的时间（秒，相对整首开头）
    if (opt.bpm <= 0.0)
        for (double b : trackBeats (env, fps, bpm)) beatT.push_back (b + offset);
    if (beatT.size() < 8)
    {
        // 拍点找不出来 / 手动指定了速度：等间隔
        const double lag = fps * 60.0 / bpm;
        double bestPhase = 0.0, bestSum = -1.0;
        for (double ph = 0.0; ph < lag; ph += 0.5)
        {
            double sum = 0.0;
            for (double t = ph; t < (double) env.size() - 1; t += lag) sum += env[(size_t) t];
            if (sum > bestSum) { bestSum = sum; bestPhase = ph; }
        }
        beatT.clear();
        for (double t = bestPhase; t < (double) env.size(); t += lag) beatT.push_back (offset + t / fps);
    }
    // 实际的平均速度（比自相关找的 0.5 BPM 一格更准）
    {
        std::vector<double> iv;
        for (size_t i = 1; i < beatT.size(); ++i) iv.push_back (beatT[i] - beatT[i - 1]);
        std::sort (iv.begin(), iv.end());
        if (! iv.empty()) bpm = 60.0 / iv[iv.size() / 2];
    }
    const double firstNote = notesMain.front().start;
    const double lastNoteEnd = [&] { double e = 0.0; for (auto& n : notesMain) e = juce::jmax (e, n.end); for (auto& n : lowNotes) e = juce::jmax (e, n.end); return e; }();
    // 两头接长：开头补到第一个音之前，结尾补到最后一个音之后
    {
        const double d0 = beatT.size() >= 5 ? (beatT[4] - beatT[0]) / 4.0 : 60.0 / bpm;
        while (beatT.front() > firstNote - d0 * 0.25) beatT.insert (beatT.begin(), beatT.front() - d0);
        const size_t n = beatT.size();
        const double d1 = n >= 5 ? (beatT[n - 1] - beatT[n - 5]) / 4.0 : 60.0 / bpm;
        while (beatT.back() < lastNoteEnd + d1 * 8.0) beatT.push_back (beatT.back() + d1);
    }
    // 小节第一拍：起音（和贝斯的起音）最多的那一拍
    {
        std::array<double, 4> acc {};
        for (size_t i = 0; i < beatT.size(); ++i)
        {
            const int f = (int) std::round ((beatT[i] - offset) * fps);
            double e = 0.0;
            for (int k = -2; k <= 2; ++k) if (f + k >= 0 && f + k < (int) env.size()) e = juce::jmax (e, (double) env[(size_t) (f + k)]);
            for (auto& n : lowNotes) if (std::abs (n.start - beatT[i]) < 0.06) e += 0.5 * n.amplitude;
            acc[i % 4] += e;
        }
        const size_t ph = (size_t) (std::max_element (acc.begin(), acc.end()) - acc.begin());
        beatT.erase (beatT.begin(), beatT.begin() + (long) ph);
        // 第一个音前面至少有一点点空：不够就往前补一小节
        const double d0 = (beatT[4] - beatT[0]) / 4.0;
        while (beatT.front() > firstNote - d0 * 0.25)
            for (int k = 0; k < 4; ++k) beatT.insert (beatT.begin(), beatT.front() - d0);
    }
    // 秒 ↔ 拍
    auto beatOf = [&] (double t)
    {
        if (t <= beatT.front()) return (t - beatT.front()) / (beatT[1] - beatT[0]);
        if (t >= beatT.back()) { const size_t n = beatT.size(); return (double) (n - 1) + (t - beatT.back()) / (beatT[n - 1] - beatT[n - 2]); }
        const size_t i = (size_t) (std::upper_bound (beatT.begin(), beatT.end(), t) - beatT.begin()) - 1;
        return (double) i + (t - beatT[i]) / (beatT[i + 1] - beatT[i]);
    };
    auto timeOf = [&] (double b)
    {
        const int n = (int) beatT.size();
        if (b <= 0.0) return beatT[0] + b * (beatT[1] - beatT[0]);
        if (b >= n - 1) return beatT[(size_t) n - 1] + (b - (n - 1)) * (beatT[(size_t) n - 1] - beatT[(size_t) n - 2]);
        const int i = (int) b;
        return beatT[(size_t) i] + (b - i) * (beatT[(size_t) i + 1] - beatT[(size_t) i]);
    };
    const double firstBeat = beatT.front();
    res.bpm = bpm;
    res.firstBeatSeconds = firstBeat;

    // ---- 分轨 -------------------------------------------------------------------------
    if (! report (opt, 0.82f, T ("分轨（节奏 / 主音 / 贝斯）…"))) { res.cancelled = true; return res; }
    std::vector<TrackPlan> plans;
    int lowCount = 0;
    for (auto& n : notesMain) lowCount += n.midi < 40 ? 1 : 0;
    const bool bassPresent = opt.mode == Options::Mode::autoTracks
                             && (separated ? lowNotes.size() >= 8
                                           : (lowNotes.size() >= 16 || lowCount >= 8 || lowCount > (int) notesMain.size() / 20));
    std::vector<Note> bassNotes, guitarNotes;
    {
        auto cl = clusters (notesMain);
        for (auto& c : cl)
        {
            int lowest = c.front();
            for (int i : c) if (notesMain[(size_t) i].midi < notesMain[(size_t) lowest].midi) lowest = i;
            for (int i : c)
            {
                const auto& n = notesMain[(size_t) i];
                bool isBass = false;
                if (separated)
                {
                    // 吉他声部里不会有贝斯：太低的（降 D 调弦以下）当杂音丢掉
                    if (n.midi >= 38) guitarNotes.push_back (n);
                    continue;
                }
                if (bassPresent && n.midi < 40) isBass = true;
                // 低音区最低的那个音，比上面的音低一个八度左右，又长：多半是贝斯
                if (bassPresent && ! isBass && i == lowest && n.midi <= 45 && c.size() >= 2 && n.end - n.start > 0.15)
                {
                    int next = 999;
                    for (int j : c) if (j != i) next = juce::jmin (next, notesMain[(size_t) j].midi);
                    isBass = next - n.midi >= 10;
                }
                if (n.midi < 40 && ! bassPresent) continue;     // 吉他弹不到的低音：丢掉
                (isBass ? bassNotes : guitarNotes).push_back (n);
            }
        }
    }

    auto chordRatio = [] (const std::vector<Note>& ns)
    {
        if (ns.empty()) return 0.0f;
        int inChords = 0;
        for (auto& c : clusters (ns)) if (c.size() >= 2) inChords += (int) c.size();
        return (float) inChords / (float) ns.size();
    };
    juce::String layout;
    bool panned = false;
    if (checkPanning)
    {
        auto gl = onlyIn (notesL, notesR), gr = onlyIn (notesR, notesL);
        auto keepGuitar = [] (std::vector<Note> v) { v.erase (std::remove_if (v.begin(), v.end(), [] (const Note& n) { return n.midi < 40; }), v.end()); return v; };
        gl = keepGuitar (gl); gr = keepGuitar (gr);
        const float mLR = matchRate (notesL, notesR), mRL = matchRate (notesR, notesL);
        if (juce::jmin (mLR, mRL) < 0.55f && gl.size() >= 15 && gr.size() >= 15)
        {
            panned = true;
            const float cl = chordRatio (gl), cr = chordRatio (gr);
            TrackPlan a, b;
            a.notes = gl; b.notes = gr;
            if (std::abs (cl - cr) > 0.12f)
            {
                const bool leftRhythm = cl > cr;
                a.name = leftRhythm ? T ("节奏吉他（左）") : T ("主音吉他（左）");
                b.name = leftRhythm ? T ("主音吉他（右）") : T ("节奏吉他（右）");
                a.chordal = leftRhythm; b.chordal = ! leftRhythm;
                layout = leftRhythm ? T ("两把吉他：左声道节奏、右声道主音") : T ("两把吉他：左声道主音、右声道节奏");
            }
            else
            {
                a.name = T ("吉他 1（左）"); b.name = T ("吉他 2（右）");
                a.chordal = cl > 0.3f; b.chordal = cr > 0.3f;
                layout = T ("两把吉他，分在左右声道");
            }
            plans.push_back (a);
            plans.push_back (b);
        }
    }
    if (! panned)
    {
        const float cr = chordRatio (guitarNotes);
        if (opt.mode == Options::Mode::autoTracks && cr > 0.2f && cr < 0.85f)
        {
            // 和弦里的音 → 节奏；单独的、在中高音区的音 → 主音
            TrackPlan rhythm, lead;
            rhythm.name = T ("节奏吉他"); rhythm.chordal = true;
            lead.name = T ("主音吉他");
            std::vector<int> chordTops;
            auto cl = clusters (guitarNotes);
            // 和弦的“顶”：只看三个音以上的扫弦；顶上那个音隔得很开（多半是旋律）就取第二高的
            for (auto& c : cl)
                if (c.size() >= 3)
                {
                    std::vector<int> m;
                    for (int i : c) m.push_back (guitarNotes[(size_t) i].midi);
                    std::sort (m.rbegin(), m.rend());
                    chordTops.push_back (m[0] - m[1] >= 5 ? m[1] : m[0]);
                }
            std::sort (chordTops.begin(), chordTops.end());
            const int split = chordTops.empty() ? 57 : juce::jmax (55, chordTops[chordTops.size() / 2] - 3);
            for (auto& c : cl)
            {
                // 每组里最高的那个音：明显高出下面的和弦（或者单独一个音）、又在高音区 → 主音
                std::vector<int> sorted (c);
                std::sort (sorted.begin(), sorted.end(), [&] (int a, int b) { return guitarNotes[(size_t) a].midi > guitarNotes[(size_t) b].midi; });
                // 高音区差一个八度的一对：上面那个多半是模型听出来的泛音，丢掉
                if (sorted.size() >= 2 && guitarNotes[(size_t) sorted[0]].midi - guitarNotes[(size_t) sorted[1]].midi == 12
                    && guitarNotes[(size_t) sorted[1]].midi >= split
                    && guitarNotes[(size_t) sorted[0]].amplitude <= guitarNotes[(size_t) sorted[1]].amplitude * 1.2f)
                    sorted.erase (sorted.begin());
                const auto& top = guitarNotes[(size_t) sorted.front()];
                // 扫弦（三个音以上）里最高的音多半还是和弦的一部分（比如 Am 的 C、E）：要隔得更开才算主音
                const int gap = sorted.size() >= 2 ? top.midi - guitarNotes[(size_t) sorted[1]].midi : 0;
                const bool topIsLead = (sorted.size() == 1 && top.midi >= split)
                                    || (sorted.size() == 2 && top.midi >= split + 2 && gap >= 3)
                                    || (sorted.size() >= 3 && top.midi >= split + 6 && gap >= 5);
                for (size_t k = 0; k < sorted.size(); ++k)
                    ((k == 0 && topIsLead) ? lead.notes : rhythm.notes).push_back (guitarNotes[(size_t) sorted[k]]);
            }
            std::sort (lead.notes.begin(), lead.notes.end(), [] (const Note& a, const Note& b) { return a.start < b.start; });
            std::sort (rhythm.notes.begin(), rhythm.notes.end(), [] (const Note& a, const Note& b) { return a.start < b.start; });
            if (lead.notes.size() >= 12 && rhythm.notes.size() >= 12)
            {
                plans.push_back (rhythm);
                plans.push_back (lead);
                layout = T ("节奏 + 主音（同一个声道里分开的）");
            }
        }
        if (plans.empty())
        {
            TrackPlan g;
            g.name = T ("吉他");
            g.notes = guitarNotes;
            g.chordal = cr > 0.3f;
            plans.push_back (g);
            layout = cr > 0.3f ? T ("一把吉他（和弦 + 旋律）") : T ("一把吉他（单音旋律）");
        }
    }
    // 滤出来的低音那一遍比混音里找到的全：有就用它
    if (bassPresent && (separated || lowNotes.size() >= bassNotes.size())) bassNotes = lowNotes;
    if (bassPresent && bassNotes.size() >= 8)
    {
        TrackPlan b;
        b.name = T ("贝斯");
        b.bass = true;
        b.notes = bassNotes;
        plans.push_back (b);
        layout << T (" + 贝斯");
    }

    if (std::getenv ("A2T_DUMPRAW"))
    {
        for (auto& p : plans) { std::printf ("PLAN %s\n", p.name.toRawUTF8()); for (auto& n : p.notes) std::printf ("RAW %.3f %d %.2f\n", n.start, n.midi, n.amplitude); }
        for (size_t i = 0; i < beatT.size() && i < 64; ++i) std::printf ("BEAT %.3f\n", beatT[i]);
    }
    // ---- 和弦名：按拍统计节奏声部的音 -------------------------------------------------------
    const double lastEnd = [&] { double e = 0.0; for (auto& p : plans) for (auto& n : p.notes) e = juce::jmax (e, n.end); return e; }();
    const int totalBeats = juce::jmax (4, (int) std::ceil (beatOf (lastEnd) / 4.0) * 4);
    std::vector<int> beatChord ((size_t) totalBeats, -1);   // root * 4 + 类型（0 大三 1 小三 2 属七 3 强力）
    if (opt.chords)
    {
        const TrackPlan* src = nullptr;
        for (auto& p : plans) if (p.chordal && ! p.bass) { src = &p; break; }
        if (src == nullptr) for (auto& p : plans) if (! p.bass) { src = &p; break; }
        if (src != nullptr)
        {
            struct Tpl { int code; std::array<float, 12> w; };
            std::vector<Tpl> tpls;
            auto make = [&] (int type, std::initializer_list<std::pair<int, float>> iv)
            {
                for (int r = 0; r < 12; ++r)
                {
                    Tpl t; t.code = r * 4 + type; t.w.fill (0.0f);
                    for (auto& p : iv) t.w[(size_t) ((r + p.first) % 12)] = p.second;
                    float n2 = 0.0f; for (auto v : t.w) n2 += v * v;
                    for (auto& v : t.w) v /= std::sqrt (n2);
                    tpls.push_back (t);
                }
            };
            make (0, { { 0, 1.0f }, { 4, 0.85f }, { 7, 0.8f } });
            make (1, { { 0, 1.0f }, { 3, 0.85f }, { 7, 0.8f } });
            make (2, { { 0, 1.0f }, { 4, 0.75f }, { 7, 0.75f }, { 10, 0.7f } });
            make (3, { { 0, 1.0f }, { 7, 0.9f } });
            const int NT = (int) tpls.size();
            std::vector<std::vector<float>> score ((size_t) totalBeats, std::vector<float> ((size_t) NT + 1, 0.0f));
            for (int b = 0; b < totalBeats; ++b)
            {
                std::array<float, 12> c {};
                const double t0 = timeOf (b), t1 = timeOf (b + 1);
                int lowest = 999; float total = 0.0f;
                // 节奏声部 + 贝斯为主；别的吉他声部（主音）也算一点（和弦的三音常常在高音上）
                std::vector<const std::vector<Note>*> sets { &src->notes, &bassNotes };
                for (auto& p : plans) if (! p.bass && &p != src) sets.push_back (&p.notes);
                for (const std::vector<Note>* set : sets)
                    for (auto& n : *set)
                    {
                        const double ov = juce::jmin (t1, n.end) - juce::jmax (t0, n.start);
                        if (ov <= 0.0) continue;
                        const float w = (float) ov * n.amplitude * (set == &bassNotes ? 1.5f : (set == &src->notes ? 1.0f : 0.45f));
                        c[(size_t) (n.midi % 12)] += w;
                        total += w;
                        lowest = juce::jmin (lowest, n.midi);
                    }
                float n2 = 0.0f; for (auto v : c) n2 += v * v;
                const float nrm = std::sqrt (n2) + 1.0e-9f;
                for (int k = 0; k < NT; ++k)
                {
                    float dot = 0.0f;
                    for (int p = 0; p < 12; ++p) dot += tpls[(size_t) k].w[(size_t) p] * c[(size_t) p] / nrm;
                    if (lowest < 999 && tpls[(size_t) k].code / 4 == lowest % 12) dot += 0.12f;
                    if (tpls[(size_t) k].code % 4 == 3) dot -= 0.05f;      // 强力和弦只在真的只有根音 + 五音时才选
                    score[(size_t) b][(size_t) k] = dot;
                }
                score[(size_t) b][(size_t) NT] = total < 1.0e-4f ? 1.0f : 0.5f;
            }
            std::vector<std::vector<float>> acc ((size_t) totalBeats, std::vector<float> ((size_t) NT + 1));
            std::vector<std::vector<int>> arg ((size_t) totalBeats, std::vector<int> ((size_t) NT + 1));
            for (int k = 0; k <= NT; ++k) acc[0][(size_t) k] = score[0][(size_t) k];
            for (int b = 1; b < totalBeats; ++b)
            {
                int bestK = 0; float bestV = -1e9f;
                for (int k = 0; k <= NT; ++k) if (acc[(size_t) b - 1][(size_t) k] > bestV) { bestV = acc[(size_t) b - 1][(size_t) k]; bestK = k; }
                for (int k = 0; k <= NT; ++k)
                {
                    const float stay = acc[(size_t) b - 1][(size_t) k], change = bestV - 0.2f;
                    acc[(size_t) b][(size_t) k] = juce::jmax (stay, change) + score[(size_t) b][(size_t) k];
                    arg[(size_t) b][(size_t) k] = stay >= change ? k : bestK;
                }
            }
            int k = 0; float bv = -1e9f;
            for (int j = 0; j <= NT; ++j) if (acc.back()[(size_t) j] > bv) { bv = acc.back()[(size_t) j]; k = j; }
            for (int b = totalBeats - 1; b >= 0; --b)
            {
                beatChord[(size_t) b] = k == NT ? -1 : tpls[(size_t) k].code;
                k = arg[(size_t) b][(size_t) k];
            }
            for (int b = 0; b < totalBeats; ++b)
                if ((b == 0 || beatChord[(size_t) b] != beatChord[(size_t) b - 1]) && beatChord[(size_t) b] >= 0)
                {
                    const int code = beatChord[(size_t) b];
                    const Chords::Quality q = code % 4 == 0 ? Chords::Quality::major : code % 4 == 1 ? Chords::Quality::minor
                                            : code % 4 == 2 ? Chords::Quality::dom7 : Chords::Quality::power;
                    res.chords.push_back ({ timeOf (b), code / 4, (int) q });
                }
        }
    }

    // ---- 每条音轨：量化 + 排指法 + 写成拍 ------------------------------------------------------
    if (! report (opt, 0.9f, T ("排指法、量化…"))) { res.cancelled = true; return res; }
    const int baseGrid = opt.grid >= 4 ? 4 : 2;

    RawScore raw;
    raw.title = opt.title.isNotEmpty() ? opt.title : T ("扒谱");
    raw.artist = T ("老干部活动中心 · AI 扒谱");
    raw.format = "AudioToTab";
    // 速度：GP 里只能写整数 BPM。速度基本不变 → 整首一个速度（原曲同步用一个比例补回小数）；
    // 速度在变（现场录音、没有节拍器）→ 每小节写一个速度，取整时把误差往后摊，谱子的时间一直贴着原曲
    {
        const int bars = totalBeats / 4;
        std::vector<double> barBpm ((size_t) bars);
        double worst = 0.0;
        for (int k = 0; k < bars; ++k)
        {
            barBpm[(size_t) k] = 240.0 / juce::jmax (0.2, timeOf (4 * k + 4) - timeOf (4 * k));
            worst = juce::jmax (worst, std::abs (barBpm[(size_t) k] - bpm));
        }
        const double meanBpm = 60.0 * totalBeats / juce::jmax (0.5, timeOf (totalBeats) - timeOf (0));
        const bool steady = worst < 2.0 || bars < 3;
        std::vector<int> tempoOf ((size_t) bars, (int) std::round (meanBpm));
        if (steady)
            res.syncRate = std::round (meanBpm) / meanBpm;
        else
        {
            double songT = 0.0, audioT = 0.0;
            for (int k = 0; k < bars; ++k)
            {
                audioT += 240.0 / barBpm[(size_t) k];
                const double ideal = juce::jlimit (30.0, 300.0, barBpm[(size_t) k]);
                const int lo = (int) std::floor (ideal), hi = lo + 1;
                const int pick = std::abs (songT + 240.0 / lo - audioT) < std::abs (songT + 240.0 / hi - audioT) ? lo : hi;
                tempoOf[(size_t) k] = pick;
                songT += 240.0 / pick;
            }
            res.syncRate = 1.0;
        }
        raw.initialTempo = tempoOf.empty() ? std::round (bpm) : tempoOf.front();
        for (int k = 0; k < bars; ++k)
        {
            RawMasterBar mb;
            if (k == 0 || tempoOf[(size_t) k] != tempoOf[(size_t) k - 1]) mb.tempos.push_back ({ 0.0, (double) tempoOf[(size_t) k] });
            raw.masterBars.push_back (mb);
        }
        res.bpm = meanBpm;
    }

    int chordTrack = -1;
    for (int i = 0; i < (int) plans.size() && chordTrack < 0; ++i) if (plans[(size_t) i].chordal && ! plans[(size_t) i].bass) chordTrack = i;
    for (int i = 0; i < (int) plans.size() && chordTrack < 0; ++i) if (! plans[(size_t) i].bass) chordTrack = i;
    int totalNotes = 0;
    for (int pi = 0; pi < (int) plans.size(); ++pi)
    {
        auto& plan = plans[(size_t) pi];
        RawTrack track;
        track.name = plan.name;
        track.tuning = plan.bass ? std::vector<int> { 43, 38, 33, 28 } : std::vector<int> { 64, 59, 55, 50, 45, 40 };
        track.capo = plan.bass ? 0 : opt.capo;
        track.program = plan.bass ? 34 : (plan.chordal ? 30 : 29);
        std::vector<int> tuning = track.tuning;
        if (! plan.bass) for (auto& t : tuning) t += opt.capo;

        // 量化
        struct Q { int a, b, midi; float amp, bend, bendPeak; bool release; };
        // 三连音 / Shuffle：拍子里的音大多落在 1/3、2/3 上（而不是 1/4、1/2、3/4）→ 这一轨按三连音的格子量化
        int grid = baseGrid;
        {
            int nTrip = 0, nStraight = 0;
            for (auto& n : plan.notes)
            {
                const double b = beatOf (n.start);
                const double ph = b - std::floor (b);
                if (std::abs (ph - 1.0 / 3.0) < 0.06 || std::abs (ph - 2.0 / 3.0) < 0.06) ++nTrip;
                else if (std::abs (ph - 0.25) < 0.05 || std::abs (ph - 0.5) < 0.06 || std::abs (ph - 0.75) < 0.05) ++nStraight;
            }
            if (nTrip >= 8 && nTrip > nStraight * 1.4) grid = 3;
            if (std::getenv ("A2T_DUMPRAW")) std::printf ("SWING %s trip %d straight %d -> grid %d\n", plan.name.toRawUTF8(), nTrip, nStraight, grid);
        }
        const int totalSlots = totalBeats * grid;
        const int barSlots = 4 * grid;
        std::vector<Q> qs;
        // 整体的“拖拍 / 抢拍”：演奏者习惯稍微靠后弹、模型的起音也会晚一点。先量出这一轨的音相对格子
        // 平均偏了多少（圆周平均），量化前减掉，不然靠近两格中间的音会被推到下一格
        double lag = 0.0;
        {
            double sx = 0.0, sy = 0.0, wsum = 0.0;
            for (auto& n : plan.notes)
            {
                const double ph = beatOf (n.start) * grid;
                const double a = (ph - std::floor (ph)) * juce::MathConstants<double>::twoPi;
                sx += n.amplitude * std::cos (a); sy += n.amplitude * std::sin (a); wsum += n.amplitude;
            }
            if (wsum > 0.0 && std::sqrt (sx * sx + sy * sy) / wsum > 0.25)        // 偏得够一致才算
                lag = std::atan2 (sy, sx) / juce::MathConstants<double>::twoPi;     // −0.5 .. 0.5 格
            if (std::getenv ("A2T_DUMPRAW")) std::printf ("LAG %s %.3f R %.2f\n", plan.name.toRawUTF8(), lag, wsum > 0 ? std::sqrt (sx * sx + sy * sy) / wsum : 0.0);
        }
        for (auto& n : plan.notes)
        {
            int a = (int) std::round (beatOf (n.start) * grid - lag);
            int b = (int) std::round (beatOf (n.end) * grid - lag);
            a = juce::jlimit (0, totalSlots - 1, a);
            b = juce::jlimit (a + 1, totalSlots, b);
            qs.push_back ({ a, b, n.midi, n.amplitude, n.bend, n.bendPeak, n.release });
        }
        std::sort (qs.begin(), qs.end(), [] (const Q& x, const Q& y) { return x.a != y.a ? x.a < y.a : x.midi > y.midi; });
        // 同一格同一个音只留一个；单音音轨（主音 / 贝斯）同一格只留最响的
        const bool mono = plan.bass || ! plan.chordal;
        std::vector<Q> kept;
        for (auto& q : qs)
        {
            bool dup = false;
            for (int i = (int) kept.size() - 1; i >= 0 && kept[(size_t) i].a == q.a; --i)
                if (kept[(size_t) i].midi == q.midi || mono)
                {
                    dup = true;
                    if (mono && q.amp > kept[(size_t) i].amp) kept[(size_t) i] = q;
                    break;
                }
            if (! dup) kept.push_back (q);
        }
        // 单音：前一个音到下一个音开始就结束；和弦：每组最多 6 个音
        if (mono)
            for (size_t i = 0; i + 1 < kept.size(); ++i)
                kept[i].b = juce::jmin (kept[i].b, kept[i + 1].a);

        // 指法：按组（同一格开始的音）
        struct Placed { Q q; int string, fret; };
        std::vector<Placed> placed;
        float hand = plan.bass ? 3.0f : 5.0f;
        std::vector<int> stringBusyUntil (tuning.size(), -1);
        std::vector<int> stringOwner (tuning.size(), -1);
        size_t gi = 0;
        while (gi < kept.size())
        {
            size_t gj = gi;
            while (gj < kept.size() && kept[gj].a == kept[gi].a) ++gj;
            const int slot = kept[gi].a;
            std::vector<Q> group (kept.begin() + (long) gi, kept.begin() + (long) gj);
            if (group.size() > tuning.size())
            {
                std::sort (group.begin(), group.end(), [] (const Q& x, const Q& y) { return x.amp > y.amp; });
                group.resize (tuning.size());
            }
            std::vector<bool> blocked (tuning.size(), false);
            for (size_t s = 0; s < tuning.size(); ++s) blocked[s] = stringBusyUntil[s] > slot;
            std::vector<Fingered> f;
            for (int attempt = 0; attempt < 3; ++attempt)
            {
                std::vector<int> midis;
                for (auto& q : group) midis.push_back (q.midi);
                f = fingerGroup (midis, tuning, blocked, hand, plan.bass ? 20 : 19);
                bool ok = ! f.empty() && std::all_of (f.begin(), f.end(), [] (const Fingered& x) { return x.string >= 0; });
                if (ok) break;
                if (attempt == 0)
                {
                    // 还在响的音挡住了：让它们在这里结束
                    for (size_t s = 0; s < tuning.size(); ++s)
                        if (blocked[s] && stringOwner[s] >= 0) { placed[(size_t) stringOwner[s]].q.b = slot; stringBusyUntil[s] = slot; blocked[s] = false; }
                    continue;
                }
                // 还排不下：去掉最弱的一个音再试
                if (group.size() <= 1) { f.clear(); break; }
                auto weakest = std::min_element (group.begin(), group.end(), [] (const Q& x, const Q& y) { return x.amp < y.amp; });
                group.erase (weakest);
            }
            for (size_t i = 0; i < group.size() && i < f.size(); ++i)
            {
                if (f[i].string < 0) continue;
                placed.push_back ({ group[i], f[i].string, f[i].fret });
                stringBusyUntil[(size_t) f[i].string] = group[i].b;
                stringOwner[(size_t) f[i].string] = (int) placed.size() - 1;
            }
            gi = gj;
        }
        totalNotes += (int) placed.size();

        // 和弦图挂在第一条节奏（或吉他）音轨上
        const bool chordsHere = opt.chords && pi == chordTrack;
        std::map<int, int> diagramOf;
        auto diagramFor = [&] (int code)
        {
            if (auto it = diagramOf.find (code); it != diagramOf.end()) return it->second;
            const auto q = code % 4 == 0 ? Chords::Quality::major : code % 4 == 1 ? Chords::Quality::minor
                         : code % 4 == 2 ? Chords::Quality::dom7 : Chords::Quality::power;
            ChordDiagram d;
            d.name = Chords::name (code / 4, q, false);
            const auto vs = Chords::voicings (code / 4, q);
            if (! vs.empty()) for (int s = 5; s >= 0; --s) d.frets.push_back (vs.front().frets[(size_t) s]);
            track.chordDiagrams.push_back (d);
            return diagramOf[code] = (int) track.chordDiagrams.size() - 1;
        };

        // 写成拍：每个音开始、结束、换和弦、小节线的地方切开；跨过切点的音用连音线接上
        std::vector<std::set<int>> startsAt ((size_t) totalSlots + 1), endsAt ((size_t) totalSlots + 1);
        for (int i = 0; i < (int) placed.size(); ++i)
        {
            startsAt[(size_t) placed[(size_t) i].q.a].insert (i);
            endsAt[(size_t) juce::jmin (totalSlots, placed[(size_t) i].q.b)].insert (i);
        }
        std::set<int> sounding;
        for (int bar = 0; bar < totalBeats / 4; ++bar)
        {
            RawBar rb;
            RawVoice voice;
            int s = bar * barSlots;
            const int end = s + barSlots;
            while (s < end)
            {
                for (int i : endsAt[(size_t) s]) sounding.erase (i);
                std::set<int> fresh = startsAt[(size_t) s];
                for (int i : fresh) sounding.insert (i);
                const bool chordChange = chordsHere && s % grid == 0 && beatChord[(size_t) (s / grid)] >= 0
                                         && (s == bar * barSlots || beatChord[(size_t) (s / grid)] != beatChord[(size_t) (s / grid - 1)]);
                int e = s + 1;
                while (e < end && startsAt[(size_t) e].empty() && endsAt[(size_t) e].empty()
                       && ! (chordsHere && e % grid == 0 && beatChord[(size_t) (e / grid)] != beatChord[(size_t) (e / grid - 1)]))
                    ++e;
                RawBeat beat;
                beat.duration = (double) (e - s) / grid;
                if (chordChange)
                {
                    const int code = beatChord[(size_t) (s / grid)];
                    const bool repeatAtBar = s == bar * barSlots && s > 0 && beatChord[(size_t) (s / grid - 1)] == code;
                    if (! repeatAtBar) beat.chord = diagramFor (code);
                }
                for (int i : sounding)
                {
                    const auto& pl = placed[(size_t) i];
                    RawNote rn;
                    rn.string = pl.string;
                    rn.fret = pl.fret;
                    rn.tieDestination = fresh.count (i) == 0;
                    if (! rn.tieDestination && pl.q.bend >= 0.5f && ! plan.bass)
                    {
                        rn.bend = pl.q.bend;
                        rn.bendPeakPos = juce::jlimit (0.1f, 1.0f, pl.q.bendPeak);
                        rn.bendReleasePos = pl.q.release ? juce::jmin (1.0f, rn.bendPeakPos + 0.15f) : 1.0f;
                        rn.bendEnd = pl.q.release ? 0.0f : pl.q.bend;
                        rn.bendEndPos = 1.0f;
                    }
                    beat.notes.push_back (rn);
                }
                voice.beats.push_back (beat);
                s = e;
            }
            rb.voices.push_back (voice);
            track.bars.push_back (rb);
        }
        raw.tracks.push_back (std::move (track));
    }

    // 主旋律（单音）也记一份，跟老接口兼容
    for (auto& p : plans)
        if (! p.chordal && ! p.bass)
            for (auto& n : p.notes)
            {
                DetectedNote d; d.start = n.start; d.end = n.end; d.midi = n.midi; d.bend = n.bend; d.bendPeak = n.bendPeak; d.release = n.release; d.strength = n.amplitude;
                res.notes.push_back (d);
            }
    if (res.notes.empty())
        for (auto& n : notesMain) { DetectedNote d; d.start = n.start; d.end = n.end; d.midi = n.midi; d.strength = n.amplitude; res.notes.push_back (d); }

    res.song = std::shared_ptr<Song> (buildSong (raw).release());
    res.raw = std::move (raw);
    res.summary = (separated ? T ("AI 复音识别 + 乐器分离：") : T ("AI 复音识别：")) + layout + T ("，共 ") + juce::String (totalNotes) + T (" 个音");
    report (opt, 1.0f, T ("完成"));
    return res;
}
