#include "Looper.h"
#include "drums/DrumMachine.h"

void Looper::setSampleRate (double sr)
{
    if (sr <= 0.0 || juce::approximatelyEqual (sr, sampleRate))
        return;
    // 采样率变了：缓冲按新采样率重新分配（设备停着，音频线程不会碰）
    sampleRate = sr;
    ready.store (false);
    for (auto& t : tracks)
    {
        for (auto& b : t.buffer) { b.clear(); b.shrink_to_fit(); }
        t.state.store ((int) State::empty);
        t.hasAudio.store (false);
    }
    capacity = 0;
    loopLength.store (0);
    position.store (0);
    playing.store (false);
}

bool Looper::allocate()
{
    if (ready.load())
        return true;
    const int cap = (int) (sampleRate * maxSeconds);
    try
    {
        for (auto& t : tracks)
            for (auto& b : t.buffer)
                b.assign ((size_t) cap, 0.0f);
    }
    catch (const std::bad_alloc&)
    {
        return false;
    }
    capacity = cap;
    ready.store (true, std::memory_order_release);
    return true;
}

int Looper::barSamples (const DrumMachine& drums) const noexcept
{
    const auto& styles = getDrumStyles();
    const int beats = styles.empty() ? 4 : styles[(size_t) juce::jlimit (0, (int) styles.size() - 1, drums.getStyle())].beatsPerBar;
    return juce::jmax (1, (int) std::lround (60.0 / juce::jmax (30.0f, drums.getBpm()) * beats * sampleRate));
}

void Looper::declick (Track& t, int start, int len) noexcept
{
    // 接缝处（开始录的地方）做 3 ms 淡入淡出，循环回来不会“嗒”一声
    const int L = juce::jmax (1, loopLength.load());
    const int fade = juce::jmin ((int) (0.003 * sampleRate), len / 4);
    for (int i = 0; i < fade; ++i)
    {
        const float g = (float) i / (float) fade;
        const int a = (start + i) % L;
        const int b = ((start + len - 1 - i) % L + L) % L;
        for (auto& ch : t.buffer)
        {
            ch[(size_t) a] *= g;
            ch[(size_t) b] *= g;
        }
    }
}

void Looper::finishMaster (const DrumMachine& drums) noexcept
{
    auto& t = tracks[0];
    int len = masterRecorded.load();
    if (len < (int) (0.25 * sampleRate))          // 太短，当作误触
    {
        t.state.store ((int) State::empty);
        masterRecorded.store (0);
        return;
    }
    if (syncToDrums.load() && drums.isPlaying())
    {
        const int bar = barSamples (drums);
        const int bars = juce::jmax (1, (int) std::lround ((double) len / bar));
        len = juce::jmin (bars * bar, capacity);   // 多出来的部分本来就是静音
    }
    loopLength.store (len);
    declick (t, 0, juce::jmin (len, masterRecorded.load()));
    position.store (masterRecorded.load() % len);
    t.hasAudio.store (true);
    t.state.store ((int) State::playing);
    playing.store (true);
    masterRecorded.store (0);
}

void Looper::finishPass (Track& t) noexcept
{
    if (t.recordedThisPass > 0)
    {
        const int L = loopLength.load();
        const int start = ((position.load() - t.recordedThisPass) % L + L) % L;
        declick (t, start, t.recordedThisPass);
        t.hasAudio.store (true);
        t.state.store ((int) State::playing);
    }
    else
    {
        t.state.store ((int) State::empty);
    }
    t.recordedThisPass = 0;
}

void Looper::handleRequests (const DrumMachine& drums) noexcept
{
    if (clearAllReq.exchange (false))
    {
        for (auto& t : tracks)
        {
            if (t.hasAudio.load() || t.state.load() != (int) State::empty) t.zeroPending.store (true);
            t.state.store ((int) State::empty);
            t.hasAudio.store (false);
            t.recordedThisPass = 0;
        }
        loopLength.store (0);
        position.store (0);
        masterRecorded.store (0);
        playing.store (false);
        armedWaitsForBar = false;
        return;
    }

    if (const int p = playReq.exchange (0); p != 0)
    {
        if (p == 1 && loopLength.load() > 0)
            playing.store (true);
        if (p == 2)
        {
            playing.store (false);
            position.store (0);
            for (auto& t : tracks)
            {
                if (t.state.load() == (int) State::recording && loopLength.load() > 0) finishPass (t);
                if (t.state.load() == (int) State::overdubbing) t.state.store ((int) State::playing);
            }
            if (tracks[0].state.load() == (int) State::recording && loopLength.load() == 0) finishMaster (drums);
            if (tracks[0].state.load() == (int) State::armed) tracks[0].state.store ((int) State::empty);
        }
    }

    for (int i = 0; i < numTracks; ++i)
    {
        auto& t = tracks[(size_t) i];
        if (t.clearReq.exchange (false))
        {
            if (t.state.load() == (int) State::recording && i == 0 && loopLength.load() == 0)
                masterRecorded.store (0);
            t.state.store ((int) State::empty);
            t.hasAudio.store (false);
            t.recordedThisPass = 0;
            t.zeroPending.store (true);            // 清零交给界面线程（maintenance）
            bool any = false;
            for (auto& o : tracks) any |= o.hasAudio.load() || o.state.load() == (int) State::recording;
            if (! any) { loopLength.store (0); position.store (0); playing.store (false); }
        }

        if (! t.pressed.exchange (false))
            continue;

        const auto st = (State) t.state.load();
        const int L = loopLength.load();
        if (L == 0)
        {
            // 还没有循环：只有第 1 轨能定长度（按别的轨等于按第 1 轨）
            auto& m = tracks[0];
            const auto ms = (State) m.state.load();
            if (ms == State::empty && m.zeroPending.load()) { t.pressed.store (true); continue; }   // 等清零完再录
            if (ms == State::empty)
            {
                masterRecorded.store (0);
                if (syncToDrums.load() && drums.isPlaying()) { m.state.store ((int) State::armed); armedWaitsForBar = true; }
                else m.state.store ((int) State::recording);
            }
            else if (ms == State::armed)     m.state.store ((int) State::empty);
            else if (ms == State::recording) finishMaster (drums);
            continue;
        }

        switch (st)
        {
            case State::empty:
                if (t.zeroPending.load()) { t.pressed.store (true); break; }   // 等清零完再录
                t.recordedThisPass = 0;
                t.state.store ((int) State::recording);
                playing.store (true);
                break;
            case State::recording:   finishPass (t); break;
            case State::playing:     t.state.store ((int) State::overdubbing); playing.store (true); break;
            case State::overdubbing: t.state.store ((int) State::playing); break;
            case State::armed:       t.state.store ((int) State::empty); break;
        }
    }
}

void Looper::process (const float* inL, const float* inR, float* outL, float* outR, int n, const DrumMachine& drums) noexcept
{
    if (! ready.load (std::memory_order_acquire) || capacity <= 0)
        return;

    handleRequests (drums);

    // 等小节：鼓机走到第一拍才开始录第 1 轨
    if (drums.isPlaying())
    {
        const int beat = drums.getCurrentBeat();
        const bool downbeat = beat == 0 && lastDrumBeat != 0;
        lastDrumBeat = beat;
        if (armedWaitsForBar && downbeat && tracks[0].state.load() == (int) State::armed)
        {
            tracks[0].state.store ((int) State::recording);
            masterRecorded.store (0);
            armedWaitsForBar = false;
        }
    }
    else
    {
        lastDrumBeat = -1;
        if (tracks[0].state.load() == (int) State::armed)      // 鼓机停了：直接开始录
        {
            tracks[0].state.store ((int) State::recording);
            masterRecorded.store (0);
            armedWaitsForBar = false;
        }
    }

    const float master = juce::Decibels::decibelsToGain (masterGainDb.load());
    float targetGain[numTracks];
    for (int i = 0; i < numTracks; ++i)
        targetGain[i] = tracks[(size_t) i].muted.load() ? 0.0f : juce::Decibels::decibelsToGain (tracks[(size_t) i].gainDb.load()) * master;

    const int L = loopLength.load();

    // 第 1 轨定长度的那一遍
    if (L == 0)
    {
        auto& m = tracks[0];
        if (m.state.load() == (int) State::recording)
        {
            int rec = masterRecorded.load();
            float pk = 0.0f;
            for (int i = 0; i < n && rec < capacity; ++i, ++rec)
            {
                m.buffer[0][(size_t) rec] = inL[i];
                m.buffer[1][(size_t) rec] = inR[i];
                pk = juce::jmax (pk, std::abs (inL[i]));
            }
            masterRecorded.store (rec);
            if (pk > m.peak.load()) m.peak.store (pk);
            if (rec >= capacity) finishMaster (drums);
        }
        return;
    }

    if (! playing.load())
        return;

    int pos = position.load();
    for (int i = 0; i < n; ++i)
    {
        for (int k = 0; k < numTracks; ++k)
        {
            auto& t = tracks[(size_t) k];
            const int st = t.state.load (std::memory_order_relaxed);
            if (st == (int) State::empty || st == (int) State::armed)
                continue;
            float& l = t.buffer[0][(size_t) pos];
            float& r = t.buffer[1][(size_t) pos];
            if (st == (int) State::recording)
            {
                l = inL[i]; r = inR[i];
                if (++t.recordedThisPass >= L)
                {
                    position.store ((pos + 1) % L);
                    finishPass (t);
                }
                continue;                                   // 正在录的这一轨不放
            }
            if (st == (int) State::overdubbing)
            {
                l += inL[i]; r += inR[i];
            }
            t.gain += 0.002f * (targetGain[k] - t.gain);
            outL[i] += l * t.gain;
            outR[i] += r * t.gain;
            const float a = std::abs (l * t.gain);
            if (a > t.peak.load (std::memory_order_relaxed)) t.peak.store (a, std::memory_order_relaxed);
        }
        pos = (pos + 1) % L;
    }
    position.store (pos);
}

void Looper::maintenance()
{
    if (! ready.load()) return;
    for (auto& t : tracks)
        if (t.zeroPending.load() && t.state.load() == (int) State::empty)
        {
            for (auto& ch : t.buffer)
                std::fill (ch.begin(), ch.end(), 0.0f);
            t.zeroPending.store (false);
        }
}

juce::AudioBuffer<float> Looper::renderMix() const
{
    const int L = loopLength.load();
    juce::AudioBuffer<float> mix (2, juce::jmax (1, L));
    mix.clear();
    if (L <= 0 || ! ready.load()) return mix;
    const float master = juce::Decibels::decibelsToGain (masterGainDb.load());
    for (auto& t : tracks)
    {
        if (! t.hasAudio.load() || t.muted.load()) continue;
        const float g = juce::Decibels::decibelsToGain (t.gainDb.load()) * master;
        for (int c = 0; c < 2; ++c)
            mix.addFrom (c, 0, t.buffer[(size_t) c].data(), L, g);
    }
    return mix;
}
