#pragma once

#include <juce_audio_basics/juce_audio_basics.h>
#include <functional>

// 乐器分离：Meta 开源的 HT-Demucs 6 声部模型（MIT，ONNX 版约 136 MB，不编进程序，单独放在程序旁边的 models 文件夹）。
// 把一首歌分成 鼓 / 贝斯 / 其他 / 人声 / 吉他 / 钢琴 六轨，扒谱时只拿吉他和贝斯去识别，鼓轨用来找拍子。
// 本地 CPU 计算，不联网；一首 3 分钟的歌在普通电脑上大约 1–3 分钟。
class Demucs
{
public:
    static constexpr double sampleRate = 44100.0;
    static constexpr int segment = 343980;               // 7.8 秒一段
    enum Stem { drums = 0, bass, other, vocals, guitar, piano, numStems };
    static const char* stemName (int s);

    static juce::File modelLocation();                   // 找到的模型文件（找不到时返回首选位置）
    static bool isAvailable (juce::String& why);

    // 输入：任意采样率的立体声（单声道也行）。输出：每个声部一份 44.1 kHz 立体声。
    // progress 返回 false = 取消（error 里写 "cancelled"）
    static bool separate (const juce::AudioBuffer<float>& audio, double sr, juce::AudioBuffer<float> (&stems)[numStems],
                          juce::String& error, std::function<bool (float)> progress = {});
};
