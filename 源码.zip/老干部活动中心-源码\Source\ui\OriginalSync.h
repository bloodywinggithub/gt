#pragma once

#include <juce_gui_basics/juce_gui_basics.h>
#include <juce_data_structures/juce_data_structures.h>
#include "practice/BackingTrack.h"

// 谱子的原曲：哪个音频文件、怎么和谱子对齐。
//   原曲时间 = offset + 谱子时间 × rate
// 存在谱子旁边的“谱子文件名.sync.json”里（写不了的话存设置里），下次打开同一份谱子自动带上。
struct OriginalSync
{
    juce::File audio;
    double offset = 0.0;        // 谱子开头（第 0 拍）在原曲的第几秒
    double rate = 1.0;          // 原曲秒 / 谱子秒（谱子 BPM 是取整的、或者和录音有一点点差时用）
    float gainDb = -6.0f;
    bool on = true;

    bool isValid() const        { return audio.existsAsFile(); }

    static OriginalSync loadFor (const juce::File& tab, juce::PropertiesFile& settings);
    static void saveFor (const juce::File& tab, const OriginalSync& s, juce::PropertiesFile& settings);
    static void removeFor (const juce::File& tab, juce::PropertiesFile& settings);
    static juce::File sidecarFor (const juce::File& tab);
    juce::var toVar() const;
    static OriginalSync fromVar (const juce::var& v, const juce::File& tab);
};

// “原曲…”弹出的小面板：选音频、开关、音量、对齐（偏移、快慢微调）
class OriginalSyncPanel : public juce::Component, private juce::Timer
{
public:
    OriginalSyncPanel (BackingTrack& track, OriginalSync& sync);
    ~OriginalSyncPanel() override;

    std::function<void()> onChanged;          // 改了任何东西（存盘）
    std::function<void()> onChooseFile;
    std::function<void()> onRemove;

    void refresh();
    void paint (juce::Graphics&) override;
    void resized() override;

private:
    void timerCallback() override;
    void nudgeOffset (double d);
    void nudgeRate (double d);
    void apply();

    BackingTrack& track;
    OriginalSync& sync;
    juce::Label title, nameLabel, offsetLabel, rateLabel, volLabel, hint;
    juce::TextButton chooseButton, removeButton, rateReset;
    juce::ToggleButton onToggle;
    juce::Slider volSlider;
    juce::OwnedArray<juce::TextButton> offsetButtons, rateButtons;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (OriginalSyncPanel)
};
