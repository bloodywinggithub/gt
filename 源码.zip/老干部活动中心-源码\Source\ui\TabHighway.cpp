#include "TabHighway.h"
#include "Text.h"
#include "ChordDiagram.h"
#include <algorithm>

namespace
{
    // 弦的颜色（从最细的弦开始），和常见音游的配色一致
    const juce::Colour stringColours[] = {
        juce::Colour (0xffe8433f),   // 1 弦 e  红
        juce::Colour (0xfff2c12e),   // 2 弦 B  黄
        juce::Colour (0xff3d8ff0),   // 3 弦 G  蓝
        juce::Colour (0xfff07f2a),   // 4 弦 D  橙
        juce::Colour (0xff37b24d),   // 5 弦 A  绿
        juce::Colour (0xffa65be8),   // 6 弦 E  紫
        juce::Colour (0xff9aa0a6),   // 7 弦
        juce::Colour (0xff7d8590),   // 8 弦
    };

    juce::Colour colourForString (int s) { return stringColours[juce::jlimit (0, 7, s)]; }

    juce::String noteName (int midi)
    {
        static const char* names[] = { "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B" };
        return names[((midi % 12) + 12) % 12];
    }

    juce::String bendText (float semis)
    {
        // 吉他上的说法：推一个半音 = ½ 音，两个半音 = 全音
        const float tones = std::round (semis * 2.0f) / 4.0f;     // 精确到 ¼ 音
        if (tones <= 0.25f) return T ("¼音");
        if (tones <= 0.5f)  return T ("½音");
        if (std::abs (tones - 1.0f) < 0.01f) return T ("全音");
        const int whole = (int) tones;
        const float frac = tones - (float) whole;
        juce::String t = whole > 0 ? juce::String (whole) : juce::String();
        if (std::abs (frac - 0.25f) < 0.01f) t << juce::String::fromUTF8 ("\xc2\xbc");
        else if (std::abs (frac - 0.5f) < 0.01f) t << juce::String::fromUTF8 ("\xc2\xbd");
        else if (std::abs (frac - 0.75f) < 0.01f) t << juce::String::fromUTF8 ("\xc2\xbe");
        return t + T ("音");
    }

    const juce::Colour bg       { 0xff121417 };

    juce::Colour verdictColour (Verdict v)
    {
        switch (v)
        {
            case Verdict::perfect:   return juce::Colour (0xffffd34d);
            case Verdict::good:      return juce::Colour (0xff5dd879);
            case Verdict::wrongNote: return juce::Colour (0xffff8a3d);
            case Verdict::miss:      return juce::Colour (0xffff4d4d);
            case Verdict::pending:   break;
        }
        return juce::Colours::transparentBlack;
    }

    juce::Colour accuracyColour (float a)
    {
        // 红 -> 黄 -> 绿
        return a < 0.5f ? juce::Colour (0xffff4d4d).interpolatedWith (juce::Colour (0xffffc94d), a * 2.0f)
                        : juce::Colour (0xffffc94d).interpolatedWith (juce::Colour (0xff4ccf6b), (a - 0.5f) * 2.0f);
    }

    double nowSeconds()
    {
        if (TabHighway::clockOverride) return TabHighway::clockOverride();
        return juce::Time::getMillisecondCounterHiRes() * 0.001;
    }
    const juce::Colour laneLine { 0xff2a2f36 };
}

TabHighway::TabHighway (TabPlayer& p) : player (p)
{
    vblank = std::make_unique<juce::VBlankAttachment> (this, [this] { if (isShowing()) repaint(); });
}

TabHighway::~TabHighway() = default;

void TabHighway::setSong (std::shared_ptr<const Song> s, int trackIndex)
{
    song = std::move (s);
    track = trackIndex;
    analyseTrack();
    repaint();
}

void TabHighway::setTrack (int trackIndex)
{
    track = trackIndex;
    analyseTrack();
    repaint();
}

void TabHighway::setJudgeSession (std::shared_ptr<JudgeSession> s, bool wait)
{
    judge = std::move (s);
    waitMode = wait;
    seenSeq = judge != nullptr ? judge->lastSeq.load() : 0;
    flash = {};
    barAccuracy.clear();
    repaint();
}

void TabHighway::mouseWheelMove (const juce::MouseEvent& e, const juce::MouseWheelDetails& w)
{
    if (! laneArea.contains (e.getPosition()) || viewMode == ViewMode::staff)
        return;
    pxPerSec = juce::jlimit (100.0f, 600.0f, pxPerSec * (1.0f + w.deltaY * 0.5f));
    if (onZoomChanged) onZoomChanged (pxPerSec);
    repaint();
}

void TabHighway::analyseTrack()
{
    staffLayoutWidth = -1;
    hopoLabel.clear(); nextOnString.clear(); prevOnString.clear(); startSec.clear(); endSec.clear();
    if (song == nullptr || ! juce::isPositiveAndBelow (track, (int) song->tracks.size()))
        return;

    const auto& notes = song->tracks[(size_t) track].notes;
    const size_t n = notes.size();
    hopoLabel.assign (n, 0);
    nextOnString.assign (n, -1);
    prevOnString.assign (n, -1);
    startSec.resize (n);
    endSec.resize (n);

    std::vector<int> lastOn (16, -1);
    for (size_t i = 0; i < n; ++i)
    {
        const auto& note = notes[i];
        startSec[i] = song->beatToSeconds (note.start);
        endSec[i] = song->beatToSeconds (note.start + note.length);
        const int s = juce::jlimit (0, 15, note.string);
        if (lastOn[(size_t) s] >= 0)
        {
            nextOnString[(size_t) lastOn[(size_t) s]] = (int) i;
            prevOnString[i] = lastOn[(size_t) s];
            if (note.hammerPull)
                hopoLabel[i] = note.fret >= notes[(size_t) lastOn[(size_t) s]].fret ? 'H' : 'P';
        }
        if (note.tapped)
            hopoLabel[i] = 'T';
        lastOn[(size_t) s] = (int) i;
    }
}

double TabHighway::currentBeat() const
{
    return frozenBeat >= 0.0 ? frozenBeat : player.getPosition();
}

void TabHighway::resized()
{
    auto r = getLocalBounds();
    timelineArea = r.removeFromBottom (40).reduced (12, 8);
    laneArea = r.reduced (0, 8);
    hitX = 150.0f;
    buildNeckImage();
}

// 指板：弦距按真吉他比例（弦距大约是指板宽的 1/6.5），不再铺满整个高度；上面留出音名、推弦的空间
juce::Rectangle<float> TabHighway::neckBounds() const
{
    const int count = (song != nullptr && juce::isPositiveAndBelow (track, (int) song->tracks.size()))
                        ? juce::jmax (1, song->tracks[(size_t) track].stringCount()) : 6;
    const float avail = (float) laneArea.getHeight() - 70.0f;                 // 上面留 50 给标记，下面 20
    const float gap = juce::jlimit (26.0f, 52.0f, avail / (float) (count - 1 + 1.3f));
    const float h = gap * (float) (count - 1) + gap * 1.3f;
    const float top = (float) laneArea.getY() + 50.0f + juce::jmax (0.0f, (avail - h) * 0.45f);
    return { (float) laneArea.getX(), top, (float) laneArea.getWidth(), h };
}

float TabHighway::yForString (int s) const
{
    const int count = (song != nullptr && juce::isPositiveAndBelow (track, (int) song->tracks.size()))
                        ? juce::jmax (1, song->tracks[(size_t) track].stringCount()) : 6;
    const auto nb = neckBounds();
    const float gap = nb.getHeight() / ((float) (count - 1) + 1.3f);
    return nb.getY() + gap * 0.65f + gap * (float) s;
}

void TabHighway::buildNeckImage()
{
    const auto nb = neckBounds();
    const int w = juce::jmax (8, (int) nb.getWidth()), h = juce::jmax (8, (int) nb.getHeight());
    neckImage = juce::Image (juce::Image::ARGB, w, h, true);
    juce::Graphics g (neckImage);
    // 玫瑰木底色：上下边稍亮，中间深
    juce::ColourGradient base (juce::Colour (0xff3d2619), 0.0f, 0.0f, juce::Colour (0xff3a2318), 0.0f, (float) h, false);
    base.addColour (0.5, juce::Colour (0xff24150d));
    g.setGradientFill (base);
    g.fillAll();
    // 木纹：沿琴颈方向的细纹，粗细、深浅、弯曲都随机
    juce::Random rnd (7);
    for (float y = 0.0f; y < (float) h; y += 1.0f + rnd.nextFloat() * 2.2f)
    {
        juce::Path p;
        const float amp = 0.6f + rnd.nextFloat() * 2.2f, freq = 0.002f + rnd.nextFloat() * 0.01f, ph = rnd.nextFloat() * 6.28f;
        p.startNewSubPath (0.0f, y);
        for (float x = 0.0f; x <= (float) w; x += 24.0f)
            p.lineTo (x, y + amp * std::sin (x * freq + ph));
        const bool dark = rnd.nextFloat() < 0.6f;
        g.setColour ((dark ? juce::Colour (0xff120a05) : juce::Colour (0xff6b4430)).withAlpha (0.05f + rnd.nextFloat() * 0.16f));
        g.strokePath (p, juce::PathStrokeType (0.6f + rnd.nextFloat() * 1.4f));
    }
    // 几处深色的木节斑
    for (int i = 0; i < w / 160; ++i)
    {
        const float cx = rnd.nextFloat() * (float) w, cy = rnd.nextFloat() * (float) h;
        g.setColour (juce::Colour (0xff0e0703).withAlpha (0.12f));
        g.fillEllipse (cx - 40.0f, cy - 4.0f, 80.0f + rnd.nextFloat() * 60.0f, 8.0f);
    }
    // 包边（上下两条奶白色）+ 一点立体感
    g.setColour (juce::Colour (0xffe9e1cf));
    g.fillRect (0, 0, w, 3);
    g.fillRect (0, h - 3, w, 3);
    g.setColour (juce::Colours::black.withAlpha (0.35f));
    g.fillRect (0, 3, w, 2);
    g.setColour (juce::Colours::white.withAlpha (0.05f));
    g.fillRect (0, h - 6, w, 3);
}

// =============================================================================
void TabHighway::paint (juce::Graphics& g)
{
    g.fillAll (bg);

    if (song == nullptr || ! juce::isPositiveAndBelow (track, (int) song->tracks.size()))
    {
        g.setColour (juce::Colours::white.withAlpha (0.5f));
        g.setFont (juce::FontOptions (18.0f));
        g.drawText (T ("点“打开谱子…”载入一个吉他谱"), getLocalBounds().withTrimmedBottom (20), juce::Justification::centred);
        g.setFont (juce::FontOptions (13.0f));
        g.setColour (juce::Colours::white.withAlpha (0.35f));
        g.drawText (T ("支持 Guitar Pro 3 / 4 / 5 / 6 / 7 / 8（.gp3 .gp4 .gp5 .gpx .gp）"),
                    getLocalBounds().withTrimmedTop (60), juce::Justification::centred);
        return;
    }

    const double nowBeat = currentBeat();
    const double nowSec = song->beatToSeconds (nowBeat);
    if (viewMode == ViewMode::staff)
        paintStaff (g, nowBeat);
    else
        paintLanes (g, nowSec, nowBeat);
    paintTimeline (g, nowBeat);
}

void TabHighway::paintLanes (juce::Graphics& g, double nowSec, double nowBeat)
{
    const auto& tr = song->tracks[(size_t) track];
    const int strings = juce::jmax (1, tr.stringCount());
    const float left = (float) laneArea.getX(), right = (float) laneArea.getRight();
    const double secLeft = nowSec - (hitX - left) / pxPerSec;
    const double secRight = nowSec + (right - hitX) / pxPerSec;
    const double beatLeft = song->secondsToBeat (juce::jmax (0.0, secLeft));
    const double beatRight = song->secondsToBeat (secRight);

    // ---- 指板（木纹）--------------------------------------------------------
    const auto nb = neckBounds();
    if (neckImage.isNull() || neckImage.getWidth() != (int) nb.getWidth() || neckImage.getHeight() != (int) nb.getHeight())
        buildNeckImage();
    g.drawImageAt (neckImage, (int) nb.getX(), (int) nb.getY());

    // ---- 小节线、拍线、段落 ---------------------------------------------------
    const float laneTop = nb.getY() + 3.0f, laneBottom = nb.getBottom() - 3.0f;
    juce::String lastSection;
    const int firstBar = juce::jmax (0, song->barIndexAt (beatLeft) - 1);
    for (int b = firstBar; b < (int) song->bars.size(); ++b)
    {
        const auto& bar = song->bars[(size_t) b];
        if (bar.start > beatRight) break;

        for (double beat = bar.start + 1.0; beat < bar.start + bar.length - 1.0e-6; beat += 1.0)
        {
            const float x = xForSeconds (song->beatToSeconds (beat), nowSec);
            g.setColour (juce::Colour (0xffd8d0c0).withAlpha (0.10f));
            g.fillRect (x, laneTop, 1.0f, laneBottom - laneTop);
        }

        // 小节线画成品丝：镍银色，中间亮两边暗
        const float x = xForSeconds (song->beatToSeconds (bar.start), nowSec);
        juce::ColourGradient fret (juce::Colour (0xff6f6a62), x - 2.5f, 0.0f, juce::Colour (0xff6f6a62), x + 2.5f, 0.0f, false);
        fret.addColour (0.45, juce::Colour (0xffeeeae2));
        g.setGradientFill (fret);
        g.fillRect (x - 2.5f, laneTop, 5.0f, laneBottom - laneTop);
        g.setColour (juce::Colours::black.withAlpha (0.35f));
        g.fillRect (x + 2.5f, laneTop, 2.0f, laneBottom - laneTop);
        g.setColour (juce::Colours::white.withAlpha (0.6f));
        g.setFont (juce::FontOptions (12.5f, juce::Font::bold));
        g.drawText (juce::String (bar.sourceIndex + 1), (int) x + 5, (int) laneTop - 18, 40, 14, juce::Justification::centredLeft);

        if (bar.section.isNotEmpty())
        {
            g.setFont (juce::FontOptions (13.0f, juce::Font::bold));
            const int w = juce::GlyphArrangement::getStringWidthInt (g.getCurrentFont(), bar.section) + 16;
            const auto chip = juce::Rectangle<float> (x + 4.0f, (float) laneArea.getY() + 2.0f, (float) w, 20.0f);
            g.setColour (juce::Colour (0xff2f6fdb).withAlpha (0.85f));
            g.fillRoundedRectangle (chip, 6.0f);
            g.setColour (juce::Colours::white);
            g.drawText (bar.section, chip, juce::Justification::centred);
        }
    }

    // ---- 弦：金属弦，越低越粗；4–6 弦是缠弦（有斜纹），下面垫一点这根弦的颜色当轨道 ----------
    // 正在推的弦：在判定线这里被推起来（弦本身弯过去，有推拉感）
    std::array<float, 16> pushPx {};
    {
        const float gapPx = strings > 1 ? yForString (1) - yForString (0) : 40.0f;
        const auto& ns = tr.notes;
        auto it = std::lower_bound (ns.begin(), ns.end(), song->secondsToBeat (juce::jmax (0.0, nowSec - 8.0)),
                                    [] (const SongNote& n, double b) { return n.start < b; });
        for (; it != ns.end() && it->start <= currentBeat() + 1.0e-6; ++it)
        {
            const size_t i = (size_t) std::distance (ns.begin(), it);
            if (it->bend <= 0.0f || it->dead || i >= startSec.size() || ! juce::isPositiveAndBelow (it->string, 16)) continue;
            if (nowSec < startSec[i] || nowSec > endSec[i]) continue;
            const float f = (float) ((nowSec - startSec[i]) / juce::jmax (1.0e-6, endSec[i] - startSec[i]));
            pushPx[(size_t) it->string] = juce::jmin (gapPx * 1.5f, it->bendAt (f) * gapPx * 0.42f);
        }
    }
    const float pushSpan = 130.0f;

    for (int s = 0; s < strings; ++s)
    {
        const float y = yForString (s);
        // 弦的粗细按空弦音高：吉他 1 弦最细，低音弦、贝斯的弦粗；比 E3 低的是缠弦
        const int open = s < (int) tr.tuning.size() ? tr.tuning[(size_t) s] : 64 - 5 * s;
        const float th = juce::jlimit (1.2f, 6.0f, 1.3f + 0.12f * (float) (64 - open));
        const bool wound = open < 52;
        const float push = s < 16 ? pushPx[(size_t) s] : 0.0f;
        if (push > 0.8f)
        {
            // 推起来的弦：两段直弦 + 中间一段弯起来
            const juce::Colour metal = wound ? juce::Colour (0xffc9a66b) : juce::Colour (0xffdcdde0);
            const float xa = juce::jmax (left + 64.0f, hitX - pushSpan), xb = juce::jmin (right, hitX + pushSpan);
            juce::Path bent;
            bent.startNewSubPath (left + 64.0f, y);
            bent.lineTo (xa, y);
            bent.cubicTo (xa + (hitX - xa) * 0.55f, y, hitX - 26.0f, y - push, hitX, y - push);
            bent.cubicTo (hitX + 26.0f, y - push, xb - (xb - hitX) * 0.55f, y, xb, y);
            bent.lineTo (right, y);
            g.setColour (colourForString (s).withAlpha (0.35f));
            g.strokePath (bent, juce::PathStrokeType (th * 4.4f));
            g.setColour (juce::Colours::black.withAlpha (0.45f));
            g.strokePath (bent, juce::PathStrokeType (th * 0.9f), juce::AffineTransform::translation (0.0f, th + 1.0f));
            g.setColour (metal.brighter (0.15f));
            g.strokePath (bent, juce::PathStrokeType (th));
            g.setColour (juce::Colours::white.withAlpha (0.5f));
            g.strokePath (bent, juce::PathStrokeType (juce::jmax (0.6f, th * 0.3f)), juce::AffineTransform::translation (0.0f, -th * 0.2f));
            // 手指推弦的位置
            g.setColour (colourForString (s).withAlpha (0.9f));
            g.fillEllipse (hitX - 7.0f, y - push - 7.0f, 14.0f, 14.0f);
            g.setColour (juce::Colours::white);
            g.drawEllipse (hitX - 7.0f, y - push - 7.0f, 14.0f, 14.0f, 1.6f);
            continue;
        }
        g.setColour (colourForString (s).withAlpha (0.16f));
        g.fillRect (left + 64.0f, y - th * 2.2f, right - left - 64.0f, th * 4.4f);
        g.setColour (juce::Colours::black.withAlpha (0.45f));
        g.fillRect (left + 64.0f, y + th * 0.5f + 1.0f, right - left - 64.0f, th * 0.8f);        // 弦在木头上的影子
        const juce::Colour metal = wound ? juce::Colour (0xffc9a66b) : juce::Colour (0xffdcdde0);
        juce::ColourGradient sg (metal.darker (0.5f), 0.0f, y - th * 0.5f, metal.darker (0.6f), 0.0f, y + th * 0.5f, false);
        sg.addColour (0.35, metal.brighter (0.35f));
        g.setGradientFill (sg);
        g.fillRect (left + 64.0f, y - th * 0.5f, right - left - 64.0f, th);
        if (wound)
        {
            g.setColour (juce::Colours::black.withAlpha (0.18f));
            for (float x = left + 64.0f; x < right; x += 3.0f)
                g.drawLine (x, y - th * 0.5f, x + 1.5f, y + th * 0.5f, 0.8f);
        }
    }

    // 判定线
    g.setColour (juce::Colours::white.withAlpha (0.08f));
    g.fillRect (hitX - 14.0f, laneTop, 28.0f, laneBottom - laneTop);
    g.setColour (juce::Colours::white.withAlpha (0.85f));
    g.fillRect (hitX - 1.5f, laneTop, 3.0f, laneBottom - laneTop);

    // ---- 音符 ---------------------------------------------------------------
    const auto& notes = tr.notes;
    const auto firstIt = std::lower_bound (notes.begin(), notes.end(), beatLeft - 16.0,
                                           [] (const SongNote& n, double b) { return n.start < b; });
    const float gemH = juce::jlimit (18.0f, 32.0f, (yForString (1) - yForString (0)) * 0.74f);

    // 和弦连接条：同一时刻的多个音
    for (auto it = firstIt; it != notes.end() && it->start <= beatRight; )
    {
        auto end = it;
        int minS = it->string, maxS = it->string;
        while (end != notes.end() && std::abs (end->start - it->start) < 1.0e-6)
        {
            minS = juce::jmin (minS, end->string);
            maxS = juce::jmax (maxS, end->string);
            ++end;
        }
        if (maxS > minS)
        {
            const float x = xForSeconds (song->beatToSeconds (it->start), nowSec);
            g.setColour (juce::Colours::white.withAlpha (x < hitX ? 0.06f : 0.16f));
            g.fillRoundedRectangle (x - 5.0f, yForString (minS), 10.0f, yForString (maxS) - yForString (minS), 5.0f);
        }
        it = end;
    }

    // 推弦：一个半音往上推多少像素（全音 ≈ 0.8 个弦距，像真的把弦推向邻弦）
    const float stringGap = strings > 1 ? yForString (1) - yForString (0) : 40.0f;
    const float pxPerSemi = stringGap * 0.42f;
    auto bendPx = [&] (float semis) { return juce::jmin (stringGap * 1.5f, semis * pxPerSemi); };

    // 拖尾、滑音线、推弦曲线（画在音符下面）
    for (auto it = firstIt; it != notes.end() && it->start <= beatRight; ++it)
    {
        const size_t i = (size_t) std::distance (notes.begin(), it);
        const auto& n = *it;
        const float x0 = xForSeconds (startSec[i], nowSec);
        const float x1 = xForSeconds (endSec[i], nowSec);
        const float y = yForString (n.string);
        const auto c = colourForString (n.string);
        if (x1 < left) continue;
        const bool past = endSec[i] < nowSec;

        if (n.slideOut && nextOnString[i] >= 0)
        {
            const auto& nx = notes[(size_t) nextOnString[i]];
            const float xn = xForSeconds (startSec[(size_t) nextOnString[i]], nowSec);
            const float dy = nx.fret > n.fret ? -8.0f : 8.0f;
            g.setColour (c.withAlpha (0.8f));
            g.drawLine (x0 + 14.0f, y - dy * 0.5f, xn - 14.0f, y + dy * 0.5f, n.slideLegato ? 3.0f : 2.2f);
            if (! n.slideLegato)
            {
                // 换把滑音：目标音还要拨，画个小竖线提示
                g.drawLine (xn - 14.0f, y + dy * 0.5f - 6.0f, xn - 14.0f, y + dy * 0.5f + 6.0f, 1.6f);
            }
        }
        else if (n.slideOff)
        {
            // 滑出：往下滑走、渐隐
            const float xe = juce::jmin (x1, x0 + 70.0f);
            juce::ColourGradient sg (c.withAlpha (0.85f), x0 + 14.0f, y, c.withAlpha (0.0f), xe, y, false);
            g.setGradientFill (sg);
            g.drawLine (x0 + 14.0f, y - 2.0f, xe, y + 9.0f, 3.0f);
        }

        if (n.bend > 0.0f && ! n.dead && x1 - x0 > 12.0f)
        {
            // 按推弦曲线画出“被推起来的弦”
            juce::Path curve;
            const int steps = juce::jlimit (8, 80, (int) ((x1 - x0) / 5.0f));
            for (int k = 0; k <= steps; ++k)
            {
                const float f = (float) k / (float) steps;
                const float px = x0 + (x1 - x0) * f;
                const float py = y - bendPx (n.bendAt (f));
                if (k == 0) curve.startNewSubPath (px, py); else curve.lineTo (px, py);
            }
            const float a = past ? 0.35f : 1.0f;
            g.setColour (juce::Colours::black.withAlpha (0.35f * a));
            g.strokePath (curve, juce::PathStrokeType (7.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded), juce::AffineTransform::translation (0.0f, 2.0f));
            g.setColour (c.withAlpha (0.75f * a));
            g.strokePath (curve, juce::PathStrokeType (6.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
            g.setColour (c.brighter (0.7f).withAlpha (0.8f * a));
            g.strokePath (curve, juce::PathStrokeType (1.6f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

            // 目标高度：虚线 + 推多少
            const float peakX = x0 + (x1 - x0) * n.bendPeakPos;
            const float peakY = y - bendPx (n.bend);
            float dashes[] = { 4.0f, 4.0f };
            g.setColour (c.brighter (0.4f).withAlpha (0.55f * a));
            g.drawDashedLine (juce::Line<float> (x0, peakY, juce::jmax (peakX, x0 + 30.0f), peakY), dashes, 2, 1.2f);
            // 推弦方向的小箭头
            if (n.bendPeakPos > 0.05f)
            {
                const float ax = x0 + (x1 - x0) * n.bendPeakPos * 0.55f;
                const float ay = y - bendPx (n.bendAt (n.bendPeakPos * 0.55f));
                juce::Path arrow;
                arrow.addTriangle (ax - 5.0f, ay + 3.0f, ax + 5.0f, ay + 3.0f, ax, ay - 6.0f);
                g.setColour (juce::Colours::white.withAlpha (0.85f * a));
                g.fillPath (arrow);
            }
            // 放回：向下的箭头
            if (n.bendEnd < n.bend - 0.2f && n.bendEndPos > n.bendReleasePos)
            {
                const float f = (n.bendReleasePos + n.bendEndPos) * 0.5f;
                const float ax = x0 + (x1 - x0) * f;
                const float ay = y - bendPx (n.bendAt (f));
                juce::Path arrow;
                arrow.addTriangle (ax - 5.0f, ay - 3.0f, ax + 5.0f, ay - 3.0f, ax, ay + 6.0f);
                g.setColour (juce::Colours::white.withAlpha (0.85f * a));
                g.fillPath (arrow);
            }

            // 标签：预推 / 推多少
            juce::String label = (n.bendStart > 0.2f ? T ("预推 ") : juce::String()) + bendText (n.bend);
            g.setFont (juce::FontOptions (12.5f, juce::Font::bold));
            const float lw = 14.0f + juce::GlyphArrangement::getStringWidth (g.getCurrentFont(), label);
            auto pill = juce::Rectangle<float> (juce::jmax (x0 + 16.0f, peakX - lw * 0.5f), peakY - 21.0f, lw, 17.0f);
            g.setColour (juce::Colour (0xff1b1d22).withAlpha (0.9f * a));
            g.fillRoundedRectangle (pill, 8.5f);
            g.setColour (c.withAlpha (a));
            g.drawRoundedRectangle (pill, 8.5f, 1.4f);
            g.setColour (juce::Colours::white.withAlpha (a));
            g.drawText (label, pill, juce::Justification::centred);

            // 弹过以后：推到位没有
            if (judge != nullptr && judgeVisible && i < judge->noteToEvent.size() && judge->noteToEvent[i] >= 0)
            {
                const float reached = judge->bendReachedOf (judge->noteToEvent[i]);
                if (reached >= 0.0f)
                {
                    const float diff = n.bend - reached;
                    juce::String fb;
                    juce::Colour fc;
                    if (diff <= 0.35f && diff >= -0.5f) { fb = T ("到位"); fc = juce::Colour (0xff5bd47a); }
                    else if (diff > 0.35f)                 { fb = T ("差") + bendText (diff); fc = juce::Colour (0xffffa23a); }
                    else                                   { fb = T ("推过了"); fc = juce::Colour (0xffffa23a); }
                    auto fr = juce::Rectangle<float> (pill.getRight() + 4.0f, pill.getY(), 50.0f, 17.0f);
                    g.setColour (fc.withAlpha (0.9f));
                    g.fillRoundedRectangle (fr, 8.5f);
                    g.setColour (juce::Colours::black);
                    g.setFont (juce::FontOptions (11.5f, juce::Font::bold));
                    g.drawText (fb, fr, juce::Justification::centred);
                    // 实际推到的高度
                    const float ry = y - bendPx (reached);
                    g.setColour (fc);
                    g.fillEllipse (peakX - 4.0f, ry - 4.0f, 8.0f, 8.0f);
                }
            }
        }
        else if (x1 - x0 > 34.0f && ! n.dead && ! n.slideOut)
        {
            const float tailH = juce::jmax (8.0f, gemH * 0.42f);
            juce::Path tail;
            if (n.vibrato)
            {
                tail.startNewSubPath (x0, y);
                for (float x = x0; x < x1; x += 4.0f)
                    tail.lineTo (x, y + 3.0f * std::sin ((x - x0) * 0.35f));
                g.setColour (c.withAlpha (0.55f));
                g.strokePath (tail, juce::PathStrokeType (4.0f));
            }
            else
            {
                g.setColour (c.withAlpha (n.palmMute ? 0.3f : 0.55f));
                g.fillRoundedRectangle (x0, y - tailH * 0.5f, x1 - x0, tailH, tailH * 0.5f);
            }
        }
    }

    // 击弦 / 勾弦 / 点弦：从上一个音到这个音画一道连线，中间标 H / P / T（标签等音符画完再画，不被挡住）
    struct TechPill { juce::Rectangle<float> r; juce::Colour c; char kind; float alpha; };
    std::vector<TechPill> techPills;
    for (auto it = firstIt; it != notes.end() && it->start <= beatRight; ++it)
    {
        const size_t i = (size_t) std::distance (notes.begin(), it);
        if (i >= hopoLabel.size() || hopoLabel[i] == 0) continue;
        const float x = xForSeconds (startSec[i], nowSec);
        if (x < left - 30.0f) continue;
        const float y = yForString (it->string);
        const char kind = hopoLabel[i];
        const juce::Colour kc = kind == 'H' ? juce::Colour (0xff45d6c8) : (kind == 'P' ? juce::Colour (0xffff9f43) : juce::Colour (0xffe07bff));
        const bool past = startSec[i] < nowSec - 0.06;
        const float a = past ? 0.4f : 1.0f;
        const int p = i < prevOnString.size() ? prevOnString[i] : -1;
        float pillX = x - gemH * 0.62f - 12.0f, pillY = y - gemH * 0.5f - 8.0f;   // 点弦：贴在音符左上角
        if (p >= 0 && kind != 'T')
        {
            const float xp = xForSeconds (startSec[(size_t) p], nowSec);
            if (x - xp < 900.0f && x - xp > gemH * 1.24f + 26.0f)
            {
                // 连线留在这根弦自己的范围里：从上一个音的右上角拱到这个音的左上角
                const float half = gemH * 0.62f;
                const float base = y - gemH * 0.3f;
                const float lift = juce::jlimit (6.0f, stringGap * 0.34f, (x - xp) * 0.12f);
                juce::Path arc;
                arc.startNewSubPath (xp + half, base);
                arc.quadraticTo ((xp + x) * 0.5f, base - lift * 2.0f, x - half, base);
                g.setColour (juce::Colours::black.withAlpha (0.5f * a));
                g.strokePath (arc, juce::PathStrokeType (4.4f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
                g.setColour (kc.withAlpha (0.95f * a));
                g.strokePath (arc, juce::PathStrokeType (2.6f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
                pillX = (xp + x) * 0.5f - 9.0f;
                pillY = base - lift - 8.5f;
            }
        }
        techPills.push_back ({ juce::Rectangle<float> (pillX, pillY, 18.0f, 17.0f), kc, kind, a });
    }

    // 音符块
    for (auto it = firstIt; it != notes.end() && it->start <= beatRight; ++it)
    {
        const size_t i = (size_t) std::distance (notes.begin(), it);
        const auto& n = *it;
        const float x = xForSeconds (startSec[i], nowSec);
        if (x < left - 30.0f) continue;
        const float y = yForString (n.string);
        const auto c = colourForString (n.string);

        const juce::String label = n.dead ? juce::String::fromUTF8 ("\xc3\x97") : juce::String (n.fret);
        const float w = juce::jmax (gemH * 1.15f, 12.0f + 9.0f * (float) label.length());
        auto gem = juce::Rectangle<float> (x - w * 0.5f, y - gemH * 0.5f, w, gemH);

        // 已经过了判定线的音变暗；正在判定线上的音发亮
        const double dt = (startSec[i] - nowSec);
        const bool past = dt < -0.06;
        const bool atLine = std::abs (dt) <= 0.06;
        float alpha = past ? juce::jmax (0.15f, 0.6f - (float) (-dt) * 1.5f) : 1.0f;

        if (atLine)
        {
            g.setColour (c.withAlpha (0.35f));
            g.fillRoundedRectangle (gem.expanded (7.0f), 10.0f);
        }

        if (n.harmonic)
        {
            juce::Path d;
            d.addPolygon (gem.getCentre(), 4, gemH * 0.72f, juce::MathConstants<float>::pi * 0.25f);
            g.setColour (c.withAlpha (alpha));
            g.fillPath (d);
        }
        else
        {
            g.setColour (juce::Colours::black.withAlpha (0.5f * alpha));
            g.fillRoundedRectangle (gem.translated (0.0f, 2.0f).expanded (1.0f), 8.0f);
            g.setColour (c.withAlpha (alpha));
            g.fillRoundedRectangle (gem, 7.0f);
            g.setColour (juce::Colours::white.withAlpha (0.25f * alpha));
            g.fillRoundedRectangle (gem.withHeight (gemH * 0.42f).reduced (2.0f, 1.5f), 5.0f);
            g.setColour (c.darker (0.6f).withAlpha (alpha));
            g.drawRoundedRectangle (gem, 7.0f, 1.2f);
        }
        if (n.accent && ! past)
        {
            g.setColour (juce::Colours::white.withAlpha (0.9f));
            g.drawRoundedRectangle (gem.expanded (2.0f), 8.0f, 1.5f);
        }

        // 品号：更大、带深色描边，远处也看得清
        {
            const float fs = juce::jlimit (14.0f, 24.0f, gemH * 0.86f);
            g.setFont (juce::FontOptions (fs, juce::Font::bold));
            g.setColour (juce::Colours::black.withAlpha (0.55f * juce::jmax (0.35f, alpha)));
            for (auto o : { juce::Point<float> (-1.2f, 0.0f), juce::Point<float> (1.2f, 0.0f), juce::Point<float> (0.0f, -1.2f), juce::Point<float> (0.0f, 1.4f) })
                g.drawText (label, gem.translated (o.x, o.y), juce::Justification::centred);
            g.setColour (juce::Colours::white.withAlpha (juce::jmax (0.35f, alpha)));
            g.drawText (label, gem, juce::Justification::centred);
        }

        // 判定结果：金色 = Perfect，绿 = Good，橙 = 弹错，红叉 = 漏弹
        if (judge != nullptr && judgeVisible && i < judge->noteToEvent.size() && judge->noteToEvent[i] >= 0)
        {
            const auto v = judge->verdictOf (judge->noteToEvent[i]);
            if (v != Verdict::pending)
            {
                const auto vc = verdictColour (v);
                g.setColour (vc);
                g.drawRoundedRectangle (gem.expanded (2.5f), 8.0f, 2.5f);
                if (v == Verdict::miss || v == Verdict::wrongNote)
                {
                    g.setColour (vc.withAlpha (0.85f));
                    g.drawLine (gem.getX() + 3.0f, gem.getY() + 3.0f, gem.getRight() - 3.0f, gem.getBottom() - 3.0f, 2.5f);
                    g.drawLine (gem.getRight() - 3.0f, gem.getY() + 3.0f, gem.getX() + 3.0f, gem.getBottom() - 3.0f, 2.5f);
                }
            }
        }

        // 技巧标记（画在音符上方）
        juce::String tag;
        if (n.palmMute) tag << "PM ";
        if (n.slideIn) tag << "/";
        // 音名（紧贴音符上方），技巧标记再往上一行
        float tagY = gem.getY() - 15.0f;
        if (showNoteNames && ! n.dead)
        {
            const int midi = n.midi;
            const juce::String name = noteName (midi) + juce::String (midi / 12 - 1);
            g.setFont (juce::FontOptions (12.0f, juce::Font::bold));
            g.setColour (c.brighter (0.5f).withAlpha (past ? 0.35f : 0.95f));
            g.drawText (name, juce::Rectangle<float> (x - 30.0f, gem.getY() - 15.0f, 60.0f, 14.0f), juce::Justification::centred);
            tagY -= 13.0f;
        }
        if (tag.isNotEmpty())
        {
            g.setFont (juce::FontOptions (11.5f, juce::Font::bold));
            g.setColour (juce::Colours::white.withAlpha (past ? 0.3f : 0.85f));
            g.drawText (tag.trim(), (int) (x - 40), (int) tagY, 80, 14, juce::Justification::centred);
        }
    }

    for (auto& tp : techPills)
    {
        g.setColour (juce::Colours::black.withAlpha (0.5f * tp.alpha));
        g.fillRoundedRectangle (tp.r.translated (0.0f, 1.5f), 5.0f);
        g.setColour (tp.c.withAlpha (tp.alpha));
        g.fillRoundedRectangle (tp.r, 5.0f);
        g.setColour (juce::Colours::black.withAlpha (0.85f * tp.alpha));
        g.setFont (juce::FontOptions (13.0f, juce::Font::bold));
        g.drawText (juce::String::charToString ((juce::juce_wchar) tp.kind), tp.r, juce::Justification::centred);
    }

    // ---- 左边：琴头 + 琴枕 + 弦名 ---------------------------------------------
    g.setColour (bg.withAlpha (0.94f));
    g.fillRect (left, nb.getY() - 4.0f, 62.0f, nb.getHeight() + 8.0f);
    g.setColour (juce::Colour (0xffece4d0));                 // 骨质琴枕
    g.fillRect (left + 60.0f, nb.getY(), 6.0f, nb.getHeight());
    if (tr.isBass() || strings != 6)
    {
        // 不是 6 弦吉他：标一下是什么乐器
        g.setColour (tr.isBass() ? juce::Colour (0xffffb454) : juce::Colour (0xff9cc4ff));
        g.setFont (juce::FontOptions (11.5f, juce::Font::bold));
        g.drawText ((tr.isBass() ? T ("贝斯 · ") : T ("吉他 · ")) + juce::String (strings) + T (" 弦"),
                    juce::Rectangle<float> (left + 2.0f, nb.getY() - 20.0f, 80.0f, 16.0f), juce::Justification::centredLeft);
    }
    g.setColour (juce::Colours::black.withAlpha (0.4f));
    g.fillRect (left + 66.0f, nb.getY(), 2.0f, nb.getHeight());
    for (int s = 0; s < strings; ++s)
    {
        const float y = yForString (s);
        const auto c = colourForString (s);
        g.setColour (c);
        g.fillEllipse (left + 12.0f, y - 11.0f, 22.0f, 22.0f);
        g.setColour (juce::Colours::white);
        g.setFont (juce::FontOptions (12.0f, juce::Font::bold));
        g.drawText (juce::String (s + 1), juce::Rectangle<float> (left + 12.0f, y - 11.0f, 22.0f, 22.0f), juce::Justification::centred);
        if (s < (int) tr.tuning.size())
        {
            g.setColour (juce::Colours::white.withAlpha (0.7f));
            g.setFont (juce::FontOptions (12.5f));
            g.drawText (noteName (tr.tuning[(size_t) s]), (int) left + 38, (int) y - 8, 24, 16, juce::Justification::centredLeft);
        }
    }

    paintChordBox (g, nowBeat);

    if (judge != nullptr && judgeVisible)
        paintJudgeHud (g, nowBeat);

    // 预备拍提示
    if (player.isCountingIn() && frozenBeat < 0.0)
    {
        g.setColour (juce::Colours::white.withAlpha (0.85f));
        g.setFont (juce::FontOptions (40.0f, juce::Font::bold));
        g.drawText (T ("预备…"), laneArea, juce::Justification::centred);
    }
    juce::ignoreUnused (nowBeat);
}

void TabHighway::paintTimeline (juce::Graphics& g, double nowBeat)
{
    const auto r = timelineArea.toFloat();
    g.setColour (juce::Colour (0xff23272e));
    g.fillRoundedRectangle (r, 6.0f);

    const double len = juce::jmax (1.0, song->lengthBeats);
    auto xFor = [&] (double beat) { return r.getX() + (float) (beat / len) * r.getWidth(); };

    // 段落
    g.setFont (juce::FontOptions (11.0f));
    std::vector<float> sectionX;
    for (auto& bar : song->bars)
        if (bar.section.isNotEmpty())
            sectionX.push_back (xFor (bar.start));
    size_t si = 0;
    for (auto& bar : song->bars)
        if (bar.section.isNotEmpty())
        {
            const float x = sectionX[si];
            const float nextX = si + 1 < sectionX.size() ? sectionX[si + 1] : r.getRight();
            ++si;
            g.setColour (juce::Colours::white.withAlpha (0.35f));
            g.fillRect (x, r.getY(), 1.0f, r.getHeight());
            const int room = (int) (nextX - x) - 6;
            if (room < 24) continue;     // 段落太密就只画分隔线
            g.setColour (juce::Colours::white.withAlpha (0.6f));
            g.drawFittedText (bar.section, (int) x + 3, (int) r.getY(), room, (int) r.getHeight(),
                              juce::Justification::centredLeft, 1, 1.0f);
        }

    // 每个小节的命中率（进度条上沿一条色带）
    if (judge != nullptr && judgeVisible)
    {
        if (++framesSinceBarUpdate > 10 || barAccuracy.size() != song->bars.size())
        {
            barAccuracy = judge->perBarAccuracy();
            framesSinceBarUpdate = 0;
        }
        for (size_t i = 0; i < barAccuracy.size() && i < song->bars.size(); ++i)
            if (barAccuracy[i] >= 0.0f)
            {
                const auto& bar = song->bars[i];
                g.setColour (accuracyColour (barAccuracy[i]));
                g.fillRect (juce::Rectangle<float> (xFor (bar.start), r.getY(), juce::jmax (1.0f, xFor (bar.start + bar.length) - xFor (bar.start)), 5.0f));
            }
    }

    // A-B 循环
    double a = player.getLoopA(), b = player.getLoopB();
    bool showLoop = player.isLooping();
    if (draggingLoop) { a = juce::jmin (dragStartBeat, dragEndBeat); b = juce::jmax (dragStartBeat, dragEndBeat); showLoop = true; }
    if (showLoop)
    {
        g.setColour (juce::Colour (0xff37b24d).withAlpha (0.35f));
        g.fillRect (juce::Rectangle<float> (xFor (a), r.getY(), xFor (b) - xFor (a), r.getHeight()));
        g.setColour (juce::Colour (0xff37b24d));
        g.fillRect (xFor (a), r.getY(), 2.0f, r.getHeight());
        g.fillRect (xFor (b) - 2.0f, r.getY(), 2.0f, r.getHeight());
    }

    // 已播放部分 + 播放头
    g.setColour (juce::Colour (0xff3d8ff0).withAlpha (0.35f));
    g.fillRoundedRectangle (r.withWidth (xFor (nowBeat) - r.getX()), 6.0f);
    g.setColour (juce::Colours::white);
    g.fillRect (xFor (nowBeat) - 1.5f, r.getY() - 3.0f, 3.0f, r.getHeight() + 6.0f);
}

double TabHighway::beatAtTimelineX (float x) const
{
    if (song == nullptr) return 0.0;
    const auto r = timelineArea.toFloat();
    return juce::jlimit (0.0, song->lengthBeats, (double) ((x - r.getX()) / r.getWidth()) * song->lengthBeats);
}

void TabHighway::mouseDown (const juce::MouseEvent& e)
{
    if (song != nullptr && viewMode == ViewMode::staff && laneArea.contains (e.getPosition()) && staffMouseDown (e))
        return;
    if (song == nullptr || ! timelineArea.expanded (0, 6).contains (e.getPosition()))
        return;
    dragStartBeat = dragEndBeat = beatAtTimelineX ((float) e.x);
    draggingLoop = false;
}

void TabHighway::mouseDoubleClick (const juce::MouseEvent& e)
{
    if (editor == nullptr || ! editor->isActive() || viewMode != ViewMode::staff || song == nullptr) return;
    int b = 0, s = 0, r = 0; double beat = 0.0;
    if (! staffHit (e.position, b, beat, s, r)) return;
    if (e.position.y < staffLineY (r, 0) - 18.0f && onEditChord)
    {
        // 和弦那一行：吸附到拍上
        const auto& br = song->bars[(size_t) b];
        onEditChord (juce::jlimit (br.start, br.start + br.length - 1.0, br.start + std::floor (beat - br.start + 0.25)));
    }
}

void TabHighway::mouseDrag (const juce::MouseEvent& e)
{
    if (editor != nullptr && editor->isActive() && viewMode == ViewMode::staff && laneArea.contains (e.getMouseDownPosition()))
    {
        editDragNow = e.position;
        editDragging = e.getDistanceFromDragStart() > 6;
        repaint();
        return;
    }
    if (song == nullptr || ! timelineArea.expanded (0, 6).contains (e.getMouseDownPosition()))
        return;
    if (e.getDistanceFromDragStart() > 6)
    {
        draggingLoop = true;
        dragEndBeat = beatAtTimelineX ((float) e.x);
        repaint();
    }
}

void TabHighway::mouseUp (const juce::MouseEvent& e)
{
    if (editor != nullptr && editor->isActive() && viewMode == ViewMode::staff && laneArea.contains (e.getMouseDownPosition()))
    {
        if (editDragging)
        {
            editDragging = false;
            int b0 = 0, s0 = 0, r0 = 0, b1 = 0, s1 = 0, r1 = 0; double t0 = 0.0, t1 = 0.0;
            if (staffHit (editDragStart, b0, t0, s0, r0) && staffHit (e.position, b1, t1, s1, r1))
            {
                editor->selectRange (juce::jmin (t0, t1), juce::jmax (t0, t1), s0, s1, e.mods.isShiftDown());
                if (onEditSelectionChanged) onEditSelectionChanged();
            }
            repaint();
        }
        return;
    }
    if (song == nullptr || ! timelineArea.expanded (0, 6).contains (e.getMouseDownPosition()))
        return;

    if (draggingLoop)
    {
        draggingLoop = false;
        // 循环段对齐到小节
        const double a = juce::jmin (dragStartBeat, dragEndBeat), b = juce::jmax (dragStartBeat, dragEndBeat);
        const int ia = song->barIndexAt (a), ib = song->barIndexAt (b);
        if (ia >= 0 && ib >= 0 && onLoopDragged)
        {
            const auto& barB = song->bars[(size_t) ib];
            onLoopDragged (song->bars[(size_t) ia].start, barB.start + barB.length);
        }
    }
    else
    {
        // 单击：跳到所在小节开头
        const int bi = song->barIndexAt (beatAtTimelineX ((float) e.x));
        if (bi >= 0)
            player.seek (song->bars[(size_t) bi].start);
    }
    repaint();
}

// ---- 判定：飘字、计分板、等待提示 ---------------------------------------------------
void TabHighway::paintJudgeHud (juce::Graphics& g, double nowBeat)
{
    const auto& tr = song->tracks[(size_t) track];

    // 新的判定 -> 飘字
    if (const auto seq = judge->lastSeq.load(); seq != seenSeq)
    {
        seenSeq = seq;
        const auto v = (Verdict) judge->lastVerdict.load();
        const int e = judge->lastEvent.load();
        const float off = judge->lastOffsetMs.load();
        flash.time = nowSeconds();
        flash.colour = verdictColour (v);
        flash.detail = {};
        switch (v)
        {
            case Verdict::perfect:   flash.text = "PERFECT"; break;
            case Verdict::good:      flash.text = "GOOD"; break;
            case Verdict::wrongNote: flash.text = T ("错音"); break;
            case Verdict::miss:      flash.text = "MISS"; break;
            case Verdict::pending:   flash.text = {}; break;
        }
        if ((v == Verdict::perfect || v == Verdict::good) && ! waitMode && std::abs (off) >= 8.0f)
            flash.detail = (off < 0 ? T ("早 ") : T ("晚 ")) + juce::String (juce::roundToInt (std::abs (off))) + " ms";
        flash.string = 0;
        if (juce::isPositiveAndBelow (e, (int) judge->events.size()))
            flash.string = tr.notes[(size_t) judge->events[(size_t) e].firstNote].string;
    }

    const double age = nowSeconds() - flash.time;
    if (flash.text.isNotEmpty() && age < 0.8)
    {
        const float a = (float) juce::jlimit (0.0, 1.0, 1.0 - (age - 0.35) / 0.45);
        const float rise = (float) age * 30.0f;
        const float baseY = viewMode == ViewMode::staff ? flashAnchor.y : yForString (flash.string) - 30.0f;
        const float y = juce::jlimit ((float) laneArea.getY() + 30.0f, (float) laneArea.getBottom() - 30.0f, baseY - rise);
        const float hitX = viewMode == ViewMode::staff ? juce::jlimit ((float) laneArea.getX() + 90.0f, (float) laneArea.getRight() - 90.0f, flashAnchor.x) : this->hitX;
        g.setFont (juce::FontOptions (20.0f, juce::Font::bold));
        g.setColour (juce::Colours::black.withAlpha (0.5f * a));
        g.drawText (flash.text, juce::Rectangle<float> (hitX - 79.0f, y - 13.0f, 160.0f, 26.0f), juce::Justification::centred);
        g.setColour (flash.colour.withAlpha (a));
        g.drawText (flash.text, juce::Rectangle<float> (hitX - 80.0f, y - 14.0f, 160.0f, 26.0f), juce::Justification::centred);
        if (flash.detail.isNotEmpty())
        {
            g.setFont (juce::FontOptions (12.5f));
            g.setColour (juce::Colours::white.withAlpha (0.8f * a));
            g.drawText (flash.detail, juce::Rectangle<float> (hitX - 80.0f, y + 10.0f, 160.0f, 16.0f), juce::Justification::centred);
        }
    }

    // 计分板（右上角）
    const auto st = judge->computeStats();
    auto box = juce::Rectangle<float> ((float) laneArea.getRight() - 236.0f, (float) laneArea.getY() + 4.0f, 228.0f, 50.0f);
    g.setColour (juce::Colours::black.withAlpha (0.55f));
    g.fillRoundedRectangle (box, 8.0f);
    auto inner = box.reduced (10.0f, 5.0f);
    auto top = inner.removeFromTop (22.0f);
    g.setFont (juce::FontOptions (18.0f, juce::Font::bold));
    g.setColour (st.judged() > 0 ? accuracyColour (st.accuracy()) : juce::Colours::white.withAlpha (0.6f));
    g.drawText (st.judged() > 0 ? juce::String (juce::roundToInt (st.accuracy() * 100.0f)) + "%" : "--", top.removeFromLeft (64.0f), juce::Justification::centredLeft);
    g.setColour (juce::Colours::white);
    g.setFont (juce::FontOptions (14.0f, juce::Font::bold));
    const int combo = judge->combo.load();
    g.drawText (waitMode ? T ("等待模式") : (combo >= 2 ? juce::String (combo) + T (" 连击") : juce::String()),
                top, juce::Justification::centredRight);
    g.setFont (juce::FontOptions (12.0f));
    g.setColour (juce::Colours::white.withAlpha (0.75f));
    juce::String line;
    line << "P " << st.perfect << "   G " << st.good << T ("   错 ") << st.wrong << "   M " << st.miss;
    const int passes = judge->passes.load();
    if (passes > 0 && judge->lastPassAccuracy.load() >= 0.0f)
        line << T ("   上遍 ") << juce::String (juce::roundToInt (judge->lastPassAccuracy.load() * 100.0f)) << "%";
    g.drawText (line, inner, juce::Justification::centredLeft);

    // 等待模式：提示该弹哪个音
    if (waitMode && player.isPlaying() && ! player.isCountingIn())
    {
        const auto& ev = judge->events;
        auto it = std::lower_bound (ev.begin(), ev.end(), nowBeat - 1.0e-6, [] (const JudgeEvent& e, double x) { return e.beat < x; });
        for (; it != ev.end(); ++it)
            if (judge->verdictOf ((int) (it - ev.begin())) == Verdict::pending)
                break;
        if (it != ev.end() && it->beat - nowBeat < 0.02)
        {
            const float pulse = 0.5f + 0.5f * (float) std::sin (nowSeconds() * 6.0);
            g.setColour (juce::Colour (0xff6fa8ff).withAlpha (0.25f + 0.35f * pulse));
            if (viewMode == ViewMode::lanes)
                g.fillRect (hitX - 4.0f, (float) laneArea.getY() + 24.0f, 8.0f, (float) laneArea.getHeight() - 30.0f);

            juce::StringArray names;
            for (int k = it->firstNote; k < it->firstNote + it->numNotes; ++k)
            {
                const auto& n = tr.notes[(size_t) k];
                names.add (juce::String (n.string + 1) + T (" 弦 ") + (n.dead ? juce::String::fromUTF8 ("\xc3\x97") : juce::String (n.fret) + T (" 品")));
            }
            g.setFont (juce::FontOptions (13.0f, juce::Font::bold));
            g.setColour (juce::Colour (0xff9cc4ff));
            const float tx = viewMode == ViewMode::staff ? (float) laneArea.getX() + 16.0f : hitX + 16.0f;
            g.drawText (T ("等你弹：") + names.joinIntoString ("  "), juce::Rectangle<float> (tx, (float) laneArea.getBottom() - 22.0f, 420.0f, 18.0f),
                        juce::Justification::centredLeft);
        }
    }
}

// =============================================================================
// 六线谱模式：像纸上的吉他谱一样一行行排版，光标跟着播放走，整页跟着往下翻。
// 弹奏判定照常：判过的音按结果上色（金 Perfect、绿 Good、橙 错音、红 漏弹）。
// =============================================================================
namespace
{
    const juce::Colour paper     { 0xfff6f1e4 };
    const juce::Colour paperEdge { 0xffd9d0bb };
    const juce::Colour ink       { 0xff23211d };
    const juce::Colour inkSoft   { 0xff7d776a };
    const juce::Colour cursorBlue { 0xff2f7de1 };

    juce::Colour staffVerdictColour (Verdict v)
    {
        switch (v)
        {
            case Verdict::perfect:   return juce::Colour (0xffc08400);
            case Verdict::good:      return juce::Colour (0xff1e9a4b);
            case Verdict::wrongNote: return juce::Colour (0xffe0650a);
            case Verdict::miss:      return juce::Colour (0xffd62f2f);
            case Verdict::pending:   break;
        }
        return ink;
    }
}

void TabHighway::layoutStaff()
{
    const int width = laneArea.getWidth();
    if (song == nullptr || ! juce::isPositiveAndBelow (track, (int) song->tracks.size()))
        return;
    staffLayoutWidth = width;

    const auto& tr = song->tracks[(size_t) track];
    const int strings = juce::jmax (1, tr.stringCount());
    // 行距：至少能看到两行
    const float avail = (float) laneArea.getHeight() - 16.0f;
    staffLineGap = juce::jlimit (11.0f, 16.0f, (avail / 2.1f - 72.0f) / (float) juce::jmax (1, strings - 1));
    staffTopPad = tr.chords.empty() ? 38.0f : 54.0f;        // 有和弦名就多留一行
    staffRowH = staffTopPad + staffLineGap * (float) (strings - 1) + 40.0f;

    const size_t nb = song->bars.size();
    staffBarX.assign (nb, 0.0f);
    staffBarW.assign (nb, 0.0f);
    staffBarRow.assign (nb, 0);
    staffShowTimeSig.assign (nb, 0);
    staffRows.clear();

    const float rowLeft = (float) laneArea.getX() + 14.0f + 30.0f;     // 左边留给 TAB 字样
    const float rowWidth = (float) laneArea.getRight() - 14.0f - rowLeft;

    // 每小节自然宽度：最密的两个音之间至少留 26 像素
    std::vector<float> natural (nb, 110.0f);
    const auto& notes = tr.notes;
    size_t ni = 0;
    for (size_t b = 0; b < nb; ++b)
    {
        const auto& bar = song->bars[b];
        staffShowTimeSig[b] = (b == 0 || bar.numerator != song->bars[b - 1].numerator || bar.denominator != song->bars[b - 1].denominator) ? 1 : 0;
        while (ni < notes.size() && notes[ni].start < bar.start - 1.0e-6) ++ni;
        double minGap = 1.0e9, last = -1.0;
        int onsets = 0;
        for (size_t k = ni; k < notes.size() && notes[k].start < bar.start + bar.length - 1.0e-6; ++k)
        {
            if (last >= 0.0 && notes[k].start - last > 1.0e-6) minGap = juce::jmin (minGap, notes[k].start - last);
            if (last < 0.0 || notes[k].start - last > 1.0e-6) ++onsets;
            last = notes[k].start;
        }
        float w = 90.0f;
        if (onsets > 0)
        {
            const double g = juce::jmin (minGap, bar.length / juce::jmax (1, onsets));
            w = (float) (bar.length / juce::jmax (0.0625, g)) * 30.0f + 34.0f;
        }
        if (staffShowTimeSig[b]) w += 18.0f;
        natural[b] = juce::jlimit (90.0f, rowWidth, w);
    }

    // 按行排，排满一行以后拉伸到整行宽
    size_t b = 0;
    while (b < nb)
    {
        StaffRow row;
        row.firstBar = (int) b;
        float sum = 0.0f;
        while (b < nb && (sum + natural[b] <= rowWidth || b == (size_t) row.firstBar))
            sum += natural[b++];
        row.lastBar = (int) b - 1;
        const bool lastRow = b >= nb;
        // 最后一行排不满：适当拉宽一点（最多 1.8 倍），不硬撑满整行
        const float scale = (lastRow && sum < rowWidth * 0.8f) ? juce::jmin (1.8f, rowWidth / juce::jmax (1.0f, sum))
                                                                : rowWidth / juce::jmax (1.0f, sum);
        float x = rowLeft;
        for (int k = row.firstBar; k <= row.lastBar; ++k)
        {
            staffBarX[(size_t) k] = x;
            staffBarW[(size_t) k] = natural[(size_t) k] * scale;
            staffBarRow[(size_t) k] = (int) staffRows.size();
            x += staffBarW[(size_t) k];
        }
        staffRows.push_back (row);
    }
}

float TabHighway::staffX (int b, double beat) const
{
    const auto& bar = song->bars[(size_t) b];
    const float pad = 14.0f + (staffShowTimeSig[(size_t) b] ? 18.0f : 0.0f);
    const float w = staffBarW[(size_t) b] - pad - 10.0f;
    return staffBarX[(size_t) b] + pad + (float) ((beat - bar.start) / juce::jmax (1.0e-6, bar.length)) * w;
}

float TabHighway::staffLineY (int r, int s) const
{
    return (float) laneArea.getY() + 8.0f - staffScroll + (float) r * staffRowH + staffTopPad + staffLineGap * (float) s;
}

bool TabHighway::staffHit (juce::Point<float> p, int& bar, double& beat, int& string, int& row) const
{
    if (staffRows.empty() || song == nullptr) return false;
    const float top = (float) laneArea.getY() + 8.0f - staffScroll;
    row = (int) std::floor ((p.y - top) / staffRowH);
    if (! juce::isPositiveAndBelow (row, (int) staffRows.size())) return false;
    const int strings = juce::jmax (1, song->tracks[(size_t) track].stringCount());
    string = juce::jlimit (0, strings - 1, (int) std::round ((p.y - staffLineY (row, 0)) / staffLineGap));
    for (int b = staffRows[(size_t) row].firstBar; b <= staffRows[(size_t) row].lastBar; ++b)
        if (p.x >= staffBarX[(size_t) b] && p.x < staffBarX[(size_t) b] + staffBarW[(size_t) b])
        {
            bar = b;
            const auto& br = song->bars[(size_t) b];
            const float x0 = staffX (b, br.start), x1 = staffX (b, br.start + br.length);
            beat = br.start + juce::jlimit (0.0, br.length - 1.0e-6, (double) ((p.x - x0) / juce::jmax (1.0f, x1 - x0)) * br.length);
            return true;
        }
    return false;
}

bool TabHighway::staffMouseDown (const juce::MouseEvent& e)
{
    if (editor != nullptr && editor->isActive())
    {
        int b = 0, s = 0, r = 0; double beat = 0.0;
        if (! staffHit (e.position, b, beat, s, r)) return true;
        // 点到音的数字上：选那个音；点空白：光标吸附到格子上
        const auto& ns = song->tracks[(size_t) track].notes;
        double best = 1.0e9, at = -1.0;
        for (auto& n : ns)
        {
            if (n.string != s || song->barIndexAt (n.start + 1.0e-9) != b) continue;
            const float dx = std::abs (staffX (b, n.start) - e.position.x);
            if (dx < 12.0f && dx < best) { best = dx; at = n.start; }
        }
        if (at < 0.0)
        {
            const auto& br = song->bars[(size_t) b];
            at = br.start + std::round ((beat - br.start) / editor->grid) * editor->grid;
            at = juce::jlimit (br.start, br.start + br.length - editor->grid, at);
        }
        editor->select (at, s, e.mods.isShiftDown() || e.mods.isCommandDown());
        editDragging = false;
        editDragStart = editDragNow = e.position;
        if (onEditSelectionChanged) onEditSelectionChanged();
        repaint();
        return true;
    }

    if (staffRows.empty()) return false;
    const float top = (float) laneArea.getY() + 8.0f - staffScroll;
    const int r = (int) std::floor (((float) e.y - top) / staffRowH);
    if (! juce::isPositiveAndBelow (r, (int) staffRows.size())) return false;
    for (int b = staffRows[(size_t) r].firstBar; b <= staffRows[(size_t) r].lastBar; ++b)
        if ((float) e.x >= staffBarX[(size_t) b] && (float) e.x < staffBarX[(size_t) b] + staffBarW[(size_t) b])
        {
            player.seek (song->bars[(size_t) b].start);
            repaint();
            return true;
        }
    return false;
}

void TabHighway::paintStaff (juce::Graphics& g, double nowBeat)
{
    if (staffLayoutWidth != laneArea.getWidth() || staffBarX.size() != song->bars.size())
        layoutStaff();
    if (staffRows.empty())
        return;

    const auto& tr = song->tracks[(size_t) track];
    const auto& notes = tr.notes;
    const int strings = juce::jmax (1, tr.stringCount());
    const float lg = staffLineGap;

    // 纸
    const auto paperArea = laneArea.toFloat().reduced (6.0f, 2.0f);
    g.setColour (paper);
    g.fillRoundedRectangle (paperArea, 6.0f);
    g.setColour (paperEdge);
    g.drawRoundedRectangle (paperArea, 6.0f, 1.0f);

    // 跟着翻页：当前小节所在的行放在最上面（第一行之后，上面留半行看刚弹过的）
    const int curBar = juce::jlimit (0, (int) song->bars.size() - 1, song->barIndexAt (nowBeat + 1.0e-9));
    const int curRow = staffBarRow[(size_t) juce::jmax (0, curBar)];
    const float maxScroll = juce::jmax (0.0f, (float) staffRows.size() * staffRowH - ((float) laneArea.getHeight() - 16.0f));
    const float target = juce::jlimit (0.0f, maxScroll, ((float) curRow - 0.35f) * staffRowH);
    if (frozenBeat >= 0.0 || std::abs (target - staffScroll) > staffRowH * 3.0f)
        staffScroll = target;
    else
        staffScroll += (target - staffScroll) * 0.18f;

    g.saveState();
    g.reduceClipRegion (paperArea.toNearestInt());

    const float firstTop = (float) laneArea.getY() + 8.0f - staffScroll;
    auto rowTop = [&] (int r) { return firstTop + (float) r * staffRowH; };
    auto lineY = [&] (int r, int s) { return rowTop (r) + staffTopPad + lg * (float) s; };
    auto xForBeat = [&] (int b, double beat) { return staffX (b, beat); };

    const bool looping = player.isLooping();
    const double loopA = player.getLoopA(), loopB = player.getLoopB();

    const int r0 = juce::jmax (0, (int) std::floor (staffScroll / staffRowH) - 1);
    const int r1 = juce::jmin ((int) staffRows.size() - 1, r0 + (int) std::ceil ((float) laneArea.getHeight() / staffRowH) + 2);

    for (int r = r0; r <= r1; ++r)
    {
        const auto& row = staffRows[(size_t) r];
        const float yTop = lineY (r, 0), yBot = lineY (r, strings - 1);
        const float xL = staffBarX[(size_t) row.firstBar];
        const float xR = staffBarX[(size_t) row.lastBar] + staffBarW[(size_t) row.lastBar];

        // 循环段、当前小节底色
        for (int b = row.firstBar; b <= row.lastBar; ++b)
        {
            const auto& bar = song->bars[(size_t) b];
            const auto cell = juce::Rectangle<float> (staffBarX[(size_t) b], yTop - 6.0f, staffBarW[(size_t) b], yBot - yTop + 12.0f);
            if (looping && bar.start >= loopA - 1.0e-6 && bar.start < loopB - 1.0e-6)
            {
                g.setColour (juce::Colour (0x2238a35a));
                g.fillRect (cell);
            }
            if (b == curBar)
            {
                g.setColour (cursorBlue.withAlpha (0.07f));
                g.fillRect (cell);
            }
        }

        // TAB 字样
        g.setColour (ink);
        g.setFont (juce::FontOptions (juce::jmin (15.0f, (yBot - yTop) / 3.4f), juce::Font::bold));
        const float tabH = (yBot - yTop) / 3.0f;
        const char* tab[] = { "T", "A", "B" };
        for (int k = 0; k < 3; ++k)
            g.drawText (tab[k], juce::Rectangle<float> (xL - 28.0f, yTop + tabH * (float) k, 20.0f, tabH), juce::Justification::centred);

        // 六条线
        g.setColour (inkSoft);
        for (int s = 0; s < strings; ++s)
            g.fillRect (xL, lineY (r, s) - 0.5f, xR - xL, 1.0f);

        // 小节线、小节号、段落、拍号
        for (int b = row.firstBar; b <= row.lastBar; ++b)
        {
            const auto& bar = song->bars[(size_t) b];
            const float bx = staffBarX[(size_t) b];
            g.setColour (ink);
            g.fillRect (bx - 0.6f, yTop, 1.2f, yBot - yTop);
            g.setFont (juce::FontOptions (10.5f));
            g.setColour (inkSoft);
            g.drawText (juce::String (b + 1), juce::Rectangle<float> (bx + 2.0f, yTop - 30.0f, 40.0f, 12.0f), juce::Justification::centredLeft);
            if (bar.section.isNotEmpty())
            {
                g.setFont (juce::FontOptions (12.5f, juce::Font::bold));
                g.setColour (juce::Colour (0xff8a3b12));
                g.drawText ("[" + bar.section + "]", juce::Rectangle<float> (bx + 22.0f, yTop - 32.0f, 220.0f, 15.0f), juce::Justification::centredLeft);
            }
            if (staffShowTimeSig[(size_t) b])
            {
                const float mid = (yTop + yBot) * 0.5f;
                g.setColour (ink);
                g.setFont (juce::FontOptions (juce::jmin (22.0f, (yBot - yTop) * 0.45f), juce::Font::bold));
                g.drawText (juce::String (bar.numerator), juce::Rectangle<float> (bx + 4.0f, yTop, 18.0f, mid - yTop), juce::Justification::centred);
                g.drawText (juce::String (bar.denominator), juce::Rectangle<float> (bx + 4.0f, mid, 18.0f, yBot - mid), juce::Justification::centred);
            }
        }
        g.setColour (ink);
        g.fillRect (xR - 0.6f, yTop, 1.2f, yBot - yTop);
        if (row.lastBar == (int) song->bars.size() - 1)
            g.fillRect (xR - 4.0f, yTop, 3.0f, yBot - yTop);      // 结束线
    }

    // ---- 谱上写的和弦名（在小节号那一行的上方）----------------------------------
    for (auto& c : tr.chords)
    {
        const int b = song->barIndexAt (c.beat + 1.0e-9);
        if (! juce::isPositiveAndBelow (b, (int) staffBarRow.size())) continue;
        const int r = staffBarRow[(size_t) b];
        if (r < r0 || r > r1) continue;
        const auto& d = tr.chordDiagrams[(size_t) c.diagram];
        if (d.name.isEmpty()) continue;
        const float x = xForBeat (b, c.beat);
        const bool cur = tr.chordIndexAt (nowBeat) == (int) (&c - tr.chords.data());
        g.setColour (cur ? cursorBlue : juce::Colour (0xff1d4ed8).withAlpha (0.85f));
        g.setFont (juce::FontOptions (13.5f, juce::Font::bold));
        g.drawText (d.name, juce::Rectangle<float> (x - 4.0f, lineY (r, 0) - 50.0f, 90.0f, 16.0f), juce::Justification::centredLeft);
    }

    // ---- 音符 ---------------------------------------------------------------
    const double firstBeat = song->bars[(size_t) staffRows[(size_t) r0].firstBar].start;
    const auto& lastBarObj = song->bars[(size_t) staffRows[(size_t) r1].lastBar];
    const double lastBeat = lastBarObj.start + lastBarObj.length;
    const auto firstIt = std::lower_bound (notes.begin(), notes.end(), firstBeat - 1.0e-6,
                                           [] (const SongNote& n, double b) { return n.start < b; });
    const float fs = juce::jlimit (11.0f, 14.5f, lg * 0.95f);
    const juce::Font numFont (juce::FontOptions (fs, juce::Font::bold));

    // 等待模式：卡着的那个事件
    int gateEvent = -1;
    if (judge != nullptr && judgeVisible && waitMode)
    {
        const auto& ev = judge->events;
        auto it = std::lower_bound (ev.begin(), ev.end(), nowBeat - 1.0e-6, [] (const JudgeEvent& e, double x) { return e.beat < x; });
        for (; it != ev.end(); ++it)
            if (judge->verdictOf ((int) (it - ev.begin())) == Verdict::pending) { gateEvent = (int) (it - ev.begin()); break; }
    }

    struct Onset { double beat; double dur; int bar; float x; int row; };
    std::vector<Onset> onsets;
    std::vector<std::pair<int, float>> pmRun;     // 同一行里连着的闷音：(行, x)
    float pmStartX = -1.0f, pmEndX = -1.0f; int pmRow = -1;
    auto flushPm = [&]
    {
        if (pmRow < 0) return;
        const float y = lineY (pmRow, 0) - 16.0f;
        g.setColour (ink);
        g.setFont (juce::FontOptions (10.5f, juce::Font::bold));
        g.drawText ("P.M.", juce::Rectangle<float> (pmStartX - 8.0f, y - 7.0f, 30.0f, 12.0f), juce::Justification::centredLeft);
        if (pmEndX > pmStartX + 26.0f)
        {
            float dashes[] = { 3.0f, 3.0f };
            g.drawDashedLine (juce::Line<float> (pmStartX + 20.0f, y, pmEndX + 6.0f, y), dashes, 2, 1.0f);
            g.fillRect (pmEndX + 6.0f, y - 3.0f, 1.0f, 6.0f);
        }
        pmRow = -1;
    };

    for (auto it = firstIt; it != notes.end() && it->start < lastBeat - 1.0e-6; ++it)
    {
        const size_t i = (size_t) std::distance (notes.begin(), it);
        const auto& n = *it;
        const int b = song->barIndexAt (n.start + 1.0e-9);
        if (! juce::isPositiveAndBelow (b, (int) staffBarRow.size())) continue;
        const int r = staffBarRow[(size_t) b];
        if (r < r0 || r > r1) continue;
        const float x = xForBeat (b, n.start);
        const float y = lineY (r, juce::jlimit (0, strings - 1, n.string));

        if (onsets.empty() || std::abs (onsets.back().beat - n.start) > 1.0e-6)
            onsets.push_back ({ n.start, n.length, b, x, r });
        else
            onsets.back().dur = juce::jmin (onsets.back().dur, n.length);

        // 文字
        juce::String label = n.dead ? juce::String ("x") : juce::String (n.fret);
        if (n.harmonic) label = "<" + label + ">";
        const float tw = juce::GlyphArrangement::getStringWidth (numFont, label) + 4.0f;
        auto box = juce::Rectangle<float> (x - tw * 0.5f, y - fs * 0.55f, tw, fs * 1.1f);

        juce::Colour col = ink;
        bool missed = false;
        int ev = -1;
        if (judge != nullptr && i < judge->noteToEvent.size()) ev = judge->noteToEvent[i];
        if (judge != nullptr && judgeVisible && ev >= 0)
        {
            const auto v = judge->verdictOf (ev);
            if (v != Verdict::pending) col = staffVerdictColour (v);
            missed = v == Verdict::miss;
        }
        const bool sounding = nowBeat >= n.start - 1.0e-6 && nowBeat < n.start + juce::jmax (n.length, 0.12);
        const bool isGate = ev >= 0 && ev == gateEvent;

        g.setColour (paper);
        g.fillRect (box.expanded (1.0f, 0.0f));
        if (sounding || isGate)
        {
            const float pulse = isGate ? 0.6f + 0.4f * (float) std::sin (nowSeconds() * 6.0) : 1.0f;
            g.setColour (cursorBlue.withAlpha (pulse));
            g.fillRoundedRectangle (box.expanded (2.5f, 1.5f), 4.0f);
            col = juce::Colours::white;
        }
        else if (col != ink)
        {
            g.setColour (col.withAlpha (0.16f));
            g.fillRoundedRectangle (box.expanded (2.0f, 1.0f), 4.0f);
        }
        g.setFont (numFont);
        g.setColour (col);
        g.drawText (label, box, juce::Justification::centred);
        if (missed)
            g.drawLine (box.getX(), box.getBottom(), box.getRight(), box.getY(), 1.4f);

        // ---- 技巧 ----
        const float above = lineY (r, 0) - 7.0f;
        if (i < hopoLabel.size() && hopoLabel[i] != 0)
        {
            const int p = i < prevOnString.size() ? prevOnString[i] : -1;
            g.setColour (ink);
            if (hopoLabel[i] != 'T' && p >= 0)
            {
                const auto& pn = notes[(size_t) p];
                const int pb = song->barIndexAt (pn.start + 1.0e-9);
                const bool sameRow = juce::isPositiveAndBelow (pb, (int) staffBarRow.size()) && staffBarRow[(size_t) pb] == r;
                const float xp = sameRow ? xForBeat (pb, pn.start) : staffBarX[(size_t) staffRows[(size_t) r].firstBar];
                juce::Path arc;
                arc.startNewSubPath (xp + 3.0f, y - fs * 0.6f);
                arc.quadraticTo ((xp + x) * 0.5f, y - fs * 0.6f - 11.0f, x - 3.0f, y - fs * 0.6f);
                g.strokePath (arc, juce::PathStrokeType (1.2f));
                g.setFont (juce::FontOptions (10.0f, juce::Font::bold));
                g.drawText (juce::String::charToString ((juce::juce_wchar) (hopoLabel[i] == 'H' ? 'h' : 'p')),
                            juce::Rectangle<float> ((xp + x) * 0.5f - 6.0f, y - fs * 0.6f - 20.0f, 12.0f, 11.0f), juce::Justification::centred);
            }
            else if (hopoLabel[i] == 'T')
            {
                g.setFont (juce::FontOptions (10.5f, juce::Font::bold));
                g.drawText ("T", juce::Rectangle<float> (x - 6.0f, above - 14.0f, 12.0f, 11.0f), juce::Justification::centred);
            }
        }
        if (n.slideOut && i < nextOnString.size() && nextOnString[i] >= 0)
        {
            const auto& nx = notes[(size_t) nextOnString[i]];
            const int nbi = song->barIndexAt (nx.start + 1.0e-9);
            const bool sameRow = juce::isPositiveAndBelow (nbi, (int) staffBarRow.size()) && staffBarRow[(size_t) nbi] == r;
            const float xn = sameRow ? xForBeat (nbi, nx.start) : x + 30.0f;
            const float dy = nx.fret > n.fret ? -1.0f : 1.0f;
            g.setColour (ink);
            g.drawLine (x + tw * 0.5f + 1.0f, y + dy * 3.0f, xn - 8.0f, y - dy * 3.0f, 1.2f);
            if (n.slideLegato)
            {
                g.setFont (juce::FontOptions (9.5f, juce::Font::bold));
                g.drawText ("sl.", juce::Rectangle<float> ((x + xn) * 0.5f - 8.0f, y - fs * 0.6f - 12.0f, 16.0f, 10.0f), juce::Justification::centred);
            }
        }
        if (n.slideOff)
        {
            g.setColour (ink);
            g.drawLine (x + tw * 0.5f + 1.0f, y - 2.0f, x + tw * 0.5f + 13.0f, y + 4.0f, 1.2f);
        }
        if (n.slideIn)
        {
            g.setColour (ink);
            g.drawLine (x - tw * 0.5f - 13.0f, y + 4.0f, x - tw * 0.5f - 1.0f, y - 2.0f, 1.2f);
        }
        if (n.bend > 0.0f)
        {
            // 推弦箭头：从数字右边弯上去，顶上写推多少；放回再画一个向下的虚线箭头
            const float bx0 = x + tw * 0.5f + 1.0f;
            const float topY = lineY (r, 0) - 13.0f;
            const float bx1 = bx0 + 13.0f;
            juce::Path pth;
            pth.startNewSubPath (bx0, y);
            pth.quadraticTo (bx1, y, bx1, topY + 6.0f);
            g.setColour (col == juce::Colours::white ? ink : col);
            g.strokePath (pth, juce::PathStrokeType (1.4f));
            juce::Path head;
            head.addTriangle (bx1 - 4.0f, topY + 7.0f, bx1 + 4.0f, topY + 7.0f, bx1, topY);
            g.fillPath (head);
            g.setFont (juce::FontOptions (10.5f, juce::Font::bold));
            g.drawText (bendText (n.bend), juce::Rectangle<float> (bx1 - 22.0f, topY - 13.0f, 44.0f, 12.0f), juce::Justification::centred);
            if (n.bendEnd < n.bend - 0.2f)
            {
                float dashes[] = { 3.0f, 2.0f };
                const float rx = bx1 + 14.0f;
                g.drawDashedLine (juce::Line<float> (bx1 + 3.0f, topY + 2.0f, rx, y - 6.0f), dashes, 2, 1.2f);
                juce::Path h2;
                h2.addTriangle (rx - 4.0f, y - 9.0f, rx + 4.0f, y - 7.0f, rx + 1.0f, y - 1.0f);
                g.fillPath (h2);
            }
            // 弹过以后：推到位没有
            if (judge != nullptr && judgeVisible && ev >= 0)
            {
                const float reached = judge->bendReachedOf (ev);
                if (reached >= 0.0f)
                {
                    const float diff = n.bend - reached;
                    const bool ok = diff <= 0.35f && diff >= -0.5f;
                    g.setColour (ok ? juce::Colour (0xff1e9a4b) : juce::Colour (0xffe0650a));
                    g.setFont (juce::FontOptions (10.0f, juce::Font::bold));
                    g.drawText (ok ? T ("到位") : (diff > 0.0f ? T ("差") + bendText (diff) : T ("过了")),
                                juce::Rectangle<float> (bx1 + 6.0f, topY - 13.0f, 50.0f, 12.0f), juce::Justification::centredLeft);
                }
            }
        }
        if (n.vibrato)
        {
            const float vy = lineY (r, 0) - 9.0f;
            const int nbEnd = song->barIndexAt (n.start + n.length - 1.0e-6);
            float xe = (juce::isPositiveAndBelow (nbEnd, (int) staffBarRow.size()) && staffBarRow[(size_t) nbEnd] == r)
                           ? xForBeat (nbEnd, n.start + n.length) : x + 40.0f;
            xe = juce::jmax (xe, x + 14.0f);
            juce::Path w;
            w.startNewSubPath (x, vy);
            for (float xx = x; xx <= xe; xx += 2.0f)
                w.lineTo (xx, vy + 2.0f * std::sin ((xx - x) * 0.8f));
            g.setColour (ink);
            g.strokePath (w, juce::PathStrokeType (1.2f));
        }
        if (n.palmMute)
        {
            if (pmRow != r || x - pmEndX > 60.0f) { flushPm(); pmRow = r; pmStartX = x; }
            pmEndX = x;
        }
        if (n.accent)
        {
            g.setColour (ink);
            g.setFont (juce::FontOptions (11.0f, juce::Font::bold));
            g.drawText (">", juce::Rectangle<float> (x - 6.0f, lineY (r, strings - 1) + 3.0f, 12.0f, 10.0f), juce::Justification::centred);
        }
    }
    flushPm();
    juce::ignoreUnused (pmRun);

    // ---- 节奏（数字下面的符干和符杠）---------------------------------------------
    g.setColour (ink);
    for (size_t k = 0; k < onsets.size(); ++k)
    {
        auto& o = onsets[k];
        if (k + 1 < onsets.size() && onsets[k + 1].bar == o.bar)
            o.dur = juce::jmin (o.dur, onsets[k + 1].beat - o.beat);
    }
    auto beamsFor = [] (double d) { return d < 0.124 ? 3 : (d < 0.249 ? 2 : (d < 0.74 ? 1 : 0)); };
    for (size_t k = 0; k < onsets.size(); ++k)
    {
        const auto& o = onsets[k];
        const float yB = lineY (o.row, strings - 1);
        const float s0 = yB + 7.0f, s1 = yB + 26.0f;
        if (o.dur >= 3.9) continue;                                   // 全音符：不画符干
        g.fillRect (o.x - 0.6f, o.dur >= 1.9 ? s0 + 8.0f : s0, 1.2f, o.dur >= 1.9 ? s1 - s0 - 8.0f : s1 - s0);
        const double frac = o.dur / std::pow (2.0, std::floor (std::log2 (juce::jmax (1.0e-6, o.dur))));
        if (std::abs (frac - 1.5) < 0.05)
            g.fillEllipse (o.x + 3.0f, s1 - 3.0f, 3.0f, 3.0f);         // 附点
        const int nB = beamsFor (o.dur);
        if (nB == 0) continue;
        // 同一拍里的相邻音连成符杠
        const auto& bar = song->bars[(size_t) o.bar];
        const int beatIdx = (int) std::floor ((o.beat - bar.start) + 1.0e-6);
        const bool hasNext = k + 1 < onsets.size() && onsets[k + 1].bar == o.bar && onsets[k + 1].row == o.row
                             && (int) std::floor ((onsets[k + 1].beat - bar.start) + 1.0e-6) == beatIdx && beamsFor (onsets[k + 1].dur) > 0;
        const bool hasPrev = k > 0 && onsets[k - 1].bar == o.bar && onsets[k - 1].row == o.row
                             && (int) std::floor ((onsets[k - 1].beat - bar.start) + 1.0e-6) == beatIdx && beamsFor (onsets[k - 1].dur) > 0;
        for (int lvl = 0; lvl < nB; ++lvl)
        {
            const float by = s1 - 2.5f - (float) lvl * 4.0f;
            if (hasNext)
            {
                const int nextB = beamsFor (onsets[k + 1].dur);
                if (lvl < nextB)
                    g.fillRect (o.x - 0.6f, by, onsets[k + 1].x - o.x + 1.2f, 2.5f);
                else if (! hasPrev || lvl >= beamsFor (onsets[k - 1].dur))
                    g.fillRect (o.x, by, 6.0f, 2.5f);                  // 短符杠
            }
            else if (hasPrev)
            {
                if (lvl >= beamsFor (onsets[k - 1].dur))
                    g.fillRect (o.x - 6.0f, by, 6.0f, 2.5f);
            }
            else
            {
                // 单独的八分 / 十六分：符尾
                juce::Path flag;
                flag.startNewSubPath (o.x, by - 2.0f);
                flag.quadraticTo (o.x + 7.0f, by - 6.0f, o.x + 6.0f, by - 12.0f);
                g.strokePath (flag, juce::PathStrokeType (1.4f));
            }
        }
    }

    // ---- 光标 ---------------------------------------------------------------
    if (juce::isPositiveAndBelow (curBar, (int) staffBarRow.size()))
    {
        const int r = staffBarRow[(size_t) curBar];
        const float cx = xForBeat (curBar, juce::jmin (nowBeat, song->bars[(size_t) curBar].start + song->bars[(size_t) curBar].length));
        const float y0 = lineY (r, 0) - 10.0f, y1 = lineY (r, strings - 1) + 10.0f;
        g.setColour (cursorBlue.withAlpha (0.18f));
        g.fillRoundedRectangle (cx - 7.0f, y0, 14.0f, y1 - y0, 4.0f);
        g.setColour (cursorBlue.withAlpha (0.9f));
        g.fillRect (cx - 1.0f, y0, 2.0f, y1 - y0);
        flashAnchor = { cx, y0 - 14.0f };
    }

    if (editor != nullptr && editor->isActive())
        paintEditOverlay (g, r0, r1);

    g.restoreState();
    if (judge != nullptr && judgeVisible)
        paintJudgeHud (g, nowBeat);
    if (player.isCountingIn() && frozenBeat < 0.0)
    {
        g.setColour (ink.withAlpha (0.75f));
        g.setFont (juce::FontOptions (40.0f, juce::Font::bold));
        g.drawText (T ("预备…"), laneArea, juce::Justification::centred);
    }
}

// ---- 谱子里写的和弦：当前和弦的指法图 + 下一个和弦 ------------------------------------
void TabHighway::paintChordBox (juce::Graphics& g, double nowBeat)
{
    const auto& tr = song->tracks[(size_t) track];
    if (tr.chords.empty()) return;
    const int ci = tr.chordIndexAt (nowBeat);
    const int ni = ci + 1 < (int) tr.chords.size() ? ci + 1 : -1;
    if (ci < 0 && ni < 0) return;

    // 放在左边（判定线左侧、弦名右侧），不挡住滚过来的音符
    const float w = 76.0f, h = 112.0f;
    auto box = juce::Rectangle<float> ((float) laneArea.getX() + 64.0f, (float) laneArea.getY() + 22.0f, w, h);
    g.setColour (juce::Colours::black.withAlpha (0.6f));
    g.fillRoundedRectangle (box, 8.0f);
    if (ci >= 0)
    {
        const auto& d = tr.chordDiagrams[(size_t) tr.chords[(size_t) ci].diagram];
        ChordDraw::Args a;
        a.title = d.name.isNotEmpty() ? d.name : T ("和弦");
        std::array<int, 6> f6;
        if (d.hasDiagram() && ChordDraw::fromSong (d.frets, f6))
        {
            a.frets = f6;
            ChordDraw::draw (g, box.reduced (3.0f, 3.0f).withTrimmedBottom (16.0f), a);
        }
        else
        {
            g.setColour (juce::Colours::white);
            g.setFont (juce::FontOptions (26.0f, juce::Font::bold));
            g.drawFittedText (a.title, box.reduced (6.0f).withTrimmedBottom (18.0f).toNearestInt(), juce::Justification::centred, 1, 0.6f);
        }
    }
    if (ni >= 0)
    {
        const auto& nd = tr.chordDiagrams[(size_t) tr.chords[(size_t) ni].diagram];
        const double inBeats = tr.chords[(size_t) ni].beat - nowBeat;
        g.setColour (inBeats < 1.0 ? juce::Colour (0xffffd166) : juce::Colours::white.withAlpha (0.6f));
        g.setFont (juce::FontOptions (11.0f, juce::Font::bold));
        g.drawFittedText (juce::String::fromUTF8 ("\xe2\x86\x92 ") + nd.name, box.removeFromBottom (16.0f).withTrimmedBottom (2.0f).toNearestInt(),
                          juce::Justification::centred, 1, 0.7f);
    }
}

// ---- 改谱：选中的音、光标、格子 ----------------------------------------------------------
void TabHighway::paintEditOverlay (juce::Graphics& g, int r0, int r1)
{
    const auto& tr = song->tracks[(size_t) track];
    const int strings = juce::jmax (1, tr.stringCount());
    const juce::Colour sel (0xfff97316);
    const float fs = juce::jlimit (11.0f, 14.5f, staffLineGap * 0.95f);
    auto rowOf = [&] (double beat, int& b) { b = song->barIndexAt (beat + 1.0e-9); return juce::isPositiveAndBelow (b, (int) staffBarRow.size()) ? staffBarRow[(size_t) b] : -1; };

    // 光标所在小节：格子刻度
    int cb = 0;
    const int cr = rowOf (editor->cursor.beat, cb);
    if (cr >= r0 && cr <= r1)
    {
        const auto& br = song->bars[(size_t) cb];
        const float yB = staffLineY (cr, strings - 1) + 4.0f;
        for (double t = br.start; t < br.start + br.length - 1.0e-6; t += editor->grid)
        {
            const bool onBeat = std::abs (t - std::round (t)) < 1.0e-6;
            g.setColour (sel.withAlpha (onBeat ? 0.55f : 0.28f));
            g.fillRect (staffX (cb, t) - 0.5f, yB, 1.0f, onBeat ? 5.0f : 3.0f);
        }
        // 光标：没有音的地方画一个虚线框（闪）
        const float x = staffX (cb, editor->cursor.beat), y = staffLineY (cr, editor->cursor.string);
        const bool blink = std::fmod (juce::Time::getMillisecondCounterHiRes() / 1000.0, 1.0) < 0.6;
        if (editor->noteAt (editor->cursor.beat, editor->cursor.string, 1.0e-3) < 0 && blink)
        {
            juce::Path p;
            p.addRoundedRectangle (x - 8.0f, y - fs * 0.6f, 16.0f, fs * 1.2f, 3.0f);
            float dashes[] = { 3.0f, 2.0f };
            juce::PathStrokeType st (1.6f);
            juce::Path dashed;
            st.createDashedStroke (dashed, p, dashes, 2);
            g.setColour (sel);
            g.fillPath (dashed);
        }
    }
    // 选中的音
    for (int i : editor->selectedIndices())
    {
        const auto& n = tr.notes[(size_t) i];
        int b = 0;
        const int r = rowOf (n.start, b);
        if (r < r0 || r > r1) continue;
        const float x = staffX (b, n.start), y = staffLineY (r, n.string);
        const juce::String label = n.dead ? juce::String ("x") : juce::String (n.fret);
        const float tw = juce::GlyphArrangement::getStringWidth (juce::Font (juce::FontOptions (fs, juce::Font::bold)), label) + 8.0f;
        auto box = juce::Rectangle<float> (x - tw * 0.5f, y - fs * 0.62f, tw, fs * 1.24f);
        g.setColour (sel);
        g.fillRoundedRectangle (box, 4.0f);
        g.setColour (juce::Colours::white);
        g.setFont (juce::FontOptions (fs, juce::Font::bold));
        g.drawText (label, box, juce::Justification::centred);
        // 时值：从数字往后画一条细线到结束
        const int be = song->barIndexAt (n.start + n.length - 1.0e-6);
        if (be == b)
        {
            g.setColour (sel.withAlpha (0.45f));
            g.fillRect (box.getRight(), y - 1.0f, juce::jmax (0.0f, staffX (b, n.start + n.length) - box.getRight() - 2.0f), 2.0f);
        }
    }
    // 框选
    if (editDragging)
    {
        const auto r = juce::Rectangle<float> (editDragStart, editDragNow);
        g.setColour (sel.withAlpha (0.12f));
        g.fillRect (r);
        g.setColour (sel.withAlpha (0.8f));
        g.drawRect (r, 1.0f);
    }
}
