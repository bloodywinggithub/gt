#include "Demucs.h"
#include "OrtRuntime.h"
#include "BasicPitch.h"
#include "AppPaths.h"
#include "onnxruntime_c_api.h"
#include <cmath>
#include <cstring>
#include <mutex>
#include <vector>

namespace
{
    struct Session
    {
        std::mutex lock;
        bool tried = false, ok = false;
        juce::String error;
        juce::File loadedFrom;
        const OrtApi* api = nullptr;
        OrtEnv* env = nullptr;
        OrtMemoryInfo* mem = nullptr;
        OrtSession* session = nullptr;

        bool check (OrtStatus* st)
        {
            if (st == nullptr) return true;
            error = juce::String (api->GetErrorMessage (st));
            api->ReleaseStatus (st);
            return false;
        }

        bool init()
        {
            const auto f = Demucs::modelLocation();
            if (tried && (ok || f == loadedFrom)) return ok;
            tried = true;
            loadedFrom = f;
            if (! f.existsAsFile())
            {
                error = juce::String::fromUTF8 ("没有找到分离模型 ") + f.getFileName() + juce::String::fromUTF8 ("（放在程序旁边的 models 文件夹里）");
                return false;
            }
            if (! OrtRuntime::get (api, env, mem, error)) return false;
            OrtSessionOptions* so = nullptr;
            if (! check (api->CreateSessionOptions (&so))) return false;
            api->SetIntraOpNumThreads (so, juce::jlimit (1, 16, juce::SystemStats::getNumCpus()));
            api->SetSessionGraphOptimizationLevel (so, ORT_ENABLE_ALL);
           #if JUCE_WINDOWS
            const bool made = check (api->CreateSession (env, f.getFullPathName().toWideCharPointer(), so, &session));
           #else
            const bool made = check (api->CreateSession (env, f.getFullPathName().toRawUTF8(), so, &session));
           #endif
            api->ReleaseSessionOptions (so);
            ok = made;
            return ok;
        }
    };
    Session& ses() { static Session s; return s; }
}

const char* Demucs::stemName (int s)
{
    static const char* names[] = { "drums", "bass", "other", "vocals", "guitar", "piano" };
    return juce::isPositiveAndBelow (s, (int) numStems) ? names[s] : "?";
}

juce::File Demucs::modelLocation()
{
    const auto env = juce::SystemStats::getEnvironmentVariable ("LIANQIN_DEMUCS", {});
    if (env.isNotEmpty()) return juce::File (env);
    auto exe = juce::File::getSpecialLocation (juce::File::currentExecutableFile);
    juce::Array<juce::File> dirs { exe.getParentDirectory(), exe.getParentDirectory().getChildFile ("models"), AppPaths::appFolder().getChildFile ("models") };
   #if JUCE_MAC
    // LianqinHost.app/Contents/MacOS/LianqinHost：模型可以放在 .app 旁边，也可以在 Resources 里
    dirs.add (exe.getParentDirectory().getParentDirectory().getChildFile ("Resources").getChildFile ("models"));
    dirs.add (exe.getParentDirectory().getParentDirectory().getParentDirectory().getParentDirectory().getChildFile ("models"));
   #endif
    for (auto& d : dirs)
        for (auto name : { "htdemucs_6s_fp16weights.onnx", "htdemucs_6s.onnx" })
            if (d.getChildFile (name).existsAsFile()) return d.getChildFile (name);
    return exe.getParentDirectory().getChildFile ("models").getChildFile ("htdemucs_6s_fp16weights.onnx");
}

bool Demucs::isAvailable (juce::String& why)
{
    if (! modelLocation().existsAsFile()) { why = juce::String::fromUTF8 ("没有分离模型"); return false; }
    auto& s = ses();
    std::lock_guard<std::mutex> l (s.lock);
    const bool ok = s.init();
    if (! ok) why = s.error;
    return ok;
}

bool Demucs::separate (const juce::AudioBuffer<float>& audio, double sr, juce::AudioBuffer<float> (&stems)[numStems],
                       juce::String& error, std::function<bool (float)> progress)
{
    // 调试用：LIANQIN_DEMUCS_CACHE=文件夹 → 同一段音频分离过一次就存下来（测试反复跑的时候省时间）
    juce::File cacheFile;
    {
        const auto dir = juce::SystemStats::getEnvironmentVariable ("LIANQIN_DEMUCS_CACHE", {});
        if (dir.isNotEmpty())
        {
            uint64_t h = 1469598103934665603ull ^ (uint64_t) audio.getNumSamples() ^ ((uint64_t) sr << 20);
            for (int c = 0; c < audio.getNumChannels(); ++c)
                for (int i = 0; i < audio.getNumSamples(); i += 97)
                {
                    uint32_t bits; const float v = audio.getSample (c, i); std::memcpy (&bits, &v, 4);
                    h = (h ^ bits) * 1099511628211ull;
                }
            cacheFile = juce::File (dir).getChildFile (juce::String::toHexString ((juce::int64) h) + ".stems");
            if (cacheFile.existsAsFile())
            {
                juce::FileInputStream in (cacheFile);
                const int len = in.readInt();
                for (int st = 0; st < numStems; ++st)
                {
                    stems[st].setSize (2, len);
                    for (int c = 0; c < 2; ++c) in.read (stems[st].getWritePointer (c), len * (int) sizeof (float));
                }
                if (progress) progress (1.0f);
                return true;
            }
        }
    }
    auto& s = ses();
    std::lock_guard<std::mutex> l (s.lock);
    if (! s.init()) { error = s.error; return false; }

    // ---- 转成 44.1 kHz 立体声 ----
    const int inLen = audio.getNumSamples();
    const int len = (int) std::ceil (inLen * sampleRate / sr);
    std::vector<float> x[2];
    for (int c = 0; c < 2; ++c)
    {
        x[c].assign ((size_t) len, 0.0f);
        const float* src = audio.getReadPointer (juce::jmin (c, audio.getNumChannels() - 1));
        if (std::abs (sr - sampleRate) < 0.5)
            std::copy (src, src + juce::jmin (inLen, len), x[c].begin());
        else
        {
            juce::LagrangeInterpolator li;
            li.process (sr / sampleRate, src, x[c].data(), juce::jmin (len, (int) ((inLen - 4) * sampleRate / sr)));
        }
    }
    // 归一化（和 Demucs 原版一样：用混音的均值、标准差）
    double mean = 0.0, var = 0.0;
    for (int i = 0; i < len; ++i) mean += 0.5 * (x[0][(size_t) i] + x[1][(size_t) i]);
    mean /= juce::jmax (1, len);
    for (int i = 0; i < len; ++i) { const double v = 0.5 * (x[0][(size_t) i] + x[1][(size_t) i]) - mean; var += v * v; }
    const double stdev = std::sqrt (var / juce::jmax (1, len)) + 1.0e-8;
    for (auto& ch : x) for (auto& v : ch) v = (float) ((v - mean) / stdev);

    // ---- 分段（重叠 1/4，三角窗加权拼接）----
    const int stride = (int) (segment * 0.75);
    std::vector<float> weight ((size_t) segment);
    for (int i = 0; i < segment; ++i) weight[(size_t) i] = (float) juce::jmin (i + 1, segment - i);
    const float wmax = *std::max_element (weight.begin(), weight.end());
    for (auto& w : weight) w /= wmax;

    std::vector<float> acc ((size_t) numStems * 2 * (size_t) len, 0.0f), wsum ((size_t) len, 0.0f);
    std::vector<float> input ((size_t) 2 * segment);
    const int numSegs = juce::jmax (1, (int) std::ceil ((double) juce::jmax (1, len - segment) / stride) + 1);
    const char* inNames[] = { "mix" };
    const char* outNames[] = { "stems" };
    for (int k = 0; k < numSegs; ++k)
    {
        const int start = k * stride;
        if (start >= len && k > 0) break;
        for (int c = 0; c < 2; ++c)
            for (int i = 0; i < segment; ++i)
                input[(size_t) c * segment + (size_t) i] = start + i < len ? x[c][(size_t) (start + i)] : 0.0f;
        const int64_t shape[] = { 1, 2, segment };
        OrtValue* in = nullptr;
        if (! s.check (s.api->CreateTensorWithDataAsOrtValue (s.mem, input.data(), input.size() * sizeof (float), shape, 3,
                                                              ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT, &in)))
        { error = s.error; return false; }
        OrtValue* out = nullptr;
        const bool ran = s.check (s.api->Run (s.session, nullptr, inNames, &in, 1, outNames, 1, &out));
        s.api->ReleaseValue (in);
        if (! ran) { error = s.error; if (out) s.api->ReleaseValue (out); return false; }
        float* p = nullptr;
        s.api->GetTensorMutableData (out, reinterpret_cast<void**> (&p));
        const int n = juce::jmin (segment, len - start);
        for (int st = 0; st < numStems; ++st)
            for (int c = 0; c < 2; ++c)
            {
                const float* src = p + ((size_t) st * 2 + (size_t) c) * segment;
                float* dst = acc.data() + ((size_t) st * 2 + (size_t) c) * (size_t) len + (size_t) start;
                for (int i = 0; i < n; ++i) dst[i] += src[i] * weight[(size_t) i];
            }
        for (int i = 0; i < n; ++i) wsum[(size_t) (start + i)] += weight[(size_t) i];
        s.api->ReleaseValue (out);
        if (progress && ! progress ((float) (k + 1) / (float) numSegs)) { error = "cancelled"; return false; }
    }

    for (int st = 0; st < numStems; ++st)
    {
        stems[st].setSize (2, len);
        for (int c = 0; c < 2; ++c)
        {
            const float* a = acc.data() + ((size_t) st * 2 + (size_t) c) * (size_t) len;
            float* d = stems[st].getWritePointer (c);
            for (int i = 0; i < len; ++i)
                d[i] = (float) (a[i] / juce::jmax (1.0e-6f, wsum[(size_t) i]) * stdev + mean / (double) numStems);
        }
    }
    if (cacheFile != juce::File())
    {
        cacheFile.getParentDirectory().createDirectory();
        juce::FileOutputStream out (cacheFile);
        if (out.openedOk())
        {
            out.writeInt (len);
            for (int st = 0; st < numStems; ++st)
                for (int c = 0; c < 2; ++c) out.write (stems[st].getReadPointer (c), (size_t) len * sizeof (float));
        }
    }
    return true;
}
