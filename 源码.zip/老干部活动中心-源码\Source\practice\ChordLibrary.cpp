#include "ChordLibrary.h"
#include "Text.h"
#include <map>
#include <set>

namespace Chords
{
namespace
{
    constexpr int X = -100;      // 指型里的“不弹”

    struct Shape
    {
        const char* name;
        int rootString;               // 0 = 6 弦
        int openPc;                   // 这根弦空弦的音名
        std::array<int, 6> offsets;   // 相对根音品位，X = 不弹
        std::array<int, 6> fingers;
        bool barre;
    };

    using Q = Quality;
    // 可移动指型（按 Quality 分）
    const std::map<Q, std::vector<Shape>>& shapes()
    {
        static const std::map<Q, std::vector<Shape>> m = {
            { Q::major, { { "E 型横按", 0, 4, { 0, 2, 2, 1, 0, 0 }, { 1, 3, 4, 2, 1, 1 }, true },
                          { "A 型横按", 1, 9, { X, 0, 2, 2, 2, 0 }, { 0, 1, 3, 3, 3, 1 }, true },
                          { "D 型",     2, 2, { X, X, 0, 2, 3, 2 }, { 0, 0, 1, 2, 4, 3 }, false } } },
            { Q::minor, { { "E 型横按", 0, 4, { 0, 2, 2, 0, 0, 0 }, { 1, 3, 4, 1, 1, 1 }, true },
                          { "A 型横按", 1, 9, { X, 0, 2, 2, 1, 0 }, { 0, 1, 3, 4, 2, 1 }, true },
                          { "D 型",     2, 2, { X, X, 0, 2, 3, 1 }, { 0, 0, 1, 3, 4, 2 }, false } } },
            { Q::dom7,  { { "E 型横按", 0, 4, { 0, 2, 0, 1, 0, 0 }, { 1, 3, 1, 2, 1, 1 }, true },
                          { "A 型横按", 1, 9, { X, 0, 2, 0, 2, 0 }, { 0, 1, 3, 1, 4, 1 }, true },
                          { "D 型",     2, 2, { X, X, 0, 2, 1, 2 }, { 0, 0, 1, 3, 2, 4 }, false } } },
            { Q::maj7,  { { "E 型",     0, 4, { 0, X, 1, 1, 0, X }, { 1, 0, 3, 4, 2, 0 }, false },
                          { "A 型横按", 1, 9, { X, 0, 2, 1, 2, 0 }, { 0, 1, 3, 2, 4, 1 }, true },
                          { "D 型",     2, 2, { X, X, 0, 2, 2, 2 }, { 0, 0, 1, 3, 3, 3 }, false } } },
            { Q::min7,  { { "E 型横按", 0, 4, { 0, 2, 0, 0, 0, 0 }, { 1, 3, 1, 1, 1, 1 }, true },
                          { "A 型横按", 1, 9, { X, 0, 2, 0, 1, 0 }, { 0, 1, 3, 1, 2, 1 }, true },
                          { "D 型",     2, 2, { X, X, 0, 2, 1, 1 }, { 0, 0, 1, 3, 2, 2 }, false } } },
            { Q::sus2,  { { "A 型横按", 1, 9, { X, 0, 2, 2, 0, 0 }, { 0, 1, 3, 4, 1, 1 }, true },
                          { "D 型",     2, 2, { X, X, 0, 2, 3, 0 }, { 0, 0, 1, 2, 4, 1 }, false } } },
            { Q::sus4,  { { "E 型横按", 0, 4, { 0, 2, 2, 2, 0, 0 }, { 1, 2, 3, 4, 1, 1 }, true },
                          { "A 型横按", 1, 9, { X, 0, 2, 2, 3, 0 }, { 0, 1, 2, 3, 4, 1 }, true },
                          { "D 型",     2, 2, { X, X, 0, 2, 3, 3 }, { 0, 0, 1, 2, 3, 4 }, false } } },
            { Q::add9,  { { "A 型",     1, 9, { X, 0, 2, 4, 2, 0 }, { 0, 1, 2, 4, 3, 1 }, true } } },
            { Q::power, { { "6 弦根音", 0, 4, { 0, 2, 2, X, X, X }, { 1, 3, 4, 0, 0, 0 }, false },
                          { "5 弦根音", 1, 9, { X, 0, 2, 2, X, X }, { 0, 1, 3, 4, 0, 0 }, false } } },
            { Q::dim,   { { "E 型",     0, 4, { 0, 1, 2, 0, X, X }, { 1, 2, 3, 1, 0, 0 }, false },
                          { "A 型",     1, 9, { X, 0, 1, 2, 1, X }, { 0, 1, 2, 4, 3, 0 }, false } } },
            { Q::dim7,  { { "E 型",     0, 4, { 0, X, -1, 0, -1, X }, { 2, 0, 1, 3, 1, 0 }, false },
                          { "A 型",     1, 9, { X, 0, 1, -1, 1, X }, { 0, 2, 3, 1, 4, 0 }, false } } },
            { Q::m7b5,  { { "E 型",     0, 4, { 0, X, 0, 0, -1, X }, { 2, 0, 3, 4, 1, 0 }, false },
                          { "A 型",     1, 9, { X, 0, 1, 0, 1, X }, { 0, 1, 3, 2, 4, 0 }, false } } },
            { Q::aug,   { { "A 型",     1, 9, { X, 0, 3, 2, 2, 1 }, { 0, 1, 4, 3, 3, 2 }, false },
                          { "E 型",     0, 4, { 0, X, 2, 1, 1, X }, { 1, 0, 4, 2, 3, 0 }, false } } },
            { Q::sixth, { { "E 型",     0, 4, { 0, X, -1, 1, 0, X }, { 2, 0, 1, 4, 3, 0 }, false },
                          { "A 型横按", 1, 9, { X, 0, 2, 2, 2, 2 }, { 0, 1, 3, 3, 3, 3 }, true } } },
            { Q::min6,  { { "E 型",     0, 4, { 0, X, -1, 0, 0, X }, { 2, 0, 1, 3, 4, 0 }, false },
                          { "A 型",     1, 9, { X, 0, 2, 2, 1, 2 }, { 0, 1, 3, 3, 2, 4 }, false } } },
        };
        return m;
    }

    struct Open { int root; Q q; std::array<int, 6> frets; std::array<int, 6> fingers; };
    const std::vector<Open>& openChords()
    {
        static const std::vector<Open> v = {
            // 大三
            { 0, Q::major, { -1, 3, 2, 0, 1, 0 }, { 0, 3, 2, 0, 1, 0 } },
            { 2, Q::major, { -1, -1, 0, 2, 3, 2 }, { 0, 0, 0, 1, 3, 2 } },
            { 4, Q::major, { 0, 2, 2, 1, 0, 0 }, { 0, 2, 3, 1, 0, 0 } },
            { 7, Q::major, { 3, 2, 0, 0, 0, 3 }, { 2, 1, 0, 0, 0, 3 } },
            { 9, Q::major, { -1, 0, 2, 2, 2, 0 }, { 0, 0, 1, 2, 3, 0 } },
            { 5, Q::major, { -1, -1, 3, 2, 1, 1 }, { 0, 0, 3, 2, 1, 1 } },
            // 小三
            { 9, Q::minor, { -1, 0, 2, 2, 1, 0 }, { 0, 0, 2, 3, 1, 0 } },
            { 2, Q::minor, { -1, -1, 0, 2, 3, 1 }, { 0, 0, 0, 2, 3, 1 } },
            { 4, Q::minor, { 0, 2, 2, 0, 0, 0 }, { 0, 2, 3, 0, 0, 0 } },
            // 属七
            { 9, Q::dom7, { -1, 0, 2, 0, 2, 0 }, { 0, 0, 2, 0, 3, 0 } },
            { 11, Q::dom7, { -1, 2, 1, 2, 0, 2 }, { 0, 2, 1, 3, 0, 4 } },
            { 0, Q::dom7, { -1, 3, 2, 3, 1, 0 }, { 0, 3, 2, 4, 1, 0 } },
            { 2, Q::dom7, { -1, -1, 0, 2, 1, 2 }, { 0, 0, 0, 2, 1, 3 } },
            { 4, Q::dom7, { 0, 2, 0, 1, 0, 0 }, { 0, 2, 0, 1, 0, 0 } },
            { 7, Q::dom7, { 3, 2, 0, 0, 0, 1 }, { 3, 2, 0, 0, 0, 1 } },
            // 大七
            { 9, Q::maj7, { -1, 0, 2, 1, 2, 0 }, { 0, 0, 2, 1, 3, 0 } },
            { 0, Q::maj7, { -1, 3, 2, 0, 0, 0 }, { 0, 3, 2, 0, 0, 0 } },
            { 2, Q::maj7, { -1, -1, 0, 2, 2, 2 }, { 0, 0, 0, 1, 1, 1 } },
            { 4, Q::maj7, { 0, 2, 1, 1, 0, 0 }, { 0, 3, 1, 2, 0, 0 } },
            { 5, Q::maj7, { -1, -1, 3, 2, 1, 0 }, { 0, 0, 3, 2, 1, 0 } },
            { 7, Q::maj7, { 3, 2, 0, 0, 0, 2 }, { 3, 2, 0, 0, 0, 1 } },
            // 小七
            { 9, Q::min7, { -1, 0, 2, 0, 1, 0 }, { 0, 0, 2, 0, 1, 0 } },
            { 2, Q::min7, { -1, -1, 0, 2, 1, 1 }, { 0, 0, 0, 2, 1, 1 } },
            { 4, Q::min7, { 0, 2, 2, 0, 3, 0 }, { 0, 1, 2, 0, 3, 0 } },
            { 11, Q::min7, { -1, 2, 0, 2, 0, 2 }, { 0, 2, 0, 3, 0, 4 } },
            // 挂留
            { 9, Q::sus2, { -1, 0, 2, 2, 0, 0 }, { 0, 0, 1, 2, 0, 0 } },
            { 2, Q::sus2, { -1, -1, 0, 2, 3, 0 }, { 0, 0, 0, 1, 3, 0 } },
            { 9, Q::sus4, { -1, 0, 2, 2, 3, 0 }, { 0, 0, 1, 2, 3, 0 } },
            { 2, Q::sus4, { -1, -1, 0, 2, 3, 3 }, { 0, 0, 0, 1, 3, 4 } },
            { 4, Q::sus4, { 0, 2, 2, 2, 0, 0 }, { 0, 2, 3, 4, 0, 0 } },
            // 加九
            { 0, Q::add9, { -1, 3, 2, 0, 3, 0 }, { 0, 2, 1, 0, 3, 0 } },
            { 4, Q::add9, { 0, 2, 4, 1, 0, 0 }, { 0, 2, 4, 1, 0, 0 } },
            { 7, Q::add9, { 3, 0, 0, 2, 0, 3 }, { 2, 0, 0, 1, 0, 3 } },
            // 强力和弦
            { 4, Q::power, { 0, 2, 2, -1, -1, -1 }, { 0, 1, 2, 0, 0, 0 } },
            { 9, Q::power, { -1, 0, 2, 2, -1, -1 }, { 0, 0, 1, 2, 0, 0 } },
            { 2, Q::power, { -1, -1, 0, 2, 3, -1 }, { 0, 0, 0, 1, 2, 0 } },
            // 增三、六和弦
            { 0, Q::aug, { -1, 3, 2, 1, 1, 0 }, { 0, 4, 3, 1, 2, 0 } },
            { 4, Q::aug, { 0, 3, 2, 1, 1, 0 }, { 0, 4, 3, 1, 2, 0 } },
            { 0, Q::sixth, { -1, 3, 2, 2, 1, 0 }, { 0, 4, 2, 3, 1, 0 } },
            { 9, Q::sixth, { -1, 0, 2, 2, 2, 2 }, { 0, 0, 1, 1, 1, 1 } },
            { 2, Q::sixth, { -1, -1, 0, 2, 0, 2 }, { 0, 0, 0, 1, 0, 2 } },
            { 4, Q::sixth, { 0, 2, 2, 1, 2, 0 }, { 0, 2, 3, 1, 4, 0 } },
            { 7, Q::sixth, { 3, 2, 0, 0, 0, 0 }, { 2, 1, 0, 0, 0, 0 } },
            { 9, Q::min6, { -1, 0, 2, 2, 1, 2 }, { 0, 0, 2, 3, 1, 4 } },
            { 2, Q::min6, { -1, -1, 0, 2, 0, 1 }, { 0, 0, 0, 2, 0, 1 } },
            { 4, Q::min6, { 0, 2, 2, 0, 2, 0 }, { 0, 2, 3, 0, 4, 0 } },
        };
        return v;
    }
}

const QualityInfo& info (Quality q)
{
    static const std::array<QualityInfo, numQualities> t = { {
        { "",     "大三和弦",   { 0, 4, 7 } },
        { "m",    "小三和弦",   { 0, 3, 7 } },
        { "7",    "属七和弦",   { 0, 4, 7, 10 } },
        { "maj7", "大七和弦",   { 0, 4, 7, 11 } },
        { "m7",   "小七和弦",   { 0, 3, 7, 10 } },
        { "sus2", "挂二和弦",   { 0, 2, 7 } },
        { "sus4", "挂四和弦",   { 0, 5, 7 } },
        { "add9", "加九和弦",   { 0, 4, 7, 2 } },
        { "5",    "强力和弦",   { 0, 7 } },
        { "dim",  "减三和弦",   { 0, 3, 6 } },
        { "dim7", "减七和弦",   { 0, 3, 6, 9 } },
        { "m7b5", "半减七和弦", { 0, 3, 6, 10 } },
        { "aug",  "增三和弦",   { 0, 4, 8 } },
        { "6",    "大六和弦",   { 0, 4, 7, 9 } },
        { "m6",   "小六和弦",   { 0, 3, 7, 9 } },
    } };
    return t[(size_t) q];
}

int Voicing::lowestFret() const
{
    int lo = 99;
    for (int f : frets) if (f > 0) lo = juce::jmin (lo, f);
    return lo == 99 ? 0 : lo;
}

int Voicing::highestFret() const
{
    int hi = 0;
    for (int f : frets) hi = juce::jmax (hi, f);
    return hi;
}

std::vector<int> Voicing::midiNotes() const
{
    std::vector<int> out;
    for (int s = 0; s < 6; ++s)
        if (frets[(size_t) s] >= 0) out.push_back (standardTuning[(size_t) s] + frets[(size_t) s]);
    return out;
}

const juce::StringArray& rootNames (bool flats)
{
    static const juce::StringArray sharps { "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B" };
    static const juce::StringArray fl { "C", "Db", "D", "Eb", "E", "F", "Gb", "G", "Ab", "A", "Bb", "B" };
    return flats ? fl : sharps;
}

juce::String name (int root, Quality q, bool flats)
{
    return rootNames (flats)[(root % 12 + 12) % 12] + info (q).suffix;
}

std::vector<Voicing> voicings (int root, Quality q)
{
    root = (root % 12 + 12) % 12;
    std::vector<Voicing> out;
    auto addUnique = [&out] (const Voicing& v)
    {
        for (auto& o : out) if (o.frets == v.frets) return;
        out.push_back (v);
    };
    for (auto& o : openChords())
        if (o.root == root && o.q == q)
        {
            Voicing v;
            v.frets = o.frets;
            v.fingers = o.fingers;
            v.shape = T ("开放和弦");
            if (root == 5 && q == Quality::major) v.shape = T ("小横按 F");
            addUnique (v);
        }

    const auto it = shapes().find (q);
    if (it != shapes().end())
        for (auto& sh : it->second)
        {
            int f = ((root - sh.openPc) % 12 + 12) % 12;
            // 指型里有比根音低的品（减七等）或者 0 品的横按：往上挪一个八度
            int minOff = 0;
            for (int o : sh.offsets) if (o != X) minOff = juce::jmin (minOff, o);
            if (f + minOff < 1 && (sh.barre || minOff < 0 || f == 0)) f += 12;
            if (f + minOff < 0 || f > 14) continue;
            Voicing v;
            for (int s = 0; s < 6; ++s)
            {
                v.frets[(size_t) s] = sh.offsets[(size_t) s] == X ? -1 : f + sh.offsets[(size_t) s];
                v.fingers[(size_t) s] = sh.offsets[(size_t) s] == X ? 0 : sh.fingers[(size_t) s];
            }
            v.shape = T (sh.name) + T (" · 第 ") + juce::String (f) + T (" 品");
            if (sh.barre)
            {
                v.barreFret = f;
                v.barreFrom = sh.rootString;
                v.barreTo = 5;
                for (int s = 5; s > sh.rootString; --s)
                    if (sh.offsets[(size_t) s] == X) v.barreTo = s - 1; else break;
            }
            addUnique (v);
        }
    // 按把位从低到高
    std::stable_sort (out.begin(), out.end(), [] (const Voicing& a, const Voicing& b) { return a.lowestFret() < b.lowestFret(); });
    return out;
}

std::vector<Diatonic> diatonic (int key, bool minor, bool sevenths)
{
    static const int majSteps[] = { 0, 2, 4, 5, 7, 9, 11 };
    static const int minSteps[] = { 0, 2, 3, 5, 7, 8, 10 };
    static const Quality majTri[] = { Q::major, Q::minor, Q::minor, Q::major, Q::major, Q::minor, Q::dim };
    static const Quality majSev[] = { Q::maj7, Q::min7, Q::min7, Q::maj7, Q::dom7, Q::min7, Q::m7b5 };
    static const Quality minTri[] = { Q::minor, Q::dim, Q::major, Q::minor, Q::minor, Q::major, Q::major };
    static const Quality minSev[] = { Q::min7, Q::m7b5, Q::maj7, Q::min7, Q::min7, Q::maj7, Q::dom7 };
    static const char* majRoman[] = { "I", "ii", "iii", "IV", "V", "vi", "vii°" };
    static const char* minRoman[] = { "i", "ii°", "III", "iv", "v", "VI", "VII" };
    std::vector<Diatonic> out;
    for (int d = 0; d < 7; ++d)
    {
        Diatonic x;
        x.root = (key + (minor ? minSteps[d] : majSteps[d])) % 12;
        x.quality = minor ? (sevenths ? minSev[d] : minTri[d]) : (sevenths ? majSev[d] : majTri[d]);
        x.roman = juce::String::fromUTF8 (minor ? minRoman[d] : majRoman[d]);
        if (sevenths)
        {
            if (x.quality == Q::maj7) x.roman << "maj7";
            else if (x.quality == Q::m7b5) x.roman = x.roman.upToFirstOccurrenceOf (juce::String::fromUTF8 ("°"), false, false) + juce::String::fromUTF8 ("ø7");
            else x.roman << "7";
        }
        out.push_back (x);
    }
    return out;
}

bool matches (const Voicing& v, int root, Quality q)
{
    std::set<int> played, want;
    for (int m : v.midiNotes()) played.insert (m % 12);
    for (int iv : info (q).intervals) want.insert ((root + iv) % 12);
    for (int p : played) if (! want.count (p)) return false;     // 不能有和弦外的音
    for (int w : want)
        if (! played.count (w) && w != (root + 7) % 12) return false;   // 只允许省五音
    // 最低音要是根音（强力和弦、开放和弦也一样）
    const auto notes = v.midiNotes();
    return ! notes.empty() && notes.front() % 12 == root % 12;
}
}
