#include "BasicPitch.h"
#include "OrtRuntime.h"
#include "onnxruntime_c_api.h"
#include "BinaryData.h"
#include <cmath>
#include <mutex>

namespace
{
    constexpr int windowSamples = 43844;          // 2 秒 − 1 帧
    constexpr int windowFrames = 172;
    constexpr int overlapFrames = 30;
    constexpr int overlapSamples = overlapFrames * BasicPitch::hop;
    constexpr int windowHop = windowSamples - overlapSamples;
    constexpr int batch = 4;

    struct Runtime
    {
        std::mutex lock;
        bool tried = false, ok = false;
        juce::String error;
        juce::DynamicLibrary lib;
        const OrtApi* api = nullptr;
        OrtEnv* env = nullptr;
        OrtSession* session = nullptr;
        OrtMemoryInfo* mem = nullptr;

        bool check (OrtStatus* st)
        {
            if (st == nullptr) return true;
            error = juce::String (api->GetErrorMessage (st));
            api->ReleaseStatus (st);
            return false;
        }

        bool libTried = false, libOk = false;
        bool initLibrary()
        {
            if (libTried) return libOk;
            libTried = true;
            const auto f = BasicPitch::runtimeLocation();
            if (! f.existsAsFile())
            {
                error = juce::String::fromUTF8 ("没有找到 ") + f.getFileName() + juce::String::fromUTF8 ("（应该和程序放在一起）");
                return false;
            }
            if (! lib.open (f.getFullPathName()))
            {
                error = juce::String::fromUTF8 ("加载不了 ") + f.getFileName();
                return false;
            }
            using GetApiBase = const OrtApiBase* (ORT_API_CALL*) ();
            auto fn = reinterpret_cast<GetApiBase> (lib.getFunction ("OrtGetApiBase"));
            if (fn == nullptr) { error = "OrtGetApiBase not found"; return false; }
            api = fn()->GetApi (ORT_API_VERSION);
            if (api == nullptr) { error = juce::String::fromUTF8 ("onnxruntime 版本太旧（需要 1.20 以上）"); return false; }
            if (! check (api->CreateEnv (ORT_LOGGING_LEVEL_ERROR, "lianqin", &env))) return false;
            if (! check (api->CreateCpuMemoryInfo (OrtArenaAllocator, OrtMemTypeDefault, &mem))) return false;
            libOk = true;
            return true;
        }

        bool init()
        {
            if (tried) return ok;
            tried = true;
            if (! initLibrary()) return false;
            OrtSessionOptions* so = nullptr;
            if (! check (api->CreateSessionOptions (&so))) return false;
            api->SetIntraOpNumThreads (so, juce::jlimit (1, 8, juce::SystemStats::getNumCpus() - 1));
            api->SetSessionGraphOptimizationLevel (so, ORT_ENABLE_ALL);
            int size = 0;
            const char* model = BinaryData::getNamedResource ("basic_pitch_onnx", size);
            if (model == nullptr) { error = "model missing"; api->ReleaseSessionOptions (so); return false; }
            const bool made = check (api->CreateSessionFromArray (env, model, (size_t) size, so, &session));
            api->ReleaseSessionOptions (so);
            if (! made) return false;
            ok = true;
            return true;
        }
    };

    Runtime& rt() { static Runtime r; return r; }
}

bool OrtRuntime::get (const OrtApi*& api, OrtEnv*& env, OrtMemoryInfo*& mem, juce::String& error)
{
    auto& r = rt();
    std::lock_guard<std::mutex> l (r.lock);
    if (! r.initLibrary()) { error = r.error; return false; }
    api = r.api; env = r.env; mem = r.mem;
    return true;
}

juce::File BasicPitch::runtimeLocation()
{
    const auto env = juce::SystemStats::getEnvironmentVariable ("LIANQIN_ONNXRUNTIME", {});
    if (env.isNotEmpty()) return juce::File (env);
    const auto dir = juce::File::getSpecialLocation (juce::File::currentExecutableFile).getParentDirectory();
   #if JUCE_WINDOWS
    return dir.getChildFile ("onnxruntime.dll");
   #elif JUCE_MAC
    return dir.getChildFile ("libonnxruntime.dylib");
   #else
    return dir.getChildFile ("libonnxruntime.so");
   #endif
}

bool BasicPitch::isAvailable (juce::String& why)
{
    auto& r = rt();
    std::lock_guard<std::mutex> l (r.lock);
    const bool ok = r.init();
    if (! ok) why = r.error;
    return ok;
}

bool BasicPitch::run (const std::vector<float>& x, Output& out, juce::String& error, std::function<bool (float)> progress)
{
    auto& r = rt();
    std::lock_guard<std::mutex> l (r.lock);
    if (! r.init()) { error = r.error; return false; }

    // 前面补半个重叠，按窗切开
    const int orig = (int) x.size();
    std::vector<float> padded ((size_t) (overlapSamples / 2), 0.0f);
    padded.insert (padded.end(), x.begin(), x.end());
    const int numWindows = juce::jmax (1, (int) std::ceil ((double) padded.size() / windowHop));

    std::vector<float> note, onset, contour;
    const int keep = windowFrames - overlapFrames;          // 每窗留中间 142 帧
    note.reserve ((size_t) numWindows * keep * keys);
    std::vector<float> input ((size_t) batch * windowSamples);
    const char* inNames[] = { "serving_default_input_2:0" };
    const char* outNames[] = { "StatefulPartitionedCall:1", "StatefulPartitionedCall:2", "StatefulPartitionedCall:0" };   // note, onset, contour

    for (int w0 = 0; w0 < numWindows; w0 += batch)
    {
        const int nb = juce::jmin (batch, numWindows - w0);
        std::fill (input.begin(), input.end(), 0.0f);
        for (int b = 0; b < nb; ++b)
        {
            const size_t start = (size_t) (w0 + b) * windowHop;
            for (int i = 0; i < windowSamples && start + (size_t) i < padded.size(); ++i)
                input[(size_t) b * windowSamples + (size_t) i] = padded[start + (size_t) i];
        }
        const int64_t shape[] = { nb, windowSamples, 1 };
        OrtValue* in = nullptr;
        if (! r.check (r.api->CreateTensorWithDataAsOrtValue (r.mem, input.data(), (size_t) nb * windowSamples * sizeof (float), shape, 3,
                                                              ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT, &in)))
        { error = r.error; return false; }
        OrtValue* outs[3] = { nullptr, nullptr, nullptr };
        const bool ran = r.check (r.api->Run (r.session, nullptr, inNames, &in, 1, outNames, 3, outs));
        r.api->ReleaseValue (in);
        if (! ran) { error = r.error; for (auto* o : outs) if (o) r.api->ReleaseValue (o); return false; }
        float* p[3] {};
        for (int k = 0; k < 3; ++k) r.api->GetTensorMutableData (outs[k], reinterpret_cast<void**> (&p[k]));
        for (int b = 0; b < nb; ++b)
            for (int f = overlapFrames / 2; f < windowFrames - overlapFrames / 2; ++f)
            {
                const size_t row = (size_t) b * windowFrames + (size_t) f;
                note.insert (note.end(), p[0] + row * keys, p[0] + (row + 1) * keys);
                onset.insert (onset.end(), p[1] + row * keys, p[1] + (row + 1) * keys);
                contour.insert (contour.end(), p[2] + row * contourBins, p[2] + (row + 1) * contourBins);
            }
        for (auto* o : outs) r.api->ReleaseValue (o);
        if (progress && ! progress ((float) (w0 + nb) / (float) numWindows)) { error = "cancelled"; return false; }
    }
    // 去掉尾巴上补出来的帧
    const int total = (int) (note.size() / keys);
    const int expected = juce::jmin (total, (int) ((double) orig / windowHop * keep));
    out.frames = expected;
    note.resize ((size_t) expected * keys);
    onset.resize ((size_t) expected * keys);
    contour.resize ((size_t) expected * contourBins);
    out.note = std::move (note);
    out.onset = std::move (onset);
    out.contour = std::move (contour);
    return true;
}

double BasicPitch::frameToSeconds (int f)
{
    // 和 Basic Pitch 的 model_frames_to_time 一样（每窗有一点点偏移要扣掉）
    const double windowOffset = (double) hop / sampleRate * (windowFrames - (double) windowSamples / hop) + 0.0018;
    return f * (double) hop / sampleRate - windowOffset * std::floor ((double) f / windowFrames);
}

std::vector<BasicPitch::Note> BasicPitch::notes (const Output& o, const NoteParams& p)
{
    std::vector<Note> result;
    const int n = o.frames;
    if (n < 3) return result;
    const int kLo = juce::jlimit (0, keys, p.lowestMidi - 21), kHi = juce::jlimit (0, keys, p.highestMidi - 21 + 1);

    std::vector<float> frames (o.note), onsets (o.onset);
    for (int t = 0; t < n; ++t)
        for (int k = 0; k < keys; ++k)
            if (k < kLo || k >= kHi) { frames[(size_t) t * keys + (size_t) k] = 0.0f; onsets[(size_t) t * keys + (size_t) k] = 0.0f; }
    auto F = [&] (int t, int k) -> float& { return frames[(size_t) t * keys + (size_t) k]; };
    auto O = [&] (int t, int k) -> float& { return onsets[(size_t) t * keys + (size_t) k]; };

    // 从“正在响”的跳变里补起音
    {
        std::vector<float> diff ((size_t) n * keys, 0.0f);
        float maxDiff = 0.0f, maxOn = 0.0f;
        for (int t = 0; t < n; ++t)
            for (int k = 0; k < keys; ++k)
            {
                maxOn = juce::jmax (maxOn, O (t, k));
                if (t < 2) continue;
                const float d1 = F (t, k) - F (t - 1, k), d2 = F (t, k) - F (t - 2, k);
                const float d = juce::jmax (0.0f, juce::jmin (d1, d2));
                diff[(size_t) t * keys + (size_t) k] = d;
                maxDiff = juce::jmax (maxDiff, d);
            }
        if (maxDiff > 0.0f)
            for (int t = 0; t < n; ++t)
                for (int k = 0; k < keys; ++k)
                    O (t, k) = juce::jmax (O (t, k), maxOn * diff[(size_t) t * keys + (size_t) k] / maxDiff);
    }

    std::vector<float> rem (frames);
    auto R = [&] (int t, int k) -> float& { return rem[(size_t) t * keys + (size_t) k]; };
    auto clearAround = [&] (int t, int k)
    {
        R (t, k) = 0.0f;
        if (k < keys - 1) R (t, k + 1) = 0.0f;
        if (k > 0) R (t, k - 1) = 0.0f;
    };
    struct Ev { int a, b, k; float amp; };
    std::vector<Ev> evs;

    // 起音峰（时间方向的局部最大），从后往前处理
    std::vector<std::pair<int, int>> peaks;
    for (int t = 1; t < n - 1; ++t)
        for (int k = 0; k < keys; ++k)
        {
            const float v = O (t, k);
            if (v >= p.onsetThreshold && v > O (t - 1, k) && v > O (t + 1, k))
                peaks.push_back ({ t, k });
        }
    std::sort (peaks.begin(), peaks.end(), [] (auto a, auto b) { return a.first != b.first ? a.first > b.first : a.second > b.second; });
    constexpr int energyTol = 11;
    for (auto [s, k] : peaks)
    {
        if (s >= n - 1) continue;
        int i = s + 1, c = 0;
        while (i < n - 1 && c < energyTol) { c = R (i, k) < p.frameThreshold ? c + 1 : 0; ++i; }
        i -= c;
        if (i - s <= p.minNoteFrames) continue;
        float amp = 0.0f;
        for (int t = s; t < i; ++t) { amp += F (t, k); clearAround (t, k); }
        evs.push_back ({ s, i, k, amp / (float) (i - s) });
    }

    // 没有明显起音、但一直在响的音（连奏、推弦后的音）
    if (p.melodiaTrick)
    {
        // 反复取剩下最大的那格 = 按值从大到小走一遍（格子只会被清零，不会变大）
        std::vector<std::pair<float, int>> cells;
        for (int t = 0; t < n; ++t)
            for (int k = kLo; k < kHi; ++k)
                if (R (t, k) > p.frameThreshold) cells.push_back ({ R (t, k), t * keys + k });
        std::sort (cells.begin(), cells.end(), [] (auto a, auto b) { return a.first > b.first; });
        for (auto& cell : cells)
        {
            const int bt = cell.second / keys, bk = cell.second % keys;
            if (R (bt, bk) <= p.frameThreshold) continue;
            R (bt, bk) = 0.0f;
            int i = bt + 1, c = 0;
            while (i < n - 1 && c < energyTol) { c = R (i, bk) < p.frameThreshold ? c + 1 : 0; clearAround (i, bk); ++i; }
            const int iEnd = i - 1 - c;
            i = bt - 1; c = 0;
            while (i > 0 && c < energyTol) { c = R (i, bk) < p.frameThreshold ? c + 1 : 0; clearAround (i, bk); --i; }
            const int iStart = i + 1 + c;
            if (iEnd - iStart <= p.minNoteFrames) continue;
            float amp = 0.0f;
            for (int t = iStart; t < iEnd; ++t) amp += F (t, bk);
            evs.push_back ({ iStart, iEnd, bk, amp / (float) (iEnd - iStart) });
        }
    }

    // 音高轮廓 → 推弦
    for (auto& e : evs)
    {
        Note nt;
        nt.start = frameToSeconds (e.a);
        nt.end = frameToSeconds (e.b);
        nt.midi = e.k + 21;
        nt.amplitude = e.amp;
        const int centre = e.k * 3;
        float mx = 0.0f; int mxAt = e.a; float last = 0.0f;
        for (int t = e.a; t < e.b; ++t)
        {
            float best = -1.0f; int arg = 0;
            for (int d = -6; d <= 8; ++d)          // 往下 2 个半音、往上 2⅔ 个半音
            {
                const int b = centre + d;
                if (b < 0 || b >= contourBins) continue;
                const float w = std::exp (-0.5f * (float) (d * d) / 25.0f) * o.contourAt (t, b);
                if (w > best) { best = w; arg = d; }
            }
            const float semis = (float) arg / 3.0f;
            if (semis > mx) { mx = semis; mxAt = t; }
            if (t >= e.b - 3) last = semis;
        }
        if (mx >= 0.65f && e.b - e.a >= 14)
        {
            nt.bend = std::round (mx * 2.0f) / 2.0f;
            nt.bendPeak = (float) (mxAt - e.a) / (float) (e.b - e.a);
            nt.release = last < mx * 0.4f;
        }
        result.push_back (nt);
    }
    std::sort (result.begin(), result.end(), [] (const Note& a, const Note& b) { return a.start != b.start ? a.start < b.start : a.midi < b.midi; });
    return result;
}
