#pragma once

#include <juce_gui_basics/juce_gui_basics.h>
#include <juce_audio_basics/juce_audio_basics.h>
#include "practice/ScaleTheory.h"
#include "PitchDetector.h"
#include "practice/NoteQuiz.h"

class AudioEngine;

// 指板：6 根弦 × 0–22 品，画出音阶里的音。当前把位的音实色，其余的淡色当参考。
class Fretboard : public juce::Component
{
public:
    enum class Labels { noteNames, degrees, none };

    void setScale (int root, const ScaleTheory::Scale& sc, bool flats);
    void setPosition (const std::vector<ScaleTheory::Spot>& spots, bool wholeNeck);
    void setLabels (Labels l)                    { labels = l; repaint(); }
    void setPlayed (int midi, bool valid)        { if (playedMidi != (valid ? midi : -1)) { playedMidi = valid ? midi : -1; repaint(); } }
    void setTarget (int midi, int string, int fret);  // 跟弹 / 示范时要弹的那个位置；midi < 0 = 没有
    void setFlash (bool good)                    { flashGood = good; flashUntil = juce::Time::getMillisecondCounterHiRes() + 260.0; repaint(); }

    std::function<void (int midi)> onNoteClicked;

    // 认音训练：不画音阶，只画题目标记；范围外的格子压暗；点格子回调 onSpotClicked
    struct QuizMark { int string = 0, fret = 0; juce::Colour colour; juce::String text; bool pulse = false; };
    void setQuizMode (bool on, const NoteQuiz::Range& r) { quizMode = on; quizRange = r; repaint(); }
    void setQuizMarks (std::vector<QuizMark> m)  { quizMarks = std::move (m); repaint(); }
    bool isQuizMode() const                      { return quizMode; }
    std::function<void (int string, int fret)> onSpotClicked;

    void paint (juce::Graphics&) override;
    void mouseDown (const juce::MouseEvent&) override;

    // 位置换算（测试 / 截图也用）
    juce::Point<float> centreOf (int string, int fret) const;

private:
    juce::Rectangle<float> boardArea() const;
    float fretX (int fret) const;

    int root = 9;
    ScaleTheory::Scale scale;
    bool flats = false, wholeNeck = true;
    std::vector<ScaleTheory::Spot> spots;
    Labels labels = Labels::noteNames;
    int playedMidi = -1, targetMidi = -1, targetString = -1, targetFret = -1;
    bool flashGood = true;
    double flashUntil = 0.0;
    bool quizMode = false;
    NoteQuiz::Range quizRange;
    std::vector<QuizMark> quizMarks;
    void paintQuiz (juce::Graphics&, float radius);
};

// 指板认音训练的操作面板（出题、作答按钮、统计）
class NoteTrainer : public juce::Component, private juce::Timer
{
public:
    NoteTrainer (Fretboard& board, AudioEngine& engine, juce::PropertiesFile& settings);
    ~NoteTrainer() override;

    void start();
    void stop();
    void refreshInstrument();      // 换了乐器（吉他 / 贝斯）：弦的选项重新生成
    bool isRunning() const                       { return running; }
    void setDetectedNote (int midi);             // 稳定下来的音（-1 = 没弹）
    bool keyPressed (const juce::KeyPress&) override;
    NoteQuiz& getQuiz()                          { return quiz; }
    void setTypeForSnapshot (int t)              { typeBox.setSelectedItemIndex (t, juce::sendNotificationSync); }
    std::function<void (int event, int combo)> onPetEvent;

    void paint (juce::Graphics&) override;
    void resized() override;

private:
    void timerCallback() override;
    void ask();
    void applyRange();
    void showMarks (bool reveal);
    void handle (NoteQuiz::Outcome o);
    void saveBest();

    Fretboard& board;
    AudioEngine& engine;
    juce::PropertiesFile& settings;
    NoteQuiz quiz { (uint32_t) juce::Time::getMillisecondCounter() };
    bool running = false;
    bool flats = false;
    double nextAt = 0.0;                         // 判完以后多久出下一题
    juce::String feedback;
    juce::Colour feedbackColour { 0xff9a9a9a };
    int lastPlayed = -1;

    juce::ComboBox typeBox, stringsBox, fretsBox;
    juce::ToggleButton naturalsToggle, soundToggle;
    juce::TextButton resetButton, skipButton;
    std::array<juce::TextButton, 12> nameButtons;
    juce::Rectangle<int> questionArea, statsArea;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (NoteTrainer)
};

// “指板音阶”页：选根音 / 音阶 / 把位，示范播放，听你弹、跟弹练习
class ScalesPanel : public juce::Component,
                    private juce::Timer
{
public:
    ScalesPanel (AudioEngine& engine, juce::PropertiesFile& settings);
    ~ScalesPanel() override;

    // 主界面每帧把调音器那一路的音高结果传进来
    void setDetectedPitch (const PitchDetector::Result& r);
    void stopAll();

    // 配鼓：选了一套鼓点，交给主界面下方的鼓机（风格序号、速度、摇摆 %、加花间隔、副歌）
    std::function<void (int style, float bpm, float swingPercent, int fillEvery, bool chorus)> onApplyGroove;
    // 给桌宠的反馈：PetView::Event 的序号、连击数
    std::function<void (int event, int combo)> onPetEvent;

    struct Groove { const char* name; const char* fits; int style; float bpm; float swing; int fillEvery; bool chorus; };
    static const std::vector<Groove>& grooves();
    static int recommendedGroove (const ScaleTheory::Selection& s);

    bool keyPressed (const juce::KeyPress&) override;
    void paint (juce::Graphics&) override;
    void resized() override;

    // 截图 / 测试用
    Fretboard& getFretboard()                    { return board; }
    NoteTrainer& getTrainer()                    { return *trainer; }
    void showQuizForSnapshot (bool on)           { setQuiz (on); }
    bool isBassMode() const                      { return ScaleTheory::currentInstrument().bass; }
    void selectInstrumentForSnapshot (int i)     { instrumentBox.setSelectedItemIndex (i, juce::sendNotificationSync); }
    void selectForSnapshot (int root, int family, bool minor, int minorType, int mode, int position);
    void stepPositionForSnapshot (int d)         { stepPosition (d); }
    void setLabelsForSnapshot (int i)            { labelsBox.setSelectedItemIndex (i, juce::sendNotificationSync); }
    void setFollowForSnapshot (bool on)          { followButton.setToggleState (on, juce::dontSendNotification); setFollow (on); }
    void applyGrooveForSnapshot()                { applyGroove (recommendedGroove (sel)); }
    std::vector<ScaleTheory::Spot> followSequenceForSnapshot() const { return sequence(); }

private:
    void timerCallback() override;
    void rebuild();                // 选项变了：重算音阶、把位、界面
    void refreshPositionBox();
    void saveSettings();
    std::vector<ScaleTheory::Spot> currentSpots() const;
    std::vector<ScaleTheory::Spot> sequence() const;   // 示范 / 跟弹的顺序
    void startDemo();
    void stopDemo();
    void setFollow (bool on);
    void stepPosition (int delta);
    void setQuiz (bool on);
    void refreshGrooveBox();
    void applyGroove (int index);

    AudioEngine& engine;
    juce::PropertiesFile& settings;

    ScaleTheory::Selection sel;
    ScaleTheory::Scale scale;
    int positionIndex = 0;          // 0 = 全指板，1.. = 把位
    Fretboard board;

    juce::Label rootLabel, familyLabel, positionLabel, labelsLabel, speedLabel, grooveLabel;
    juce::ComboBox grooveBox, instrumentBox;
    juce::TextButton grooveButton;
    juce::ComboBox rootBox, familyBox, minorTypeBox, modeBox, positionBox, labelsBox, directionBox;
    juce::TextButton majorButton, minorButton, prevPosButton, nextPosButton, playButton, followButton, quizButton;
    std::unique_ptr<NoteTrainer> trainer;
    juce::ToggleButton loopToggle;
    juce::Slider bpmSlider;

    juce::String titleText, formulaText, notesText, relativeText, descText;
    juce::String playedText, followText;
    juce::Colour playedTextColour { 0xff9a9a9a };
    juce::Rectangle<int> infoArea, followArea;

    // 示范播放
    bool demoPlaying = false;
    std::vector<ScaleTheory::Spot> demoSeq;
    size_t demoIndex = 0;
    double demoNextMs = 0.0;

    // 跟弹练习
    bool following = false;
    std::vector<ScaleTheory::Spot> followSeq;
    size_t followIndex = 0;
    int stableMidi = -1, stableFrames = 0, lastAcceptedMidi = -1;
    float noiseFloorDb = -70.0f;     // 不弹时的底噪，门槛跟着它走
    double followStartMs = 0.0;
    int followRounds = 0;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (ScalesPanel)
};
