#include "OriginalSync.h"
#include "Text.h"

// ---- 存取 ------------------------------------------------------------------------
juce::File OriginalSync::sidecarFor (const juce::File& tab)
{
    return tab.getSiblingFile (tab.getFileName() + ".sync.json");
}

juce::var OriginalSync::toVar() const
{
    auto* o = new juce::DynamicObject();
    o->setProperty ("audio", audio.getFullPathName());
    o->setProperty ("audioName", audio.getFileName());
    o->setProperty ("offset", offset);
    o->setProperty ("rate", rate);
    o->setProperty ("gainDb", gainDb);
    o->setProperty ("on", on);
    return juce::var (o);
}

OriginalSync OriginalSync::fromVar (const juce::var& v, const juce::File& tab)
{
    OriginalSync s;
    if (! v.isObject()) return s;
    s.audio = juce::File (v.getProperty ("audio", "").toString());
    if (! s.audio.existsAsFile())
    {
        // 整个文件夹搬了家：在谱子旁边找同名的音频
        const auto name = v.getProperty ("audioName", "").toString();
        if (name.isNotEmpty() && tab.getSiblingFile (name).existsAsFile())
            s.audio = tab.getSiblingFile (name);
    }
    s.offset = (double) v.getProperty ("offset", 0.0);
    s.rate = juce::jlimit (0.5, 2.0, (double) v.getProperty ("rate", 1.0));
    s.gainDb = (float) (double) v.getProperty ("gainDb", -6.0);
    s.on = (bool) v.getProperty ("on", true);
    return s;
}

static juce::String settingsKey (const juce::File& tab)
{
    return "origSync_" + juce::String::toHexString (tab.getFullPathName().toLowerCase().hashCode64());
}

OriginalSync OriginalSync::loadFor (const juce::File& tab, juce::PropertiesFile& settings)
{
    if (tab == juce::File()) return {};
    const auto side = sidecarFor (tab);
    if (side.existsAsFile())
    {
        auto s = fromVar (juce::JSON::parse (side.loadFileAsString()), tab);
        if (s.audio != juce::File()) return s;
    }
    const auto txt = settings.getValue (settingsKey (tab));
    return txt.isNotEmpty() ? fromVar (juce::JSON::parse (txt), tab) : OriginalSync {};
}

void OriginalSync::saveFor (const juce::File& tab, const OriginalSync& s, juce::PropertiesFile& settings)
{
    if (tab == juce::File()) return;
    const auto json = juce::JSON::toString (s.toVar());
    if (sidecarFor (tab).replaceWithText (json))
        settings.removeValue (settingsKey (tab));
    else
        settings.setValue (settingsKey (tab), json);      // 谱子在只读的地方：存设置里
}

void OriginalSync::removeFor (const juce::File& tab, juce::PropertiesFile& settings)
{
    sidecarFor (tab).deleteFile();
    settings.removeValue (settingsKey (tab));
}

// ---- 面板 ------------------------------------------------------------------------
OriginalSyncPanel::OriginalSyncPanel (BackingTrack& t, OriginalSync& s) : track (t), sync (s)
{
    auto label = [this] (juce::Label& l, float size, juce::Colour c)
    {
        l.setFont (juce::FontOptions (size));
        l.setColour (juce::Label::textColourId, c);
        addAndMakeVisible (l);
    };
    title.setText (T ("原曲同步"), juce::dontSendNotification);
    title.setFont (juce::FontOptions (15.0f, juce::Font::bold));
    title.setColour (juce::Label::textColourId, juce::Colours::white);
    addAndMakeVisible (title);
    label (nameLabel, 13.0f, juce::Colour (0xffd4d4d8));
    label (offsetLabel, 13.0f, juce::Colours::white);
    label (rateLabel, 13.0f, juce::Colours::white);
    label (volLabel, 13.0f, juce::Colour (0xffd4d4d8));
    label (hint, 12.0f, juce::Colour (0xff9ca3af));
    volLabel.setText (T ("音量"), juce::dontSendNotification);
    hint.setJustificationType (juce::Justification::topLeft);
    hint.setText (T ("扒谱生成的谱子会自动配上原曲并对齐。别处下载的谱子：选好原曲，播放听着，"
                     "用“开头”按钮把第一拍对上；越往后越偏，就调“快慢”。放慢练习时原曲音高不变。"
                     "想只听原曲，把“示范音”关掉。"), juce::dontSendNotification);

    chooseButton.setButtonText (T ("选择原曲…"));
    chooseButton.onClick = [this] { if (onChooseFile) onChooseFile(); };
    addAndMakeVisible (chooseButton);
    removeButton.setButtonText (T ("去掉"));
    removeButton.onClick = [this] { if (onRemove) onRemove(); };
    addAndMakeVisible (removeButton);

    onToggle.setButtonText (T ("播放原曲（O 键）"));
    onToggle.onClick = [this] { sync.on = onToggle.getToggleState(); apply(); };
    addAndMakeVisible (onToggle);

    volSlider.setSliderStyle (juce::Slider::LinearHorizontal);
    volSlider.setTextBoxStyle (juce::Slider::TextBoxRight, false, 60, 20);
    volSlider.setRange (-30.0, 6.0, 0.5);
    volSlider.setTextValueSuffix (" dB");
    volSlider.onValueChange = [this] { sync.gainDb = (float) volSlider.getValue(); apply(); };
    addAndMakeVisible (volSlider);

    for (double d : { -1.0, -0.1, -0.01, 0.01, 0.1, 1.0 })
    {
        auto* b = offsetButtons.add (new juce::TextButton ((d > 0 ? "+" : "") + juce::String (d, d == 1.0 || d == -1.0 ? 0 : (std::abs (d) < 0.05 ? 2 : 1))));
        b->setTooltip (T ("谱子开头对应原曲的时间往后 / 往前挪（秒）"));
        b->onClick = [this, d] { nudgeOffset (d); };
        addAndMakeVisible (b);
    }
    for (double d : { -0.005, -0.001, 0.001, 0.005 })
    {
        auto* b = rateButtons.add (new juce::TextButton ((d > 0 ? "+" : "") + juce::String (d * 100.0, 1) + "%"));
        b->setTooltip (T ("谱子越往后越比原曲快 / 慢时微调"));
        b->onClick = [this, d] { nudgeRate (d); };
        addAndMakeVisible (b);
    }
    rateReset.setButtonText (T ("复位"));
    rateReset.onClick = [this] { sync.rate = 1.0; apply(); };
    addAndMakeVisible (rateReset);

    setSize (400, 300);
    refresh();
    startTimerHz (4);
}

OriginalSyncPanel::~OriginalSyncPanel() = default;

void OriginalSyncPanel::apply()
{
    track.setFollowOffset (sync.offset);
    track.setFollowRate (sync.rate);
    track.setGainDb (sync.gainDb);
    track.setFollowEnabled (sync.on);
    refresh();
    if (onChanged) onChanged();
}

void OriginalSyncPanel::nudgeOffset (double d)
{
    sync.offset = std::round ((sync.offset + d) * 1000.0) / 1000.0;
    apply();
}

void OriginalSyncPanel::nudgeRate (double d)
{
    // rate 是原曲秒 / 谱子秒：显示成“谱子比原曲快多少”更直观，这里直接按比例乘
    sync.rate = juce::jlimit (0.5, 2.0, sync.rate * (1.0 + d));
    apply();
}

void OriginalSyncPanel::refresh()
{
    const bool has = sync.isValid();
    const bool loading = track.isLoading();
    nameLabel.setText (has ? (loading ? T ("正在读取：") : T ("原曲：")) + sync.audio.getFileName()
                           : T ("还没有原曲。选一个这首歌的音频文件（MP3 / WAV / FLAC…）"), juce::dontSendNotification);
    offsetLabel.setText (T ("开头：谱子第 1 拍 = 原曲 ") + juce::String (sync.offset, 3) + T (" 秒"), juce::dontSendNotification);
    const double pct = (1.0 / sync.rate - 1.0) * 100.0;
    rateLabel.setText (T ("快慢：") + (std::abs (pct) < 0.005 ? T ("和原曲一样")
                                                              : (pct > 0 ? T ("原曲比谱子快 ") : T ("原曲比谱子慢 ")) + juce::String (std::abs (pct), 2) + "%"),
                       juce::dontSendNotification);
    onToggle.setToggleState (sync.on, juce::dontSendNotification);
    volSlider.setValue (sync.gainDb, juce::dontSendNotification);
    removeButton.setEnabled (has);
    chooseButton.setButtonText (has ? T ("换一个…") : T ("选择原曲…"));
    for (auto* c : { (juce::Component*) &onToggle, (juce::Component*) &volSlider, (juce::Component*) &rateReset })
        c->setEnabled (has);
    for (auto* b : offsetButtons) b->setEnabled (has);
    for (auto* b : rateButtons) b->setEnabled (has);
}

void OriginalSyncPanel::timerCallback()
{
    if (track.isLoading() || nameLabel.getText().startsWith (T ("正在读取")))
        refresh();
}

void OriginalSyncPanel::paint (juce::Graphics& g)
{
    g.fillAll (juce::Colour (0xff262626));
}

void OriginalSyncPanel::resized()
{
    auto r = getLocalBounds().reduced (12, 8);
    auto top = r.removeFromTop (24);
    removeButton.setBounds (top.removeFromRight (52).reduced (0, 1));
    top.removeFromRight (6);
    chooseButton.setBounds (top.removeFromRight (90).reduced (0, 1));
    title.setBounds (top);
    r.removeFromTop (2);
    nameLabel.setBounds (r.removeFromTop (20));
    r.removeFromTop (4);
    {
        auto row = r.removeFromTop (24);
        onToggle.setBounds (row.removeFromLeft (150));
        volLabel.setBounds (row.removeFromLeft (36));
        volSlider.setBounds (row);
    }
    r.removeFromTop (8);
    offsetLabel.setBounds (r.removeFromTop (20));
    {
        auto row = r.removeFromTop (26);
        const int w = row.getWidth() / offsetButtons.size();
        for (auto* b : offsetButtons) b->setBounds (row.removeFromLeft (w).reduced (2, 1));
    }
    r.removeFromTop (8);
    rateLabel.setBounds (r.removeFromTop (20));
    {
        auto row = r.removeFromTop (26);
        const int w = row.getWidth() / (rateButtons.size() + 1);
        for (auto* b : rateButtons) b->setBounds (row.removeFromLeft (w).reduced (2, 1));
        rateReset.setBounds (row.reduced (2, 1));
    }
    r.removeFromTop (8);
    hint.setBounds (r);
}
