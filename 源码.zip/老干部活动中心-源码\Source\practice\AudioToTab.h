#pragma once

#include <juce_audio_basics/juce_audio_basics.h>
#include <functional>
#include <memory>
#include "song/Song.h"

// 音频扒谱：从一首歌（或自己录的一段）里扒出主旋律 / Solo 的单音谱子，外加每拍的和弦名。
//
// 做法（全部离线、不用神经网络）：
//   1. 选声道：混音 / 左 / 右 / 侧边（L−R，去掉居中的人声、贝斯、底鼓，常常能把左右声道的吉他留下来）
//   2. 逐帧（约 12 ms）算谐波和显著度，找最突出的那条旋律线；Viterbi 平滑，防止八度乱跳
//   3. 起音检测 + 音高跳变切成一个个音；音内平滑上滑的识别成推弦
//   4. 自相关估计速度、找拍点，按 1/8 或 1/16 量化到小节里（也可以手动指定 BPM）
//   5. 色度（chroma）模板匹配，每拍识别一个和弦（大三 / 小三 / 属七 / 强力和弦），按吉他和弦库配指法图
//   6. 动态规划排指法：手的移动最少、尽量在 12 品以内、推弦不放在空弦上
//
// 效果有上限：单音旋律、清楚的 Solo 准；失真扫弦、多把吉他叠在一起会乱。生成的谱是“辅助扒谱”用的。
class AudioToTab
{
public:
    enum class Source { mix, left, right, side };

    struct Options
    {
        Source source = Source::mix;
        double bpm = 0.0;              // 0 = 自动
        int grid = 4;                  // 每拍分几格：2 = 八分，4 = 十六分
        int lowestMidi = 40;           // E2
        int highestMidi = 88;          // E6
        bool chords = true;
        int capo = 0;
        double startSeconds = 0.0, endSeconds = 0.0;      // end <= start = 整首
        juce::String title;
        // 扒哪些：自动分轨（节奏 / 主音 / 贝斯，和弦是和弦）、只要主旋律（单音）、所有音放一条音轨
        enum class Mode { autoTracks, melody, allInOne };
        Mode mode = Mode::autoTracks;
        bool useAi = true;             // 有 onnxruntime 时用 Basic Pitch 复音识别
        bool separate = true;          // 有分离模型（Demucs）时先把吉他 / 贝斯 / 鼓分开再扒
        std::function<bool (float progress, const juce::String& stage)> progress;   // 返回 false = 取消
    };

    struct DetectedNote
    {
        double start = 0.0, end = 0.0;    // 秒（相对整首开头）
        int midi = 60;
        float bend = 0.0f, bendPeak = 0.5f; // 推弦：推了几个半音、最高点在音里的位置
        bool release = false;               // 推上去又放回来
        bool legato = false;                // 没有明显起音、音高直接跳过去：击弦 / 勾弦
        bool slideIn = false;               // 从上一个音滑过来
        float strength = 0.0f;
    };
    struct DetectedChord { double start = 0.0; int root = 0; int quality = 0; };   // quality：Chords::Quality

    struct Result
    {
        std::shared_ptr<Song> song;
        RawScore raw;
        double bpm = 120.0, firstBeatSeconds = 0.0;
        std::vector<DetectedNote> notes;      // 量化以前（秒）
        std::vector<DetectedChord> chords;
        juce::String error;
        bool cancelled = false;
        juce::String summary;          // 给人看的：识别到了什么（几把吉他、贝斯、用的哪种算法）
        bool usedAi = false;
        bool separated = false;        // 用了乐器分离
        double syncRate = 1.0;         // 原曲同步：原曲秒 / 谱子秒（谱里的 BPM 是整数，和实际差一点点时用）
    };

    static Result transcribe (const juce::AudioBuffer<float>& audio, double sampleRate, const Options& options);
    // 老的单音算法（没有 onnxruntime 时、或者“只要主旋律”时用）
    static Result transcribeMelody (const juce::AudioBuffer<float>& audio, double sampleRate, const Options& options);
    // 复音 + 分轨（Basic Pitch）
    static Result transcribePoly (const juce::AudioBuffer<float>& audio, double sampleRate, const Options& options);


    // ---- 各步骤（测试也用）----
    static std::vector<float> mixdown (const juce::AudioBuffer<float>& audio, double sampleRate, Source s, double targetRate,
                                       double startSec, double endSec);
    static double estimateTempo (const std::vector<float>& onsetEnvelope, double framesPerSecond, double& firstBeatSeconds);
    // 动态规划找拍点（允许速度慢慢变化）：返回每一拍的时间（秒，相对起音曲线开头）
    static std::vector<double> trackBeats (const std::vector<float>& onsetEnvelope, double framesPerSecond, double bpm, double tightness = 300.0);

    // 排指法：每个音选一根弦一个品（标准调弦 + 变调夹）
    struct Fingered { int string = 0, fret = 0; };     // string：0 = 1 弦（最细）
    // 一组同时开始的音排到吉他 / 贝斯上（tuning[0] = 最细的弦）；返回每个音的弦和品，排不下的 string = -1
    static std::vector<Fingered> fingerGroup (const std::vector<int>& midis, const std::vector<int>& tuning,
                                              const std::vector<bool>& blockedStrings, float& handPos, int maxFret = 19);
    static std::vector<Fingered> fingering (const std::vector<int>& midi, const std::vector<double>& startSeconds,
                                            const std::vector<bool>& bends, int capo);

    // 写成 Guitar Pro 3 文件（Guitar Pro、TuxGuitar、本程序都能打开）
    static bool writeGp3 (const RawScore& score, const juce::File& file, juce::String& error);
};
