#pragma once

#include "Song.h"
#include <functional>
#include <memory>
#include <vector>

// 把展开好的 Song 再写回 RawScore（存 GP3 用）。反复记号已经展开，存出来是“照着弹的顺序”一路写下去。
// 同一时刻几根弦长短不一的音：在每个音开始 / 结束的地方切开，跨过切点的用连音线接上。
RawScore songToRaw (const Song& song);

// 六线谱编辑：在一份可改的 Song 上改一条音轨的音符和和弦，带撤销 / 重做。
// 位置都用“拍”；时值的最小格是 1/48 拍（够写十六分音符和三连音）。
class TabEditor
{
public:
    void begin (std::shared_ptr<const Song> song, int track);
    void end()                                   { active = false; }
    bool isActive() const                        { return active && work != nullptr; }
    int getTrack() const                         { return track; }

    // 改过以后的谱（每次改动都是新的一份，可以直接交给播放器 / 谱面）
    std::shared_ptr<const Song> current() const  { return published; }
    bool isDirty() const                         { return dirty; }
    void markSaved()                             { dirty = false; }

    // ---- 光标 / 选择 ----
    struct Pos { double beat = 0.0; int string = 0; };
    Pos cursor;
    std::vector<Pos> selection;                  // 选中的音（按开始拍 + 弦来认）
    double grid = 0.25;                          // 吸附格（拍）：0.25 = 十六分音符
    double newLength = 0.5;                      // 新加的音的时值

    int noteAt (double beat, int string, double tolerance = 1.0e-4) const;   // 在这里开始的音（下标）
    std::vector<int> selectedIndices() const;
    void select (double beat, int string, bool add);
    void selectRange (double beatA, double beatB, int stringA, int stringB, bool add);
    void clearSelection()                        { selection.clear(); }
    bool hasSelection() const                    { return ! selectedIndices().empty(); }

    // ---- 改动（返回 true = 谱变了）----
    bool typeDigit (int digit, double nowMs);    // 改品位 / 在光标处新加一个音；两位数要在 0.9 秒内连着按
    bool deleteSelected();
    bool moveCursorString (int delta);           // 光标换弦（不改谱）
    bool moveSelectedToString (int delta);       // 选中的音换到相邻的弦上，音高不变（自动换品）
    bool transposeSelected (int semitones);      // 品位 ±1
    bool scaleLength (double factor);            // 时值 ×2 / ÷2
    bool setLength (double beats);
    bool shiftTime (int steps);                  // 往前 / 往后挪 steps 格
    bool toggleHammer();
    bool toggleDead();
    bool toggleBend();                           // 没推弦 → 推全音；推全音 → 推半音；推半音 → 不推
    bool setChordAt (double beat, int root, int quality);   // quality：Chords::Quality 的下标
    bool clearChordAt (double beat);
    int  chordAt (double beat) const;            // 正好在这一拍开始的和弦（tr.chords 的下标），-1 = 没有

    // 光标移到上一个 / 下一个音（按开始时间）
    bool stepCursor (int dir);

    bool undo();
    bool redo();
    bool canUndo() const                         { return ! undoStack.empty(); }
    bool canRedo() const                         { return ! redoStack.empty(); }

    // 最近一次操作的说明（状态栏显示）
    juce::String lastMessage;

private:
    struct Snapshot { std::vector<SongNote> notes; std::vector<ChordDiagram> diagrams; std::vector<SongChord> chords; std::vector<Pos> selection; Pos cursor; };
    Snapshot snapshot() const;
    void restore (const Snapshot&);
    void pushUndo();
    void commit();                               // 排序、算音高、发布新的一份
    SongTrack& tr()                              { return work->tracks[(size_t) track]; }
    const SongTrack& tr() const                  { return work->tracks[(size_t) track]; }
    int midiOf (int string, int fret) const;
    double snap (double beat) const;
    void fixOverlaps (int keepIndex);            // 同一根弦上和新音重叠的前一个音截短

    std::unique_ptr<Song> work;
    std::shared_ptr<const Song> published;
    int track = 0;
    bool active = false, dirty = false;
    std::vector<Snapshot> undoStack, redoStack;
    double lastDigitMs = -1.0e9;
    int lastDigitValue = -1;
};
