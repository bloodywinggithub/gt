#include "ChordDiagram.h"

namespace ChordDraw
{
bool fromSong (const std::vector<int>& songFrets, std::array<int, 6>& out)
{
    if (songFrets.size() != 6) return false;
    for (int s = 0; s < 6; ++s) out[(size_t) s] = songFrets[(size_t) (5 - s)];
    return true;
}

void draw (juce::Graphics& g, juce::Rectangle<float> area, const Args& a)
{
    auto r = area;
    const bool tiny = area.getWidth() < 90.0f;

    // 标题
    if (a.title.isNotEmpty())
    {
        g.setColour (a.highlight ? a.accent.brighter (0.4f) : juce::Colours::white);
        g.setFont (juce::FontOptions (tiny ? 13.0f : 18.0f, juce::Font::bold));
        g.drawFittedText (a.title, r.removeFromTop (tiny ? 16.0f : 24.0f).toNearestInt(), juce::Justification::centred, 1, 0.7f);
    }
    if (a.subtitle.isNotEmpty())
    {
        g.setColour (juce::Colour (0xff9a9a9a));
        g.setFont (juce::FontOptions (tiny ? 9.5f : 11.5f));
        g.drawFittedText (a.subtitle, r.removeFromTop (tiny ? 12.0f : 16.0f).toNearestInt(), juce::Justification::centred, 1, 0.7f);
    }

    int lo = 99, hi = 0;
    for (int f : a.frets) if (f > 0) { lo = juce::jmin (lo, f); hi = juce::jmax (hi, f); }
    if (lo == 99) { lo = 1; hi = 1; }
    const int rows = juce::jmax (4, hi - lo + 1 <= 4 && hi <= 4 ? 4 : hi - lo + 1);
    const int base = hi <= 4 ? 1 : lo;        // 第一格是第几品

    const float topMark = tiny ? 10.0f : 16.0f;
    r.removeFromTop (topMark);
    const float leftPad = tiny ? 14.0f : 30.0f;
    auto grid = r.withTrimmedLeft (leftPad).withTrimmedRight (tiny ? 6.0f : 10.0f).withTrimmedBottom (tiny ? 4.0f : 8.0f);
    // 保持比例
    const float cellW = grid.getWidth() / 5.0f;
    const float cellH = juce::jmin (grid.getHeight() / (float) rows, cellW * 1.35f);
    grid = grid.withHeight (cellH * (float) rows);
    auto xOf = [&] (int s) { return grid.getX() + cellW * (float) s; };
    auto yOf = [&] (int row) { return grid.getY() + cellH * (float) row; };

    // 品格
    g.setColour (juce::Colour (0xff8d8a83));
    for (int row = 0; row <= rows; ++row)
        g.fillRect (grid.getX(), yOf (row) - 0.6f, grid.getWidth(), 1.2f);
    for (int s = 0; s < 6; ++s)
        g.fillRect (xOf (s) - 0.6f, grid.getY(), 1.2f + (5 - s) * 0.18f, grid.getHeight());
    if (base == 1)
    {
        g.setColour (juce::Colour (0xffe8e2d4));
        g.fillRect (grid.getX() - 1.0f, grid.getY() - (tiny ? 3.0f : 4.5f), grid.getWidth() + 2.0f, tiny ? 3.0f : 4.5f);
    }
    else
    {
        g.setColour (juce::Colour (0xffcfcfcf));
        g.setFont (juce::FontOptions (tiny ? 9.5f : 12.0f, juce::Font::bold));
        g.drawText (juce::String (base) + (tiny ? "" : "fr"), juce::Rectangle<float> (area.getX(), yOf (0), leftPad - 2.0f, cellH),
                    juce::Justification::centredRight);
    }

    // 空弦 / 不弹 + 听音状态
    for (int s = 0; s < 6; ++s)
    {
        const float x = xOf (s);
        const float y = grid.getY() - topMark * 0.5f - (base == 1 ? 2.0f : 0.0f);
        const float m = tiny ? 3.0f : 5.0f;
        const uint8_t st = a.status != nullptr ? (*a.status)[(size_t) s] : 0;
        if (a.frets[(size_t) s] < 0)
        {
            g.setColour (juce::Colour (0xffb0b0b0));
            g.drawLine (x - m, y - m, x + m, y + m, 1.4f);
            g.drawLine (x + m, y - m, x - m, y + m, 1.4f);
        }
        else if (a.frets[(size_t) s] == 0)
        {
            g.setColour (st == 1 ? juce::Colour (0xff22c55e) : st == 2 ? juce::Colour (0xffef4444) : st == 3 ? juce::Colour (0xff8b8f97) : juce::Colour (0xffe0e0e0));
            g.drawEllipse (x - m, y - m, m * 2.0f, m * 2.0f, st != 0 ? 2.4f : 1.4f);
        }
    }

    const float dot = juce::jmin (cellW, cellH) * 0.36f;
    // 横按
    if (a.barreFret >= base && a.barreFret < base + rows)
    {
        const float y = yOf (a.barreFret - base) + cellH * 0.5f;
        g.setColour (a.accent.withAlpha (0.9f));
        g.fillRoundedRectangle (juce::Rectangle<float>::leftTopRightBottom (xOf (a.barreFrom) - dot * 0.8f, y - dot * 0.75f, xOf (a.barreTo) + dot * 0.8f, y + dot * 0.75f), dot * 0.75f);
    }
    for (int s = 0; s < 6; ++s)
    {
        const int f = a.frets[(size_t) s];
        if (f <= 0) continue;
        const float x = xOf (s), y = yOf (f - base) + cellH * 0.5f;
        const uint8_t st = a.status != nullptr ? (*a.status)[(size_t) s] : 0;
        juce::Colour c = a.accent;
        if (st == 1) c = juce::Colour (0xff22c55e);
        if (st == 2) c = juce::Colour (0xffef4444);
        if (st == 3) c = juce::Colour (0xff8b8f97);
        g.setColour (c);
        g.fillEllipse (x - dot, y - dot, dot * 2.0f, dot * 2.0f);
        if (a.hasFingers && a.fingers[(size_t) s] > 0 && ! tiny)
        {
            g.setColour (juce::Colours::white);
            g.setFont (juce::FontOptions (dot * 1.25f, juce::Font::bold));
            g.drawText (juce::String (a.fingers[(size_t) s]), juce::Rectangle<float> (x - dot, y - dot, dot * 2.0f, dot * 2.0f), juce::Justification::centred);
        }
    }
}
}
