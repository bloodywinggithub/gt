#include "MainComponent.h"
#include "AppPaths.h"
#include "Text.h"
#include "AppInfo.h"

namespace
{
    const juce::Colour bgColour    { 0xff151515 };
    const juce::Colour panelColour { 0xff222222 };
    const juce::Colour mutedText   { 0xff9a9a9a };

    void styleLabel (juce::Label& l, float size, juce::Colour c = juce::Colours::white)
    {
        l.setFont (juce::FontOptions (size));
        l.setColour (juce::Label::textColourId, c);
    }

    void styleGainSlider (juce::Slider& s, double min, double max, double value)
    {
        s.setSliderStyle (juce::Slider::LinearHorizontal);
        s.setTextBoxStyle (juce::Slider::TextBoxRight, false, 64, 22);
        s.setRange (min, max, 0.5);
        s.setTextValueSuffix (" dB");
        s.setDoubleClickReturnValue (true, 0.0);
        s.setValue (value, juce::dontSendNotification);
    }

    juce::File getAppDataFolder()
    {
        return juce::File::getSpecialLocation (juce::File::userApplicationDataDirectory).getChildFile ("LianqinHost");
    }
}

MainComponent::MainComponent()
    : inputMeter (T ("输入")), outputMeter (T ("输出"))
{
    // 这台电脑第一次运行：如果压缩包里带了“默认设置”（打包的人当时的音色、鼓机、练习设置），就用它
    {
        const auto userFile = getAppDataFolder().getChildFile ("LianqinHost.settings");
        const auto bundled = AppPaths::appFolder()
                                 .getChildFile (T ("默认设置")).getChildFile ("LianqinHost.settings");
        if (! userFile.existsAsFile() && bundled.existsAsFile())
        {
            getAppDataFolder().createDirectory();
            bundled.copyFileTo (userFile);
        }
    }

    juce::PropertiesFile::Options opts;
    opts.applicationName     = "LianqinHost";
    opts.folderName          = "LianqinHost";
    opts.filenameSuffix      = ".settings";
    opts.osxLibrarySubFolder = "Application Support";
    appProperties.setStorageParameters (opts);
    auto* settings = appProperties.getUserSettings();

    // ---- 顶栏 ---------------------------------------------------------------
    titleLabel.setText (T (AppInfo::name), juce::dontSendNotification);
    styleLabel (titleLabel, 21.0f);
    titleLabel.setFont (juce::FontOptions (21.0f, juce::Font::bold));
    addAndMakeVisible (titleLabel);
    authorLabel.setText (T ("制作者：") + T (AppInfo::author), juce::dontSendNotification);
    styleLabel (authorLabel, 12.5f, mutedText);
    addAndMakeVisible (authorLabel);
    styleLabel (statusLabel, 14.0f, mutedText);
    addAndMakeVisible (statusLabel);
    styleLabel (latencyLabel, 14.0f, juce::Colour (0xff5dcaa5));
    latencyLabel.setJustificationType (juce::Justification::centredRight);
    addAndMakeVisible (latencyLabel);
    settingsButton.setButtonText (T ("音频设置…"));
    settingsButton.onClick = [this] { openAudioSettings(); };
    addAndMakeVisible (settingsButton);

    // ---- 左栏：输入输出 -------------------------------------------------------
    channelLabel.setText (T ("吉他输入通道"), juce::dontSendNotification);
    styleLabel (channelLabel, 14.0f, mutedText);
    addAndMakeVisible (channelLabel);
    channelBox.onChange = [this]
    {
        const int i = channelBox.getSelectedItemIndex();
        if (juce::isPositiveAndBelow (i, channelForComboId.size()))
        {
            engine.setGuitarChannel (channelForComboId[i]);
            saveSettings();
        }
    };
    addAndMakeVisible (channelBox);

    inputGainLabel.setText (T ("输入增益"), juce::dontSendNotification);
    styleLabel (inputGainLabel, 14.0f, mutedText);
    addAndMakeVisible (inputGainLabel);
    styleGainSlider (inputGainSlider, -24.0, 24.0, settings->getDoubleValue ("inputGainDb", 0.0));
    inputGainSlider.onValueChange = [this] { engine.setInputGainDb ((float) inputGainSlider.getValue()); };
    addAndMakeVisible (inputGainSlider);

    outputGainLabel.setText (T ("吉他音量"), juce::dontSendNotification);
    styleLabel (outputGainLabel, 14.0f, mutedText);
    addAndMakeVisible (outputGainLabel);
    styleGainSlider (outputGainSlider, -60.0, 6.0, settings->getDoubleValue ("outputGainDb", -6.0));
    outputGainSlider.setDoubleClickReturnValue (true, -6.0);
    outputGainSlider.onValueChange = [this] { engine.setOutputGainDb ((float) outputGainSlider.getValue()); };
    addAndMakeVisible (outputGainSlider);

    monitorToggle.setButtonText (T ("监听吉他"));
    monitorToggle.setToggleState (settings->getBoolValue ("monitoring", true), juce::dontSendNotification);
    monitorToggle.onClick = [this] { engine.setMonitoring (monitorToggle.getToggleState()); };
    addAndMakeVisible (monitorToggle);

    styleLabel (hintLabel, 13.0f, juce::Colour (0xffef9f27));
    hintLabel.setJustificationType (juce::Justification::topLeft);
    hintLabel.setMinimumHorizontalScale (1.0f);
    addAndMakeVisible (hintLabel);

    addAndMakeVisible (inputMeter);
    addAndMakeVisible (outputMeter);
    addAndMakeVisible (tuner);

    engine.setInputGainDb ((float) inputGainSlider.getValue());
    engine.setOutputGainDb ((float) outputGainSlider.getValue());
    engine.setMonitoring (monitorToggle.getToggleState());
    engine.setGuitarChannel (settings->getIntValue ("guitarChannel", 0));

    // ---- 声卡 ---------------------------------------------------------------
    std::unique_ptr<juce::XmlElement> savedDevice (settings->getXmlValue ("audioDevice"));
    const auto err = deviceManager.initialise (2, 2, savedDevice.get(), true);
    if (savedDevice == nullptr)
    {
        for (auto* type : deviceManager.getAvailableDeviceTypes())
        {
            if (type->getTypeName() == "ASIO")
            {
                type->scanForDevices();
                if (type->getDeviceNames().size() > 0)
                    deviceManager.setCurrentAudioDeviceType ("ASIO", true);
                break;
            }
        }
    }
    if (err.isNotEmpty())
        hintLabel.setText (T ("打开声卡失败：") + err, juce::dontSendNotification);

    deviceManager.addAudioCallback (&engine);
    deviceManager.addChangeListener (this);

    // ---- 效果器链 / 预设 / 鼓机 -----------------------------------------------
    if (auto xml = settings->getXmlValue ("knownPlugins"))
        chain.getKnownPlugins().recreateFromXml (*xml);
    chain.getKnownPlugins().addChangeListener (this);

    chainLabel.setText (T ("效果器链"), juce::dontSendNotification);
    chainLabel.setFont (juce::FontOptions (17.0f, juce::Font::bold));
    addAndMakeVisible (chainLabel);

    presetBar = std::make_unique<PresetBar> (chain, *settings);
    addAndMakeVisible (*presetBar);

    pedalBoard = std::make_unique<PedalBoard> (chain, [this] { openPluginManager(); });
    pedalBoard->onOpenPedalEditor = [this] (EffectSlotPtr s) { showPedalEditor (std::move (s)); };
    pedalBoard->onSlotGone = [this] (EffectSlot* s)
    {
        if (pedalOverlay != nullptr && pedalOverlay->getSlot() == s)
            closePedalEditor();
    };
    addAndMakeVisible (*pedalBoard);

    drumPanel = std::make_unique<DrumPanel> (engine.getDrums(), *settings);
    addAndMakeVisible (*drumPanel);
    dockLooper = std::make_unique<LooperPanel> (engine.getLooper(), engine.getDrums(), *settings);
    addChildComponent (*dockLooper);
    backingPanel = std::make_unique<BackingPanel> (engine.getBacking(), *settings);
    addChildComponent (*backingPanel);
    dockDrumsButton.setButtonText (T ("鼓机"));
    dockLoopButton.setButtonText (T ("循环 ×5"));
    dockBackingButton.setButtonText (T ("音频伴奏"));
    dockDrumsButton.setTooltip (T ("鼓机：选风格、速度，配合练习"));
    dockLoopButton.setTooltip (T ("五轨循环录音（Looper）：录一段，再一轨轨往上叠"));
    dockBackingButton.setTooltip (T ("导入一首歌 / 伴奏（MP3、WAV、FLAC…）跟着弹，可 A-B 循环、变速"));
    {
        int i = 0;
        for (auto* b : { &dockDrumsButton, &dockLoopButton, &dockBackingButton })
        {
            b->setClickingTogglesState (true);
            b->setRadioGroupId (1002);
            b->setColour (juce::TextButton::buttonOnColourId, i == 0 ? juce::Colour (0xff2f6fdb) : (i == 1 ? juce::Colour (0xff7c3aed) : juce::Colour (0xff0f8f80)));
            b->onClick = [this, i, b] { if (b->getToggleState()) setDockTab (i); };
            addAndMakeVisible (*b);
            ++i;
        }
    }
    dockDrumsButton.setConnectedEdges (juce::Button::ConnectedOnRight);
    dockLoopButton.setConnectedEdges (juce::Button::ConnectedOnLeft | juce::Button::ConnectedOnRight);
    dockBackingButton.setConnectedEdges (juce::Button::ConnectedOnLeft);
    dockTab = juce::jlimit (0, 2, settings->getIntValue ("dockTab", 0));

    // ---- 练习谱面 -----------------------------------------------------------
    practicePanel = std::make_unique<PracticePanel> (engine.getTabPlayer(), engine.getDrums(), engine.getJudge(),
                                                     engine.getRecorder(), practiceLog, *settings);
    engine.getJudge().startAnalysis();
    practicePanel->attachLooper (engine.getLooper());
    practicePanel->attachOriginal (engine.getOriginal());
    addChildComponent (*practicePanel);

    toneViewButton.setButtonText (T ("音色 · 鼓机"));
    practiceViewButton.setButtonText (T ("练习谱面"));
    statsViewButton.setButtonText (T ("练习记录"));
    scalesViewButton.setButtonText (T ("指板音阶"));
    scalesPanel = std::make_unique<ScalesPanel> (engine, *settings);
    scalesPanel->onApplyGroove = [this] (int style, float bpm, float swing, int fill, bool chorus)
    {
        drumPanel->applyGroove (style, bpm, swing, fill, chorus);
    };
    addChildComponent (*scalesPanel);
    chordsViewButton.setButtonText (T ("吉他和弦"));
    chordPanel = std::make_unique<ChordPanel> (engine, *settings);
    addChildComponent (*chordPanel);
    statsView = std::make_unique<StatsView> (practiceLog);
    statsView->onOpenSong = [this] (const juce::File& f)
    {
        setView (View::practice);
        if (f.existsAsFile())
            practicePanel->loadFile (f);
    };
    addChildComponent (*statsView);

    pet.setEnabled (settings->getBoolValue ("petEnabled", true));
    pet.onEnabledChanged = [this] (bool on)
    {
        if (auto* st = appProperties.getUserSettings()) st->setValue ("petEnabled", on);
        resized();
    };
    addAndMakeVisible (pet);
    scalesPanel->onPetEvent = [this] (int e, int combo) { pet.react ((PetView::Event) e, combo); };
    chordPanel->onPetEvent = [this] (int e, int combo) { pet.react ((PetView::Event) e, combo); };
    for (auto* b : { &toneViewButton, &practiceViewButton, &scalesViewButton, &chordsViewButton, &statsViewButton })
    {
        b->setClickingTogglesState (true);
        b->setRadioGroupId (1001);
        b->setColour (juce::TextButton::buttonOnColourId, juce::Colour (0xff2f6fdb));
        addAndMakeVisible (*b);
    }
    toneViewButton.setConnectedEdges (juce::Button::ConnectedOnRight);
    practiceViewButton.setConnectedEdges (juce::Button::ConnectedOnLeft | juce::Button::ConnectedOnRight);
    scalesViewButton.setConnectedEdges (juce::Button::ConnectedOnLeft | juce::Button::ConnectedOnRight);
    chordsViewButton.setConnectedEdges (juce::Button::ConnectedOnLeft | juce::Button::ConnectedOnRight);
    scalesViewButton.onClick = [this] { if (scalesViewButton.getToggleState()) setView (View::scales); };
    chordsViewButton.onClick = [this] { if (chordsViewButton.getToggleState()) setView (View::chords); };
    statsViewButton.setConnectedEdges (juce::Button::ConnectedOnLeft);
    statsViewButton.onClick = [this] { if (statsViewButton.getToggleState()) setView (View::stats); };
    toneViewButton.onClick = [this] { if (toneViewButton.getToggleState()) setView (View::tone); };
    practiceViewButton.onClick = [this] { if (practiceViewButton.getToggleState()) setView (View::practice); };

    // 恢复上次的链路；第一次运行加载默认音色
    if (auto xml = settings->getXmlValue ("currentChain"))
    {
        juce::StringArray problems;
        chain.loadFromXml (*xml, problems);
        if (! problems.isEmpty())
            juce::AlertWindow::showMessageBoxAsync (juce::MessageBoxIconType::WarningIcon,
                                                    T ("部分效果器没有加载"), problems.joinIntoString ("\n"));
    }
    else
    {
        presetBar->loadPreset (presetBar->getCurrentPresetName().isNotEmpty() ? presetBar->getCurrentPresetName() : T ("清音"));
    }
    chain.addChangeListener (this);

    {
        const auto v = settings->getValue ("view");
        setView (v == "practice" ? View::practice : v == "stats" ? View::stats : v == "scales" ? View::scales
                 : v == "chords" ? View::chords : View::tone);
    }

    tunerBuffer.resize (8192);     // 贝斯最低音 41 Hz 也要够两个周期
    refreshInputChannelList();
    refreshStatus();

    setWantsKeyboardFocus (true);
    setSize (1240, 800);
    startTimerHz (30);
}

MainComponent::~MainComponent()
{
    stopTimer();
    engine.getJudge().stopAnalysis();
    saveSettings();

    chain.removeChangeListener (this);
    chain.getKnownPlugins().removeChangeListener (this);
    deviceManager.removeChangeListener (this);

    // 先关插件窗口和放大踏板，再停音频，最后释放效果器
    pedalOverlay = nullptr;
    pedalBoard->onSlotGone = nullptr;
    pedalBoard->closeAllEditors();
    deviceManager.removeAudioCallback (&engine);
    deviceManager.closeAudioDevice();

    // 插件实例要在插件格式管理器（属于 chain）之前销毁
    chain.clear();
    engine.releaseAllChains();

    practicePanel = nullptr;
    statsView = nullptr;
    drumPanel = nullptr;
    pedalBoard = nullptr;
    presetBar = nullptr;
}

void MainComponent::saveSettings()
{
    auto* s = appProperties.getUserSettings();
    if (auto xml = deviceManager.createStateXml())
        s->setValue ("audioDevice", xml.get());
    s->setValue ("guitarChannel", engine.getGuitarChannel());
    s->setValue ("inputGainDb", inputGainSlider.getValue());
    s->setValue ("outputGainDb", outputGainSlider.getValue());
    s->setValue ("monitoring", monitorToggle.getToggleState());
    s->setValue ("view", view == View::practice ? "practice" : view == View::stats ? "stats" : view == View::scales ? "scales"
                         : view == View::chords ? "chords" : "tone");
    practiceLog.saveIfNeeded();
    if (auto xml = chain.toXml())
        s->setValue ("currentChain", xml.get());
    s->saveIfNeeded();
}

void MainComponent::openAudioSettings()
{
    auto* selector = new juce::AudioDeviceSelectorComponent (deviceManager, 1, 16, 2, 16, false, false, false, false);
    selector->setSize (560, 520);

    juce::DialogWindow::LaunchOptions o;
    o.content.setOwned (selector);
    o.dialogTitle = T ("音频设置");
    o.dialogBackgroundColour = panelColour;
    o.escapeKeyTriggersCloseButton = true;
    o.useNativeTitleBar = true;
    o.resizable = true;
    o.launchAsync();
}

void MainComponent::openPluginManager()
{
    auto folder = getAppDataFolder();
    folder.createDirectory();

    auto* list = new juce::PluginListComponent (chain.getFormatManager(), chain.getKnownPlugins(),
                                                folder.getChildFile ("RecentlyCrashedPluginsList"),
                                                appProperties.getUserSettings(), true);
    list->setSize (760, 520);

    juce::DialogWindow::LaunchOptions o;
    o.content.setOwned (list);
    o.dialogTitle = T ("VST3 插件（点左下角 Options 里的 Scan 扫描）");
    o.dialogBackgroundColour = panelColour;
    o.escapeKeyTriggersCloseButton = true;
    o.useNativeTitleBar = true;
    o.resizable = true;
    o.launchAsync();
}

void MainComponent::changeListenerCallback (juce::ChangeBroadcaster* source)
{
    if (source == &chain)
    {
        chainDirty = true;
        return;
    }

    if (source == &chain.getKnownPlugins())
    {
        if (auto xml = chain.getKnownPlugins().createXml())
            appProperties.getUserSettings()->setValue ("knownPlugins", xml.get());
        appProperties.getUserSettings()->saveIfNeeded();
        return;
    }

    // 设备、采样率、缓冲区或启用的通道变了
    refreshInputChannelList();
    refreshStatus();
    saveSettings();
}

void MainComponent::showPedalEditor (EffectSlotPtr slot)
{
    pedalOverlay = nullptr;

    PedalEditorOverlay::Callbacks cb;
    auto* raw = slot.get();
    cb.toggleBypass = [this, raw] { pedalBoard->toggleBypassFor (raw); };
    cb.replaceFile  = [this, raw] { pedalBoard->replaceFileFor (raw); };
    cb.close        = [this] { closePedalEditor(); };

    pedalOverlay = std::make_unique<PedalEditorOverlay> (std::move (slot), std::move (cb));
    addAndMakeVisible (*pedalOverlay);
    pedalOverlay->setBounds (getLocalBounds());
    pedalOverlay->grabKeyboardFocus();
}

void MainComponent::closePedalEditor()
{
    if (pedalOverlay == nullptr)
        return;

    // 可能是在放大踏板自己的按钮回调里关闭的，所以放到下一轮消息再删除
    pedalOverlay->setVisible (false);
    auto* raw = pedalOverlay.release();
    juce::MessageManager::callAsync ([raw] { delete raw; });
    if (isShowing()) grabKeyboardFocus();
}

bool MainComponent::keyPressed (const juce::KeyPress& key)
{
    if (key == juce::KeyPress::escapeKey && pedalOverlay != nullptr)
    {
        closePedalEditor();
        return true;
    }
    if (view == View::practice)
        return practicePanel->keyPressed (key);
    if (view == View::stats)
        return false;
    const bool docked = view == View::tone || view == View::scales || view == View::chords;
    if (docked && dockTab == 1 && dockLooper->handleKey (key))
        return true;
    if (docked && dockTab == 2)
    {
        if (backingPanel->handleKey (key)) return true;
        if (view == View::tone && key == juce::KeyPress::spaceKey) { backingPanel->togglePlay(); return true; }
    }
    if (view == View::chords)
    {
        if (key.getTextCharacter() == 'd' || key.getTextCharacter() == 'D')
        {
            if (! engine.getDrums().isPlaying()) engine.getTabPlayer().setPlaying (false);
            drumPanel->togglePlay();
            return true;
        }
        return chordPanel->keyPressed (key);
    }
    if (view == View::scales)
    {
        if (key.getTextCharacter() == 'd' || key.getTextCharacter() == 'D')
        {
            if (! engine.getDrums().isPlaying())
                engine.getTabPlayer().setPlaying (false);
            drumPanel->togglePlay();
            return true;
        }
        return scalesPanel->keyPressed (key);
    }

    if (key == juce::KeyPress::spaceKey)
    {
        if (! engine.getDrums().isPlaying())
            engine.getTabPlayer().setPlaying (false);   // 鼓机和谱子不同时放
        drumPanel->togglePlay();
        return true;
    }
    return false;
}

void MainComponent::setView (View v)
{
    view = v;
    const bool tone = v == View::tone;
    toneViewButton.setToggleState (tone, juce::dontSendNotification);
    practiceViewButton.setToggleState (v == View::practice, juce::dontSendNotification);
    statsViewButton.setToggleState (v == View::stats, juce::dontSendNotification);
    scalesViewButton.setToggleState (v == View::scales, juce::dontSendNotification);
    chordsViewButton.setToggleState (v == View::chords, juce::dontSendNotification);
    scalesPanel->setVisible (v == View::scales);
    chordPanel->setVisible (v == View::chords);
    if (v != View::chords) chordPanel->setListening (false);
    if (v != View::scales)
        scalesPanel->stopAll();
    for (auto* c : std::initializer_list<juce::Component*> { &chainLabel, presetBar.get(), pedalBoard.get() })
        c->setVisible (tone);
    updateDockVisibility();     // 指板音阶页下面也放鼓机 / 循环 / 伴奏，配合即兴
    practicePanel->setVisible (v == View::practice);
    statsView->setVisible (v == View::stats);
    if (v == View::stats)
        statsView->refresh();
    if (! tone)
        closePedalEditor();
    resized();
    repaint();
    if (isShowing()) grabKeyboardFocus();
}

bool MainComponent::isInterestedInFileDrag (const juce::StringArray& files)
{
    for (auto& f : files)
        if (juce::File (f).hasFileExtension ("gp3;gp4;gp5;gpx;gp;wav;mp3;flac;ogg;aif;aiff;m4a;wma"))
            return true;
    return false;
}

void MainComponent::filesDropped (const juce::StringArray& files, int x, int y)
{
    // 音频文件：当伴奏
    for (auto& f : files)
        if (juce::File (f).hasFileExtension ("wav;mp3;flac;ogg;aif;aiff;m4a;wma"))
        {
            if (view != View::tone && view != View::scales) setView (View::tone);
            setDockTab (2);
            backingPanel->filesDropped (juce::StringArray (f), x, y);
            return;
        }
    for (auto& f : files)
        if (juce::File (f).hasFileExtension ("gp3;gp4;gp5;gpx;gp"))
        {
            setView (View::practice);
            practicePanel->loadFile (juce::File (f));
            return;
        }
}

void MainComponent::refreshInputChannelList()
{
    channelBox.clear (juce::dontSendNotification);
    channelForComboId.clear();

    auto* device = deviceManager.getCurrentAudioDevice();
    if (device == nullptr)
    {
        channelBox.setTextWhenNothingSelected (T ("没有打开的声卡"));
        return;
    }

    const auto names = device->getInputChannelNames();
    const auto active = device->getActiveInputChannels();
    const int wanted = engine.getGuitarChannel();
    int selectIndex = -1;

    for (int ch = 0; ch < names.size(); ++ch)
    {
        if (! active[ch])
            continue;
        channelForComboId.add (ch);
        channelBox.addItem (juce::String (ch + 1) + "  " + names[ch], channelForComboId.size());
        if (ch == wanted)
            selectIndex = channelForComboId.size() - 1;
    }

    if (channelForComboId.isEmpty())
    {
        channelBox.setTextWhenNothingSelected (T ("没有启用的输入通道"));
        return;
    }

    if (selectIndex < 0)
    {
        selectIndex = 0;
        engine.setGuitarChannel (channelForComboId[0]);
    }
    channelBox.setSelectedItemIndex (selectIndex, juce::dontSendNotification);
}

void MainComponent::refreshStatus()
{
    auto* device = deviceManager.getCurrentAudioDevice();
    if (device == nullptr)
    {
        statusLabel.setText (T ("没有打开声卡，点右上角的“音频设置…”选择设备"), juce::dontSendNotification);
        latencyLabel.setText ({}, juce::dontSendNotification);
        return;
    }

    const double sr = device->getCurrentSampleRate();
    const int block = device->getCurrentBufferSizeSamples();
    const int latencySamples = device->getInputLatencyInSamples() + device->getOutputLatencyInSamples();
    const double latencyMs = sr > 0 ? 1000.0 * latencySamples / sr : 0.0;
    const double cpu = deviceManager.getCpuUsage() * 100.0;

    statusLabel.setText (device->getTypeName() + "  |  " + device->getName() + "  |  "
                             + juce::String (sr / 1000.0, 1) + " kHz  |  "
                             + juce::String (block) + T (" 采样缓冲  |  CPU ") + juce::String (juce::roundToInt (cpu)) + "%",
                         juce::dontSendNotification);

    latencyLabel.setText (T ("往返延迟 ") + juce::String (latencyMs, 1) + " ms", juce::dontSendNotification);
    if (practicePanel != nullptr)
        practicePanel->setDeviceLatencyMs ((float) latencyMs);
    latencyLabel.setColour (juce::Label::textColourId, latencyMs <= 12.0 ? juce::Colour (0xff5dcaa5) : juce::Colour (0xffef9f27));

    juce::String hint;
   #if JUCE_WINDOWS
    if (device->getTypeName() != "ASIO")
        hint = T ("当前不是 ASIO 驱动，延迟会比较大。");
   #else
    if (false) {}
   #endif
    else if (latencyMs > 12.0)
        hint = T ("延迟偏大：把缓冲区调到 64 或 128。");
    if (cpu > 70.0)
        hint = T ("CPU 占用偏高：缓冲区调大一档，或关掉几个效果器。");
    if (channelForComboId.isEmpty())
        hint = T ("没有启用的输入通道：在“音频设置”里勾选吉他那一路。");

    hintLabel.setText (hint, juce::dontSendNotification);
}

void MainComponent::timerCallback()
{
    const float inPeak = engine.takeInputPeak();
    inputMeter.push (inPeak, engine.takeInputClipped());
    feedPet (inPeak);
    outputMeter.push (engine.takeOutputPeak(), engine.takeOutputClipped());

    const double sr = engine.copyRecentDrySamples (tunerBuffer.data(), (int) tunerBuffer.size());
    if (sr > 0.0)
    {
        const bool bass = view == View::scales && scalesPanel->isBassMode();
        const int len = juce::jmin ((int) tunerBuffer.size(), bass ? (sr > 50000.0 ? 8192 : 4096) : (sr > 50000.0 ? 4096 : 2048));
        const auto pitch = bass ? pitchDetector.detect (tunerBuffer.data() + (tunerBuffer.size() - (size_t) len), len, sr, 35.0f, 500.0f, 0.15f, -72.0f)
                                : pitchDetector.detectGuitar (tunerBuffer.data() + (tunerBuffer.size() - (size_t) len), len, sr);
        tuner.update (pitch.rmsDb > -55.0f ? pitch : PitchDetector::Result {});
        if (view == View::scales)
            scalesPanel->setDetectedPitch (pitch);
    }

    chain.collectGarbage();
    engine.getTabPlayer().releaseRetiredSongs();
    engine.getOriginal().collectGarbage();

    if (++frameCounter % 15 == 0)
        refreshStatus();

    if (chainDirty && frameCounter % 30 == 0)
    {
        chainDirty = false;
        if (auto xml = chain.toXml())
            appProperties.getUserSettings()->setValue ("currentChain", xml.get());
    }
}

void MainComponent::paint (juce::Graphics& g)
{
    g.fillAll (bgColour);
    g.setColour (panelColour);
    g.fillRoundedRectangle (leftPanel.toFloat(), 10.0f);
    if (view == View::tone)
        for (auto& r : { fxPanel, drumPanelArea })
            g.fillRoundedRectangle (r.toFloat(), 10.0f);
    if (view == View::scales || view == View::chords)
        g.fillRoundedRectangle (drumPanelArea.toFloat(), 10.0f);
}

void MainComponent::resized()
{
    auto area = getLocalBounds().reduced (16);

    // 顶栏
    auto header = area.removeFromTop (34);
    settingsButton.setBounds (header.removeFromRight (120).reduced (0, 1));
    header.removeFromRight (12);
    latencyLabel.setBounds (header.removeFromRight (170));
    titleLabel.setBounds (header.removeFromLeft (160));
    authorLabel.setBounds (header.removeFromLeft (124));
    toneViewButton.setBounds (header.removeFromLeft (110).reduced (0, 1));
    practiceViewButton.setBounds (header.removeFromLeft (96).reduced (0, 1));
    scalesViewButton.setBounds (header.removeFromLeft (96).reduced (0, 1));
    chordsViewButton.setBounds (header.removeFromLeft (96).reduced (0, 1));
    statsViewButton.setBounds (header.removeFromLeft (96).reduced (0, 1));
    header.removeFromLeft (14);
    statusLabel.setBounds (header);
    area.removeFromTop (12);

    // 左栏
    leftPanel = area.removeFromLeft (310);
    area.removeFromLeft (14);
    {
        auto p = leftPanel.reduced (16);
        auto rowWithLabel = [&p] (juce::Label& l, juce::Component& c)
        {
            l.setBounds (p.removeFromTop (20));
            c.setBounds (p.removeFromTop (30));
            p.removeFromTop (10);
        };
        rowWithLabel (channelLabel, channelBox);
        rowWithLabel (inputGainLabel, inputGainSlider);
        rowWithLabel (outputGainLabel, outputGainSlider);
        monitorToggle.setBounds (p.removeFromTop (26));
        p.removeFromTop (8);
        hintLabel.setBounds (p.removeFromBottom (36));
        p.removeFromBottom (4);
        // 桌宠在调音表下面（关掉以后只留一行“显示桌宠”）
        pet.setBounds (pet.isPetEnabled() ? p.removeFromBottom (juce::jlimit (150, 330, p.getHeight() * 11 / 20)) : p.removeFromBottom (24));
        p.removeFromBottom (6);

        auto meters = p.removeFromRight (100);
        inputMeter.setBounds (meters.removeFromLeft (44));
        meters.removeFromLeft (12);
        outputMeter.setBounds (meters.removeFromLeft (44));
        p.removeFromRight (12);
        tuner.setBounds (p);
    }

    // 右侧：练习谱面 / 效果器链 + 鼓机
    practiceArea = area;
    practicePanel->setBounds (practiceArea);
    statsView->setBounds (practiceArea);
    scalesPanel->setBounds (practiceArea.withTrimmedBottom (232 + 14));
    chordPanel->setBounds (practiceArea.withTrimmedBottom (232 + 14));
    drumPanelArea = area.removeFromBottom (232);
    area.removeFromBottom (14);
    fxPanel = area;

    {
        auto p = fxPanel.reduced (16);
        auto top = p.removeFromTop (32);
        chainLabel.setBounds (top.removeFromLeft (100));
        presetBar->setBounds (top);
        p.removeFromTop (10);
        pedalBoard->setBounds (p);
    }

    {
        auto d = drumPanelArea.reduced (12, 8);
        auto tabs = d.removeFromTop (24);
        tabs = tabs.removeFromRight (300);
        dockDrumsButton.setBounds (tabs.removeFromLeft (90));
        dockLoopButton.setBounds (tabs.removeFromLeft (100));
        dockBackingButton.setBounds (tabs);
        d.removeFromTop (2);
        drumPanel->setBounds (d.withTrimmedLeft (4).withTrimmedRight (4));
        dockLooper->setBounds (d);
        backingPanel->setBounds (d);
    }

    if (pedalOverlay != nullptr)
        pedalOverlay->setBounds (getLocalBounds());
}

void MainComponent::setDockTab (int t)
{
    dockTab = juce::jlimit (0, 2, t);
    if (auto* st = appProperties.getUserSettings()) st->setValue ("dockTab", dockTab);
    updateDockVisibility();
    if (isShowing()) grabKeyboardFocus();
}

void MainComponent::updateDockVisibility()
{
    const bool dock = view == View::tone || view == View::scales || view == View::chords;
    drumPanel->setVisible (dock && dockTab == 0);
    dockLooper->setVisible (dock && dockTab == 1);
    backingPanel->setVisible (dock && dockTab == 2);
    for (auto* b : { &dockDrumsButton, &dockLoopButton, &dockBackingButton })
        b->setVisible (dock);
    dockDrumsButton.setToggleState (dockTab == 0, juce::dontSendNotification);
    dockLoopButton.setToggleState (dockTab == 1, juce::dontSendNotification);
    dockBackingButton.setToggleState (dockTab == 2, juce::dontSendNotification);
    dockDrumsButton.toFront (false);
    dockLoopButton.toFront (false);
    dockBackingButton.toFront (false);
}

// ---- 桌宠：把弹奏判定、弹琴的动静告诉它 ---------------------------------------------
void MainComponent::feedPet (float inputPeak)
{
    auto& drums = engine.getDrums();
    pet.setActivity (inputPeak, drums.isPlaying(), drums.getCurrentBeat(), drums.getBpm());

    auto js = practicePanel->getJudgeSession();
    if (js.get() != petSession)
    {
        petSession = js.get();
        petSeenSeq = js != nullptr ? js->lastSeq.load() : 0;
        petLastComboShown = 0;
    }
    if (js == nullptr || ! practicePanel->isJudging()) return;
    const auto seq = js->lastSeq.load();
    if (seq == petSeenSeq) return;
    petSeenSeq = seq;
    const auto v = (Verdict) js->lastVerdict.load();
    const float off = js->lastOffsetMs.load();
    const int combo = js->combo.load();
    const bool wait = practicePanel->isWaitMode();
    if (combo >= 10 && combo % 10 == 0 && combo != petLastComboShown)
    {
        petLastComboShown = combo;
        pet.react (PetView::Event::combo, combo);
        return;
    }
    switch (v)
    {
        case Verdict::perfect:
        case Verdict::good:
            if (! wait && off < -45.0f)      pet.react (PetView::Event::early, combo, T ("早 ") + juce::String (juce::roundToInt (-off)) + " ms");
            else if (! wait && off > 45.0f)  pet.react (PetView::Event::late, combo, T ("晚 ") + juce::String (juce::roundToInt (off)) + " ms");
            else pet.react (v == Verdict::perfect ? PetView::Event::perfect : PetView::Event::good, combo);
            break;
        case Verdict::wrongNote: pet.react (PetView::Event::wrong); break;
        case Verdict::miss:      pet.react (PetView::Event::miss); break;
        case Verdict::pending:   break;
    }
}
