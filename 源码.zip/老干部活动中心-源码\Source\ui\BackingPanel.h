#pragma once

#include <juce_gui_basics/juce_gui_basics.h>
#include "practice/BackingTrack.h"

// 音频伴奏面板：导入一首歌 / 伴奏（也可以把文件拖进来），看波形，点波形跳转，
// 在波形上拖一段 = A-B 循环；整首循环、变速（会变调）、音量。
class BackingPanel : public juce::Component,
                     public juce::FileDragAndDropTarget,
                     private juce::Timer
{
public:
    BackingPanel (BackingTrack& track, juce::PropertiesFile& settings);
    ~BackingPanel() override;

    void chooseFile();
    void togglePlay();
    bool handleKey (const juce::KeyPress&);

    void paint (juce::Graphics&) override;
    void resized() override;
    void mouseDown (const juce::MouseEvent&) override;
    void mouseDrag (const juce::MouseEvent&) override;
    void mouseUp (const juce::MouseEvent&) override;
    void visibilityChanged() override;

    bool isInterestedInFileDrag (const juce::StringArray&) override;
    void filesDropped (const juce::StringArray&, int, int) override;

private:
    void timerCallback() override;
    void refresh();
    void load (const juce::File&);
    double secondsAtX (float x) const;

    BackingTrack& track;
    juce::PropertiesFile& settings;
    std::unique_ptr<juce::FileChooser> chooser;

    juce::Label title, nameLabel, timeLabel, speedLabel, volumeLabel, hint;
    juce::TextButton importButton, playButton, rewindButton, aButton, bButton, clearLoopButton;
    juce::ToggleButton loopToggle;
    juce::Slider speedSlider, volumeSlider;
    juce::Rectangle<int> waveArea;
    bool dragging = false;
    double dragA = 0.0, dragB = 0.0;
    bool dropHover = false;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (BackingPanel)
};
