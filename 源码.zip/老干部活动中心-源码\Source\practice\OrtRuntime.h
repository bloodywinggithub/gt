#pragma once

#include <juce_core/juce_core.h>

struct OrtApi;
struct OrtEnv;
struct OrtMemoryInfo;

// ONNX Runtime 只加载一次（onnxruntime.dll / libonnxruntime.dylib），Basic Pitch 和 Demucs 共用
namespace OrtRuntime
{
    bool get (const OrtApi*& api, OrtEnv*& env, OrtMemoryInfo*& mem, juce::String& error);
}
