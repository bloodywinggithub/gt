#include "TabLibraryBox.h"
#include "Text.h"

namespace
{
    const juce::Colour bgColour    { 0xff1d2024 };
    const juce::Colour mutedText   { 0xff9a9a9a };
}

std::vector<TabLibraryBox::Entry> TabLibraryBox::scan (const juce::Array<juce::File>& roots)
{
    std::vector<Entry> out;
    juce::StringArray seen;
    for (auto& root : roots)
    {
        if (! root.isDirectory()) continue;
        for (const auto& it : juce::RangedDirectoryIterator (root, true, "*.gp3;*.gp4;*.gp5;*.gpx;*.gp", juce::File::findFiles))
        {
            const auto f = it.getFile();
            if (seen.contains (f.getFullPathName())) continue;
            seen.add (f.getFullPathName());
            Entry e;
            e.file = f;
            e.name = f.getFileNameWithoutExtension();
            const auto rel = f.getParentDirectory().getRelativePathFrom (root);
            e.folder = rel == "." ? juce::String() : rel.replaceCharacter ('\\', '/');
            e.category = e.folder.upToFirstOccurrenceOf ("/", false, false);
            if (e.category.isEmpty()) e.category = T ("（未分类）");
            e.searchKey = (e.name + " " + e.folder).toLowerCase();
            out.push_back (std::move (e));
        }
    }
    std::sort (out.begin(), out.end(), [] (const Entry& a, const Entry& b)
    {
        if (a.category != b.category) return a.category.compareNatural (b.category) < 0;
        return a.name.compareNatural (b.name) < 0;
    });
    return out;
}

TabLibraryBox::TabLibraryBox (juce::Array<juce::File> r, juce::String lastCategory) : roots (std::move (r))
{
    entries = scan (roots);
    for (auto& e : entries)
        categories.addIfNotAlreadyThere (e.category);

    title.setFont (juce::FontOptions (16.0f, juce::Font::bold));
    title.setColour (juce::Label::textColourId, juce::Colours::white);
    title.setText (T ("谱库（") + juce::String ((int) entries.size()) + T (" 首）"), juce::dontSendNotification);
    addAndMakeVisible (title);

    hint.setFont (juce::FontOptions (12.0f));
    hint.setColour (juce::Label::textColourId, mutedText);
    hint.setJustificationType (juce::Justification::topLeft);
    if (entries.empty())
        hint.setText (T ("谱库是空的。谱库是单独下载的压缩包（老干部活动中心-谱库.zip），解压到程序所在的文件夹"
                         "（会合并到“吉他谱”文件夹里）就能在这里看到；自己的谱子也可以直接放进“吉他谱”文件夹。"),
                      juce::dontSendNotification);
    else
        hint.setText (T ("输入歌名或歌手搜索；双击打开。自己的谱子放进“吉他谱”文件夹（可以建子文件夹当分类）也会出现在这里。"),
                      juce::dontSendNotification);
    addAndMakeVisible (hint);

    search.setTextToShowWhenEmpty (T ("搜索歌名 / 歌手 / 文件夹…"), mutedText);
    search.addListener (this);
    search.setFont (juce::FontOptions (14.0f));
    addAndMakeVisible (search);

    category.addItem (T ("全部分类"), 1);
    for (int i = 0; i < categories.size(); ++i)
        category.addItem (categories[i], i + 2);
    const int idx = categories.indexOf (lastCategory);
    category.setSelectedId (idx >= 0 ? idx + 2 : 1, juce::dontSendNotification);
    category.onChange = [this]
    {
        refilter();
        if (onCategoryChanged) onCategoryChanged (category.getSelectedId() > 1 ? categories[category.getSelectedId() - 2] : juce::String());
    };
    addAndMakeVisible (category);

    list.setRowHeight (36);
    list.setColour (juce::ListBox::backgroundColourId, juce::Colour (0xff15181c));
    addAndMakeVisible (list);

    openButton.setButtonText (T ("打开"));
    openButton.onClick = [this]
    {
        const int r = list.getSelectedRow();
        if (juce::isPositiveAndBelow (r, (int) matches.size()) && onOpen) onOpen (entries[(size_t) matches[(size_t) r]].file);
    };
    addAndMakeVisible (openButton);
    openFolderButton.setButtonText (T ("打开谱库文件夹"));
    openFolderButton.onClick = [this] { if (! roots.isEmpty()) roots.getFirst().startAsProcess(); };
    addAndMakeVisible (openFolderButton);

    refilter();
    setSize (560, 470);
}

void TabLibraryBox::setFilter (const juce::String& text)
{
    search.setText (text, juce::dontSendNotification);
    refilter();
}

void TabLibraryBox::refilter()
{
    matches.clear();
    juce::StringArray words;
    words.addTokens (search.getText().toLowerCase(), " ", {});
    words.removeEmptyStrings();
    const juce::String cat = category.getSelectedId() > 1 ? categories[category.getSelectedId() - 2] : juce::String();
    for (size_t i = 0; i < entries.size(); ++i)
    {
        const auto& e = entries[i];
        if (cat.isNotEmpty() && e.category != cat) continue;
        bool ok = true;
        for (auto& w : words) if (! e.searchKey.contains (w)) { ok = false; break; }
        if (ok) matches.push_back ((int) i);
    }
    list.updateContent();
    list.repaint();
    if (! matches.empty()) list.selectRow (0);
}

void TabLibraryBox::paintListBoxItem (int row, juce::Graphics& g, int w, int h, bool selected)
{
    if (! juce::isPositiveAndBelow (row, (int) matches.size())) return;
    const auto& e = entries[(size_t) matches[(size_t) row]];
    if (selected)
    {
        g.setColour (juce::Colour (0xff2f6fdb).withAlpha (0.55f));
        g.fillRect (0, 0, w, h);
    }
    g.setColour (juce::Colours::white);
    g.setFont (juce::FontOptions (14.0f, juce::Font::bold));
    g.drawText (e.name, 10, 2, w - 80, h / 2 + 2, juce::Justification::centredLeft, true);
    g.setColour (mutedText);
    g.setFont (juce::FontOptions (11.5f));
    g.drawText (e.folder.isEmpty() ? T ("吉他谱") : e.folder, 10, h / 2, w - 80, h / 2 - 2, juce::Justification::centredLeft, true);
    g.drawText (e.file.getFileExtension().substring (1).toUpperCase(), w - 64, 0, 56, h, juce::Justification::centredRight);
    g.setColour (juce::Colours::white.withAlpha (0.06f));
    g.fillRect (0, h - 1, w, 1);
}

void TabLibraryBox::listBoxItemDoubleClicked (int row, const juce::MouseEvent&)
{
    returnKeyPressed (row);
}

void TabLibraryBox::returnKeyPressed (int row)
{
    if (juce::isPositiveAndBelow (row, (int) matches.size()) && onOpen) onOpen (entries[(size_t) matches[(size_t) row]].file);
}

void TabLibraryBox::textEditorTextChanged (juce::TextEditor&)       { refilter(); }
void TabLibraryBox::textEditorReturnKeyPressed (juce::TextEditor&)  { returnKeyPressed (list.getSelectedRow()); }

void TabLibraryBox::paint (juce::Graphics& g)
{
    g.fillAll (bgColour);
}

void TabLibraryBox::resized()
{
    auto r = getLocalBounds().reduced (12);
    auto top = r.removeFromTop (26);
    title.setBounds (top.removeFromLeft (200));
    category.setBounds (top.removeFromRight (180));
    r.removeFromTop (8);
    search.setBounds (r.removeFromTop (28));
    r.removeFromTop (6);
    auto bottom = r.removeFromBottom (28);
    openButton.setBounds (bottom.removeFromRight (80));
    bottom.removeFromRight (8);
    openFolderButton.setBounds (bottom.removeFromRight (120));
    r.removeFromBottom (6);
    hint.setBounds (r.removeFromBottom (34));
    r.removeFromBottom (4);
    list.setBounds (r);
}
