#pragma once

#include <juce_core/juce_core.h>
#include <memory>
#include <vector>

// =============================================================================
// 谱子的内部格式：所有导入器（GP3/4/5、GPX、GP7/8）都先转成 RawScore，
// 再由 buildSong() 展开反复记号、合并连音线，得到按演奏顺序排好的 Song。
// 时间单位统一用“四分音符拍”（beat）。
// 弦的编号：0 = 最细的弦（高音 E），和吉他谱上从上到下的顺序一致。
// =============================================================================

struct SongNote
{
    double start = 0.0;          // 拍
    double length = 0.0;         // 拍
    int string = 0;              // 0 = 最细的弦
    int fret = 0;
    int midi = 0;                // 实际音高（含变调夹）
    float bend = 0.0f;           // 推弦最大音高（半音），0 = 不推
    float bendStart = 0.0f;      // 推弦曲线：开始时的音高（预推 > 0）
    float bendEnd = 0.0f;        //            结束时的音高（推上去再放回 = 0）
    float bendPeakPos = 1.0f;    //            推到最高的位置（时值的 0..1）
    float bendReleasePos = 1.0f; //            开始放回的位置
    float bendEndPos = 1.0f;     //            放到 bendEnd 的位置

    // 推弦曲线：在这个音的第 frac (0..1) 处推到了多少个半音
    float bendAt (float frac) const
    {
        if (bend <= 0.0f) return 0.0f;
        auto ease = [] (float t) { t = t < 0.0f ? 0.0f : (t > 1.0f ? 1.0f : t); return t * t * (3.0f - 2.0f * t); };
        if (frac <= bendPeakPos)
            return bendPeakPos <= 0.0f ? bend : bendStart + (bend - bendStart) * ease (frac / bendPeakPos);
        if (frac <= bendReleasePos || bendEnd >= bend - 0.01f)
            return bend;
        const float span = bendEndPos - bendReleasePos;
        return span <= 0.0f ? bendEnd : bend + (bendEnd - bend) * ease ((frac - bendReleasePos) / span);
    }
    bool hammerPull = false;     // 这个音是击弦 / 勾弦弹出来的（不用拨）
    bool tapped = false;         // 点弦（右手敲出来的，也不用拨）
    bool slideOut = false;       // 滑到下一个音
    bool slideLegato = false;    // 连音滑弦：下一个音不用再拨
    bool slideOff = false;       // 滑出（不指向下一个音）
    bool slideIn = false;
    bool palmMute = false;
    bool dead = false;           // 闷音 ×
    bool harmonic = false;
    bool vibrato = false;
    bool letRing = false;
    bool accent = false;
};

// 和弦图：谱上写的和弦名 + 指法（frets[0] = 最细的弦，-1 = 不弹）
struct ChordDiagram
{
    juce::String name;
    std::vector<int> frets;
    bool hasDiagram() const { for (int f : frets) if (f >= 0) return true; return false; }
};

struct SongChord { double beat = 0.0; int diagram = 0; };     // 从这一拍开始是这个和弦

struct SongTrack
{
    juce::String name;
    bool percussion = false;
    std::vector<int> tuning;     // MIDI 音高，[0] = 最细的弦
    int capo = 0;
    int program = 25;            // GM 音色
    std::vector<SongNote> notes; // 按 start 排序
    std::vector<ChordDiagram> chordDiagrams;
    std::vector<SongChord> chords;      // 按 beat 排序
    int chordIndexAt (double beat) const
    {
        int found = -1;
        for (size_t i = 0; i < chords.size() && chords[i].beat <= beat + 1.0e-6; ++i) found = (int) i;
        return found;
    }

    // 贝斯：GM 音色是贝斯，或者音轨名里有 bass / 贝斯，或者最低的弦比吉他低八度（E1 一带）
    bool isBass() const
    {
        if (percussion) return false;
        if (program >= 32 && program <= 39) return true;
        if (name.containsIgnoreCase ("bass") || name.contains (juce::String::fromUTF8 ("贝斯"))) return true;
        int lowest = 127;
        for (int t : tuning) lowest = juce::jmin (lowest, t);
        return ! tuning.empty() && tuning.size() <= 6 && lowest < 36 && tuning.front() < 50;
    }
    int stringCount() const { return (int) tuning.size(); }
};

struct SongBar
{
    double start = 0.0;          // 拍（展开反复以后）
    double length = 4.0;         // 拍
    int numerator = 4, denominator = 4;
    int sourceIndex = 0;         // 在原谱里是第几小节（从 0 开始）
    juce::String section;        // 段落名（前奏、主歌……）
};

struct TempoPoint
{
    double beat = 0.0;
    double bpm = 120.0;
};

struct Song
{
    juce::String title, artist, sourceFormat;
    juce::File file;
    std::vector<SongBar> bars;
    std::vector<TempoPoint> tempos;      // 至少一个，按拍排序
    std::vector<double> tempoStartSeconds; // 每个速度点开始时的秒数（buildSong 里算好）
    std::vector<SongTrack> tracks;
    double lengthBeats = 0.0;

    double tempoAt (double beat) const;
    double beatToSeconds (double beat) const;
    double secondsToBeat (double seconds) const;
    double lengthSeconds() const { return beatToSeconds (lengthBeats); }
    int barIndexAt (double beat) const;
    int defaultTrack() const;            // 第一条有音符的吉他轨
};

// =============================================================================
// 导入器的中间格式（未展开反复）
struct RawNote
{
    int string = 0;              // 0 = 最细的弦
    int fret = 0;
    bool tieDestination = false;
    bool dead = false, hammerPull = false, palmMute = false, harmonic = false;
    bool vibrato = false, letRing = false, accent = false;
    bool slideOut = false, slideIn = false, slideLegato = false, slideOff = false, tapped = false;
    float bend = 0.0f;           // 半音
    float bendStart = 0.0f, bendEnd = 0.0f, bendPeakPos = 1.0f, bendReleasePos = 1.0f, bendEndPos = 1.0f;
};

struct RawBeat
{
    double duration = 1.0;       // 拍
    bool grace = false;          // 装饰音：不占时值
    int chord = -1;              // RawTrack::chordDiagrams 的下标
    std::vector<RawNote> notes;
};

struct RawVoice { std::vector<RawBeat> beats; };
struct RawBar   { std::vector<RawVoice> voices; };

struct RawTempo
{
    double ratio = 0.0;          // 小节内的位置 0..1
    double bpm = 120.0;
};

struct RawMasterBar
{
    int numerator = 4, denominator = 4;
    bool repeatStart = false;
    int repeatCount = 0;         // >0 表示这里是反复结束，总共弹几遍
    int alternateEndings = 0;    // 位掩码：第 1 遍 = bit0 …
    juce::String section;
    std::vector<RawTempo> tempos;
};

struct RawTrack
{
    juce::String name;
    bool percussion = false;
    std::vector<int> tuning;     // [0] = 最细的弦
    int capo = 0;
    int program = 25;
    std::vector<RawBar> bars;
    std::vector<ChordDiagram> chordDiagrams;
};

struct RawScore
{
    juce::String title, artist, format;
    double initialTempo = 120.0;
    std::vector<RawMasterBar> masterBars;
    std::vector<RawTrack> tracks;
};

// 展开反复、合并连音线、生成速度表
std::unique_ptr<Song> buildSong (const RawScore& raw);

// 读取吉他谱文件（.gp3 .gp4 .gp5 .gpx .gp），失败时返回 nullptr 并写入 error
std::unique_ptr<Song> loadSongFile (const juce::File& file, juce::String& error);

// 内部使用（也给测试用）
bool importGp3To5 (const juce::MemoryBlock& data, RawScore& out, juce::String& error);
bool importGpif (const juce::String& xml, RawScore& out, juce::String& error);
bool extractGpxScore (const juce::MemoryBlock& data, juce::String& xmlOut, juce::String& error);
