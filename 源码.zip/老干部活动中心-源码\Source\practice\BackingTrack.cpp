#include "BackingTrack.h"
#include "Text.h"
#include <juce_events/juce_events.h>

namespace
{
    constexpr double maxSeconds = 20.0 * 60.0;     // 最长 20 分钟（立体声 44.1k 约 400 MB 内存的一半）

    void registerFormats (juce::AudioFormatManager& fm)
    {
        fm.registerBasicFormats();      // WAV / AIFF / FLAC / OGG / MP3（开了 JUCE_USE_MP3AUDIOFORMAT）/ Windows 上的 WMF（M4A、WMA）
    }
}

class BackingTrack::Loader : public juce::Thread
{
public:
    Loader (BackingTrack& o, juce::File f) : juce::Thread ("BackingLoader"), owner (o), file (std::move (f)) {}
    void run() override
    {
        juce::String error;
        auto clip = BackingTrack::decode (file, error);
        if (threadShouldExit()) return;
        auto* raw = clip.release();
        BackingTrack* o = &owner;
        auto alive = owner.aliveFlag;
        juce::MessageManager::callAsync ([o, raw, error, alive]
        {
            std::unique_ptr<Clip> c (raw);
            if (! *alive) return;
            {
                const juce::ScopedLock sl (o->errorLock);
                o->lastError = error;
            }
            if (c != nullptr) o->install (std::move (c));
            o->loading.store (false);
            if (o->onLoaded) o->onLoaded();
        });
    }
    BackingTrack& owner;
    juce::File file;
};

BackingTrack::BackingTrack() = default;

BackingTrack::~BackingTrack()
{
    *aliveFlag = false;
    if (loader != nullptr) loader->stopThread (4000);
    live.store (nullptr);
}

juce::String BackingTrack::supportedWildcard()
{
    juce::AudioFormatManager fm;
    registerFormats (fm);
    auto w = fm.getWildcardForAllFormats();
    for (auto ext : { "*.mp3", "*.wav", "*.flac", "*.ogg", "*.aif", "*.aiff" })
        if (! w.contains (ext)) w << ";" << ext;
    return w;
}

std::unique_ptr<BackingTrack::Clip> BackingTrack::decode (const juce::File& file, juce::String& error)
{
    juce::AudioFormatManager fm;
    registerFormats (fm);
    std::unique_ptr<juce::AudioFormatReader> reader (fm.createReaderFor (file));
    if (reader == nullptr)
    {
        error = T ("打不开这个音频文件（支持 WAV / MP3 / FLAC / OGG / AIFF")
#if JUCE_WINDOWS
                + T (" / M4A / WMA")
#endif
                + T ("）：") + file.getFileName();
        return nullptr;
    }
    if (reader->sampleRate <= 0.0 || reader->lengthInSamples <= 0)
    {
        error = T ("音频文件是空的：") + file.getFileName();
        return nullptr;
    }
    const double seconds = (double) reader->lengthInSamples / reader->sampleRate;
    if (seconds > maxSeconds)
    {
        error = T ("音频太长了（") + juce::String (seconds / 60.0, 1) + T (" 分钟），最长 20 分钟");
        return nullptr;
    }

    auto clip = std::make_unique<Clip>();
    clip->sampleRate = reader->sampleRate;
    clip->file = file;
    clip->name = file.getFileNameWithoutExtension();
    const int len = (int) reader->lengthInSamples;
    clip->audio.setSize (2, len);
    if (reader->numChannels == 1)
    {
        reader->read (&clip->audio, 0, len, 0, true, false);
        clip->audio.copyFrom (1, 0, clip->audio, 0, 0, len);
    }
    else
    {
        reader->read (&clip->audio, 0, len, 0, true, true);
    }

    // 波形缩略图
    clip->peaks.assign ((size_t) Clip::peakBins * 2, 0.0f);
    for (int b = 0; b < Clip::peakBins; ++b)
    {
        const int s0 = (int) ((int64_t) len * b / Clip::peakBins);
        const int s1 = juce::jmax (s0 + 1, (int) ((int64_t) len * (b + 1) / Clip::peakBins));
        float lo = 0.0f, hi = 0.0f;
        const float* l = clip->audio.getReadPointer (0);
        const float* r = clip->audio.getReadPointer (1);
        for (int i = s0; i < s1 && i < len; i += 4)
        {
            const float v = 0.5f * (l[i] + r[i]);
            lo = juce::jmin (lo, v);
            hi = juce::jmax (hi, v);
        }
        clip->peaks[(size_t) b * 2] = lo;
        clip->peaks[(size_t) b * 2 + 1] = hi;
    }
    return clip;
}

void BackingTrack::loadAsync (const juce::File& file)
{
    if (loader != nullptr) loader->stopThread (4000);
    loading.store (true);
    loader = std::make_unique<Loader> (*this, file);
    loader->startThread();
}

bool BackingTrack::loadNow (const juce::File& file, juce::String& error)
{
    auto clip = decode (file, error);
    if (clip == nullptr) return false;
    install (std::move (clip));
    return true;
}

void BackingTrack::install (std::unique_ptr<Clip> clip)
{
    playing.store (false);
    clearLoopRange();
    seekReq.store (0.0);
    positionSec.store (0.0);
    live.store (clip.get());
    if (owned != nullptr)
        retired.push_back ({ std::move (owned), audioEpoch.load() });
    owned = std::move (clip);
}

void BackingTrack::unload()
{
    playing.store (false);
    live.store (nullptr);
    if (owned != nullptr)
        retired.push_back ({ std::move (owned), audioEpoch.load() });
    positionSec.store (0.0);
}

void BackingTrack::collectGarbage()
{
    const uint32_t now = audioEpoch.load();
    retired.erase (std::remove_if (retired.begin(), retired.end(),
                                   [now] (const Retired& r) { return now - r.epoch >= 2; }),
                   retired.end());
    // 设备没在跑（音频线程不走）的时候也别一直攒着
    if (retired.size() > 4) retired.erase (retired.begin());
}

void BackingTrack::seekSeconds (double s)
{
    seekReq.store (juce::jmax (0.0, s));
    positionSec.store (juce::jmax (0.0, s));
}

double BackingTrack::getPositionSeconds() const
{
    return positionSec.load();
}

void BackingTrack::setLoopRange (double a, double b)
{
    loopA.store (juce::jmax (0.0, juce::jmin (a, b)));
    loopB.store (juce::jmax (a, b));
    if (b <= a) { loopA.store (0.0); loopB.store (0.0); }
}

void BackingTrack::process (float* outL, float* outR, int n) noexcept
{
    audioEpoch.fetch_add (1);
    Clip* clip = live.load();
    if (clip != lastLive)
    {
        lastLive = clip;
        readPos = 0.0;
        smoothGain = 0.0f;
    }
    if (clip == nullptr)
        return;

    const double cs = clip->sampleRate;
    if (const double sk = seekReq.exchange (-1.0); sk >= 0.0)
    {
        readPos = juce::jlimit (0.0, (double) clip->audio.getNumSamples() - 1.0, sk * cs);
        smoothGain = 0.0f;          // 跳转时淡入，避免爆音
    }

    const bool play = playing.load();
    const float target = play ? juce::Decibels::decibelsToGain (gainDb.load(), -60.0f) : 0.0f;
    if (! play && smoothGain < 1.0e-4f)
    {
        positionSec.store (readPos / cs);
        return;
    }

    const double step = cs / deviceRate.load() * (double) speed.load();
    const int len = clip->audio.getNumSamples();
    const float* l = clip->audio.getReadPointer (0);
    const float* r = clip->audio.getReadPointer (1);
    const double a = loopA.load() * cs, b = loopB.load() * cs;
    const bool range = b > a + 1.0;
    const float coeff = 1.0f - std::exp (-1.0f / (0.01f * (float) deviceRate.load()));
    float pk = 0.0f;

    for (int i = 0; i < n; ++i)
    {
        if (range && readPos >= b) readPos = a + (readPos - b);
        if (readPos >= len - 1)
        {
            if (loopWhole.load()) readPos = 0.0;
            else { playing.store (false); readPos = len - 1.0; break; }
        }
        smoothGain += (target - smoothGain) * coeff;
        const int i0 = (int) readPos;
        const float f = (float) (readPos - i0);
        const int i1 = juce::jmin (len - 1, i0 + 1);
        // 线性插值（变速 / 采样率不同时）
        const float vl = (l[i0] + (l[i1] - l[i0]) * f) * smoothGain;
        const float vr = (r[i0] + (r[i1] - r[i0]) * f) * smoothGain;
        outL[i] += vl;
        outR[i] += vr;
        pk = juce::jmax (pk, std::abs (vl), std::abs (vr));
        readPos += step;
    }
    if (pk > peak.load()) peak.store (pk);
    positionSec.store (readPos / cs);
}

// =============================================================================
// 跟谱模式：位置由谱子决定的 WSOLA
//   每 hop 个输出采样放一个颗粒（约 21 ms 长，汉宁窗，50% 重叠，窗加起来正好是 1）。
//   颗粒从“原曲里此刻应该在的位置”开始取；放慢 / 加快时，在目标附近 ±12 ms 找一个和上一个颗粒
//   自然接续最像的起点（波形对得上，不会有“嗡嗡”的相位抵消）。原速时正好就是接续点，声音原样输出。
void BackingTrack::resetFollow() noexcept
{
    accL.fill (0.0f);
    accR.fill (0.0f);
    phase = 0;
    prevValid = false;
}

void BackingTrack::addGrain (const Clip& clip, double startClip, double ratio, float gain) noexcept
{
    const int len = clip.audio.getNumSamples();
    const float* l = clip.audio.getReadPointer (0);
    const float* r = clip.audio.getReadPointer (1);
    for (int j = 0; j < grainLen; ++j)
    {
        const double p = startClip + j * ratio;
        if (p < 0.0 || p >= len - 1) continue;
        const int i0 = (int) p;
        const float fr = (float) (p - i0);
        const float w = window[(size_t) j] * gain;
        accL[(size_t) j] += (l[i0] + (l[i0 + 1] - l[i0]) * fr) * w;
        accR[(size_t) j] += (r[i0] + (r[i0 + 1] - r[i0]) * fr) * w;
    }
}

double BackingTrack::chooseStart (const Clip& clip, double target, double natural, double ratio) noexcept
{
    const int len = clip.audio.getNumSamples();
    const float* l = clip.audio.getReadPointer (0);
    const float* r = clip.audio.getReadPointer (1);
    auto mono = [&] (double p) -> float
    {
        if (p < 0.0 || p >= len - 1) return 0.0f;
        const int i0 = (int) p;
        const float fr = (float) (p - i0);
        return 0.5f * ((l[i0] + (l[i0 + 1] - l[i0]) * fr) + (r[i0] + (r[i0 + 1] - r[i0]) * fr));
    };
    // 参考：上一个颗粒自然接下去的那一段（重叠区，隔 4 个采样取一个）
    const int m = juce::jmin ((int) natRef.size(), hopLen / 4);
    for (int k = 0; k < m; ++k) natRef[(size_t) k] = mono (natural + k * 4 * ratio);
    auto score = [&] (double c)
    {
        double xy = 0.0, yy = 1.0e-9;
        for (int k = 0; k < m; k += 2)        // 再隔一个：每格 8 个采样
        {
            const float y = mono (c + k * 4 * ratio);
            xy += natRef[(size_t) k] * y;
            yy += y * y;
        }
        return xy / std::sqrt (yy);
    };
    const double range = 0.012 * clip.sampleRate;
    double best = target, bestScore = -1.0e30;
    for (double d = -range; d <= range; d += 8.0)          // 粗找
        if (const double sc = score (target + d); sc > bestScore) { bestScore = sc; best = target + d; }
    const double coarse = best;
    for (double d = -8.0; d <= 8.0; d += 1.0)               // 细找
        if (const double sc = score (coarse + d); sc > bestScore) { bestScore = sc; best = coarse + d; }
    return best;
}

void BackingTrack::processFollow (float* outL, float* outR, int n, const Follow& f) noexcept
{
    audioEpoch.fetch_add (1);
    Clip* clip = live.load();
    if (clip != lastLive)
    {
        lastLive = clip;
        smoothGain = 0.0f;
        resetFollow();
    }
    if (clip == nullptr)
        return;

    const double dev = deviceRate.load();
    if (dev != grainRate)
    {
        grainRate = dev;
        grainLen = juce::jlimit (512, grainMax, (int) std::pow (2.0, std::round (std::log2 (0.03 * dev))));
        hopLen = grainLen / 2;
        for (int j = 0; j < grainLen; ++j)
            window[(size_t) j] = 0.5f - 0.5f * std::cos (juce::MathConstants<float>::twoPi * (float) j / (float) grainLen);
        resetFollow();
    }

    const bool on = followOn.load();
    const float target = on ? juce::Decibels::decibelsToGain (gainDb.load(), -60.0f) : 0.0f;
    const bool rolling = on && f.rolling && f.secPerSample > 0.02 / dev;   // 等待模式停住时不出声（不然一个颗粒反复放会“嗡”）
    if (! rolling && ! prevValid && phase == 0 && smoothGain < 1.0e-4f)
    {
        bool silent = true;
        for (int j = 0; j < grainLen && silent; ++j) silent = accL[(size_t) j] == 0.0f && accR[(size_t) j] == 0.0f;
        if (silent) { smoothGain = target; return; }
    }

    const double cs = clip->sampleRate, ratio = cs / dev;
    const double off = followOffset.load(), rate = followRate.load();
    const float coeff = 1.0f - std::exp (-1.0f / (0.02f * (float) dev));
    float pk = 0.0f;
    for (int i = 0; i < n; ++i)
    {
        if (phase == 0)
        {
            // 前半已经输出过：往前挪 hop，后面补零
            std::copy (accL.begin() + hopLen, accL.begin() + grainLen, accL.begin());
            std::copy (accR.begin() + hopLen, accR.begin() + grainLen, accR.begin());
            std::fill (accL.begin() + (grainLen - hopLen), accL.begin() + grainLen, 0.0f);
            std::fill (accR.begin() + (grainLen - hopLen), accR.begin() + grainLen, 0.0f);
            if (rolling)
            {
                const double songSec = (f.wrapOffset >= 0 && i >= f.wrapOffset) ? f.wrapSec + (i - f.wrapOffset) * f.secPerSample
                                                                                 : f.startSec + i * f.secPerSample;
                const double want = (off + songSec * rate) * cs;
                const double natural = prevStart + hopLen * ratio;
                double start = want;
                if (prevValid && std::abs (want - natural) < 0.5)
                    start = natural;                                   // 原速：严格接续，声音原样
                else if (prevValid && std::abs (want - natural) < 0.03 * cs)
                    start = chooseStart (*clip, want, natural, ratio); // 变速：找最像的接续点
                // 否则是跳转 / 循环跳回：直接从新位置开始，和旧颗粒的尾巴自然交叉淡化
                addGrain (*clip, start, ratio, 1.0f);
                prevStart = start;
                prevValid = true;
                positionSec.store (start / cs);
            }
            else
            {
                prevValid = false;
            }
        }
        smoothGain += (target - smoothGain) * coeff;
        const float vl = accL[(size_t) phase] * smoothGain, vr = accR[(size_t) phase] * smoothGain;
        outL[i] += vl;
        outR[i] += vr;
        pk = juce::jmax (pk, std::abs (vl), std::abs (vr));
        if (++phase >= hopLen) phase = 0;
    }
    if (pk > peak.load()) peak.store (pk);
}
