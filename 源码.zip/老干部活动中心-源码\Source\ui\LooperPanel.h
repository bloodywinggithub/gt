#pragma once

#include <juce_gui_basics/juce_gui_basics.h>
#include "practice/Looper.h"

class DrumMachine;

// 五轨循环录音的操作条：每轨一个大按钮（录 / 结束 / 叠录）、静音、清除、音量；
// 上面是循环长度、进度、全部播放 / 停止、全部清除、跟鼓机对齐、导出 WAV。
class LooperPanel : public juce::Component,
                    private juce::Timer
{
public:
    LooperPanel (Looper& looper, DrumMachine& drums, juce::PropertiesFile& settings);
    ~LooperPanel() override;

    // 1–5 键按对应轨，0 键全部播放 / 停止
    bool handleKey (const juce::KeyPress& key);
    juce::File exportMix();        // 返回写出的文件（失败返回空）

    void paint (juce::Graphics&) override;
    void resized() override;
    void visibilityChanged() override;

private:
    void timerCallback() override;
    void refresh();

    Looper& looper;
    DrumMachine& drums;
    juce::PropertiesFile& settings;

    struct Strip
    {
        juce::TextButton main, mute, clear;
        juce::Slider volume;
        float level = 0.0f;
        juce::Rectangle<int> area, meter;
    };
    std::array<Strip, Looper::numTracks> strips;

    juce::Label title, lengthLabel, hint;
    juce::TextButton playAllButton, clearAllButton, exportButton;
    juce::ToggleButton syncToggle;
    juce::Rectangle<int> progressArea, topArea;
    juce::String lastExport;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (LooperPanel)
};
