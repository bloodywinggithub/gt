#pragma once

#include <juce_core/juce_core.h>
#include <array>
#include <vector>

// 吉他和弦库：开放和弦 + 可移动的横按指型（E 型 / A 型 / D 型），任何根音都能生成。
// 指法数组的顺序：[0] = 6 弦（最粗）… [5] = 1 弦；品 -1 = 不弹；手指 0 = 空弦 / 不用，1 食指 … 4 小指。
namespace Chords
{
    enum class Quality { major, minor, dom7, maj7, min7, sus2, sus4, add9, power, dim, dim7, m7b5, aug, sixth, min6 };
    constexpr int numQualities = 15;

    struct QualityInfo { const char* suffix; const char* zh; std::vector<int> intervals; };
    const QualityInfo& info (Quality q);

    struct Voicing
    {
        std::array<int, 6> frets {};     // -1 = 不弹
        std::array<int, 6> fingers {};
        juce::String shape;              // “开放和弦” / “E 型横按” …
        int barreFret = -1, barreFrom = 0, barreTo = 5;   // 横按（食指）的品和弦范围
        int lowestFret() const;          // 按着的最低品（0 = 全是空弦）
        int highestFret() const;
        std::vector<int> midiNotes() const;               // 标准调弦
    };

    const juce::StringArray& rootNames (bool flats);
    juce::String name (int root, Quality q, bool flats = false);
    std::vector<Voicing> voicings (int root, Quality q);

    // 调内和弦（顺阶和弦）：大调 I ii iii IV V vi vii°，小调 i ii° III iv v VI VII
    struct Diatonic { int root; Quality quality; juce::String roman; };
    std::vector<Diatonic> diatonic (int keyRoot, bool minor, bool sevenths);

    // 一个和弦图能不能对上这个和弦（测试用）：响的弦的音名集合 == 和弦的音（可以少五音）
    bool matches (const Voicing& v, int root, Quality q);

    constexpr std::array<int, 6> standardTuning { 40, 45, 50, 55, 59, 64 };
}
