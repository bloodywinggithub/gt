#include "AudioEngine.h"

AudioEngine::AudioEngine()
    : dryRing ((size_t) ringSize, 0.0f)
{
    for (auto& a : activeIndexForDeviceChannel)
        a.store (-1);

    prepareInternal (48000.0, 512);
}

AudioEngine::~AudioEngine()
{
    // 设备回调已经被移除，这里可以安全释放所有快照
    releaseAllChains();
}

// ---- 效果器链快照 --------------------------------------------------------------
void AudioEngine::publishChain (std::unique_ptr<ChainSnapshot> snapshot)
{
    // 音频线程还没来得及取走的旧快照，直接由界面线程释放
    delete pending.exchange (snapshot.release(), std::memory_order_acq_rel);
}

void AudioEngine::releaseAllChains()
{
    delete pending.exchange (nullptr);
    delete incoming;
    delete current;
    incoming = current = nullptr;
    fadeState = 0;
    collectGarbage();
}

void AudioEngine::retire (ChainSnapshot* s) noexcept
{
    if (s == nullptr)
        return;

    const auto scope = garbageFifo.write (1);
    if (scope.blockSize1 > 0)
        garbage[(size_t) scope.startIndex1] = s;
    // 队列满（界面线程长时间没回收）时只能泄漏，绝不在音频线程里 delete
}

void AudioEngine::collectGarbage()
{
    const auto scope = garbageFifo.read (garbageFifo.getNumReady());
    for (int i = 0; i < scope.blockSize1; ++i)
        delete garbage[(size_t) (scope.startIndex1 + i)];
    for (int i = 0; i < scope.blockSize2; ++i)
        delete garbage[(size_t) (scope.startIndex2 + i)];
}

// ---- 设备 ----------------------------------------------------------------------
void AudioEngine::updateActiveInputMap (juce::AudioIODevice* device)
{
    for (auto& a : activeIndexForDeviceChannel)
        a.store (-1);

    if (device == nullptr)
        return;

    auto active = device->getActiveInputChannels();
    int index = 0;
    for (int ch = 0; ch < juce::jmin (maxDeviceChannels, active.getHighestBit() + 1); ++ch)
        if (active[ch])
            activeIndexForDeviceChannel[ch].store (index++);
}

void AudioEngine::prepareInternal (double sr, int block)
{
    block = juce::jmax (16, block);
    preparedBlockSize.store (block);
    lastSampleRate.store (sr);

    chainBuffer.setSize (2, block, false, true, false);
    monoBuffer.assign ((size_t) block, 0.0f);

    inputGain.reset (sr, 0.02);
    outputGain.reset (sr, 0.02);
    inputGain.setCurrentAndTargetValue (juce::Decibels::decibelsToGain (inputGainDb.load()));
    outputGain.setCurrentAndTargetValue (juce::Decibels::decibelsToGain (outputGainDb.load()));

    drums.prepare (sr);
    tabPlayer.prepare (sr);
    previewSynth.prepare (sr);
    looper.setSampleRate (sr);
    backing.setDeviceSampleRate (sr);
    original.setDeviceSampleRate (sr);
    loopInL.assign ((size_t) block, 0.0f);
    loopInR.assign ((size_t) block, 0.0f);
    previewL.assign ((size_t) block, 0.0f);
    previewR.assign ((size_t) block, 0.0f);
    judge.setSampleRate (sr);
    recorder.setSampleRate (sr);

    // 设备没在跑，链路里的效果器可以安全地重新准备
    for (auto* snap : { current, incoming, pending.load() })
        if (snap != nullptr)
            for (auto& s : snap->slots)
                s->prepare (sr, block);
}

void AudioEngine::audioDeviceAboutToStart (juce::AudioIODevice* device)
{
    updateActiveInputMap (device);
    prepareInternal (device->getCurrentSampleRate(), device->getCurrentBufferSizeSamples());

    std::fill (dryRing.begin(), dryRing.end(), 0.0f);
    dryWritePos.store (0);
    currentSampleRate.store (device->getCurrentSampleRate());
}

void AudioEngine::audioDeviceStopped()
{
    currentSampleRate.store (0.0);
    guitarChannelActive.store (false);
}

// ---- 处理 ----------------------------------------------------------------------
void AudioEngine::audioDeviceIOCallbackWithContext (const float* const* inputChannelData,
                                                    int numInputChannels,
                                                    float* const* outputChannelData,
                                                    int numOutputChannels,
                                                    int numSamples,
                                                    const juce::AudioIODeviceCallbackContext&)
{
    juce::ScopedNoDenormals noDenormals;

    const int devCh = guitarDeviceChannel.load();
    const int idx = (devCh >= 0 && devCh < maxDeviceChannels) ? activeIndexForDeviceChannel[devCh].load() : -1;
    const float* in = (idx >= 0 && idx < numInputChannels) ? inputChannelData[idx] : nullptr;
    guitarChannelActive.store (in != nullptr);

    // 找前两个输出通道
    float* outL = nullptr;
    float* outR = nullptr;
    for (int ch = 0; ch < numOutputChannels; ++ch)
    {
        if (outputChannelData[ch] == nullptr)
            continue;
        if (outL == nullptr)      outL = outputChannelData[ch];
        else if (outR == nullptr) outR = outputChannelData[ch];
        else juce::FloatVectorOperations::clear (outputChannelData[ch], numSamples);
    }

    // 按准备好的块大小切开处理，保证插件拿到的样本数不超过 prepareToPlay 时的值
    const int block = preparedBlockSize.load();
    for (int pos = 0; pos < numSamples; )
    {
        const int n = juce::jmin (block, numSamples - pos);
        float* l = chainBuffer.getWritePointer (0);
        float* r = chainBuffer.getWritePointer (1);
        processSubBlock (in != nullptr ? in + pos : nullptr, l, r, n);

        if (outL != nullptr && outR != nullptr)
        {
            juce::FloatVectorOperations::copy (outL + pos, l, n);
            juce::FloatVectorOperations::copy (outR + pos, r, n);
        }
        else if (outL != nullptr)
        {
            for (int i = 0; i < n; ++i)
                outL[pos + i] = 0.5f * (l[i] + r[i]);
        }
        pos += n;
    }
}

void AudioEngine::processSubBlock (const float* guitarIn, float* outL, float* outR, int n) noexcept
{
    float* mono = monoBuffer.data();

    // 1. 吉他输入 + 削波检测
    if (guitarIn != nullptr)
    {
        const auto range = juce::FloatVectorOperations::findMinAndMax (guitarIn, n);
        if (juce::jmax (std::abs (range.getStart()), std::abs (range.getEnd())) >= 0.98f)
            inputClipped.store (true);
        juce::FloatVectorOperations::copy (mono, guitarIn, n);
    }
    else
    {
        juce::FloatVectorOperations::clear (mono, n);
    }

    // 1b. 回放录音时用录音代替吉他输入；录音时把原始输入写盘（都在输入增益之前）
    recorder.replaceInput (mono, n);
    recorder.capture (mono, n, tabPlayer.isPlaying(), tabPlayer.getPosition());

    // 2. 干信号写入环形缓冲
    {
        const uint32_t w = dryWritePos.load (std::memory_order_relaxed);
        for (int i = 0; i < n; ++i)
            dryRing[(size_t) ((w + (uint32_t) i) & (ringSize - 1))] = mono[i];
        dryWritePos.store (w + (uint32_t) n, std::memory_order_release);
    }

    // 3. 输入增益
    inputGain.setTargetValue (juce::Decibels::decibelsToGain (inputGainDb.load()));
    for (int i = 0; i < n; ++i)
        mono[i] *= inputGain.getNextValue();
    {
        const auto r = juce::FloatVectorOperations::findMinAndMax (mono, n);
        const float p = juce::jmax (std::abs (r.getStart()), std::abs (r.getEnd()));
        float prev = inputPeak.load();
        while (p > prev && ! inputPeak.compare_exchange_weak (prev, p)) {}
    }

    juce::FloatVectorOperations::copy (outL, mono, n);
    juce::FloatVectorOperations::copy (outR, mono, n);

    // 4. 效果器链（换链路时：旧链路淡出一块，新链路淡入一块）
    if (fadeState == 0)
    {
        if (auto* p = pending.exchange (nullptr, std::memory_order_acq_rel))
        {
            incoming = p;
            fadeState = current != nullptr ? 1 : 2;
            if (current == nullptr)
            {
                current = incoming;
                incoming = nullptr;
            }
        }
    }

    juce::AudioBuffer<float> io (chainBuffer.getArrayOfWritePointers(), 2, n);
    if (current != nullptr)
        for (auto& s : current->slots)
            s->process (io, n);

    if (fadeState == 1)
    {
        io.applyGainRamp (0, n, 1.0f, 0.0f);
        retire (current);
        current = incoming;
        incoming = nullptr;
        fadeState = 2;
    }
    else if (fadeState == 2)
    {
        io.applyGainRamp (0, n, 0.0f, 1.0f);
        fadeState = 0;
    }

    // 4b. 循环录音录的是效果器之后、吉他音量之前的声音（关了监听也照样录）
    if (n <= (int) loopInL.size())
    {
        juce::FloatVectorOperations::copy (loopInL.data(), outL, n);
        juce::FloatVectorOperations::copy (loopInR.data(), outR, n);
    }

    // 5. 吉他音量 / 监听开关
    outputGain.setTargetValue (monitoring.load() ? juce::Decibels::decibelsToGain (outputGainDb.load()) : 0.0f);
    for (int i = 0; i < n; ++i)
    {
        const float g = outputGain.getNextValue();
        outL[i] *= g;
        outR[i] *= g;
    }

    // 6. 谱子播放（示范 / 伴奏 / 谱里的鼓）和鼓机
    tabPlayer.render (outL, outR, n, drums);
    drums.render (outL, outR, n);

    // 6'. 谱子的原曲：跟着谱子的走带（变速时音高不变）
    {
        const auto& bp = tabPlayer.getLastBlockPosition();
        BackingTrack::Follow f;
        f.rolling = bp.secRolling;
        f.startSec = bp.secStart;
        f.secPerSample = bp.secPerSample;
        f.wrapOffset = bp.wrapOffset;
        f.wrapSec = bp.secWrapStart;
        original.processFollow (outL, outR, n, f);
    }

    // 6a'. 导入的音频伴奏（不过效果器）
    backing.process (outL, outR, n);

    // 6a. 五轨循环
    if (n <= (int) loopInL.size())
        looper.process (loopInL.data(), loopInR.data(), outL, outR, n, drums);

    // 6b. 试听音（指板音阶）
    if (previewStop.exchange (false))
        previewSynth.allNotesOff();
    {
        int s1, n1, s2, n2;
        previewFifo.prepareToRead (previewFifo.getNumReady(), s1, n1, s2, n2);
        for (int i = 0; i < n1; ++i) previewSynth.noteOn (previewQueue[(size_t) (s1 + i)]);
        for (int i = 0; i < n2; ++i) previewSynth.noteOn (previewQueue[(size_t) (s2 + i)]);
        previewFifo.finishedRead (n1 + n2);
    }
    if (n <= (int) previewL.size())
    {
        juce::FloatVectorOperations::clear (previewL.data(), n);
        juce::FloatVectorOperations::clear (previewR.data(), n);
        previewSynth.render (previewL.data(), previewR.data(), n);
        const float g = juce::Decibels::decibelsToGain (previewGainDb.load());
        juce::FloatVectorOperations::addWithMultiply (outL, previewL.data(), g, n);
        juce::FloatVectorOperations::addWithMultiply (outR, previewR.data(), g, n);
    }

    // 弹奏判定：干信号（输入增益后、效果器前）+ 这一块对应的谱子位置
    {
        const auto& bp = tabPlayer.getLastBlockPosition();
        JudgeFeed::Block info;
        info.beat = bp.beat;
        info.beatsPerSample = bp.beatsPerSample;
        info.nominalBps = bp.nominalBps;
        info.rolling = bp.rolling;
        info.wrapOffset = bp.wrapOffset;
        info.wrapBeat = bp.wrapBeat;
        info.loopA = bp.loopA;
        info.loopB = bp.loopB;
        judge.getFeed().push (mono, n, info);
    }

    // 7. 输出电平
    {
        const auto rl = juce::FloatVectorOperations::findMinAndMax (outL, n);
        const auto rr = juce::FloatVectorOperations::findMinAndMax (outR, n);
        const float p = juce::jmax (std::abs (rl.getStart()), std::abs (rl.getEnd()), std::abs (rr.getStart()), std::abs (rr.getEnd()));
        if (p >= 0.99f)
            outputClipped.store (true);
        float prev = outputPeak.load();
        while (p > prev && ! outputPeak.compare_exchange_weak (prev, p)) {}
    }
}

void AudioEngine::previewNote (int midi, float velocity, double seconds)
{
    PluckSynth::NoteOn on;
    on.midi = juce::jlimit (20, 100, midi);
    on.velocity = velocity;
    on.bass = midi < 40;          // 贝斯的低音：用贝斯的音色
    on.lengthSeconds = seconds;
    const juce::SpinLock::ScopedLockType lock (previewPushLock);
    int s1, n1, s2, n2;
    previewFifo.prepareToWrite (1, s1, n1, s2, n2);
    if (n1 > 0) previewQueue[(size_t) s1] = on;
    else if (n2 > 0) previewQueue[(size_t) s2] = on;
    previewFifo.finishedWrite (n1 + n2);
}

double AudioEngine::copyRecentDrySamples (float* dest, int numSamples) const
{
    const double sr = currentSampleRate.load();
    if (sr <= 0.0 || numSamples > ringSize)
        return 0.0;

    const uint32_t end = dryWritePos.load (std::memory_order_acquire);
    const uint32_t start = end - (uint32_t) numSamples;
    for (int i = 0; i < numSamples; ++i)
        dest[i] = dryRing[(size_t) ((start + (uint32_t) i) & (ringSize - 1))];
    return sr;
}

// ---- 离线测试 ------------------------------------------------------------------
void AudioEngine::prepareForOffline (double sampleRate, int blockSize)
{
    prepareInternal (sampleRate, blockSize);
    currentSampleRate.store (sampleRate);
}

void AudioEngine::processOffline (const float* monoIn, float* outL, float* outR, int numSamples)
{
    const int block = preparedBlockSize.load();
    for (int pos = 0; pos < numSamples; )
    {
        const int n = juce::jmin (block, numSamples - pos);
        float* l = chainBuffer.getWritePointer (0);
        float* r = chainBuffer.getWritePointer (1);
        processSubBlock (monoIn + pos, l, r, n);
        juce::FloatVectorOperations::copy (outL + pos, l, n);
        juce::FloatVectorOperations::copy (outR + pos, r, n);
        pos += n;
    }
}
