#!/bin/bash
# 老干部活动中心 · Mac 一键编译 + 打包（在 Mac 上运行：打开“终端”，把这个文件拖进去回车）
# 需要：Xcode 命令行工具（第一次运行会提示安装）、CMake（brew install cmake，或从 cmake.org 下载）
set -e
cd "$(dirname "$0")"
ROOT="$(pwd)"
echo "=================================================="
echo "  老干部活动中心 Mac 版编译"
echo "=================================================="

if ! xcode-select -p >/dev/null 2>&1; then
    echo "[错误] 没有 Xcode 命令行工具。正在弹出安装窗口，装好以后再运行一次本脚本。"
    xcode-select --install || true
    exit 1
fi
CMAKE="$(command -v cmake || true)"
[ -z "$CMAKE" ] && [ -x /Applications/CMake.app/Contents/bin/cmake ] && CMAKE=/Applications/CMake.app/Contents/bin/cmake
if [ -z "$CMAKE" ]; then
    echo "[错误] 没有找到 CMake。装法二选一："
    echo "  1. 有 Homebrew：brew install cmake"
    echo "  2. 到 https://cmake.org/download/ 下载 macOS 版，拖到“应用程序”"
    exit 1
fi

# ---- 第三方库 ----
[ -f third_party/JUCE/CMakeLists.txt ] || { echo "解压 JUCE ..."; (cd third_party && unzip -q -o JUCE-9.0.4.zip); }
[ -f third_party/nam/NAM/dsp.h ] || { echo "解压 NAM ..."; (cd third_party && unzip -q -o NAM-core.zip); }
ORT_VER=1.20.1
ORT_DIR=third_party/onnxruntime/osx-universal2
if ! ls $ORT_DIR/lib/libonnxruntime.*.*.*.dylib >/dev/null 2>&1; then
    echo "下载 ONNX Runtime $ORT_VER（AI 扒谱用，约 30 MB）..."
    mkdir -p third_party/onnxruntime
    curl -L --fail -o /tmp/ort.tgz "https://github.com/microsoft/onnxruntime/releases/download/v$ORT_VER/onnxruntime-osx-universal2-$ORT_VER.tgz"
    rm -rf "$ORT_DIR" /tmp/ort_x && mkdir -p /tmp/ort_x && tar -xzf /tmp/ort.tgz -C /tmp/ort_x
    mv /tmp/ort_x/onnxruntime-osx-universal2-$ORT_VER "$ORT_DIR"
fi

# ---- 编译（Apple 芯片 + Intel 通用版）----
echo "[1/2] 编译（第一次约 5-15 分钟）..."
"$CMAKE" -S . -B build-mac -DCMAKE_BUILD_TYPE=Release
"$CMAKE" --build build-mac --config Release --parallel "$(sysctl -n hw.ncpu)"
APP_BUILT="$(find build-mac -name 'LianqinHost.app' -type d -path '*Release*' | head -1)"
[ -d "$APP_BUILT" ] || { echo "[错误] 没有找到编译出来的 LianqinHost.app"; exit 1; }

# ---- 打包 ----
echo "[2/2] 打包 .app 和 .dmg ..."
VER=$(sed -n 's/^project(LianqinHost VERSION \([0-9.]*\).*/\1/p' CMakeLists.txt)
OUT="$ROOT/发布"
STAGE="$OUT/老干部活动中心-v$VER-mac"
APP="$STAGE/老干部活动中心.app"
rm -rf "$STAGE" && mkdir -p "$STAGE"
cp -R "$APP_BUILT" "$APP"
RES="$APP/Contents/Resources"
[ -f "$APP/Contents/MacOS/libonnxruntime.dylib" ] || cp "$(ls $ORT_DIR/lib/libonnxruntime.*.*.*.dylib | head -1)" "$APP/Contents/MacOS/libonnxruntime.dylib"
# 程序自带的东西放进 .app 里（拖到“应用程序”就能用）
[ -d "音色库" ] && cp -R "音色库" "$RES/音色库" || mkdir -p "$RES/音色库"
[ -d "$HOME/Documents/LianqinHost/音色预设" ] && cp -R "$HOME/Documents/LianqinHost/音色预设" "$RES/音色预设"
[ -d "默认设置" ] && cp -R "默认设置" "$RES/默认设置"
mkdir -p "$RES/吉他谱"
cp 使用说明.txt "$STAGE/使用说明.txt"
cp -R licenses "$STAGE/许可证"
if [ -f third_party/demucs/htdemucs_6s_fp16weights.onnx ] && [ "${WITH_DEMUCS:-0}" = "1" ]; then
    mkdir -p "$RES/models" && cp third_party/demucs/htdemucs_6s_fp16weights.onnx "$RES/models/"
fi
cat > "$STAGE/Mac 第一次打开看这里.txt" <<'TXT'
1. 把“老干部活动中心.app”拖到“应用程序”文件夹。
2. 第一次打开：右键（或按住 Control 点）程序 → 打开 → 再点“打开”。
   如果提示“已损坏，无法打开”：打开“终端”，输入下面这行回车（要输开机密码）：
       sudo xattr -dr com.apple.quarantine /Applications/老干部活动中心.app
   （这是因为程序没有苹果开发者签名，不是真的坏了。）
3. 第一次用会问“是否允许使用麦克风”：点允许——这是读取声卡里的吉他信号。
   点错了：系统设置 → 隐私与安全性 → 麦克风，把“老干部活动中心”打开。
4. 声卡：程序右上角“音频设置…”选你的声卡。Mac 自带 CoreAudio 驱动，延迟本来就低，不需要 ASIO。
5. 自己的谱子、扒谱生成的谱在“文稿/LianqinHost/吉他谱”；音色预设在“文稿/LianqinHost/音色预设”。
6. 更准的 AI 扒谱：下载“分离模型”压缩包，解压后把 models 文件夹放到“老干部活动中心.app”旁边。
TXT
# 改过 .app 里的文件以后要重新签名（Apple 芯片上不签名根本打不开；这里是本机临时签名，不是开发者签名）
codesign --force --deep --sign - "$APP"
ln -s /Applications "$STAGE/应用程序"
DMG="$OUT/老干部活动中心-v$VER-mac.dmg"
rm -f "$DMG"
hdiutil create -volname "老干部活动中心" -srcfolder "$STAGE" -ov -format UDZO "$DMG" >/dev/null
echo ""
echo "=================================================="
echo "  完成：$DMG"
echo "=================================================="
