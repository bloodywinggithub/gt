#pragma once

#include <juce_audio_formats/juce_audio_formats.h>
#include <array>
#include <atomic>
#include <cmath>
#include <functional>
#include <memory>
#include <vector>

// 音频伴奏：导入一首歌 / 伴奏音轨（WAV、MP3、FLAC、OGG、AIFF；Windows 上还有 M4A / WMA），
// 跟着弹。可以播放 / 暂停 / 拖动位置 / 整首循环 / A-B 循环 / 调音量 / 变速（会跟着变调）。
// 伴奏不经过效果器，直接进声卡输出。
//
// 线程：载入在后台线程解码；音频线程只读一个不会再改的“片段”（Clip）。
// 换片段时旧的不马上删，等音频线程确认走过两块以后再由界面线程删（collectGarbage）。
class BackingTrack
{
public:
    struct Clip
    {
        juce::AudioBuffer<float> audio;     // 立体声，文件原来的采样率
        double sampleRate = 44100.0;
        juce::String name;
        juce::File file;
        std::vector<float> peaks;           // 波形缩略图：每格 (min, max)，共 peakBins 格
        static constexpr int peakBins = 1200;
        double lengthSeconds() const { return audio.getNumSamples() / sampleRate; }
    };

    BackingTrack();
    ~BackingTrack();

    // ---- 界面线程 ---------------------------------------------------------------
    // 在后台开始解码；完成后 onLoaded（消息线程）回调。失败时 error 里写原因。
    void loadAsync (const juce::File& file);
    bool isLoading() const                    { return loading.load(); }
    juce::String getLastError() const         { const juce::ScopedLock sl (errorLock); return lastError; }
    std::function<void()> onLoaded;           // 成功或失败都会调；看 getClip() 是否为空

    // 同步载入（测试用）
    bool loadNow (const juce::File& file, juce::String& error);
    void unload();

    const Clip* getClip() const               { return owned.get(); }
    static juce::String supportedWildcard();  // "*.wav;*.mp3;..."

    void setPlaying (bool p)                  { playing.store (p && owned != nullptr); }
    bool isPlaying() const                    { return playing.load(); }
    void seekSeconds (double s);
    double getPositionSeconds() const;
    void setLoopWhole (bool on)               { loopWhole.store (on); }
    bool getLoopWhole() const                 { return loopWhole.load(); }
    void setLoopRange (double aSec, double bSec);   // b <= a = 不循环
    void clearLoopRange()                     { setLoopRange (0.0, 0.0); }
    double getLoopA() const                   { return loopA.load(); }
    double getLoopB() const                   { return loopB.load(); }
    bool hasLoopRange() const                 { return loopB.load() > loopA.load(); }
    void setGainDb (float db)                 { gainDb.store (db); }
    float getGainDb() const                   { return gainDb.load(); }
    void setSpeed (float ratio)               { speed.store (juce::jlimit (0.5f, 1.5f, ratio)); }
    float getSpeed() const                    { return speed.load(); }
    float takePeak()                          { return peak.exchange (0.0f); }

    void collectGarbage();

    // ---- 跟谱模式（原曲和谱子同步）------------------------------------------------
    // 谱子的走带是主控：每块告诉这里“谱子时间轴上从第几秒走到第几秒”，这里按
    //   原曲时间 = offset + 谱子时间 × rate
    // 取原曲的声音。放慢时用 WSOLA 拉伸（音高不变）；跳转、A-B 循环跳回时交叉淡化。
    struct Follow
    {
        bool rolling = false;
        double startSec = 0.0;        // 这一块第一个采样对应的谱子时间（秒，原速）
        double secPerSample = 0.0;    // 谱子时间每个输出采样走多少秒（含变速）
        int wrapOffset = -1;          // 这一块里从 B 跳回 A 的位置
        double wrapSec = 0.0;
    };
    void setFollowOffset (double sec)         { followOffset.store (sec); }
    double getFollowOffset() const            { return followOffset.load(); }
    void setFollowRate (double r)             { followRate.store (juce::jlimit (0.5, 2.0, r)); }
    double getFollowRate() const              { return followRate.load(); }
    void setFollowEnabled (bool on)           { followOn.store (on); }
    bool isFollowEnabled() const              { return followOn.load(); }

    // ---- 音频线程 ---------------------------------------------------------------
    void setDeviceSampleRate (double sr)      { deviceRate.store (sr > 0.0 ? sr : 48000.0); }
    void process (float* outL, float* outR, int n) noexcept;
    void processFollow (float* outL, float* outR, int n, const Follow& f) noexcept;

private:
    class Loader;
    static std::unique_ptr<Clip> decode (const juce::File& file, juce::String& error);
    void install (std::unique_ptr<Clip> clip);

    std::unique_ptr<Clip> owned;                       // 界面线程持有
    std::atomic<Clip*> live { nullptr };               // 音频线程读
    struct Retired { std::unique_ptr<Clip> clip; uint32_t epoch; };
    std::vector<Retired> retired;
    std::atomic<uint32_t> audioEpoch { 0 };

    std::atomic<bool> playing { false }, loopWhole { true }, loading { false };
    std::atomic<double> loopA { 0.0 }, loopB { 0.0 }, seekReq { -1.0 }, positionSec { 0.0 };
    std::atomic<double> deviceRate { 48000.0 };
    std::atomic<float> gainDb { -6.0f }, speed { 1.0f }, peak { 0.0f };
    double readPos = 0.0;                              // 音频线程：在片段里的位置（采样，片段采样率）
    float smoothGain = 0.0f;
    Clip* lastLive = nullptr;

    // 跟谱模式（WSOLA）
    std::atomic<double> followOffset { 0.0 }, followRate { 1.0 };
    std::atomic<bool> followOn { true };
    static constexpr int grainMax = 4096;
    std::array<float, grainMax> accL {}, accR {}, window {};
    std::array<float, grainMax / 4> natRef {};
    int grainLen = 0, hopLen = 0, phase = 0;
    double grainRate = 0.0;           // 按哪个设备采样率准备的窗
    double prevStart = 0.0;           // 上一个颗粒从片段第几个采样开始
    bool prevValid = false;
    void resetFollow() noexcept;
    void addGrain (const Clip& clip, double startClip, double ratio, float gain) noexcept;
    double chooseStart (const Clip& clip, double target, double natural, double ratio) noexcept;

    std::unique_ptr<Loader> loader;
    std::shared_ptr<std::atomic<bool>> aliveFlag = std::make_shared<std::atomic<bool>> (true);
    juce::CriticalSection errorLock;
    juce::String lastError;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (BackingTrack)
};
