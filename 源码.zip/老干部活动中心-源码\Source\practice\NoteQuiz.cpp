#include "NoteQuiz.h"

using namespace ScaleTheory;

namespace
{
    bool isNatural (int pc) { pc = (pc % 12 + 12) % 12; return pc == 0 || pc == 2 || pc == 4 || pc == 5 || pc == 7 || pc == 9 || pc == 11; }
}

bool NoteQuiz::inRange (int s, int f) const
{
    if (! juce::isPositiveAndBelow (s, numStrings()) || f < range.fretLo || f > range.fretHi) return false;
    if ((range.stringMask & (1u << s)) == 0) return false;
    return ! range.naturalsOnly || isNatural (openMidi[s] + f);
}

std::vector<NoteQuiz::Spot> NoteQuiz::spotsOf (int pc) const
{
    std::vector<Spot> out;
    for (int s = 0; s < numStrings(); ++s)
        for (int f = range.fretLo; f <= range.fretHi; ++f)
            if (inRange (s, f) && (openMidi[s] + f) % 12 == (pc % 12 + 12) % 12)
                out.push_back ({ s, f });
    return out;
}

void NoteQuiz::next (double nowMs)
{
    answered = false;
    missedThis = false;
    askedAt = nowMs;
    targetSpots.clear();
    foundFlags.clear();

    if (type == Type::nameTheSpot)
    {
        std::vector<Spot> all;
        for (int s = 0; s < numStrings(); ++s)
            for (int f = range.fretLo; f <= range.fretHi; ++f)
                if (inRange (s, f)) all.push_back ({ s, f });
        if (all.empty()) { asked = { 0, 0 }; return; }
        // 不连着出同一个位置
        for (int tries = 0; tries < 8; ++tries)
        {
            asked = all[(size_t) rng.nextInt ((int) all.size())];
            if (asked.string * 100 + asked.fret != lastKey || all.size() == 1) break;
        }
        lastKey = asked.string * 100 + asked.fret;
        askedPc = asked.midi() % 12;
    }
    else
    {
        std::vector<int> pcs;
        for (int pc = 0; pc < 12; ++pc)
            if (! spotsOf (pc).empty()) pcs.push_back (pc);
        if (pcs.empty()) { askedPc = 0; return; }
        for (int tries = 0; tries < 8; ++tries)
        {
            askedPc = pcs[(size_t) rng.nextInt ((int) pcs.size())];
            if (askedPc != lastKey || pcs.size() == 1) break;
        }
        lastKey = askedPc;
        targetSpots = spotsOf (askedPc);
        foundFlags.assign (targetSpots.size(), false);
    }
}

void NoteQuiz::finish (bool ok, double nowMs)
{
    answered = true;
    ++stats.asked;
    if (ok)
    {
        ++stats.correct;
        stats.totalMs += nowMs - askedAt;
        stats.bestStreak = juce::jmax (stats.bestStreak, ++stats.streak);
    }
    else
    {
        ++stats.wrong;
        stats.streak = 0;
        ++stats.missesByPc[(size_t) askedPc];
    }
}

NoteQuiz::Outcome NoteQuiz::answerName (int pc, double nowMs)
{
    if (answered || type != Type::nameTheSpot) return Outcome::none;
    const bool ok = (pc % 12 + 12) % 12 == askedPc;
    finish (ok, nowMs);
    return ok ? Outcome::correct : Outcome::wrong;
}

NoteQuiz::Outcome NoteQuiz::answerSpot (int s, int f, double nowMs)
{
    if (answered || type != Type::findTheNote) return Outcome::none;
    for (size_t i = 0; i < targetSpots.size(); ++i)
        if (targetSpots[i].string == s && targetSpots[i].fret == f)
        {
            if (foundFlags[i]) return Outcome::none;
            foundFlags[i] = true;
            if (std::all_of (foundFlags.begin(), foundFlags.end(), [] (bool b) { return b; }))
            {
                finish (! missedThis, nowMs);
                return missedThis ? Outcome::wrong : Outcome::correct;
            }
            return Outcome::partial;
        }
    if (! inRange (s, f)) return Outcome::none;      // 点到范围外：不算
    missedThis = true;                               // 点错一次，这题就不算全对（但可以继续找完）
    return Outcome::wrong;
}

NoteQuiz::Outcome NoteQuiz::answerPlayed (int midi, double nowMs)
{
    if (answered || type != Type::findTheNote || midi < 0) return Outcome::none;
    if (midi % 12 != askedPc)
    {
        // 弹了别的音：算错一次
        missedThis = true;
        return Outcome::wrong;
    }
    // 同一个音高可能在好几根弦上：标第一个还没找到的
    for (size_t i = 0; i < targetSpots.size(); ++i)
        if (! foundFlags[i] && targetSpots[i].midi() == midi)
            return answerSpot (targetSpots[i].string, targetSpots[i].fret, nowMs);
    return Outcome::none;     // 这个音高的位置都找过了
}

juce::String NoteQuiz::weakestNotes (bool flats) const
{
    std::vector<std::pair<int, int>> v;
    for (int pc = 0; pc < 12; ++pc)
        if (stats.missesByPc[(size_t) pc] > 0) v.push_back ({ stats.missesByPc[(size_t) pc], pc });
    std::sort (v.begin(), v.end(), [] (auto a, auto b) { return a.first > b.first; });
    juce::StringArray names;
    for (size_t i = 0; i < v.size() && i < 3; ++i)
        names.add (noteName (60 + v[i].second, flats));
    return names.joinIntoString (juce::String::fromUTF8 ("、"));
}
