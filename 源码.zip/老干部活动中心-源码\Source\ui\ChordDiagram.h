#pragma once

#include <juce_gui_basics/juce_gui_basics.h>
#include <array>

// 画一个和弦指法图（竖着看：左边 6 弦，右边 1 弦；上面是琴枕）。
// frets[0] = 6 弦 … frets[5] = 1 弦，-1 = 不弹。fingers 可以为空。
// status（可选）：每根弦 0 = 不显示，1 = 听到了（绿），2 = 没听到（红），3 = 说不准（灰，和低音弦同名、分不出来）
namespace ChordDraw
{
    struct Args
    {
        std::array<int, 6> frets { -1, -1, -1, -1, -1, -1 };
        std::array<int, 6> fingers {};
        bool hasFingers = false;
        int barreFret = -1, barreFrom = 0, barreTo = 5;
        juce::String title, subtitle;
        juce::Colour accent { 0xff3b82f6 };
        const std::array<uint8_t, 6>* status = nullptr;
        bool highlight = false;
    };

    void draw (juce::Graphics&, juce::Rectangle<float> area, const Args&);

    // 谱子里的和弦图（frets[0] = 最细的弦）转成上面的顺序；不是 6 弦就返回 false
    bool fromSong (const std::vector<int>& songFrets, std::array<int, 6>& out);
}
