#pragma once

#include <juce_core/juce_core.h>
#include <array>
#include <vector>
#include "practice/ScaleTheory.h"

// 指板认音训练的出题 / 判分逻辑（不含界面，方便测试）。
//   看位置说音名：指板上亮一个位置，选出它是什么音。
//   看音名找位置：给一个音名，在范围内把它所有的位置都找出来（弹出来或者点出来）。
class NoteQuiz
{
public:
    enum class Type { nameTheSpot, findTheNote };

    struct Range
    {
        int fretLo = 0, fretHi = 12;
        uint8_t stringMask = 0x3f;      // 第 0 位 = 6 弦（最粗）… 第 5 位 = 1 弦
        bool naturalsOnly = false;      // 只出自然音（C D E F G A B）
    };
    struct Spot { int string = 0, fret = 0; int midi() const { return ScaleTheory::openMidi[string] + fret; } };

    explicit NoteQuiz (uint32_t seed = 0) : rng ((int64_t) seed) {}

    void setType (Type t)                   { type = t; }
    Type getType() const                    { return type; }
    void setRange (Range r)                 { range = r; }
    const Range& getRange() const           { return range; }

    bool inRange (int string, int fret) const;
    std::vector<Spot> spotsOf (int pitchClass) const;   // 范围内这个音名的所有位置

    // ---- 出题 ----
    void next (double nowMs);
    const Spot& askedSpot() const           { return asked; }      // 看位置说音名
    int askedPitchClass() const             { return askedPc; }   // 看音名找位置
    const std::vector<Spot>& targets() const { return targetSpots; }
    const std::vector<bool>& found() const  { return foundFlags; }

    // ---- 作答 ----
    enum class Outcome { none, correct, wrong, partial };
    Outcome answerName (int pitchClass, double nowMs);          // 看位置说音名
    Outcome answerSpot (int string, int fret, double nowMs);    // 看音名找位置：点了一个位置
    Outcome answerPlayed (int midi, double nowMs);              // 看音名找位置：弹了一个音

    // ---- 统计 ----
    struct Stats
    {
        int asked = 0, correct = 0, wrong = 0, streak = 0, bestStreak = 0;
        double totalMs = 0.0;
        std::array<int, 12> missesByPc {};
        float accuracy() const { return asked > 0 ? (float) correct / (float) asked : 0.0f; }
        double avgSeconds() const { return correct > 0 ? totalMs / correct / 1000.0 : 0.0; }
    };
    const Stats& getStats() const           { return stats; }
    void resetStats()                       { stats = {}; }
    juce::String weakestNotes (bool flats) const;     // 最容易错的音（最多 3 个）
    bool isAnswered() const                 { return answered; }

private:
    void finish (bool ok, double nowMs);

    Type type = Type::nameTheSpot;
    Range range;
    juce::Random rng;
    Spot asked;
    int askedPc = 0;
    std::vector<Spot> targetSpots;
    std::vector<bool> foundFlags;
    double askedAt = 0.0;
    bool answered = false, missedThis = false;
    int lastKey = -1;
    Stats stats;
};
