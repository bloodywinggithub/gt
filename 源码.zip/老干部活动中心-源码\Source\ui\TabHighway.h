#pragma once

#include <juce_gui_basics/juce_gui_basics.h>
#include "song/Song.h"
#include "practice/TabPlayer.h"
#include "practice/Judge.h"
#include "song/TabEdit.h"

// 音游式谱面：每根弦一条横向轨道，音符从右往左滚向判定线。
// 底部是全曲进度条：点击跳转，拖动框出 A-B 循环段。
class TabHighway : public juce::Component
{
public:
    explicit TabHighway (TabPlayer& playerToUse);
    ~TabHighway() override;

    void setSong (std::shared_ptr<const Song> song, int trackIndex);
    void setTrack (int trackIndex);
    void setZoom (float pixelsPerSecond)     { pxPerSec = pixelsPerSecond; repaint(); }
    float getZoom() const                    { return pxPerSec; }

    // 只用于离线截图：固定显示某个位置
    void setFrozenPosition (double beat)     { frozenBeat = beat; repaint(); }

    std::function<void (double, double)> onLoopDragged;   // 在进度条上框选了 A-B
    std::function<void (float)> onZoomChanged;           // 滚轮调了间距

    // 弹奏判定结果（nullptr = 不显示）
    void setJudgeSession (std::shared_ptr<JudgeSession> s, bool waitMode);
    void setJudgeVisible (bool v)            { judgeVisible = v; repaint(); }

    // 离线渲染（宣传视频）用：替换飘字动画的时钟
    static inline std::function<double()> clockOverride;

    // 显示方式：音游（横向滚动的轨道）或六线谱（一行行排版、光标跟着走、整页跟着翻）
    enum class ViewMode { lanes, staff };
    void setViewMode (ViewMode m)            { viewMode = m; staffLayoutWidth = -1; repaint(); }
    ViewMode getViewMode() const             { return viewMode; }

    // 在每个音上面写音名（例如 E4、C#3）
    void setShowNoteNames (bool v)           { showNoteNames = v; repaint(); }

    // 改谱（六线谱模式里点音符、框选）：editor 为空 = 不在改谱
    void setEditor (TabEditor* e)            { editor = e; repaint(); }
    std::function<void()> onEditSelectionChanged;        // 点选 / 框选了
    std::function<void (double beat)> onEditChord;       // 双击和弦那一行：在这一拍设和弦

    void paint (juce::Graphics&) override;
    void resized() override;
    void mouseDown (const juce::MouseEvent&) override;
    void mouseDoubleClick (const juce::MouseEvent&) override;
    void mouseDrag (const juce::MouseEvent&) override;
    void mouseUp (const juce::MouseEvent&) override;
    void mouseWheelMove (const juce::MouseEvent&, const juce::MouseWheelDetails&) override;

    // 截图 / 宣传片用：六线谱里某一拍、某根弦在组件里的位置（不在屏幕上返回 -1,-1）
    juce::Point<float> staffPointForSnapshot (double beat, int string) const
    {
        if (song == nullptr) return { -1.0f, -1.0f };
        const int b = song->barIndexAt (beat + 1.0e-9);
        if (! juce::isPositiveAndBelow (b, (int) staffBarRow.size())) return { -1.0f, -1.0f };
        return { staffX (b, beat), staffLineY (staffBarRow[(size_t) b], string) };
    }

private:
    void analyseTrack();
    double currentBeat() const;
    float xForSeconds (double s, double nowSec) const { return hitX + (float) ((s - nowSec) * pxPerSec); }
    float yForString (int s) const;
    void paintLanes (juce::Graphics&, double nowSec, double nowBeat);
    void paintTimeline (juce::Graphics&, double nowBeat);
    double beatAtTimelineX (float x) const;
    void paintJudgeHud (juce::Graphics&, double nowBeat);
    void paintChordBox (juce::Graphics&, double nowBeat);

    // ---- 六线谱模式（TabStaff.cpp）----
    void layoutStaff();
    void paintStaff (juce::Graphics&, double nowBeat);
    bool staffMouseDown (const juce::MouseEvent&);
    // 六线谱的坐标（音符画在哪、点的是哪）
    float staffX (int bar, double beat) const;
    float staffLineY (int row, int string) const;
    bool staffHit (juce::Point<float> p, int& bar, double& beat, int& string, int& row) const;
    void paintEditOverlay (juce::Graphics&, int r0, int r1);
    TabEditor* editor = nullptr;
    bool editDragging = false;
    juce::Point<float> editDragStart, editDragNow;
    struct StaffRow { int firstBar = 0, lastBar = -1; };
    std::vector<StaffRow> staffRows;
    std::vector<float> staffBarX, staffBarW;
    std::vector<int> staffBarRow;
    std::vector<uint8_t> staffShowTimeSig;
    int staffLayoutWidth = -1;
    float staffScroll = 0.0f, staffRowH = 150.0f, staffLineGap = 15.0f, staffTopPad = 38.0f;
    ViewMode viewMode = ViewMode::lanes;
    // 飘字的位置（两种模式各自设置）
    juce::Point<float> flashAnchor;
    bool flashAnchorSet = false;

    TabPlayer& player;
    std::shared_ptr<const Song> song;
    int track = 0;
    float pxPerSec = 240.0f;
    double frozenBeat = -1.0;

    // 当前轨预先算好的信息
    std::vector<char> hopoLabel;        // 'H' 击弦，'P' 勾弦，0 无
    std::vector<int> nextOnString;      // 同一根弦的下一个音（画滑音线）
    std::vector<int> prevOnString;      // 同一根弦的上一个音（画击勾弦的连线）
    std::vector<double> startSec, endSec;

    juce::Rectangle<int> laneArea, timelineArea;
    juce::Image neckImage;              // 指板木纹（按大小生成一次）
    juce::Rectangle<float> neckArea;    // 指板在组件里的位置
    void buildNeckImage();
    juce::Rectangle<float> neckBounds() const;
    float hitX = 150.0f;
    bool draggingLoop = false;
    double dragStartBeat = 0.0, dragEndBeat = 0.0;

    std::unique_ptr<juce::VBlankAttachment> vblank;

    std::shared_ptr<JudgeSession> judge;
    bool judgeVisible = true, waitMode = false, showNoteNames = true;
    uint32_t seenSeq = 0;
    struct Flash { juce::String text, detail; juce::Colour colour; int string = 0; double time = -10.0; };
    Flash flash;
    std::vector<float> barAccuracy;
    int framesSinceBarUpdate = 0;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (TabHighway)
};
