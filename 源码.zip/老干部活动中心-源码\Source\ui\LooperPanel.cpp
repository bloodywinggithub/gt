#include "LooperPanel.h"
#include "drums/DrumMachine.h"
#include "practice/Recorder.h"
#include "Text.h"
#include <juce_audio_formats/juce_audio_formats.h>

namespace
{
    const juce::Colour panelColour { 0xff222222 };
    const juce::Colour mutedText   { 0xff9a9a9a };
    const juce::Colour recColour   { 0xffd9534f };
    const juce::Colour playColour  { 0xff2e9e4f };
    const juce::Colour dubColour   { 0xffe0a800 };
    const juce::Colour armColour   { 0xffd97a1f };
    double barSeconds (const DrumMachine& d)
    {
        const auto& st = getDrumStyles();
        const int beats = st.empty() ? 4 : st[(size_t) juce::jlimit (0, (int) st.size() - 1, d.getStyle())].beatsPerBar;
        return 60.0 / juce::jmax (30.0f, d.getBpm()) * beats;
    }
    const juce::Colour trackColours[] = { juce::Colour (0xff3b82f6), juce::Colour (0xffa855f7), juce::Colour (0xff14b8a6),
                                          juce::Colour (0xfff97316), juce::Colour (0xffec4899) };
}

LooperPanel::LooperPanel (Looper& l, DrumMachine& d, juce::PropertiesFile& s) : looper (l), drums (d), settings (s)
{
    title.setText (T ("五轨循环"), juce::dontSendNotification);
    title.setFont (juce::FontOptions (16.0f, juce::Font::bold));
    title.setColour (juce::Label::textColourId, juce::Colours::white);
    addAndMakeVisible (title);
    lengthLabel.setFont (juce::FontOptions (13.0f));
    lengthLabel.setColour (juce::Label::textColourId, juce::Colour (0xff9cc4ff));
    addAndMakeVisible (lengthLabel);
    hint.setFont (juce::FontOptions (12.0f));
    hint.setColour (juce::Label::textColourId, mutedText);
    hint.setText (T ("键盘 1–5 按对应轨，0 全部播放 / 停止"), juce::dontSendNotification);
    addAndMakeVisible (hint);

    playAllButton.onClick = [this] { looper.setPlaying (! looper.isPlaying()); };
    addAndMakeVisible (playAllButton);
    clearAllButton.setButtonText (T ("全部清除"));
    clearAllButton.onClick = [this] { looper.clearAll(); };
    addAndMakeVisible (clearAllButton);
    exportButton.setButtonText (T ("导出 WAV"));
    exportButton.setTooltip (T ("把现在的几轨混成一个 WAV（一圈），存到 我的文档\\LianqinHost\\录音"));
    exportButton.onClick = [this]
    {
        const auto f = exportMix();
        lastExport = f.existsAsFile() ? T ("已导出：") + f.getFileName() : T ("还没有可以导出的循环");
        hint.setText (lastExport, juce::dontSendNotification);
        if (f.existsAsFile()) f.revealToUser();
    };
    addAndMakeVisible (exportButton);

    syncToggle.setButtonText (T ("跟鼓机对齐"));
    syncToggle.setTooltip (T ("鼓机在走时：第 1 轨从下一小节第一拍开始录，长度取整到整小节"));
    syncToggle.setToggleState (settings.getBoolValue ("looperSync", true), juce::dontSendNotification);
    syncToggle.onClick = [this]
    {
        looper.setSyncToDrums (syncToggle.getToggleState());
        settings.setValue ("looperSync", syncToggle.getToggleState());
    };
    looper.setSyncToDrums (syncToggle.getToggleState());
    addAndMakeVisible (syncToggle);

    for (int i = 0; i < Looper::numTracks; ++i)
    {
        auto& s = strips[(size_t) i];
        s.main.onClick = [this, i] { looper.pressTrack (i); };
        s.main.setTooltip (T ("第 1 轨：按一下开始录，再按一下结束并开始循环（定长度）\n"
                              "其他轨：录一圈自动转播放；正在播放的轨再按 = 叠录"));
        addAndMakeVisible (s.main);

        s.mute.setButtonText ("M");
        s.mute.setClickingTogglesState (true);
        s.mute.setColour (juce::TextButton::buttonOnColourId, juce::Colour (0xffd9534f));
        s.mute.setTooltip (T ("静音这一轨"));
        s.mute.onClick = [this, i] { looper.setMuted (i, strips[(size_t) i].mute.getToggleState()); };
        addAndMakeVisible (s.mute);

        s.clear.setButtonText (juce::String::fromUTF8 ("\xc3\x97"));
        s.clear.setTooltip (T ("清除这一轨"));
        s.clear.onClick = [this, i] { looper.clearTrack (i); };
        addAndMakeVisible (s.clear);

        s.volume.setSliderStyle (juce::Slider::LinearHorizontal);
        s.volume.setTextBoxStyle (juce::Slider::NoTextBox, false, 0, 0);
        s.volume.setRange (-30.0, 6.0, 0.5);
        s.volume.setDoubleClickReturnValue (true, 0.0);
        s.volume.setValue (settings.getDoubleValue ("looperGain" + juce::String (i), 0.0), juce::dontSendNotification);
        s.volume.setTooltip (T ("这一轨的音量（双击回到 0 dB）"));
        s.volume.onValueChange = [this, i]
        {
            looper.setTrackGainDb (i, (float) strips[(size_t) i].volume.getValue());
            settings.setValue ("looperGain" + juce::String (i), strips[(size_t) i].volume.getValue());
        };
        looper.setTrackGainDb (i, (float) s.volume.getValue());
        addAndMakeVisible (s.volume);
    }

    refresh();
}

LooperPanel::~LooperPanel()
{
    stopTimer();
}

void LooperPanel::visibilityChanged()
{
    if (isVisible())
    {
        if (! looper.allocate())
            hint.setText (T ("内存不够，循环录音开不了"), juce::dontSendNotification);
        startTimerHz (30);
    }
    else
    {
        stopTimer();
    }
}

bool LooperPanel::handleKey (const juce::KeyPress& key)
{
    const auto c = key.getTextCharacter();
    if (c >= '1' && c <= '5') { looper.pressTrack (c - '1'); return true; }
    if (c == '0')             { looper.setPlaying (! looper.isPlaying()); return true; }
    return false;
}

juce::File LooperPanel::exportMix()
{
    if (looper.getLoopLength() <= 0)
        return {};
    auto mix = looper.renderMix();
    auto folder = Recorder::getFolder();
    folder.createDirectory();
    auto f = folder.getChildFile (T ("循环 ") + juce::Time::getCurrentTime().formatted ("%Y-%m-%d %H-%M-%S") + ".wav");
    juce::WavAudioFormat wav;
    std::unique_ptr<juce::OutputStream> os (f.createOutputStream().release());
    if (os == nullptr) return {};
    std::unique_ptr<juce::AudioFormatWriter> w (wav.createWriterFor (os.get(), looper.getSampleRate(), 2, 24, {}, 0));
    if (w == nullptr) return {};
    os.release();
    w->writeFromAudioSampleBuffer (mix, 0, mix.getNumSamples());
    w.reset();
    return f;
}

void LooperPanel::timerCallback()
{
    looper.maintenance();
    refresh();
    repaint (progressArea);
    for (auto& s : strips) repaint (s.meter);
}

void LooperPanel::refresh()
{
    const int L = looper.getLoopLength();
    const double sr = looper.getSampleRate();
    juce::String len;
    if (L > 0)
    {
        len = juce::String (L / sr, 1) + T (" 秒");
        if (drums.isPlaying())
        {
            const double bars = L / sr / barSeconds (drums);
            if (std::abs (bars - std::round (bars)) < 0.02) len << T ("（") << (int) std::round (bars) << T (" 小节）");
        }
    }
    else if (looper.getState (0) == Looper::State::recording)
        len = T ("正在录第 1 轨：") + juce::String (looper.getRecordedSoFar() / sr, 1) + T (" 秒（再按一下定长度）");
    else if (looper.getState (0) == Looper::State::armed)
        len = T ("等鼓机下一小节第一拍开始录…");
    else
        len = T ("先录第 1 轨：按“● 录”开始，再按一下定下循环长度");
    lengthLabel.setText (len, juce::dontSendNotification);

    playAllButton.setButtonText (looper.isPlaying() ? juce::String::fromUTF8 ("\xe2\x96\xa0 ") + T ("停止")
                                                    : juce::String::fromUTF8 ("\xe2\x96\xb6 ") + T ("播放"));
    playAllButton.setEnabled (L > 0);

    for (int i = 0; i < Looper::numTracks; ++i)
    {
        auto& s = strips[(size_t) i];
        juce::String text;
        juce::Colour col (0xff3a3a3a);
        switch (looper.getState (i))
        {
            case Looper::State::empty:       text = juce::String::fromUTF8 ("\xe2\x97\x8f ") + T ("录"); col = juce::Colour (0xff3a3a3a); break;
            case Looper::State::armed:       text = T ("等小节…");                   col = armColour; break;
            case Looper::State::recording:   text = juce::String::fromUTF8 ("\xe2\x96\xa0 ") + T ("录音中"); col = recColour; break;
            case Looper::State::playing:     text = juce::String::fromUTF8 ("\xe2\x96\xb6 ") + T ("播放 · 按了叠录"); col = playColour.darker (0.2f); break;
            case Looper::State::overdubbing: text = T ("叠录中 · 按了结束");          col = dubColour.darker (0.2f); break;
        }
        if (s.main.getButtonText() != text) s.main.setButtonText (text);
        s.main.setColour (juce::TextButton::buttonColourId, col);
        s.level = juce::jmax (looper.getTrackPeak (i), s.level * 0.85f);
        s.mute.setToggleState (looper.isMuted (i), juce::dontSendNotification);
        s.clear.setEnabled (looper.hasAudio (i) || looper.getState (i) != Looper::State::empty);
    }
}

void LooperPanel::paint (juce::Graphics& g)
{
    g.setColour (panelColour);
    g.fillRoundedRectangle (getLocalBounds().toFloat(), 10.0f);

    // 循环进度
    const int L = looper.getLoopLength();
    auto p = progressArea.toFloat();
    g.setColour (juce::Colour (0xff333333));
    g.fillRoundedRectangle (p, 3.0f);
    if (L > 0)
    {
        const float frac = (float) looper.getPosition() / (float) L;
        g.setColour (looper.isPlaying() ? playColour : mutedText);
        g.fillRoundedRectangle (p.withWidth (juce::jmax (4.0f, p.getWidth() * frac)), 3.0f);
        // 小节线
        if (drums.isPlaying())
        {
            const double barSec = barSeconds (drums);
            const int bars = (int) std::round (L / looper.getSampleRate() / barSec);
            g.setColour (juce::Colours::black.withAlpha (0.5f));
            for (int b = 1; b < bars && bars <= 32; ++b)
                g.fillRect (p.getX() + p.getWidth() * (float) b / (float) bars - 0.5f, p.getY(), 1.0f, p.getHeight());
        }
    }

    // 每轨：编号色条 + 电平
    for (int i = 0; i < Looper::numTracks; ++i)
    {
        const auto& s = strips[(size_t) i];
        g.setColour (trackColours[i]);
        g.fillRoundedRectangle (s.area.toFloat().removeFromTop (4.0f), 2.0f);
        g.setColour (juce::Colours::white);
        g.setFont (juce::FontOptions (13.0f, juce::Font::bold));
        g.drawText (T ("轨 ") + juce::String (i + 1), s.area.withHeight (22).withTrimmedTop (6), juce::Justification::centredLeft);
        auto m = s.meter.toFloat();
        g.setColour (juce::Colour (0xff333333));
        g.fillRect (m);
        g.setColour (trackColours[i].withAlpha (0.9f));
        g.fillRect (m.withWidth (m.getWidth() * juce::jmin (1.0f, s.level * 1.4f)));
    }
}

void LooperPanel::resized()
{
    auto r = getLocalBounds().reduced (12, 8);
    topArea = r.removeFromTop (28);
    auto top = topArea;
    title.setBounds (top.removeFromLeft (76));
    playAllButton.setBounds (top.removeFromLeft (80).reduced (0, 1));
    top.removeFromLeft (8);
    exportButton.setBounds (top.removeFromRight (84).reduced (0, 1));
    top.removeFromRight (6);
    clearAllButton.setBounds (top.removeFromRight (80).reduced (0, 1));
    top.removeFromRight (8);
    syncToggle.setBounds (top.removeFromRight (104));
    lengthLabel.setBounds (top);

    r.removeFromTop (6);
    progressArea = r.removeFromTop (6);
    r.removeFromTop (8);
    hint.setBounds (r.removeFromBottom (16));
    r.removeFromBottom (2);

    const int w = (r.getWidth() - 8 * (Looper::numTracks - 1)) / Looper::numTracks;
    for (int i = 0; i < Looper::numTracks; ++i)
    {
        auto& s = strips[(size_t) i];
        s.area = r.removeFromLeft (w);
        r.removeFromLeft (8);
        auto a = s.area;
        auto head = a.removeFromTop (24);
        s.clear.setBounds (head.removeFromRight (24).reduced (0, 2));
        head.removeFromRight (4);
        s.mute.setBounds (head.removeFromRight (26).reduced (0, 2));
        a.removeFromTop (2);
        s.main.setBounds (a.removeFromTop (32));
        a.removeFromTop (4);
        s.meter = a.removeFromTop (4);
        a.removeFromTop (2);
        s.volume.setBounds (a.removeFromTop (20));
    }
}
