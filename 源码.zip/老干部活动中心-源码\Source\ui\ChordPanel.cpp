#include "ChordPanel.h"
#include "ChordDiagram.h"
#include "AudioEngine.h"
#include "Text.h"

using namespace Chords;

namespace
{
    const juce::Colour panelColour { 0xff222222 };
    const juce::Colour mutedText   { 0xff9a9a9a };
    const juce::Colour accent      { 0xff3b82f6 };
    const juce::Colour selColour   { 0xff2f6fdb };

    constexpr int fftOrder = 14;      // 16384 点（补零），48 kHz 时每格约 2.9 Hz
    constexpr int analysisLen = 8192;

    double midiHz (int m) { return 440.0 * std::pow (2.0, (m - 69) / 12.0); }

    juce::String intervalName (int iv)
    {
        static const char* n[] = { "1", "b2", "2", "b3", "3", "4", "b5", "5", "#5", "6", "b7", "7" };
        return n[(iv % 12 + 12) % 12];
    }
}

ChordPanel::ChordPanel (AudioEngine& e, juce::PropertiesFile& s) : engine (e), settings (s)
{
    flats = settings.getBoolValue ("chordFlats", false);
    for (int i = 0; i < 12; ++i)
    {
        auto& b = rootButtons[(size_t) i];
        b.setClickingTogglesState (true);
        b.setRadioGroupId (3101);
        b.setColour (juce::TextButton::buttonOnColourId, selColour);
        b.onClick = [this, i] { if (rootButtons[(size_t) i].getToggleState()) select (i, quality); };
        addAndMakeVisible (b);
    }
    for (int q = 0; q < numQualities; ++q)
    {
        auto& b = qualityButtons[(size_t) q];
        const auto& qi = info ((Quality) q);
        b.setButtonText (juce::String (qi.suffix).isEmpty() ? T ("大三") : juce::String (qi.suffix));
        b.setTooltip (T (qi.zh));
        b.setClickingTogglesState (true);
        b.setRadioGroupId (3102);
        b.setColour (juce::TextButton::buttonOnColourId, juce::Colour (0xff7c3aed));
        b.onClick = [this, q] { if (qualityButtons[(size_t) q].getToggleState()) select (root, (Quality) q); };
        addAndMakeVisible (b);
    }
    flatsToggle.setButtonText (T ("用降号"));
    flatsToggle.setTooltip (T ("音名用 Db Eb Gb Ab Bb，而不是 C# D# F# G# A#"));
    flatsToggle.setToggleState (flats, juce::dontSendNotification);
    flatsToggle.onClick = [this] { flats = flatsToggle.getToggleState(); save(); refresh(); };
    addAndMakeVisible (flatsToggle);

    strumButton.setButtonText (juce::String::fromUTF8 ("\xe2\x96\xb6 ") + T ("扫弦"));
    strumButton.setColour (juce::TextButton::buttonColourId, juce::Colour (0xff2e9e4f));
    strumButton.setTooltip (T ("听一下这个指法（空格）"));
    strumButton.onClick = [this] { strum (false); };
    addAndMakeVisible (strumButton);
    arpButton.setButtonText (T ("分解"));
    arpButton.setTooltip (T ("一根根弦弹出来听（A）"));
    arpButton.onClick = [this] { strum (true); };
    addAndMakeVisible (arpButton);
    listenToggle.setButtonText (T ("听我弹：看哪根弦没响"));
    listenToggle.setTooltip (T ("按好和弦扫一下：每根弦上的点变绿 = 听到了，变红 = 没响（闷住了或者没按好）（L）"));
    listenToggle.onClick = [this] { setListening (listenToggle.getToggleState()); };
    addAndMakeVisible (listenToggle);

    diatonicLabel.setText (T ("调内和弦"), juce::dontSendNotification);
    diatonicLabel.setFont (juce::FontOptions (15.0f, juce::Font::bold));
    diatonicLabel.setColour (juce::Label::textColourId, juce::Colours::white);
    addAndMakeVisible (diatonicLabel);
    for (int i = 0; i < 12; ++i) keyBox.addItem (rootNames (false)[i] + (rootNames (true)[i] != rootNames (false)[i] ? "/" + rootNames (true)[i] : juce::String()), i + 1);
    keyBox.setSelectedItemIndex (juce::jlimit (0, 11, settings.getIntValue ("chordKey", 7)), juce::dontSendNotification);
    keyBox.onChange = [this] { save(); refresh(); };
    addAndMakeVisible (keyBox);
    keyMajorButton.setButtonText (T ("大调"));
    keyMinorButton.setButtonText (T ("小调"));
    for (auto* b : { &keyMajorButton, &keyMinorButton })
    {
        b->setClickingTogglesState (true);
        b->setRadioGroupId (3103);
        b->setColour (juce::TextButton::buttonOnColourId, selColour);
        b->onClick = [this] { save(); refresh(); };
        addAndMakeVisible (*b);
    }
    keyMajorButton.setConnectedEdges (juce::Button::ConnectedOnRight);
    keyMinorButton.setConnectedEdges (juce::Button::ConnectedOnLeft);
    (settings.getBoolValue ("chordKeyMinor", false) ? keyMinorButton : keyMajorButton).setToggleState (true, juce::dontSendNotification);
    seventhsToggle.setButtonText (T ("七和弦"));
    seventhsToggle.setToggleState (settings.getBoolValue ("chordSevenths", false), juce::dontSendNotification);
    seventhsToggle.onClick = [this] { save(); refresh(); };
    addAndMakeVisible (seventhsToggle);

    setWantsKeyboardFocus (true);
    select (juce::jlimit (0, 11, settings.getIntValue ("chordRoot", 0)),
            (Quality) juce::jlimit (0, numQualities - 1, settings.getIntValue ("chordQuality", 0)));
}

ChordPanel::~ChordPanel()
{
    stopTimer();
}

void ChordPanel::save()
{
    settings.setValue ("chordRoot", root);
    settings.setValue ("chordQuality", (int) quality);
    settings.setValue ("chordFlats", flats);
    settings.setValue ("chordKey", keyBox.getSelectedItemIndex());
    settings.setValue ("chordKeyMinor", keyMinorButton.getToggleState());
    settings.setValue ("chordSevenths", seventhsToggle.getToggleState());
}

void ChordPanel::select (int r, Quality q)
{
    root = (r % 12 + 12) % 12;
    quality = q;
    voicings = Chords::voicings (root, q);
    selected = 0;
    statusValid = false;
    save();
    refresh();
}

void ChordPanel::selectVoicing (int index)
{
    if (! juce::isPositiveAndBelow (index, (int) voicings.size())) return;
    selected = index;
    statusValid = false;
    repaint();
}

void ChordPanel::refresh()
{
    for (int i = 0; i < 12; ++i)
    {
        rootButtons[(size_t) i].setButtonText (rootNames (flats)[i]);
        rootButtons[(size_t) i].setToggleState (i == root, juce::dontSendNotification);
    }
    for (int q = 0; q < numQualities; ++q)
        qualityButtons[(size_t) q].setToggleState (q == (int) quality, juce::dontSendNotification);
    diatonicChords = diatonic (keyBox.getSelectedItemIndex(), keyMinorButton.getToggleState(), seventhsToggle.getToggleState());
    resized();
    repaint();
}

void ChordPanel::strum (bool arpeggio)
{
    if (! juce::isPositiveAndBelow (selected, (int) voicings.size())) return;
    const double now = juce::Time::getMillisecondCounterHiRes();
    double t = now;
    for (int m : voicings[(size_t) selected].midiNotes())
    {
        pending.push_back ({ t, m });
        t += arpeggio ? 260.0 : 28.0;
    }
    if (! isTimerRunning()) startTimerHz (60);
}

void ChordPanel::setListening (bool on)
{
    listening = on;
    listenToggle.setToggleState (on, juce::dontSendNotification);
    statusValid = false;
    if (on && fft == nullptr)
    {
        fft = std::make_unique<juce::dsp::FFT> (fftOrder);
        dry.assign (analysisLen, 0.0f);
        work.assign ((size_t) (2 << fftOrder), 0.0f);
    }
    if (on || ! pending.empty()) startTimerHz (60); else stopTimer();
    resized();
    repaint();
}

void ChordPanel::visibilityChanged()
{
    if (! isVisible()) { stopTimer(); pending.clear(); }
    else if (listening) startTimerHz (60);
}

std::array<uint8_t, 6> ChordPanel::analyse (const float* x, int n, double sr, const Voicing& v, juce::dsp::FFT& fft, std::vector<float>& w)
{
    std::array<uint8_t, 6> st {};
    const int N = fft.getSize();
    w.assign ((size_t) N * 2, 0.0f);
    const int L = juce::jmin (n, N);
    for (int i = 0; i < L; ++i)
        w[(size_t) i] = x[n - L + i] * (0.5f - 0.5f * std::cos (juce::MathConstants<float>::twoPi * (float) i / (float) L));
    fft.performFrequencyOnlyForwardTransform (w.data(), true);
    const double binHz = sr / N;
    const int kTop = juce::jmin (N / 2 - 2, (int) (5000.0 / binHz));
    // 底噪：中位数
    std::vector<float> db;
    for (int k = (int) (60.0 / binHz); k <= kTop; ++k) db.push_back (juce::Decibels::gainToDecibels (w[(size_t) k] + 1.0e-9f, -160.0f));
    if (db.empty()) return st;
    std::nth_element (db.begin(), db.begin() + (long) db.size() / 2, db.end());
    const float floorDb = db[db.size() / 2];
    auto peakDb = [&] (double f)
    {
        const int k0 = juce::jmax (1, (int) std::floor (f * 0.985 / binHz));
        const int k1 = juce::jmin (kTop, (int) std::ceil (f * 1.015 / binHz));
        float p = 0.0f;
        for (int k = k0; k <= k1; ++k) p = juce::jmax (p, w[(size_t) k]);
        return juce::Decibels::gainToDecibels (p + 1.0e-9f, -160.0f) - floorDb;
    };
    std::vector<int> sounding;
    for (int s = 0; s < 6; ++s)
        if (v.frets[(size_t) s] >= 0) sounding.push_back (standardTuning[(size_t) s] + v.frets[(size_t) s]);
    auto isHarmonicOfLower = [&] (int m)
    {
        // 正好落在另一根更低的弦的 2–6 次泛音上（高八度同名音等）
        for (int lower : sounding)
            for (int h = 2; h <= 6; ++h)
                if (lower < m && std::abs (12.0 * std::log2 (midiHz (m) / (midiHz (lower) * h))) < 0.3)
                    return true;
        return false;
    };
    for (int s = 0; s < 6; ++s)
    {
        if (v.frets[(size_t) s] < 0) continue;
        const int m = standardTuning[(size_t) s] + v.frets[(size_t) s];
        const double f0 = midiHz (m);
        float score = peakDb (f0);
        // 最低的那根弦基频可能很弱：可以借它的 2 次泛音，但前提是那里没有别的弦的音
        if (m == sounding.front())
        {
            bool clash = false;
            for (int other : sounding)
                if (other != m && std::abs (12.0 * std::log2 (midiHz (other) / (f0 * 2.0))) < 0.3) clash = true;
            if (! clash) score = juce::jmax (score, peakDb (f0 * 2.0) - 4.0f);
        }
        if (isHarmonicOfLower (m))
            st[(size_t) s] = score > 14.0f ? 3 : 2;       // 3 = 听到了这个音高，但可能是低音弦的泛音，说不准
        else
            st[(size_t) s] = score > 14.0f ? 1 : 2;
    }
    return st;
}

void ChordPanel::timerCallback()
{
    const double now = juce::Time::getMillisecondCounterHiRes();
    for (size_t i = 0; i < pending.size(); )
    {
        if (pending[i].at <= now)
        {
            engine.previewNote (pending[i].midi, 0.75f, 2.0);
            pending.erase (pending.begin() + (long) i);
        }
        else ++i;
    }

    if (listening && fft != nullptr && ++framesSinceAnalysis >= 6 && juce::isPositiveAndBelow (selected, (int) voicings.size()))
    {
        framesSinceAnalysis = 0;
        const double sr = engine.copyRecentDrySamples (dry.data(), (int) dry.size());
        if (sr > 0.0)
        {
            double s2 = 0.0;
            for (auto x : dry) s2 += (double) x * x;
            const float rmsDb = juce::Decibels::gainToDecibels ((float) std::sqrt (s2 / (double) dry.size()), -100.0f);
            if (rmsDb > -48.0f)
            {
                lastLoudMs = now;
                status = analyse (dry.data(), (int) dry.size(), sr, voicings[(size_t) selected], *fft, work);
                statusValid = true;
                if (onPetEvent && now - lastPetMs > 2500.0)
                {
                    lastPetMs = now;
                    bool missing = false;
                    for (auto x : status) missing = missing || x == 2;
                    onPetEvent (missing ? 2 : 0, 0);
                }
                repaint (cardsArea);
            }
            else if (statusValid && now - lastLoudMs > 2500.0)
            {
                statusValid = false;
                repaint (cardsArea);
            }
        }
    }
    if (! listening && pending.empty()) stopTimer();
}

bool ChordPanel::keyPressed (const juce::KeyPress& key)
{
    if (key == juce::KeyPress::spaceKey) { strum (false); return true; }
    const auto c = key.getTextCharacter();
    if (c == 'a' || c == 'A') { strum (true); return true; }
    if (c == 'l' || c == 'L') { setListening (! listening); return true; }
    if (key == juce::KeyPress::leftKey)  { selectVoicing (juce::jmax (0, selected - 1)); return true; }
    if (key == juce::KeyPress::rightKey) { selectVoicing (juce::jmin ((int) voicings.size() - 1, selected + 1)); return true; }
    if (key == juce::KeyPress::upKey)    { select (root + 1, quality); return true; }
    if (key == juce::KeyPress::downKey)  { select (root + 11, quality); return true; }
    return false;
}

void ChordPanel::mouseDown (const juce::MouseEvent& e)
{
    for (size_t i = 0; i < cardAreas.size(); ++i)
        if (cardAreas[i].contains (e.position))
        {
            selectVoicing ((int) i);
            strum (false);
            return;
        }
    for (size_t i = 0; i < diatonicAreas.size() && i < diatonicChords.size(); ++i)
        if (diatonicAreas[i].contains (e.position))
        {
            select (diatonicChords[i].root, diatonicChords[i].quality);
            strum (false);
            return;
        }
}

void ChordPanel::paint (juce::Graphics& g)
{
    g.setColour (panelColour);
    g.fillRoundedRectangle (getLocalBounds().toFloat(), 10.0f);

    // 和弦说明
    {
        const auto& qi = info (quality);
        juce::StringArray notes, degrees;
        for (int iv : qi.intervals)
        {
            notes.add (rootNames (flats)[(root + iv) % 12]);
            degrees.add (quality == Quality::add9 && iv == 2 ? juce::String ("9") : intervalName (iv));
        }
        auto r = infoArea;
        g.setColour (juce::Colours::white);
        g.setFont (juce::FontOptions (24.0f, juce::Font::bold));
        const auto nm = name (root, quality, flats);
        const int w = juce::GlyphArrangement::getStringWidthInt (juce::FontOptions (24.0f, juce::Font::bold), nm) + 16;
        g.drawText (nm, r.removeFromLeft (w), juce::Justification::centredLeft);
        g.setFont (juce::FontOptions (15.0f));
        g.setColour (juce::Colour (0xff9cc4ff));
        g.drawText (T (qi.zh) + T ("    组成音：") + notes.joinIntoString (" ") + "   (" + degrees.joinIntoString (" ") + ")"
                        + (voicings.empty() ? juce::String() : T ("    ") + juce::String ((int) voicings.size()) + T (" 种指法，点一下试听")),
                    r, juce::Justification::centredLeft, true);
    }

    // 指法卡片
    for (size_t i = 0; i < cardAreas.size() && i < voicings.size(); ++i)
    {
        const auto& v = voicings[i];
        auto card = cardAreas[i];
        const bool sel = (int) i == selected;
        g.setColour (sel ? juce::Colour (0xff1e2a3d) : juce::Colour (0xff1a1c20));
        g.fillRoundedRectangle (card, 8.0f);
        g.setColour (sel ? selColour : juce::Colour (0xff33363c));
        g.drawRoundedRectangle (card, 8.0f, sel ? 2.0f : 1.0f);
        ChordDraw::Args a;
        a.frets = v.frets;
        a.fingers = v.fingers;
        a.hasFingers = true;
        a.barreFret = v.barreFret; a.barreFrom = v.barreFrom; a.barreTo = v.barreTo;
        a.title = name (root, quality, flats);
        a.subtitle = v.shape;
        a.highlight = sel;
        a.status = (sel && listening && statusValid) ? &status : nullptr;
        ChordDraw::draw (g, card.reduced (8.0f, 6.0f), a);
    }
    if (voicings.empty())
    {
        g.setColour (mutedText);
        g.setFont (juce::FontOptions (15.0f));
        g.drawText (T ("这个和弦还没有收录指法"), cardsArea, juce::Justification::centred);
    }
    if (listening)
    {
        int missing = 0, unsure = 0;
        if (statusValid && juce::isPositiveAndBelow (selected, (int) voicings.size()))
            for (int s = 0; s < 6; ++s)
            {
                missing += status[(size_t) s] == 2 ? 1 : 0;
                unsure += status[(size_t) s] == 3 ? 1 : 0;
            }
        g.setFont (juce::FontOptions (14.0f, juce::Font::bold));
        g.setColour (statusValid ? (missing == 0 ? juce::Colour (0xff22c55e) : juce::Colour (0xffffa23a)) : mutedText);
        juce::String msg;
        if (! statusValid)
            msg = T ("按好选中的指法扫一下……");
        else if (missing == 0)
            msg = T ("都响了，很好！");
        else
            msg = juce::String (missing) + T (" 根弦没响（红点）：检查那根弦按实了没有、别的手指有没有碰到它");
        if (statusValid && unsure > 0)
            msg << T ("    灰点：和低音弦是同名音，分不出来");
        g.drawText (msg, cardsArea.withY (cardsArea.getBottom() + 2).withHeight (20), juce::Justification::centredLeft);
    }

    // 调内和弦
    for (size_t i = 0; i < diatonicAreas.size() && i < diatonicChords.size(); ++i)
    {
        const auto& d = diatonicChords[i];
        auto card = diatonicAreas[i];
        const bool sel = d.root == root && d.quality == quality;
        g.setColour (sel ? juce::Colour (0xff1e2a3d) : juce::Colour (0xff1a1c20));
        g.fillRoundedRectangle (card, 6.0f);
        if (sel) { g.setColour (selColour); g.drawRoundedRectangle (card, 6.0f, 1.6f); }
        auto top = card.removeFromTop (16.0f);
        g.setColour (juce::Colour (0xffffd166));
        g.setFont (juce::FontOptions (12.5f, juce::Font::bold));
        g.drawText (d.roman, top, juce::Justification::centred);
        const auto vs = Chords::voicings (d.root, d.quality);
        ChordDraw::Args a;
        if (! vs.empty()) { a.frets = vs.front().frets; a.barreFret = vs.front().barreFret; a.barreFrom = vs.front().barreFrom; a.barreTo = vs.front().barreTo; }
        a.title = name (d.root, d.quality, flats);
        a.accent = juce::Colour (0xff60a5fa);
        ChordDraw::draw (g, card.reduced (4.0f, 2.0f), a);
    }
}

void ChordPanel::resized()
{
    auto r = getLocalBounds().reduced (14, 10);
    auto row1 = r.removeFromTop (28);
    flatsToggle.setBounds (row1.removeFromRight (80));
    row1.removeFromRight (8);
    {
        const int w = row1.getWidth() / 12;
        for (auto& b : rootButtons) b.setBounds (row1.removeFromLeft (w).reduced (2, 0));
    }
    r.removeFromTop (6);
    auto row2 = r.removeFromTop (28);
    {
        const int w = row2.getWidth() / numQualities;
        for (auto& b : qualityButtons) b.setBounds (row2.removeFromLeft (w).reduced (2, 0));
    }
    r.removeFromTop (8);
    auto row3 = r.removeFromTop (30);
    strumButton.setBounds (row3.removeFromRight (80).reduced (0, 2));
    row3.removeFromRight (6);
    arpButton.setBounds (row3.removeFromRight (60).reduced (0, 2));
    row3.removeFromRight (10);
    listenToggle.setBounds (row3.removeFromRight (190));
    infoArea = row3;
    r.removeFromTop (6);

    // 下面：调内和弦
    auto dia = r.removeFromBottom (juce::jlimit (130, 190, r.getHeight() * 2 / 5));
    auto diaTop = dia.removeFromTop (26);
    diatonicLabel.setBounds (diaTop.removeFromLeft (80));
    keyBox.setBounds (diaTop.removeFromLeft (100).reduced (0, 1));
    diaTop.removeFromLeft (6);
    keyMajorButton.setBounds (diaTop.removeFromLeft (54).reduced (0, 1));
    keyMinorButton.setBounds (diaTop.removeFromLeft (54).reduced (0, 1));
    diaTop.removeFromLeft (10);
    seventhsToggle.setBounds (diaTop.removeFromLeft (90));
    dia.removeFromTop (4);
    diatonicArea = dia;
    diatonicAreas.clear();
    {
        const float w = (float) dia.getWidth() / 7.0f;
        for (int i = 0; i < 7; ++i)
            diatonicAreas.push_back (juce::Rectangle<float> ((float) dia.getX() + w * (float) i, (float) dia.getY(), w, (float) dia.getHeight()).reduced (3.0f, 0.0f));
    }
    r.removeFromBottom (listening ? 26 : 10);

    // 指法卡片
    cardsArea = r;
    cardAreas.clear();
    const int n = juce::jmin (6, (int) voicings.size());
    if (n > 0)
    {
        const float h = (float) r.getHeight();
        const float w = juce::jmin (h * 0.78f, (float) r.getWidth() / (float) n - 10.0f);
        float x = (float) r.getX();
        for (int i = 0; i < n; ++i)
        {
            cardAreas.push_back (juce::Rectangle<float> (x, (float) r.getY(), w, h));
            x += w + 10.0f;
        }
    }
}
