// 离线测试：不需要声卡，直接把合成的吉他信号送进引擎，检查输出。
// 用法：LianqinTests <NAM 模型目录> <输出目录>
#include <juce_audio_formats/juce_audio_formats.h>
#include <juce_events/juce_events.h>
#include "AudioEngine.h"
#include "fx/BuiltinEffects.h"
#include "fx/NamProcessor.h"
#include "drums/DrumMachine.h"
#include "fx/DefaultPresets.h"
#include "PitchDetector.h"
#include "ui/PedalEditor.h"
#include "ui/PedalBoard.h"
#include "ui/PracticePanel.h"
#include "ui/TabSearch.h"
#include "ui/TabLibraryBox.h"
#include "practice/ChordLibrary.h"
#include "practice/AudioToTab.h"
#include "practice/BasicPitch.h"
#include "ui/OriginalSync.h"
#include "song/TabEdit.h"
#include "practice/Demucs.h"
#include "ui/ChordPanel.h"
#include "ui/PetView.h"
#include "ui/StatsView.h"
#include "ui/PresetBar.h"
#include "ui/ScalesPanel.h"
#include "ui/DrumPanel.h"
#include "MainComponent.h"
#include "ui/EffectStyle.h"
#include "song/Song.h"
#include "practice/PluckSynth.h"
#include "practice/Judge.h"
#include "practice/SpeedTrainer.h"
#include "practice/PracticeLog.h"
#include "practice/ScaleTheory.h"
#include <cstdio>
#include <set>

namespace juce::detail { bool dispatchNextMessageOnSystemQueue (bool returnIfNoPendingMessages); }

namespace
{
    constexpr double sr = 48000.0;
    constexpr int block = 128;
    int failures = 0;

    void check (bool ok, const juce::String& what)
    {
        std::printf ("  [%s] %s\n", ok ? "OK  " : "FAIL", what.toRawUTF8());
        if (! ok) ++failures;
    }

    // 合成吉他：每 0.5 秒拨一个音，带泛音、指数衰减
    std::vector<float> makeGuitar (double seconds, float level = 0.3f)
    {
        std::vector<float> s ((size_t) (seconds * sr), 0.0f);
        const double notes[] = { 82.41, 110.0, 146.83, 196.0, 246.94, 329.63 };
        for (size_t i = 0; i < s.size(); ++i)
        {
            const double t = (double) i / sr;
            const int n = (int) (t / 0.5);
            const double tn = t - n * 0.5;
            const double f = notes[n % 6];
            double v = 0.0;
            for (int h = 1; h <= 8; ++h)
                v += std::sin (juce::MathConstants<double>::twoPi * f * h * tn) / (h * h * 0.6 + 0.4);
            s[i] = (float) (level * v * std::exp (-tn * 4.0));
        }
        return s;
    }

    struct Stats { float peak = 0, rms = 0; bool finite = true; float maxStep = 0; };

    Stats stats (const std::vector<float>& l, const std::vector<float>& r, size_t from = 0)
    {
        Stats st;
        double sum = 0.0;
        for (size_t i = from; i < l.size(); ++i)
        {
            if (! std::isfinite (l[i]) || ! std::isfinite (r[i])) st.finite = false;
            st.peak = juce::jmax (st.peak, std::abs (l[i]), std::abs (r[i]));
            sum += (double) l[i] * l[i];
            if (i > from) st.maxStep = juce::jmax (st.maxStep, std::abs (l[i] - l[i - 1]));
        }
        st.rms = (float) std::sqrt (sum / juce::jmax ((size_t) 1, l.size() - from));
        return st;
    }

    juce::String db (float g) { return juce::String (juce::Decibels::gainToDecibels (g, -120.0f), 1) + " dB"; }

    void writeWav (const juce::File& f, const std::vector<float>& l, const std::vector<float>& r)
    {
        f.deleteFile();
        juce::WavAudioFormat wav;
        auto stream = f.createOutputStream();
        if (stream == nullptr) return;
        auto options = juce::AudioFormatWriterOptions().withSampleRate (sr).withNumChannels (2).withBitsPerSample (24);
        std::unique_ptr<juce::OutputStream> os (stream.release());
        if (auto writer = wav.createWriterFor (os, options))
        {
            const float* chans[] = { l.data(), r.data() };
            writer->writeFromFloatArrays (chans, 2, (int) l.size());
        }
    }

    // 把输入送进引擎，返回立体声输出
    void run (AudioEngine& engine, const std::vector<float>& in, std::vector<float>& l, std::vector<float>& r)
    {
        l.assign (in.size(), 0.0f);
        r.assign (in.size(), 0.0f);
        engine.processOffline (in.data(), l.data(), r.data(), (int) in.size());
    }
}

// 把每个效果器的放大踏板渲染成 PNG，用来检查界面
static int renderPedalSnapshots (const juce::File& outDir)
{
    outDir.createDirectory();
    AudioEngine engine;
    engine.prepareForOffline (sr, block);
    EffectChain chain (engine);
    for (auto& info : getBuiltinEffectList())
    {
        auto slot = chain.createBuiltin (info.id);
        PedalEditorOverlay overlay (slot, {});
        overlay.setSize (1240, 800);
        auto img = overlay.createComponentSnapshot (overlay.getLocalBounds(), true, 1.0f);
        juce::PNGImageFormat png;
        auto f = outDir.getChildFile ("pedal_" + info.id + ".png");
        f.deleteFile();
        if (auto os = f.createOutputStream())
            png.writeImageToStream (img, *os);
        std::printf ("  %s\n", f.getFileName().toRawUTF8());
    }
    return 0;
}

// 练习页截图：载入谱子，把谱面定在几个位置
static int renderHighwaySnapshots (const juce::File& songFile, const juce::File& outDir)
{
    outDir.createDirectory();
    AudioEngine engine;
    engine.prepareForOffline (sr, block);
    juce::PropertiesFile::Options o;
    o.applicationName = "LianqinTests";
    juce::PropertiesFile props (outDir.getChildFile ("test.settings"), o);
    PracticeLog plog (outDir.getChildFile ("log.json"));
    PracticePanel panel (engine.getTabPlayer(), engine.getDrums(), engine.getJudge(), engine.getRecorder(), plog, props);
    panel.setSize (884, 630);
    if (! panel.loadFile (songFile)) { std::printf ("  载入失败\n"); return 1; }
    if (auto* tr = std::getenv ("HW_TRACK")) panel.selectTrackForSnapshot (juce::String (tr).getIntValue());
    auto song = engine.getTabPlayer().getSong();
    const double len = song->lengthBeats;
    int i = 0;
    for (double frac : { 0.0, 0.12, 0.3, 0.55 })
    {
        // 找到 frac 附近第一个音之前一点，让判定线上有音
        const auto& notes = song->tracks[(size_t) engine.getTabPlayer().getTrack()].notes;
        double beat = frac * len;
        for (auto& n : notes) if (n.start >= beat) { beat = juce::jmax (0.0, n.start - 0.02); break; }
        panel.getHighway().setFrozenPosition (beat);
        auto img = panel.createComponentSnapshot (panel.getLocalBounds(), true, 1.0f);
        juce::PNGImageFormat png;
        auto f = outDir.getChildFile ("highway_" + juce::String (i++) + ".png");
        f.deleteFile();
        if (auto os = f.createOutputStream()) png.writeImageToStream (img, *os);
        std::printf ("  %s  (拍 %.2f)\n", f.getFileName().toRawUTF8(), beat);
    }
    // 推弦进行到一半的样子（弦被推起来）
    for (auto& n : song->tracks[(size_t) engine.getTabPlayer().getTrack()].notes)
        if (n.bend > 0.0f)
        {
            panel.getHighway().setFrozenPosition (n.start + n.length * 0.3);
            auto img = panel.createComponentSnapshot (panel.getLocalBounds(), true, 1.0f);
            juce::PNGImageFormat png;
            auto f = outDir.getChildFile ("highway_bend.png");
            f.deleteFile();
            if (auto os = f.createOutputStream()) png.writeImageToStream (img, *os);
            std::printf ("  %s\n", f.getFileName().toRawUTF8());
            break;
        }
    // 六线谱模式
    panel.getHighway().setViewMode (TabHighway::ViewMode::staff);
    for (double frac : { 0.0, 0.3 })
    {
        panel.getHighway().setFrozenPosition (frac * len);
        auto img = panel.createComponentSnapshot (panel.getLocalBounds(), true, 1.0f);
        juce::PNGImageFormat png;
        auto f = outDir.getChildFile ("staff_" + juce::String (juce::roundToInt (frac * 10)) + ".png");
        f.deleteFile();
        if (auto os = f.createOutputStream()) png.writeImageToStream (img, *os);
        std::printf ("  %s\n", f.getFileName().toRawUTF8());
    }
    panel.getHighway().setViewMode (TabHighway::ViewMode::lanes);
    std::vector<TrackMixer::Strip> strips (song->tracks.size());
    if (strips.size() > 1) { strips[1].mute = true; strips[0].solo = true; strips[0].db = -6.0f; }
    TrackMixer mixer (*song, strips, nullptr);
    auto img = mixer.createComponentSnapshot (mixer.getLocalBounds(), true, 1.0f);
    juce::PNGImageFormat png;
    auto f = outDir.getChildFile ("mixer.png");
    f.deleteFile();
    if (auto os = f.createOutputStream()) png.writeImageToStream (img, *os);
    return 0;
}

// 读取一个目录里所有吉他谱，打印概要；同名不同格式（.gp5/.gpx/.gp）互相比对
// 打印一首谱子的技巧标记（调试用）
static const double A2T_TOL = juce::SystemStats::getEnvironmentVariable ("A2T_TOL", "0.08").getDoubleValue();
static int dumpSong (const juce::File& f)
{
    juce::String error;
    auto song = loadSongFile (f, error);
    if (song == nullptr) { std::printf ("载入失败：%s\n", error.toRawUTF8()); return 1; }
    const auto& tr = song->tracks[(size_t) song->defaultTrack()];
    for (auto& c : tr.chords)
    {
        const auto& d = tr.chordDiagrams[(size_t) c.diagram];
        juce::String fr;
        for (int f : d.frets) fr << (f < 0 ? juce::String ("x") : juce::String (f)) << " ";
        std::printf ("chord @%.2f  %s  [%s]\n", c.beat, d.name.toRawUTF8(), fr.toRawUTF8());
    }
    for (auto& n : tr.notes)
    {
        juce::String t;
        if (n.hammerPull) t << "HP ";
        if (n.tapped) t << "TAP ";
        if (n.slideOut) t << (n.slideLegato ? "SL-leg " : "SL-shift ");
        if (n.slideOff) t << "SL-off ";
        if (n.slideIn) t << "SL-in ";
        if (n.bend > 0.0f) t << "bend " << n.bendStart << "->" << n.bend << "@" << n.bendPeakPos << " rel@" << n.bendReleasePos
                             << "->" << n.bendEnd << "@" << n.bendEndPos;
        std::printf ("%7.3f s%d f%-2d len %.3f  %s\n", n.start, n.string, n.fret, n.length, t.toRawUTF8());
    }
    return 0;
}

static int testSongs (const juce::File& dir)
{
    int failed = 0, total = 0;
    std::map<juce::String, std::vector<std::pair<juce::String, juce::String>>> fingerprints;

    for (auto& f : dir.findChildFiles (juce::File::findFiles, true, "*.gp3;*.gp4;*.gp5;*.gpx;*.gp"))
    {
        ++total;
        juce::String error;
        auto song = loadSongFile (f, error);
        if (song == nullptr)
        {
            ++failed;
            std::printf ("  [FAIL] %s: %s\n", f.getFileName().toRawUTF8(), error.toRawUTF8());
            continue;
        }

        int notes = 0;
        for (auto& t : song->tracks) notes += (int) t.notes.size();
        const int dt = song->defaultTrack();

        // 指纹：第一条轨前 24 个音的（拍位置, 弦, 品）
        juce::String fp;
        if (juce::isPositiveAndBelow (dt, (int) song->tracks.size()))
        {
            const auto& tr = song->tracks[(size_t) dt];
            for (size_t i = 0; i < juce::jmin ((size_t) 24, tr.notes.size()); ++i)
                fp << juce::String (tr.notes[i].start, 3) << ":" << tr.notes[i].string << "/" << tr.notes[i].fret << " ";
            fp << "| bars=" << (int) song->bars.size() << " notes=" << (int) tr.notes.size();
        }
        fingerprints[f.getFileNameWithoutExtension()].push_back ({ f.getFileExtension(), fp });

        std::printf ("  [OK  ] %-42s %-15s %3d 小节 %2d 轨 %5d 音  %5.1f 秒  速度 %.0f\n",
                     f.getFileName().toRawUTF8(), song->sourceFormat.toRawUTF8(), (int) song->bars.size(),
                     (int) song->tracks.size(), notes, song->lengthSeconds(), song->tempos.front().bpm);
    }

    std::printf ("\n== 同一首曲子不同格式的比对\n");
    int compared = 0, mismatched = 0;
    for (auto& [name, list] : fingerprints)
    {
        if (list.size() < 2) continue;
        ++compared;
        bool same = true;
        for (auto& e : list) same = same && e.second == list.front().second;
        if (! same)
        {
            ++mismatched;
            std::printf ("  [DIFF] %s\n", name.toRawUTF8());
            for (auto& e : list) std::printf ("         %-5s %s\n", e.first.toRawUTF8(), e.second.substring (0, 160).toRawUTF8());
        }
    }
    std::printf ("\n读取 %d 个文件，失败 %d；%d 组多格式比对，不一致 %d\n", total, failed, compared, mismatched);
    return failed == 0 ? 0 : 1;
}

// ---- 弹奏判定测试用：自己编的练习曲 + 合成的“演奏” ------------------------------
namespace judgetest
{
    RawNote note (int str, int fret, bool hammer = false)
    {
        RawNote n; n.string = str; n.fret = fret; n.hammerPull = hammer; return n;
    }

    // 8 小节，100 BPM：四分音符单音、八分音符、强力和弦、击弦
    std::shared_ptr<const Song> makeExerciseSong()
    {
        RawScore raw;
        raw.title = "Judge test";
        raw.initialTempo = 100.0;
        RawTrack t;
        t.name = "Guitar";
        t.tuning = { 64, 59, 55, 50, 45, 40 };
        auto addBar = [&] (std::vector<RawBeat> beats)
        {
            RawMasterBar mb;
            raw.masterBars.push_back (mb);
            RawBar bar;
            bar.voices.push_back ({ std::move (beats) });
            t.bars.push_back (std::move (bar));
        };
        auto beat = [] (double d, std::vector<RawNote> ns) { RawBeat b; b.duration = d; b.notes = std::move (ns); return b; };

        // 1–4：四分音符，各根弦各个把位
        const int q[4][4][2] = { { {5,3},{4,2},{3,0},{2,2} }, { {1,1},{0,0},{0,3},{1,3} },
                                 { {2,4},{3,2},{4,3},{5,5} }, { {3,5},{2,7},{1,8},{0,7} } };
        for (auto& bar : q)
        {
            std::vector<RawBeat> beats;
            for (auto& nf : bar) beats.push_back (beat (1.0, { note (nf[0], nf[1]) }));
            addBar (beats);
        }
        // 5–6：八分音符音阶
        const int e[16][2] = { {5,5},{5,7},{4,5},{4,7},{3,4},{3,5},{3,7},{2,5}, {2,7},{1,5},{1,6},{1,8},{0,5},{0,7},{0,8},{0,10} };
        for (int b = 0; b < 2; ++b)
        {
            std::vector<RawBeat> beats;
            for (int i = 0; i < 8; ++i) beats.push_back (beat (0.5, { note (e[b * 8 + i][0], e[b * 8 + i][1]) }));
            addBar (beats);
        }
        // 7：强力和弦（二分音符）
        addBar ({ beat (2.0, { note (5, 0), note (4, 2), note (3, 2) }), beat (2.0, { note (4, 0), note (3, 2), note (2, 2) }) });
        // 8：拨一个音 + 击弦
        {
            std::vector<RawBeat> beats;
            for (int i = 0; i < 4; ++i)
            {
                beats.push_back (beat (0.5, { note (2, 5) }));
                beats.push_back (beat (0.5, { note (2, 7, true) }));
            }
            addBar (beats);
        }
        raw.tracks.push_back (t);
        return std::shared_ptr<const Song> (buildSong (raw).release());
    }

    struct Plan { int kind = 0; float offsetMs = 0.0f; };   // 0 正确，1 弹错（高半音），2 漏弹

    // 按计划合成演奏（单声道），lat = 整体再晚多少毫秒
    std::vector<float> perform (const Song& song, const JudgeSession& js, const std::vector<Plan>& plan, double extraLatencyMs)
    {
        const auto& notes = song.tracks[0].notes;
        const double total = song.lengthSeconds() + 1.5;
        std::vector<float> out ((size_t) (total * sr), 0.0f);
        PluckSynth synth;
        synth.prepare (sr);
        struct Hit { int64_t at; PluckSynth::NoteOn on; };
        std::vector<Hit> hits;
        for (size_t e = 0; e < js.events.size(); ++e)
        {
            const auto& ev = js.events[e];
            if (plan[e].kind == 2) continue;
            const double t = song.beatToSeconds (ev.beat) + (plan[e].offsetMs + extraLatencyMs) / 1000.0;
            for (int k = ev.firstNote; k < ev.firstNote + ev.numNotes; ++k)
            {
                const auto& n = notes[(size_t) k];
                PluckSynth::NoteOn on;
                on.midi = n.midi + (plan[e].kind == 1 ? 1 : 0);
                on.velocity = n.hammerPull ? 0.55f : 0.85f;
                on.hammer = n.hammerPull;
                on.lengthSeconds = song.beatToSeconds (n.start + n.length) - song.beatToSeconds (n.start);
                hits.push_back ({ (int64_t) (t * sr), on });
            }
        }
        std::sort (hits.begin(), hits.end(), [] (const Hit& a, const Hit& b) { return a.at < b.at; });
        std::vector<float> l (block), r (block);
        size_t h = 0;
        juce::Random rnd (7);
        for (int64_t pos = 0; pos < (int64_t) out.size(); pos += block)
        {
            const int n = (int) juce::jmin ((int64_t) block, (int64_t) out.size() - pos);
            while (h < hits.size() && hits[h].at < pos + n)
            {
                auto on = hits[h].on;
                on.delaySamples = (int) juce::jmax ((int64_t) 0, hits[h].at - pos);
                synth.noteOn (on);
                ++h;
            }
            std::fill (l.begin(), l.end(), 0.0f); std::fill (r.begin(), r.end(), 0.0f);
            synth.render (l.data(), r.data(), n);
            for (int i = 0; i < n; ++i)
                out[(size_t) (pos + i)] = 0.5f * (l[(size_t) i] + r[(size_t) i]) + 0.0005f * (rnd.nextFloat() - 0.5f)
                                          + 0.0015f * (float) std::sin (2.0 * juce::MathConstants<double>::pi * 50.0 * (double) (pos + i) / sr);
        }
        return out;
    }

    // 把演奏喂进引擎 + 判定（同步处理，不开线程）
    void runEngine (AudioEngine& engine, const std::vector<float>& in)
    {
        std::vector<float> l (in.size()), r (in.size());
        for (size_t pos = 0; pos < in.size(); pos += block)
        {
            const int n = (int) juce::jmin ((size_t) block, in.size() - pos);
            engine.processOffline (in.data() + pos, l.data() + pos, r.data() + pos, n);
            engine.getJudge().processPending();
        }
    }

    void setupEngine (AudioEngine& engine, std::shared_ptr<const Song> song, std::shared_ptr<JudgeSession> js, float latencyMs)
    {
        engine.prepareForOffline (sr, block);
        engine.setOutputGainDb (-60.0f);
        auto& tp = engine.getTabPlayer();
        tp.setSong (song);
        tp.setTrack (0);
        tp.setCountIn (false);
        tp.setDemoOn (false);
        tp.setBackingVolumeDb (-60.0f);
        engine.getJudge().setSession (js);
        engine.getJudge().setLatencyMs (latencyMs);
        engine.getJudge().setEnabled (true);
        engine.getJudge().processPending();
        tp.setPlaying (true);
    }
}

// 看每个 NAM 模型有没有带箱体：白噪声进去，比较 6–10 kHz 和 1–3 kHz 的能量
static int probeNamModels (const juce::File& dir)
{
    for (auto& f : dir.findChildFiles (juce::File::findFiles, false, "*.nam"))
    {
        NamProcessor p;
        juce::String err;
        if (! p.loadModel (f, err)) { std::printf ("  [FAIL] %s %s\n", f.getFileName().toRawUTF8(), err.toRawUTF8()); continue; }
        p.prepareToPlay (48000.0, 512);
        juce::Random rnd (1);
        juce::dsp::FFT fft (12);
        std::vector<float> acc (2048, 0.0f), buf (8192);
        juce::AudioBuffer<float> b (2, 4096);
        double inSum = 0.0, outSum = 0.0;
        for (int k = 0; k < 24; ++k)
        {
            for (int i = 0; i < 4096; ++i) { const float x = 0.05f * (rnd.nextFloat() * 2.0f - 1.0f); b.setSample (0, i, x); b.setSample (1, i, x); inSum += x * x; }
            for (int pos = 0; pos < 4096; pos += 512)
            {
                juce::AudioBuffer<float> sub (b.getArrayOfWritePointers(), 2, pos, 512);
                juce::MidiBuffer m;
                p.processBlock (sub, m);
            }
            if (k < 4) continue;
            for (int i = 0; i < 4096; ++i) { buf[(size_t) i] = b.getSample (0, i) * (0.5f - 0.5f * std::cos (6.2831853f * i / 4096.0f)); outSum += b.getSample (0, i) * b.getSample (0, i); }
            std::fill (buf.begin() + 4096, buf.end(), 0.0f);
            fft.performFrequencyOnlyForwardTransform (buf.data());
            for (int i = 0; i < 2048; ++i) acc[(size_t) i] += buf[(size_t) i] * buf[(size_t) i];
        }
        auto band = [&] (double lo, double hi) { double s = 0; for (int i = (int) (lo / 11.71875); i < (int) (hi / 11.71875); ++i) s += acc[(size_t) i]; return s / (hi - lo); };
        const double hiRatio = 10.0 * std::log10 (band (6000, 10000) / band (1000, 3000));
        const double lowRatio = 10.0 * std::log10 (band (60, 200) / band (1000, 3000));
        std::printf ("  %-48s 高频 %6.1f dB  低频 %6.1f dB  增益 %5.1f dB\n", f.getFileName().toRawUTF8(), hiRatio, lowRatio,
                     10.0 * std::log10 (outSum / (inSum * 20.0 / 24.0)));
    }
    return 0;
}

// 判定界面截图：合成一段有对有错的演奏，渲染谱面和成绩卡
static int renderJudgeSnapshots (const juce::File& outDir)
{
    using namespace judgetest;
    outDir.createDirectory();
    auto song = makeExerciseSong();
    auto js = std::make_shared<JudgeSession> (song, 0);
    std::vector<Plan> plan (js->events.size());
    juce::Random rnd (3);
    for (size_t e = 0; e < plan.size(); ++e)
    {
        plan[e].kind = (e % 9 == 4) ? 1 : (e % 11 == 6 ? 2 : 0);
        plan[e].offsetMs = (rnd.nextFloat() - 0.5f) * 90.0f;
    }
    const auto audio = perform (*song, *js, plan, 0.0);
    AudioEngine engine;
    setupEngine (engine, song, js, 0.0f);
    runEngine (engine, audio);

    juce::PNGImageFormat png;
    auto save = [&] (juce::Component& c, const juce::String& name)
    {
        auto img = c.createComponentSnapshot (c.getLocalBounds(), true, 1.0f);
        auto f = outDir.getChildFile (name);
        f.deleteFile();
        if (auto os = f.createOutputStream()) png.writeImageToStream (img, *os);
        std::printf ("  %s\n", f.getFileName().toRawUTF8());
    };

    juce::PropertiesFile::Options o;
    o.applicationName = "LianqinTests";
    juce::PropertiesFile props (outDir.getChildFile ("test.settings"), o);
    PracticeLog plog (outDir.getChildFile ("log.json"));
    PracticePanel panel (engine.getTabPlayer(), engine.getDrums(), engine.getJudge(), engine.getRecorder(), plog, props);
    panel.setSize (884, 630);
    auto& hw = panel.getHighway();
    hw.setSong (song, 0);
    hw.setJudgeSession (js, false);
    hw.setFrozenPosition (17.0);
    save (panel, "judge_highway.png");
    hw.setViewMode (TabHighway::ViewMode::staff);
    save (panel, "judge_staff.png");
    hw.setFrozenPosition (27.3);
    save (panel, "judge_staff2.png");
    hw.setViewMode (TabHighway::ViewMode::lanes);

    JudgeSummaryCard card;
    card.setSize (460, 240);
    card.show (*js);
    save (card, "judge_summary.png");

    // 练习记录页（假数据，只为看排版）
    {
        const auto f = outDir.getChildFile ("stats_demo.json");
        f.deleteFile();
        PracticeLog pl (f);
        juce::Random rr (5);
        const char* names[] = { "Canon Rock", "Exercise in A minor", "Blues shuffle in E", "Pentatonic run" };
        for (int k = 0; k < 4; ++k)
        {
            const juce::String path = juce::String ("C:/tabs/") + names[k] + ".gp5";
            pl.addTime (path, names[k], 600.0 + 900.0 * rr.nextFloat());
            float acc = 0.55f + 0.1f * (float) k;
            for (int i = 0; i < 18 + 6 * k; ++i)
            {
                acc = juce::jlimit (0.3f, 1.0f, acc + (rr.nextFloat() - 0.35f) * 0.08f);
                pl.addPass (path, names[k], acc, juce::jmin (1.0f, 0.6f + 0.025f * (float) i));
            }
        }
        StatsView sv (pl);
        sv.setSize (884, 690);
        sv.refresh();
        save (sv, "stats_view.png");
        f.deleteFile();
    }
    return 0;
}

int renderPromo (const juce::File& out, const juce::File& songDir);
int renderPromo2 (const juce::File& out);
int renderPromo3 (const juce::File& out, const juce::File& songFile);
int renderPromo4 (const juce::File& out, const juce::File& aiTab, const juce::File& demoAudio);
int renderGervanaSnap (const juce::File& out, const juce::String& id);

namespace stest { using namespace ScaleTheory;
void showScale (ScaleTheory::Selection s, const char* label)
{
    auto sc = build (s);
    std::printf ("== %s : %s\n", label, sc.name.toRawUTF8());
    std::printf ("   %s\n", relativeHint (s).toRawUTF8());
    std::string deg; for (int i : sc.intervals) deg += degreeName (i, sc).toStdString() + " ";
    std::printf ("   degrees: %s flats=%d\n", deg.c_str(), (int) preferFlats (s));
    for (int k = 0; k < numPositions (sc); ++k)
    {
        auto pos = position (s.root, sc, k);
        std::printf ("   pos %d:", k + 1);
        for (int st = 0; st < 6; ++st)
        {
            std::printf (" |");
            for (auto& p : pos) if (p.string == st) std::printf ("%d,", p.fret);
        }
        // check ascending & all in scale
        bool ok = true; for (size_t i = 1; i < pos.size(); ++i) if (pos[i].midi <= pos[i-1].midi) ok = false;
        for (auto& p : pos) if (! inScale (p.midi, s.root, sc) || p.fret < 0 || p.fret > maxFret) ok = false;
        std::printf ("  n=%d %s\n", (int) pos.size(), ok ? "ok" : "BAD");
    }
}
}

int main (int argc, char* argv[])
{
    juce::ScopedJuceInitialiser_GUI init;
    if (argc > 3 && juce::String (argv[1]) == "--a2t")
    {
        // 真实录音扒谱，和参考谱子比：--a2t 音频 参考.gp5 [mix|left|right|side]
        juce::AudioFormatManager fm;
        fm.registerBasicFormats();
        std::unique_ptr<juce::AudioFormatReader> rd (fm.createReaderFor (juce::File (juce::String::fromUTF8 (argv[2]))));
        if (rd == nullptr) { std::printf ("读不了音频\n"); return 1; }
        juce::AudioBuffer<float> buf (2, (int) rd->lengthInSamples);
        rd->read (&buf, 0, (int) rd->lengthInSamples, 0, true, true);
        AudioToTab::Options o;
        const juce::String src = argc > 4 ? juce::String (argv[4]) : "mix";
        o.source = src == "left" ? AudioToTab::Source::left : src == "right" ? AudioToTab::Source::right : src == "side" ? AudioToTab::Source::side : AudioToTab::Source::mix;
        const double t0 = juce::Time::getMillisecondCounterHiRes();
        const auto res = AudioToTab::transcribe (buf, rd->sampleRate, o);
        std::printf ("用时 %.1f 秒，%.1f BPM，%d 个音，%d 个和弦  %s\n%s\n", (juce::Time::getMillisecondCounterHiRes() - t0) / 1000.0, res.bpm,
                     (int) res.notes.size(), (int) res.chords.size(), res.error.toRawUTF8(), res.summary.toRawUTF8());
        if (res.song != nullptr)
            for (auto& t : res.song->tracks) std::printf ("  音轨 %s：%d 个音，%d 弦\n", t.name.toRawUTF8(), (int) t.notes.size(), t.stringCount());
        if (argc > 5 && res.song != nullptr)
        {
            juce::String e2;
            AudioToTab::writeGp3 (res.raw, juce::File (juce::String::fromUTF8 (argv[5])), e2);
        }
        juce::String err;
        auto ref = loadSongFile (juce::File (juce::String::fromUTF8 (argv[3])), err);
        if (ref == nullptr) return 1;
        const auto& tr = ref->tracks[(size_t) ref->defaultTrack()];
        std::printf ("参考：%s %.1f BPM，%d 个音\n", tr.name.toRawUTF8(), ref->tempoAt (0.0), (int) tr.notes.size());
        // 参考谱的“单音线”：同一时刻只取最高音
        std::vector<std::pair<double, int>> refNotes;
        for (auto& n : tr.notes)
        {
            const double t = ref->beatToSeconds (n.start);
            if (! refNotes.empty() && std::abs (refNotes.back().first - t) < 1.0e-4) { refNotes.back().second = juce::jmax (refNotes.back().second, n.midi); continue; }
            refNotes.push_back ({ t, n.midi });
        }
        double bestOff = 0.0; int bestHit = -1;
        for (double off = -3.0; off <= 6.0; off += 0.01)
        {
            int hit = 0;
            for (auto& rn : refNotes)
                for (auto& d : res.notes)
                    if (std::abs (d.start - (rn.first + off)) < A2T_TOL && (d.midi - rn.second) % 12 == 0) { ++hit; break; }
            if (hit > bestHit) { bestHit = hit; bestOff = off; }
        }
        int exact = 0;
        for (auto& rn : refNotes)
            for (auto& d : res.notes)
                if (std::abs (d.start - (rn.first + bestOff)) < A2T_TOL && d.midi == rn.second) { ++exact; break; }
        const double refEnd = refNotes.empty() ? 0.0 : refNotes.back().first + bestOff + 1.0;
        int inSpan = 0;
        for (auto& d : res.notes) if (d.start < refEnd) ++inSpan;
        std::printf ("对齐偏移 %.2f 秒：音名对 %d / %d（%.0f%%），音高也对 %d；扒出（谱子范围内）%d 个，准确率 %.0f%%\n",
                     bestOff, bestHit, (int) refNotes.size(), 100.0 * bestHit / juce::jmax (1, (int) refNotes.size()), exact, inSpan,
                     100.0 * bestHit / juce::jmax (1, inSpan));
        juce::String cs;
        for (auto& c : res.chords) cs << juce::String (c.start, 1) << ":" << Chords::name (c.root, (Chords::Quality) c.quality) << " ";
        std::printf ("和弦：%s\n", cs.substring (0, 600).toRawUTF8());
        return 0;
    }
    if (argc > 2 && juce::String (argv[1]) == "--refjson")
    {
        juce::String err;
        auto ref = loadSongFile (juce::File (juce::String::fromUTF8 (argv[2])), err);
        if (ref == nullptr) return 1;
        const int t = argc > 3 ? juce::String (argv[3]).getIntValue() : ref->defaultTrack();
        juce::String js = "[";
        for (auto& n : ref->tracks[(size_t) t].notes)
            js << "[" << ref->beatToSeconds (n.start) << "," << n.midi << "," << n.string << "],";
        js = js.trimCharactersAtEnd (",") + "]";
        std::printf ("%s\n", js.toRawUTF8());
        for (size_t i = 0; i < ref->tracks.size(); ++i)
            std::fprintf (stderr, "track %d %s notes %d bass %d\n", (int) i, ref->tracks[i].name.toRawUTF8(), (int) ref->tracks[i].notes.size(), (int) ref->tracks[i].isBass());
        return 0;
    }
    if (argc > 2 && juce::String (argv[1]) == "--dump")
        return dumpSong (juce::File (argv[2]));
    if (argc > 2 && juce::String (argv[1]) == "--songs")
        return testSongs (juce::File (argv[2]));
    if (argc > 3 && juce::String (argv[1]) == "--highway")
        return renderHighwaySnapshots (juce::File (juce::String::fromUTF8 (argv[2])), juce::File (juce::String::fromUTF8 (argv[3])));
    if (argc > 3 && juce::String (argv[1]) == "--gv-snap")
        return renderGervanaSnap (juce::File (juce::String::fromUTF8 (argv[2])), juce::String (argv[3]));
    if (argc > 4 && juce::String (argv[1]) == "--promo4")
        return renderPromo4 (juce::File (juce::String::fromUTF8 (argv[2])), juce::File (juce::String::fromUTF8 (argv[3])), juce::File (juce::String::fromUTF8 (argv[4])));
    if (argc > 3 && juce::String (argv[1]) == "--promo3")
        return renderPromo3 (juce::File (juce::String::fromUTF8 (argv[2])), juce::File (juce::String::fromUTF8 (argv[3])));
    if (argc > 2 && juce::String (argv[1]) == "--promo2")
        return renderPromo2 (juce::File (argv[2]));
    if (argc > 2 && juce::String (argv[1]) == "--promo")
        return renderPromo (juce::File (argv[2]), juce::File (argc > 3 ? argv[3] : "."));
    if (argc > 2 && juce::String (argv[1]) == "--nam-probe")
        return probeNamModels (juce::File (argv[2]));
    if (argc > 2 && juce::String (argv[1]) == "--judge-snap")
        return renderJudgeSnapshots (juce::File (argv[2]));
    if (argc > 1 && juce::String (argv[1]) == "--scales")
    {
    ScaleTheory::Selection s; s.root = 9; s.family = ScaleTheory::Family::pentatonic; s.minor = true; stest::showScale (s, "Am penta");
    s.family = ScaleTheory::Family::blues; stest::showScale (s, "Am blues");
    s.family = ScaleTheory::Family::sevenNote; s.minor = false; s.root = 7; stest::showScale (s, "G major");
    s.minor = true; s.root = 4; s.minorType = ScaleTheory::MinorType::harmonic; stest::showScale (s, "E harmonic minor");
    s.family = ScaleTheory::Family::modes; s.root = 2; s.mode = ScaleTheory::Mode::dorian; stest::showScale (s, "D dorian");
    s.mode = ScaleTheory::Mode::lydian; s.root = 5; stest::showScale (s, "F lydian");
    s.mode = ScaleTheory::Mode::locrian; s.root = 11; stest::showScale (s, "B locrian");
    s.family = ScaleTheory::Family::pentatonic; s.minor = false; s.root = 7; stest::showScale (s, "G major penta");
        return 0;
    }
    if (argc > 2 && juce::String (argv[1]) == "--scales-ui")
    {
        AudioEngine engine;
        engine.prepareForOffline (sr, block);
        const juce::File dir { juce::String (argv[2]) };
        dir.createDirectory();
        juce::PropertiesFile::Options o; o.applicationName = "LianqinTests";
        juce::PropertiesFile props (dir.getChildFile ("scales.settings"), o);
        ScalesPanel panel (engine, props);
        panel.setSize (884, 724);
        auto shot = [&] (const char* name)
        {
            for (int i = 0; i < 50; ++i) if (! juce::detail::dispatchNextMessageOnSystemQueue (true)) break;
            auto img = panel.createComponentSnapshot (panel.getLocalBounds(), true, 1.0f);
            juce::PNGImageFormat png;
            auto f = dir.getChildFile (juce::String (name) + ".png");
            f.deleteFile();
            if (auto os = f.createOutputStream()) png.writeImageToStream (img, *os);
        };
        panel.selectForSnapshot (9, 0, true, 0, 1, 1);      // A 小调五声 把位 1
        PitchDetector::Result r; r.frequency = 220.0f; r.clarity = 0.95f; r.rmsDb = -20.0f;
        panel.setDetectedPitch (r);
        shot ("scales_am_penta");
        panel.selectForSnapshot (9, 1, true, 0, 1, 0);      // A 小调布鲁斯 全指板
        shot ("scales_am_blues_all");
        panel.selectForSnapshot (4, 2, true, 1, 1, 3);      // E 和声小调 把位 3
        shot ("scales_e_harmonic");
        panel.selectForSnapshot (2, 3, false, 0, 1, 2);     // D 多利亚 把位 2
        r.frequency = 233.08f; panel.setDetectedPitch (r);  // 弹一个不在音阶里的 Bb
        shot ("scales_d_dorian");
        panel.selectInstrumentForSnapshot (1);              // 贝斯 4 弦
        panel.selectForSnapshot (9, 0, true, 0, 1, 1);
        r.frequency = 55.0f; panel.setDetectedPitch (r);
        shot ("scales_bass4_am_penta");
        panel.selectInstrumentForSnapshot (2);              // 贝斯 5 弦
        panel.selectForSnapshot (4, 0, true, 0, 1, 0);
        shot ("scales_bass5_em_all");
        panel.selectInstrumentForSnapshot (0);
        return 0;
    }
    if (argc > 1 && juce::String (argv[1]) == "--pitch-bench")
    {
        // 模拟“指板音阶”页：每 33 ms 取最近一段干声做音高检测，看拨弦后 0.6 秒内有多少帧认对了
        for (double rate : { 44100.0, 48000.0 })
        {
            std::printf ("== %.0f Hz\n", rate);
            for (float level : { 0.3f, 0.08f, 0.025f })
            {
                std::printf ("  峰值 %.3f：", level);
                for (int str = 0; str < 6; ++str)
                {
                    int ok = 0, total = 0;
                    for (int fret : { 0, 3, 5, 7, 10, 12, 15, 17 })
                    {
                        const int midi = ScaleTheory::openMidi[str] + fret;
                        PluckSynth syn; syn.prepare (rate);
                        PluckSynth::NoteOn on; on.midi = midi; on.velocity = 0.9f; on.lengthSeconds = 1.5;
                        syn.noteOn (on);
                        const int n = (int) (0.8 * rate);
                        std::vector<float> l ((size_t) n), r ((size_t) n);
                        syn.render (l.data(), r.data(), n);
                        if (juce::SystemStats::getEnvironmentVariable ("HARM", {}).isNotEmpty())
                        {
                            // 换成干净的谐波衰减音（真琴高音的样子：基音 + 几个泛音，各自指数衰减）
                            const double f0 = 440.0 * std::pow (2.0, (midi - 69) / 12.0);
                            for (int i = 0; i < n; ++i)
                            {
                                const double t = i / rate;
                                double v = 0.0;
                                for (int h = 1; h <= 6; ++h)
                                    v += std::sin (juce::MathConstants<double>::twoPi * f0 * h * t) / h * std::exp (-t * (2.0 + 1.5 * h));
                                l[(size_t) i] = (float) v;
                            }
                        }
                        float pk = 0; for (float v : l) pk = juce::jmax (pk, std::abs (v));
                        juce::Random rnd (midi);
                        for (auto& v : l) v = v / pk * level + (rnd.nextFloat() - 0.5f) * 0.0006f;   // 加一点底噪
                        PitchDetector pd;
                        const int len = rate > 50000.0 ? 4096 : 2048;
                        for (double t = 0.04; t < 0.64; t += 1.0 / 30.0)
                        {
                            const int end = (int) (t * rate);
                            if (end < len) continue;
                            const bool newWay = juce::SystemStats::getEnvironmentVariable ("OLD", {}).isEmpty();
                            const auto res = newWay ? pd.detectGuitar (l.data() + end - len, len, rate) : pd.detect (l.data() + end - len, len, rate);
                            const bool valid = newWay ? (res.frequency > 0.0f && res.clarity > 0.8f && res.rmsDb > -66.0f)
                                                      : (res.frequency > 0.0f && res.clarity > 0.85f && res.rmsDb > -52.0f);
                            const int m = valid ? juce::roundToInt (69.0 + 12.0 * std::log2 (res.frequency / 440.0)) : -1;
                            ++total; if (m == midi) ++ok;
                            if (str >= 4 && level > 0.2f && m != midi && rate < 46000.0 && juce::SystemStats::getEnvironmentVariable ("DIAG", {}).isNotEmpty())
                                std::printf ("\n     [%d弦 %d品 t=%.2f] f=%.1f clar=%.2f rms=%.1f -> %d (要 %d)", 6 - str, fret, t, res.frequency, res.clarity, res.rmsDb, m, midi);
                        }
                    }
                    std::printf ("  %d弦 %3d%%", 6 - str, 100 * ok / juce::jmax (1, total));
                }
                std::printf ("\n");
            }
        }
        return 0;
    }
    if (argc > 2 && juce::String (argv[1]) == "--scales-main")
    {
        MainComponent mc;
        mc.setSize (1240, 800);
        mc.setView (MainComponent::View::scales);
        for (int i = 0; i < 200; ++i) if (! juce::detail::dispatchNextMessageOnSystemQueue (true)) break;
        auto img = mc.createComponentSnapshot (mc.getLocalBounds(), true, 1.0f);
        juce::PNGImageFormat png;
        auto f = juce::File { juce::String (argv[2]) }.getChildFile ("scales_main.png");
        f.deleteFile();
        if (auto os = f.createOutputStream()) png.writeImageToStream (img, *os);
        return 0;
    }
    if (argc > 2 && juce::String (argv[1]) == "--dock-ui")
    {
        const juce::File dir { juce::String (argv[2]) };
        dir.createDirectory();
        // 生成一段 20 秒的测试伴奏
        const auto wav = dir.getChildFile ("backing_test.wav");
        {
            juce::AudioBuffer<float> b (2, 44100 * 20);
            for (int i = 0; i < b.getNumSamples(); ++i)
            {
                const double t = i / 44100.0;
                const float env = (float) std::exp (-6.0 * std::fmod (t, 0.5));
                const float v = 0.4f * env * (float) std::sin (2.0 * juce::MathConstants<double>::pi * (110.0 + 55.0 * std::floor (std::fmod (t, 4.0))) * t);
                b.setSample (0, i, v); b.setSample (1, i, v);
            }
            wav.deleteFile();
            juce::WavAudioFormat fmt;
            if (auto os = wav.createOutputStream())
                if (auto w = std::unique_ptr<juce::AudioFormatWriter> (fmt.createWriterFor (os.get(), 44100.0, 2, 16, {}, 0)))
                {
                    os.release();
                    w->writeFromAudioSampleBuffer (b, 0, b.getNumSamples());
                }
        }
        MainComponent mc;
        mc.setSize (1240, 800);
        mc.setView (MainComponent::View::tone);
        juce::String err;
        mc.getEngine().getBacking().loadNow (wav, err);
        mc.getEngine().getBacking().setLoopRange (6.0, 10.5);
        mc.getEngine().getBacking().seekSeconds (8.2);
        juce::PNGImageFormat png;
        const char* names[] = { "dock_drums.png", "dock_loop.png", "dock_backing.png" };
        for (int t = 0; t < 3; ++t)
        {
            mc.showDockTab (t);
            for (int i = 0; i < 200; ++i) if (! juce::detail::dispatchNextMessageOnSystemQueue (true)) break;
            auto img = mc.createComponentSnapshot (mc.getLocalBounds(), true, 1.0f);
            auto f = dir.getChildFile (names[t]);
            f.deleteFile();
            if (auto os = f.createOutputStream()) png.writeImageToStream (img, *os);
        }
        mc.showDockTab (0);
        return 0;
    }
    if (argc > 2 && juce::String (argv[1]) == "--quiz-ui")
    {
        MainComponent mc;
        mc.setSize (1240, 800);
        mc.setView (MainComponent::View::scales);
        auto* sp = mc.findChildWithID ("scales");
        juce::ignoreUnused (sp);
        for (auto* c : mc.getChildren())
            if (auto* panel = dynamic_cast<ScalesPanel*> (c))
            {
                panel->showQuizForSnapshot (true);
                for (int i = 0; i < 50; ++i) if (! juce::detail::dispatchNextMessageOnSystemQueue (true)) break;
                juce::PNGImageFormat png;
                auto save = [&] (const char* name)
                {
                    auto img = mc.createComponentSnapshot (mc.getLocalBounds(), true, 1.0f);
                    auto f = juce::File { juce::String (argv[2]) }.getChildFile (name);
                    f.deleteFile();
                    if (auto os = f.createOutputStream()) png.writeImageToStream (img, *os);
                };
                save ("quiz_name.png");
                auto& q = panel->getTrainer().getQuiz();
                juce::ignoreUnused (q);
                panel->getTrainer().keyPressed (juce::KeyPress ('c', 0, 'c'));
                save ("quiz_name_answered.png");
                panel->showQuizForSnapshot (false);
            }
        return 0;
    }
    if (argc > 2 && juce::String (argv[1]) == "--chords-ui")
    {
        MainComponent mc;
        mc.setSize (1240, 800);
        mc.setView (MainComponent::View::chords);
        for (auto* c : mc.getChildren())
            if (auto* cp = dynamic_cast<ChordPanel*> (c))
            {
                cp->select (9, Chords::Quality::minor);
                cp->setListening (true);
                cp->setStatusForSnapshot ({ 0, 1, 1, 2, 1, 1 });
                for (int i = 0; i < 50; ++i) if (! juce::detail::dispatchNextMessageOnSystemQueue (true)) break;
                auto img = mc.createComponentSnapshot (mc.getLocalBounds(), true, 1.0f);
                juce::PNGImageFormat png;
                auto f = juce::File { juce::String (argv[2]) }.getChildFile ("chords_main.png");
                f.deleteFile();
                if (auto os = f.createOutputStream()) png.writeImageToStream (img, *os);
                cp->setListening (false);
            }
        return 0;
    }
    if (argc > 1 && juce::String (argv[1]) == "--bp-timing")
    {
        // Basic Pitch 时间轴：60 秒里每 0.75 秒一个音，看识别出来的起音时间和真实时间差多少
        const double rate = BasicPitch::sampleRate;
        std::vector<float> x ((size_t) (rate * 62.0), 0.0f);
        PluckSynth syn; syn.prepare (rate);
        std::vector<double> truth;
        for (double t = 0.5; t < 60.0; t += 0.75) truth.push_back (t);
        std::vector<float> l (256), r (256);
        size_t e = 0;
        for (int pos = 0; pos < (int) x.size(); pos += 256)
        {
            const int n = juce::jmin (256, (int) x.size() - pos);
            while (e < truth.size() && (int) (truth[e] * rate) < pos + n)
            {
                PluckSynth::NoteOn on; on.midi = 60 + (int) (e % 5) * 2; on.velocity = 0.9f; on.lengthSeconds = 0.5;
                on.delaySamples = juce::jmax (0, (int) (truth[e] * rate) - pos);
                syn.noteOn (on); ++e;
            }
            std::fill (l.begin(), l.end(), 0.0f); std::fill (r.begin(), r.end(), 0.0f);
            syn.render (l.data(), r.data(), n);
            for (int i = 0; i < n; ++i) x[(size_t) (pos + i)] = 0.5f * (l[(size_t) i] + r[(size_t) i]);
        }
        BasicPitch::Output out; juce::String err;
        if (! BasicPitch::run (x, out, err)) { std::printf ("%s\n", err.toRawUTF8()); return 1; }
        auto ns = BasicPitch::notes (out, {});
        std::sort (ns.begin(), ns.end(), [] (auto& a, auto& b) { return a.start < b.start; });
        for (size_t i = 0; i < truth.size(); i += 8)
        {
            double best = 9.0;
            for (auto& n : ns) if (std::abs (n.start - truth[i]) < std::abs (best)) best = n.start - truth[i];
            std::printf ("  真实 %6.2f 秒：识别偏差 %+6.1f ms\n", truth[i], best * 1000.0);
        }
        return 0;
    }
    if (argc > 3 && juce::String (argv[1]) == "--a2teval")
    {
        // 扒谱质量：--a2teval 音频 参考谱 [只扒前多少秒] [输出.gp3]；环境变量 A2T_NOSEP=1 不分离
        juce::AudioFormatManager fm; fm.registerBasicFormats();
        std::unique_ptr<juce::AudioFormatReader> rd (fm.createReaderFor (juce::File (juce::String::fromUTF8 (argv[2]))));
        if (rd == nullptr) { std::printf ("读不了音频\n"); return 1; }
        juce::AudioBuffer<float> buf (2, (int) rd->lengthInSamples);
        rd->read (&buf, 0, (int) rd->lengthInSamples, 0, true, true);
        AudioToTab::Options o;
        o.separate = std::getenv ("A2T_NOSEP") == nullptr;
        if (argc > 4 && std::atof (argv[4]) > 0) o.endSeconds = std::atof (argv[4]);
        const double t0 = juce::Time::getMillisecondCounterHiRes();
        const auto res = AudioToTab::transcribe (buf, rd->sampleRate, o);
        if (res.song == nullptr) { std::printf ("失败：%s\n", res.error.toRawUTF8()); return 1; }
        if (argc > 5) { juce::String e2; AudioToTab::writeGp3 (res.raw, juce::File (juce::String::fromUTF8 (argv[5])), e2); }
        juce::String err;
        auto ref = loadSongFile (juce::File (juce::String::fromUTF8 (argv[3])), err);
        if (ref == nullptr) { std::printf ("参考谱读不了\n"); return 1; }
        struct N { double t; int midi; };
        auto collect = [] (const Song& s, bool bass, std::function<double (double)> toSec)
        {
            std::vector<N> v;
            for (auto& tr : s.tracks)
            {
                if (tr.percussion || tr.isBass() != bass) continue;
                for (auto& n : tr.notes) if (! n.dead) v.push_back ({ toSec (n.start), n.midi });
            }
            std::sort (v.begin(), v.end(), [] (const N& a, const N& b) { return a.t < b.t; });
            return v;
        };
        const Song* songRef = ref.get();
        auto refG = collect (*ref, false, [&] (double b) { return songRef->beatToSeconds (b); });
        auto refB = collect (*ref, true, [&] (double b) { return songRef->beatToSeconds (b); });
        auto ourToSec = [&] (double b) { return res.firstBeatSeconds + res.song->beatToSeconds (b) * res.syncRate; };
        auto ourG = collect (*res.song, false, ourToSec), ourB = collect (*res.song, true, ourToSec);
        auto hits = [] (const std::vector<N>& a, const std::vector<N>& b, double off, double tol, bool pc)
        {
            int h = 0; size_t j0 = 0;
            for (auto& x : a)
            {
                const double t = x.t + off;
                while (j0 < b.size() && b[j0].t < t - tol) ++j0;
                for (size_t j = j0; j < b.size() && b[j].t <= t + tol; ++j)
                    if (pc ? (b[j].midi - x.midi) % 12 == 0 : b[j].midi == x.midi) { ++h; break; }
            }
            return h;
        };
        const double audioLen = o.endSeconds > 0 ? o.endSeconds : rd->lengthInSamples / rd->sampleRate;
        double bestOff = 0.0; int best = -1;
        for (double off = -8.0; off <= 12.0; off += 0.01)
        {
            const int h = hits (refG, ourG, off, 0.08, true);
            if (h > best) { best = h; bestOff = off; }
        }
        // 80 ms 的窗口里有一整段平台：再用 30 ms 的窗口在附近细找，对到正中间
        {
            const double c = bestOff;
            int b2 = -1;
            for (double off = c - 0.15; off <= c + 0.15; off += 0.002)
            {
                const int h = hits (refG, ourG, off, 0.03, true);
                if (h > b2) { b2 = h; bestOff = off; }
            }
        }
        auto within = [&] (const std::vector<N>& v, double off)
        {
            std::vector<N> o2;
            for (auto& x : v) if (x.t + off >= 0.0 && x.t + off < audioLen - 0.3) o2.push_back (x);
            return o2;
        };
        auto report = [&] (const char* name, const std::vector<N>& refAll, const std::vector<N>& ours)
        {
            const auto r = within (refAll, bestOff);
            if (r.empty()) { std::printf ("  %s：参考里没有\n", name); return; }
            double lo = r.front().t + bestOff - 0.5, hi = r.back().t + bestOff + 0.5;
            std::vector<N> us;
            for (auto& x : ours) if (x.t >= lo && x.t <= hi) us.push_back (x);
            const int rec = hits (r, us, bestOff, 0.08, false), recTight = hits (r, us, bestOff, 0.04, false);
            const int recLoose = hits (r, us, bestOff, 0.16, false), recPc = hits (r, us, bestOff, 0.08, true);
            std::printf ("     （160ms 内 %.0f%%，不管八度 %.0f%%）\n", 100.0 * recLoose / r.size(), 100.0 * recPc / r.size());
            std::vector<N> rShift;
            for (auto& x : r) rShift.push_back ({ x.t + bestOff, x.midi });
            const int prec = hits (us, rShift, 0.0, 0.08, false);
            const double R = (double) rec / r.size(), P = us.empty() ? 0.0 : (double) prec / us.size();
            std::printf ("  %s：参考 %d 个，扒出 %d 个｜召回 %.0f%%（40ms 内 %.0f%%）｜准确 %.0f%%｜F1 %.0f%%\n", name, (int) r.size(), (int) us.size(),
                         100 * R, 100.0 * recTight / r.size(), 100 * P, R + P > 0 ? 200 * R * P / (R + P) : 0.0);
        };
        std::printf ("%s｜用时 %.1f 秒｜%.1f BPM｜对齐 %.2f 秒｜%s\n", juce::File (juce::String::fromUTF8 (argv[2])).getFileName().toRawUTF8(),
                     (juce::Time::getMillisecondCounterHiRes() - t0) / 1000.0, res.bpm, bestOff, res.summary.toRawUTF8());
        report ("吉他", refG, ourG);
        report ("贝斯", refB, ourB);
        return 0;
    }
    if (argc > 3 && juce::String (argv[1]) == "--demucs")
    {
        // --demucs 音频 输出目录 [秒数]
        juce::AudioFormatManager fm; fm.registerBasicFormats();
        std::unique_ptr<juce::AudioFormatReader> rd (fm.createReaderFor (juce::File (juce::String::fromUTF8 (argv[2]))));
        if (rd == nullptr) { std::printf ("读不了音频\n"); return 1; }
        const int n = argc > 4 ? (int) juce::jmin ((double) rd->lengthInSamples, std::atof (argv[4]) * rd->sampleRate) : (int) rd->lengthInSamples;
        juce::AudioBuffer<float> buf (2, n);
        rd->read (&buf, 0, n, 0, true, true);
        juce::AudioBuffer<float> stems[Demucs::numStems];
        juce::String err;
        const double t0 = juce::Time::getMillisecondCounterHiRes();
        const bool ok = Demucs::separate (buf, rd->sampleRate, stems, err, [] (float p) { std::printf ("  %.0f%%\n", p * 100.0); std::fflush (stdout); return true; });
        std::printf ("%s %.1f 秒（音频 %.1f 秒）%s\n", ok ? "完成" : "失败", (juce::Time::getMillisecondCounterHiRes() - t0) / 1000.0, n / rd->sampleRate, err.toRawUTF8());
        if (! ok) return 1;
        const juce::File dir (juce::String::fromUTF8 (argv[3]));
        dir.createDirectory();
        for (int s = 0; s < Demucs::numStems; ++s)
        {
            auto f = dir.getChildFile (juce::String (Demucs::stemName (s)) + ".wav");
            f.deleteFile();
            juce::WavAudioFormat wf;
            std::unique_ptr<juce::AudioFormatWriter> w (wf.createWriterFor (new juce::FileOutputStream (f), Demucs::sampleRate, 2, 16, {}, 0));
            if (w) w->writeFromAudioSampleBuffer (stems[s], 0, stems[s].getNumSamples());
            std::printf ("  %s rms %.4f\n", Demucs::stemName (s), stems[s].getRMSLevel (0, 0, stems[s].getNumSamples()));
        }
        return 0;
    }
    if (argc > 2 && juce::String (argv[1]) == "--roundtrip")
    {
        // 谱子 → songToRaw → GP3 → 读回来：每个音（开始、时值、弦、品）、速度应该一样
        juce::Array<juce::File> files;
        juce::File (juce::String::fromUTF8 (argv[2])).findChildFiles (files, juce::File::findFiles, true, "*.gp3;*.gp4;*.gp5;*.gpx;*.gp");
        int ok = 0, bad = 0, total = 0;
        for (auto& f : files)
        {
            juce::String err;
            auto a = loadSongFile (f, err);
            if (a == nullptr) continue;
            ++total;
            const auto tmp = juce::File::getSpecialLocation (juce::File::tempDirectory).getChildFile ("rt.gp3");
            if (! AudioToTab::writeGp3 (songToRaw (*a), tmp, err)) { std::printf ("  写不了 %s：%s\n", f.getFileName().toRawUTF8(), err.toRawUTF8()); ++bad; continue; }
            auto b = loadSongFile (tmp, err);
            juce::String why;
            if (b == nullptr) why = "读不回来：" + err;
            else if (b->tracks.size() != a->tracks.size()) why = "音轨数不同";
            else if (std::abs (b->lengthBeats - a->lengthBeats) > 0.01) why = "长度不同 " + juce::String (a->lengthBeats) + " / " + juce::String (b->lengthBeats);
            else if (std::abs (b->lengthSeconds() - a->lengthSeconds()) > 0.05 * std::max (1.0, a->lengthSeconds() / 60.0)) why = "秒数不同 " + juce::String (a->lengthSeconds(), 2) + " / " + juce::String (b->lengthSeconds(), 2);
            else
                for (size_t t = 0; t < a->tracks.size() && why.isEmpty(); ++t)
                {
                    const auto& x = a->tracks[t].notes; const auto& y = b->tracks[t].notes;
                    if (x.size() != y.size()) { why = juce::String ("音轨 ") + juce::String ((int) t) + " 音数 " + juce::String ((int) x.size()) + " / " + juce::String ((int) y.size()); break; }
                    for (size_t i = 0; i < x.size(); ++i)
                    {
                        const bool same = std::abs (x[i].start - y[i].start) < 0.03 && std::abs (x[i].length - y[i].length) < 0.05
                                          && x[i].string == y[i].string && x[i].fret == y[i].fret && x[i].hammerPull == y[i].hammerPull
                                          && std::abs (x[i].bend - y[i].bend) < 0.3f;
                        if (! same)
                        {
                            why = juce::String ("音轨 ") + juce::String ((int) t) + " 第 " + juce::String ((int) i) + " 个音："
                                  + juce::String (x[i].start, 3) + "/" + juce::String (x[i].length, 3) + " s" + juce::String (x[i].string) + " f" + juce::String (x[i].fret) + (x[i].hammerPull ? " H" : "") + " b" + juce::String (x[i].bend, 1)
                                  + "  →  " + juce::String (y[i].start, 3) + "/" + juce::String (y[i].length, 3) + " s" + juce::String (y[i].string) + " f" + juce::String (y[i].fret) + (y[i].hammerPull ? " H" : "") + " b" + juce::String (y[i].bend, 1);
                            break;
                        }
                    }
                }
            if (why.isEmpty()) ++ok;
            else { ++bad; if (bad <= 25) std::printf ("  [DIFF] %s：%s\n", f.getFileName().toRawUTF8(), why.toRawUTF8()); }
        }
        std::printf ("往返 %d 个谱子：一致 %d，不一致 %d\n", total, ok, bad);
        return 0;
    }
    if (argc > 3 && juce::String (argv[1]) == "--edit-ui")
    {
        // 改谱界面截图：--edit-ui 输出目录 谱子
        const juce::File dir { juce::String::fromUTF8 (argv[2]) };
        dir.createDirectory();
        AudioEngine engine;
        engine.prepareForOffline (sr, block);
        juce::PropertiesFile::Options po; po.applicationName = "LianqinTests";
        juce::PropertiesFile props (dir.getChildFile ("e.settings"), po);
        PracticeLog plog (dir.getChildFile ("log.json"));
        PracticePanel panel (engine.getTabPlayer(), engine.getDrums(), engine.getJudge(), engine.getRecorder(), plog, props);
        panel.setSize (1240, 780);
        if (! panel.loadFile (juce::File (juce::String::fromUTF8 (argv[3])))) return 1;
        panel.startEditing();
        auto& ed = panel.getEditor();
        const auto& ns = ed.current()->tracks[(size_t) ed.getTrack()].notes;
        const size_t k = juce::jmin ((size_t) 12, ns.size() - 1);
        ed.select (ns[k].start, ns[k].string, false);
        ed.select (ns[k + 1].start, ns[k + 1].string, true);
        ed.lastMessage = juce::String::fromUTF8 ("品位 7");
        panel.keyPressed (juce::KeyPress ('7', 0, '7'));
        panel.getHighway().setFrozenPosition (ns[k].start);
        for (int i = 0; i < 30; ++i) if (! juce::detail::dispatchNextMessageOnSystemQueue (true)) break;
        auto img = panel.createComponentSnapshot (panel.getLocalBounds(), true, 1.0f);
        juce::PNGImageFormat png;
        auto f = dir.getChildFile ("edit.png"); f.deleteFile();
        if (auto os = f.createOutputStream()) png.writeImageToStream (img, *os);
        return 0;
    }
    if (argc > 3 && juce::String (argv[1]) == "--orig-ui")
    {
        // 原曲同步的界面：--orig-ui 输出目录 谱子 [音频]
        const juce::File dir { juce::String::fromUTF8 (argv[2]) };
        dir.createDirectory();
        AudioEngine engine;
        engine.prepareForOffline (sr, block);
        juce::PropertiesFile::Options po; po.applicationName = "LianqinTests";
        juce::PropertiesFile props (dir.getChildFile ("o.settings"), po);
        PracticeLog plog (dir.getChildFile ("log.json"));
        PracticePanel panel (engine.getTabPlayer(), engine.getDrums(), engine.getJudge(), engine.getRecorder(), plog, props);
        panel.setSize (884, 630);
        panel.attachOriginal (engine.getOriginal());
        const juce::File tab { juce::String::fromUTF8 (argv[3]) };
        if (argc > 4)
        {
            OriginalSync os; os.audio = juce::File (juce::String::fromUTF8 (argv[4])); os.offset = 2.215; os.rate = 0.9982;
            panel.setOriginalForTab (tab, os);
        }
        panel.loadFile (tab);
        for (int i = 0; i < 50; ++i) if (! juce::detail::dispatchNextMessageOnSystemQueue (true)) break;
        auto shot = [&] (juce::Component& c, const char* name)
        {
            auto img = c.createComponentSnapshot (c.getLocalBounds(), true, 1.0f);
            juce::PNGImageFormat png;
            auto f = dir.getChildFile (juce::String (name) + ".png");
            f.deleteFile();
            if (auto os = f.createOutputStream()) png.writeImageToStream (img, *os);
        };
        shot (panel, "orig_practice");
        OriginalSync s2 = panel.getOriginalSync();
        OriginalSyncPanel op (engine.getOriginal(), s2);
        shot (op, "orig_panel");
        OriginalSync::removeFor (tab, props);
        return 0;
    }
    if (argc > 2 && juce::String (argv[1]) == "--pet-ui")
    {
        const juce::File dir { juce::String (argv[2]) };
        dir.createDirectory();
        juce::PNGImageFormat png;
        auto save = [&] (juce::Component& c, const juce::String& name)
        {
            auto img = c.createComponentSnapshot (c.getLocalBounds(), true, 1.0f);
            auto f = dir.getChildFile (name);
            f.deleteFile();
            if (auto os = f.createOutputStream()) png.writeImageToStream (img, *os);
        };
        {
            MainComponent mc;
            mc.setSize (1240, 800);
            mc.setView (MainComponent::View::tone);
            for (int i = 0; i < 50; ++i) if (! juce::detail::dispatchNextMessageOnSystemQueue (true)) break;
            save (mc, "pet_main.png");
        }
        // 每种反馈：冻结时钟，放一会儿动画再截
        PetView pet;
        pet.setSize (280, 250);
        struct Case { const char* name; int ev; };
        const Case cases[] = { { "idle", -1 }, { "perfect", 0 }, { "good", 1 }, { "wrong", 2 }, { "miss", 3 }, { "early", 4 }, { "late", 5 }, { "combo", 6 } };
        double t = 1000.0;
        juce::Image strip (juce::Image::ARGB, 280 * 4, 250 * 2, true);
        {
            juce::Graphics g (strip);
            g.fillAll (juce::Colour (0xff222222));
        }
        int k = 0;
        for (auto& c : cases)
        {
            pet.setClockForSnapshot (t);
            if (c.ev >= 0) pet.react ((PetView::Event) c.ev, c.ev == 6 ? 20 : 0, c.ev == 4 ? juce::String::fromUTF8 ("早 62 ms") : juce::String());
            for (int f = 0; f < 18; ++f) { t += 1.0 / 60.0; pet.setClockForSnapshot (t); pet.timerTick(); }
            auto img = pet.createComponentSnapshot (pet.getLocalBounds(), true, 1.0f);
            juce::Graphics g (strip);
            g.drawImageAt (img, (k % 4) * 280, (k / 4) * 250);
            ++k;
            t += 3.0;
            for (int f = 0; f < 200; ++f) { t += 1.0 / 60.0; pet.setClockForSnapshot (t); pet.timerTick(); }
        }
        auto f = dir.getChildFile ("pet_states.png");
        f.deleteFile();
        if (auto os = f.createOutputStream()) png.writeImageToStream (strip, *os);
        std::printf ("最后的姿势：%s\n", PetView::poseName (pet.getPose()));
        return 0;
    }
    if (argc > 2 && juce::String (argv[1]) == "--looper-ui")
    {
        MainComponent mc;
        mc.setSize (1240, 800);
        mc.setView (MainComponent::View::practice);
        auto* lpn = mc.getPracticePanel().getLooperPanel();
        if (lpn != nullptr && ! lpn->isVisible()) { lpn->setVisible (true); mc.getPracticePanel().resized(); }
        for (int i = 0; i < 200; ++i) if (! juce::detail::dispatchNextMessageOnSystemQueue (true)) break;
        auto img = mc.createComponentSnapshot (mc.getLocalBounds(), true, 1.0f);
        juce::PNGImageFormat png;
        auto f = juce::File { juce::String (argv[2]) }.getChildFile ("looper_main.png");
        f.deleteFile();
        if (auto os = f.createOutputStream()) png.writeImageToStream (img, *os);
        return 0;
    }
    if (argc > 2 && juce::String (argv[1]) == "--gervana-ui")
    {
        // 效果器板上的 Gervana 卡片（看配色和图片预留位）
        AudioEngine engine;
        engine.prepareForOffline (sr, block);
        EffectChain chain (engine);
        auto xml = juce::parseXML (T (DefaultPresets::listGervana[10][1]));
        juce::StringArray problems;
        chain.loadFromXml (*xml, problems);
        chain.insert (chain.createBuiltin ("gv_wuyin"), 1);
        chain.insert (chain.createBuiltin ("gv_yimao"));
        chain.insert (chain.createBuiltin ("gv_yiyou"), 2);
        chain.setBypassed (3, true);
        PedalBoard board (chain, nullptr);
        board.setSize (1900, 200);
        for (int i = 0; i < 200; ++i) if (! juce::detail::dispatchNextMessageOnSystemQueue (true)) break;
        auto img = board.createComponentSnapshot (board.getLocalBounds(), true, 1.5f);
        juce::PNGImageFormat png;
        auto f = juce::File (juce::String (argv[2])).getChildFile ("gervana_board.png");
        f.deleteFile();
        if (auto os = f.createOutputStream()) png.writeImageToStream (img, *os);
        return 0;
    }
    if (argc > 2 && juce::String (argv[1]) == "--snapshots")
        return renderPedalSnapshots (juce::File (argv[2]));
    const juce::File modelDir (argc > 1 ? argv[1] : ".");
    const juce::File outDir (argc > 2 ? argv[2] : ".");
    outDir.createDirectory();

    const auto guitar = makeGuitar (3.0);
    std::vector<float> l, r;

    // ---------------------------------------------------------------------
    std::printf ("\n== 1. 每个内置效果器单独测试（3 秒，48 kHz，128 采样块）\n");
    for (auto& info : getBuiltinEffectList())
    {
        AudioEngine engine;
        engine.prepareForOffline (sr, block);
        engine.setOutputGainDb (0.0f);
        EffectChain chain (engine);
        chain.insert (chain.createBuiltin (info.id));
        run (engine, guitar, l, r);
        const auto st = stats (l, r, (size_t) (0.05 * sr));
        check (st.finite && st.peak > 0.01f && st.peak < 4.0f,
               info.id + " (" + info.name + ")  峰值 " + db (st.peak) + "  RMS " + db (st.rms));
        chain.clear();
        engine.processOffline (guitar.data(), l.data(), r.data(), block * 4);
        chain.collectGarbage();
    }

    // ---------------------------------------------------------------------
    std::printf ("\n== 2. 默认音色预设整条链路\n");
    const auto presetDir = outDir.getChildFile ("presets");
    presetDir.createDirectory();
    for (auto& p : DefaultPresets::list)
        presetDir.getChildFile (T (p[0]) + ".xml").replaceWithText (T (p[1]));
    for (auto& f : presetDir.findChildFiles (juce::File::findFiles, false, "*.xml"))
    {
        AudioEngine engine;
        engine.prepareForOffline (sr, block);
        engine.setOutputGainDb (0.0f);
        EffectChain chain (engine);
        juce::StringArray problems;
        chain.loadFromXml (*juce::parseXML (f), problems);
        run (engine, guitar, l, r);
        const auto st = stats (l, r, (size_t) (0.05 * sr));
        check (problems.isEmpty() && st.finite && st.peak > 0.05f && st.peak < 1.5f,
               f.getFileNameWithoutExtension() + "  " + juce::String ((int) chain.getSlots().size()) + T (" 块  峰值 ")
                   + db (st.peak) + "  RMS " + db (st.rms));
        writeWav (outDir.getChildFile ("preset_" + f.getFileNameWithoutExtension() + ".wav"), l, r);
    }

    // ---------------------------------------------------------------------
    std::printf ("\n== 3. 换链路 / 开关时不爆音\n");
    {
        // 持续正弦，中途换链路和旁通，看相邻样本的最大跳变
        std::vector<float> sine ((size_t) (2.0 * sr));
        for (size_t i = 0; i < sine.size(); ++i)
            sine[i] = 0.3f * (float) std::sin (juce::MathConstants<double>::twoPi * 220.0 * (double) i / sr);

        AudioEngine engine;
        engine.prepareForOffline (sr, block);
        engine.setOutputGainDb (0.0f);
        EffectChain chain (engine);
        chain.insert (chain.createBuiltin ("boost"));

        std::vector<float> outL (sine.size()), outR (sine.size());
        const int quarter = (int) sine.size() / 4;
        engine.processOffline (sine.data(), outL.data(), outR.data(), quarter);
        chain.insert (chain.createBuiltin ("eq"));                // 换链路
        engine.processOffline (sine.data() + quarter, outL.data() + quarter, outR.data() + quarter, quarter);
        chain.setBypassed (0, true);                              // 旁通
        engine.processOffline (sine.data() + 2 * quarter, outL.data() + 2 * quarter, outR.data() + 2 * quarter, quarter);
        chain.remove (0);                                         // 删除
        engine.processOffline (sine.data() + 3 * quarter, outL.data() + 3 * quarter, outR.data() + 3 * quarter, quarter);
        chain.collectGarbage();

        float maxStep = 0.0f;
        for (size_t i = 1; i < outL.size(); ++i)
            maxStep = juce::jmax (maxStep, std::abs (outL[i] - outL[i - 1]));
        // 0.3 振幅 220 Hz 正弦本身的最大斜率约 0.0086；+6 dB 后约 0.017
        check (maxStep < 0.04f, T ("最大相邻样本跳变 ") + juce::String (maxStep, 4) + T ("（无爆音阈值 0.04）"));
    }

    // ---------------------------------------------------------------------
    std::printf ("\n== 4. NAM 箱头模型\n");
    for (auto& f : modelDir.findChildFiles (juce::File::findFiles, false, "*.nam"))
    {
        AudioEngine engine;
        engine.prepareForOffline (sr, block);
        engine.setOutputGainDb (0.0f);
        EffectChain chain (engine);
        juce::String error;
        auto slot = chain.createNam (f, error);
        if (slot == nullptr)
        {
            std::printf ("  [skip] %s: %s\n", f.getFileName().toRawUTF8(), error.toRawUTF8());
            continue;
        }
        chain.insert (slot);
        const double t0 = juce::Time::getMillisecondCounterHiRes();
        run (engine, guitar, l, r);
        const double ms = juce::Time::getMillisecondCounterHiRes() - t0;
        const auto st = stats (l, r, (size_t) (0.05 * sr));
        auto* nam = dynamic_cast<NamProcessor*> (&slot->getProcessor());
        check (st.finite && st.peak > 1.0e-4f,
               f.getFileName() + "  峰值 " + db (st.peak) + T ("  耗时 ") + juce::String (ms / 30.0, 2)
                   + T ("% 实时  模型采样率 ") + juce::String (nam->getExpectedSampleRate(), 0));
    }

    // ---------------------------------------------------------------------
    std::printf ("\n== 5. 箱体 IR\n");
    {
        // 合成一个 IR：低通的衰减噪声
        const auto irFile = outDir.getChildFile ("test_ir.wav");
        std::vector<float> ir ((size_t) (0.05 * sr));
        juce::Random rnd (1);
        float lp = 0.0f;
        for (size_t i = 0; i < ir.size(); ++i)
        {
            lp += 0.2f * ((rnd.nextFloat() * 2.0f - 1.0f) - lp);
            ir[i] = lp * std::exp (-(float) i / (float) (0.008 * sr));
        }
        ir[0] = 1.0f;
        writeWav (irFile, ir, ir);

        AudioEngine engine;
        engine.prepareForOffline (sr, block);
        engine.setOutputGainDb (0.0f);
        EffectChain chain (engine);
        juce::String error;
        auto slot = chain.createIr (irFile, error);
        check (slot != nullptr, T ("加载 IR ") + error);
        if (slot != nullptr)
        {
            chain.insert (slot);
            juce::Thread::sleep (500);   // 卷积在后台线程加载
            run (engine, guitar, l, r);
            const auto st = stats (l, r, (size_t) (0.05 * sr));
            check (st.finite && st.peak > 0.01f && st.peak < 4.0f, T ("IR 卷积  峰值 ") + db (st.peak));
        }
    }

    // ---------------------------------------------------------------------
    std::printf ("\n== 6. 鼓机\n");
    {
        // 6a. 节拍器在 120 BPM 下的节拍间隔必须精确
        AudioEngine engine;
        engine.prepareForOffline (sr, block);
        engine.setMonitoring (false);
        auto& drums = engine.getDrums();
        const auto& styles = getDrumStyles();
        int clickOnly = 0;
        for (int i = 0; i < (int) styles.size(); ++i)
            if (styles[(size_t) i].clickOnly) clickOnly = i;

        drums.setStyle (clickOnly);
        drums.setBpm (120.0f);
        drums.setCountIn (false);
        drums.setVolumeDb (0.0f);
        drums.setPlaying (true);

        std::vector<float> silence ((size_t) (4.0 * sr), 0.0f);
        run (engine, silence, l, r);

        std::vector<int> onsets;
        for (size_t i = 1; i < l.size(); ++i)
            if (std::abs (l[i]) > 0.02f && (onsets.empty() || (int) i - onsets.back() > (int) (0.1 * sr)))
                onsets.push_back ((int) i);

        int worst = 0;
        for (size_t i = 1; i < onsets.size(); ++i)
            worst = juce::jmax (worst, std::abs (onsets[i] - onsets[i - 1] - 24000));
        check (onsets.size() >= 7 && worst <= 2,
               T ("120 BPM 节拍器：") + juce::String ((int) onsets.size()) + T (" 拍，间隔误差最大 ") + juce::String (worst) + T (" 个采样"));

        // 6b. 每种风格渲染 8 小节
        for (int i = 0; i < (int) styles.size(); ++i)
        {
            AudioEngine e2;
            e2.prepareForOffline (sr, block);
            e2.setMonitoring (false);
            auto& d = e2.getDrums();
            d.setStyle (i);
            d.setBpm (styles[(size_t) i].defaultBpm);
            d.setSwing (styles[(size_t) i].defaultSwing);
            d.setFillEvery (4);
            d.setCountIn (true);
            d.setVolumeDb (-6.0f);
            d.setPlaying (true);
            const double secs = 60.0 / styles[(size_t) i].defaultBpm * styles[(size_t) i].beatsPerBar * 9.0;
            std::vector<float> sil ((size_t) (secs * sr), 0.0f);
            run (e2, sil, l, r);
            const auto st = stats (l, r);
            check (st.finite && st.peak > 0.05f && st.peak < 1.0f,
                   styles[(size_t) i].name + T ("  峰值 ") + db (st.peak) + "  RMS " + db (st.rms));
            writeWav (outDir.getChildFile ("drums_" + juce::String (i) + ".wav"), l, r);
        }
    }

    // ---------------------------------------------------------------------
    std::printf ("\n== 7. 吉他 + 鼓 + 默认音色 混在一起\n");
    {
        AudioEngine engine;
        engine.prepareForOffline (sr, block);
        engine.setOutputGainDb (-6.0f);
        EffectChain chain (engine);
        if (auto xml = juce::parseXML (presetDir.getChildFile (T ("过载.xml"))))
        {
            juce::StringArray p;
            chain.loadFromXml (*xml, p);
        }
        auto& d = engine.getDrums();
        d.setStyle (0); d.setBpm (110); d.setCountIn (false); d.setVolumeDb (-8.0f); d.setPlaying (true);
        const auto g = makeGuitar (6.0);
        run (engine, g, l, r);
        const auto st = stats (l, r);
        check (st.finite && st.peak < 1.0f, T ("混合输出 峰值 ") + db (st.peak) + "  RMS " + db (st.rms));
        writeWav (outDir.getChildFile ("mix.wav"), l, r);
    }

    // ---------------------------------------------------------------------
    std::printf ("\n== 8. 周边效果器：音高、降噪、去嗡声\n");
    {
        auto sineAt = [] (double f, double secs, float amp)
        {
            std::vector<float> v ((size_t) (secs * sr));
            for (size_t i = 0; i < v.size(); ++i)
                v[i] = amp * (float) std::sin (juce::MathConstants<double>::twoPi * f * (double) i / sr);
            return v;
        };

        // 跑一块效果器，返回输出（左声道）
        auto runFx = [] (const juce::String& id, std::initializer_list<std::pair<const char*, float>> params,
                         const std::vector<float>& in)
        {
            AudioEngine engine;
            engine.prepareForOffline (sr, block);
            engine.setOutputGainDb (0.0f);
            EffectChain chain (engine);
            auto slot = chain.createBuiltin (id);
            if (auto* fx = dynamic_cast<BuiltinEffect*> (&slot->getProcessor()))
                for (auto& p : params)
                    fx->setParam (p.first, p.second);
            chain.insert (slot);
            std::vector<float> outL (in.size()), outR (in.size());
            engine.processOffline (in.data(), outL.data(), outR.data(), (int) in.size());
            return outL;
        };

        auto pitchOf = [] (const std::vector<float>& v)
        {
            PitchDetector pd;
            const int len = 4096;
            return pd.detect (v.data() + v.size() - (size_t) len, len, sr, 40.0f, 2000.0f).frequency;
        };

        const auto a3 = sineAt (220.0, 1.5, 0.3f);
        struct Case { const char* name; juce::String id; std::initializer_list<std::pair<const char*, float>> p; float expect; };
        const Case cases[] = {
            { "八度 复音 低八度", "octave", { { "mode", 0 }, { "dry", 0 }, { "down", 1 }, { "up", 0 } }, 110.0f },
            { "八度 复音 高八度", "octave", { { "mode", 0 }, { "dry", 0 }, { "down", 0 }, { "up", 1 } }, 440.0f },
            { "八度 单音模拟 低八度", "octave", { { "mode", 1 }, { "dry", 0 }, { "down", 1 }, { "up", 0 } }, 110.0f },
            { "移调 +7 半音", "pitch", { { "semis", 7 }, { "mix", 1 } }, 329.6f },
            { "移调 -5 半音", "pitch", { { "semis", -5 }, { "mix", 1 } }, 164.8f },
        };
        for (auto& c : cases)
        {
            const float f = pitchOf (runFx (c.id, c.p, a3));
            const float cents = f > 0 ? 1200.0f * std::log2 (f / c.expect) : 9999.0f;
            check (std::abs (cents) < 15.0f, T (c.name) + T ("：输入 220 Hz，输出 ") + juce::String (f, 1)
                                                 + T (" Hz（期望 ") + juce::String (c.expect, 1) + "）");
        }

        // 降噪：-70 dBFS 的底噪应该被压低约 40 dB；正常弹奏音量不受影响
        std::vector<float> noise ((size_t) (1.0 * sr));
        juce::Random rnd (7);
        for (auto& x : noise) x = 0.000316f * (rnd.nextFloat() * 2.0f - 1.0f) * 1.7f;
        const auto nOut = runFx ("denoise", { { "threshold", -58 }, { "amount", 40 } }, noise);
        auto rms = [] (const std::vector<float>& v, size_t from)
        {
            double s2 = 0; for (size_t i = from; i < v.size(); ++i) s2 += (double) v[i] * v[i];
            return (float) std::sqrt (s2 / (double) (v.size() - from));
        };
        const float reduction = juce::Decibels::gainToDecibels (rms (nOut, (size_t) (0.5 * sr)) / rms (noise, (size_t) (0.5 * sr)));
        check (reduction < -35.0f, T ("降噪：底噪被压低 ") + juce::String (reduction, 1) + " dB");

        const auto loud = sineAt (220.0, 1.0, 0.1f);
        const auto lOut = runFx ("denoise", { { "threshold", -58 }, { "amount", 40 } }, loud);
        const float pass = juce::Decibels::gainToDecibels (rms (lOut, (size_t) (0.5 * sr)) / rms (loud, (size_t) (0.5 * sr)));
        check (std::abs (pass) < 0.5f, T ("降噪：正常音量的信号变化 ") + juce::String (pass, 2) + " dB");

        const auto hum = sineAt (50.0, 1.5, 0.05f);
        const auto hOut = runFx ("denoise", { { "threshold", -85 }, { "amount", 0 }, { "hum", 1 } }, hum);
        const float humCut = juce::Decibels::gainToDecibels (rms (hOut, (size_t) (1.0 * sr)) / rms (hum, (size_t) (1.0 * sr)));
        check (humCut < -20.0f, T ("去嗡声：50 Hz 被压低 ") + juce::String (humCut, 1) + " dB");
    }

    // ---------------------------------------------------------------------
    std::printf ("\n== 9. 谱子播放\n");
    {
        // 9a. 拨弦合成器音准
        for (int midi : { 40, 45, 57, 64, 76 })
        {
            PluckSynth ps;
            ps.prepare (sr);
            PluckSynth::NoteOn on;
            on.midi = midi; on.lengthSeconds = 1.0;
            on.bass = midi < 43;
            ps.noteOn (on);
            std::vector<float> bl ((size_t) (0.6 * sr), 0.0f), br (bl.size(), 0.0f);
            ps.render (bl.data(), br.data(), (int) bl.size());
            PitchDetector pd;
            const auto res = pd.detect (bl.data() + (size_t) (0.2 * sr), 4096, sr, 40.0f, 2000.0f);
            const double expect = 440.0 * std::pow (2.0, (midi - 69) / 12.0);
            const double cents = res.frequency > 0 ? 1200.0 * std::log2 (res.frequency / expect) : 9999.0;
            check (std::abs (cents) < 10.0, T ("拨弦音 MIDI ") + juce::String (midi) + T ("：") + juce::String (res.frequency, 1)
                                                + " Hz（" + juce::String (cents, 1) + T (" 音分）"));
        }

        // 9b. 走带：读一首测试谱，播放 3 秒，位置要和速度对得上
        const auto file = juce::File (argc > 3 ? argv[3] : "");
        juce::String error;
        auto loaded = file.existsAsFile() ? loadSongFile (file, error) : nullptr;
        if (loaded == nullptr)
            std::printf ("  [skip] 没有给测试谱（第三个参数）\n");
        else
        {
            std::shared_ptr<const Song> song (std::move (loaded));
            AudioEngine engine;
            engine.prepareForOffline (sr, block);
            engine.setMonitoring (false);
            auto& tp = engine.getTabPlayer();
            tp.setSong (song);
            tp.setTrack (song->defaultTrack());
            tp.setCountIn (false);
            tp.setDemoVolumeDb (0.0f);
            tp.setSpeed (0.75f);
            tp.setPlaying (true);

            std::vector<float> sil ((size_t) (3.0 * sr), 0.0f);
            run (engine, sil, l, r);
            const double expectBeats = song->secondsToBeat (3.0 * 0.75);
            const double got = tp.getPosition();
            const auto st = stats (l, r);
            check (std::abs (got - juce::jmin (expectBeats, song->lengthBeats)) < 0.02,
                   T ("75% 速度播放 3 秒：位置 ") + juce::String (got, 3) + T (" 拍（期望 ") + juce::String (expectBeats, 3) + "）");
            check (st.finite && st.peak > 0.01f && st.peak < 1.5f, T ("示范音有声音，峰值 ") + db (st.peak));

            // 9c. A-B 循环
            tp.seek (0.0);
            tp.setSpeed (1.0f);
            tp.setLoop (0.0, 2.0, true);
            run (engine, sil, l, r);
            check (tp.getPosition() >= 0.0 && tp.getPosition() <= 2.0 + 1.0e-6,
                   T ("A-B 循环 0~2 拍，3 秒后位置 ") + juce::String (tp.getPosition(), 3));
            writeWav (outDir.getChildFile ("tab_demo.wav"), l, r);
        }
    }

    // ---------------------------------------------------------------------
    std::printf ("\n== 10. 在线找谱：下载文件夹监视\n");
    {
        auto dir = juce::File::createTempFile ("dl");
        dir.createDirectory();
        dir.getChildFile ("old.gp5").replaceWithText ("old");
        DownloadWatcher w;
        w.start (dir);
        check (w.isActive() && ! w.poll().exists(), juce::String::fromUTF8 ("开始监视时已有的谱子不算新下载"));
        dir.getChildFile ("readme.txt").replaceWithText ("x");
        dir.getChildFile ("new.gp.crdownload").replaceWithText ("partial");
        check (! w.poll().exists() && ! w.poll().exists(), juce::String::fromUTF8 ("非谱子文件、未下载完的临时文件被忽略"));
        dir.getChildFile ("new.gp").replaceWithText ("0123456789");
        const auto first = w.poll();
        const auto second = w.poll();
        check (! first.exists() && second.getFileName() == "new.gp", juce::String::fromUTF8 ("新谱子大小稳定后被发现：") + second.getFileName());
        check (! w.poll().exists(), juce::String::fromUTF8 ("同一个文件只报告一次"));
        dir.deleteRecursively();

        // 谱库：按分类（第一层文件夹）、搜索
        {
            const auto lib = juce::File::getSpecialLocation (juce::File::tempDirectory).getChildFile ("lianqin_lib_test");
            lib.deleteRecursively();
            for (auto p : { "港台流行/周杰伦 - 晴天.gp5", "港台流行/五月天 - 倔强.gpx", "欧美摇滚/Queen - Bohemian.gp",
                            "欧美摇滚/AC-DC/Back in Black.gp4", "自己的.gp", "欧美摇滚/readme.txt" })
            {
                auto f = lib.getChildFile (juce::String::fromUTF8 (p));
                f.getParentDirectory().createDirectory();
                f.replaceWithText ("x");
            }
            juce::Array<juce::File> roots { lib };
            TabLibraryBox lb (roots, {});
            check (lb.getNumEntries() == 5, juce::String::fromUTF8 ("谱库扫描到 5 个谱子（不含 txt）：") + juce::String (lb.getNumEntries()));
            lb.setFilter (juce::String::fromUTF8 ("周杰伦"));
            check (lb.getNumMatches() == 1, juce::String::fromUTF8 ("按歌手搜索"));
            lb.setFilter ("ac-dc");
            check (lb.getNumMatches() == 1, juce::String::fromUTF8 ("按子文件夹名搜索（不分大小写）"));
            lb.setFilter (juce::String::fromUTF8 ("欧美 back"));
            check (lb.getNumMatches() == 1, juce::String::fromUTF8 ("多个词同时匹配"));
            lb.setFilter ({});
            lb.setSize (560, 470);
            auto img = lb.createComponentSnapshot (lb.getLocalBounds(), true, 1.0f);
            juce::PNGImageFormat png;
            auto f = outDir.getChildFile ("tablibrary.png");
            f.deleteFile();
            if (auto os = f.createOutputStream()) png.writeImageToStream (img, *os);
            lib.deleteRecursively();
        }

        TabSearchBox box ("Canon Rock", juce::File ("C:/Users/me/Downloads"));
        juce::String opened;
        box.onSearch = [&opened] (const juce::String& u) { opened = u; };
        auto img = box.createComponentSnapshot (box.getLocalBounds(), true, 1.0f);
        juce::PNGImageFormat png;
        auto f = outDir.getChildFile ("tabsearch.png");
        f.deleteFile();
        if (auto os = f.createOutputStream()) png.writeImageToStream (img, *os);
        for (auto& site : TabSearchBox::getSites())
            check (site.urlTemplate.startsWith ("https://") && site.urlTemplate.contains ("{q}"), juce::String::fromUTF8 ("搜索网址：") + site.name);
    }

    // ---------------------------------------------------------------------
    std::printf ("\n== 11. 弹奏判定（合成演奏：正确 / 弹错 / 漏弹 / 时间偏差）\n");
    for (float latency : { 0.0f, 25.0f })
    {
        using namespace judgetest;
        auto song = makeExerciseSong();
        auto js = std::make_shared<JudgeSession> (song, 0);
        std::vector<Plan> plan (js->events.size());
        juce::Random rnd (42);
        for (size_t e = 0; e < plan.size(); ++e)
        {
            plan[e].kind = (e % 10 == 3) ? 1 : (e % 10 == 7 ? 2 : 0);
            if (js->events[e].kind == JudgeEvent::legato) plan[e].kind = (e % 10 == 7) ? 2 : 0;   // 击弦只测对 / 漏
            plan[e].offsetMs = js->events[e].kind == JudgeEvent::legato ? 0.0f : (rnd.nextFloat() - 0.5f) * 60.0f;
        }
        const auto audio = perform (*song, *js, plan, latency);

        AudioEngine engine;
        setupEngine (engine, song, js, latency);
        runEngine (engine, audio);

        int okRight = 0, nRight = 0, okWrong = 0, nWrong = 0, okSkip = 0, nSkip = 0, okLegato = 0, nLegato = 0;
        double errSum = 0.0, errSq = 0.0; int errN = 0;
        for (size_t e = 0; e < plan.size(); ++e)
        {
            const auto v = js->verdictOf ((int) e);
            const bool hit = v == Verdict::perfect || v == Verdict::good;
            const auto& ev = js->events[e];
            if (ev.kind == JudgeEvent::legato && plan[e].kind == 0) { ++nLegato; okLegato += hit; continue; }
            switch (plan[e].kind)
            {
                case 0:
                    ++nRight; okRight += hit;
                    if (hit) { const double d = js->offsetOf ((int) e) - plan[e].offsetMs; errSum += d; errSq += d * d; ++errN; }
                    else std::printf ("     漏判：第 %d 个（拍 %.2f，%d 个音，判成 %d）\n", (int) e, ev.beat, ev.numPitches, (int) v);
                    break;
                case 1: ++nWrong; okWrong += (v == Verdict::wrongNote); if (v != Verdict::wrongNote) std::printf ("     错音没抓到：第 %d 个（判成 %d）\n", (int) e, (int) v); break;
                default: ++nSkip; okSkip += (v == Verdict::miss); break;
            }
        }
        const double bias = errN > 0 ? errSum / errN : 0.0;
        const double sd = errN > 1 ? std::sqrt (juce::jmax (0.0, errSq / errN - bias * bias)) : 0.0;
        const auto label = juce::String::fromUTF8 ("延迟 ") + juce::String (latency, 0) + " ms";
        check (okRight >= nRight * 95 / 100, label + juce::String::fromUTF8 ("：正确的音判中 ") + juce::String (okRight) + "/" + juce::String (nRight));
        check (okWrong >= nWrong * 8 / 10, label + juce::String::fromUTF8 ("：弹错的音判为错音 ") + juce::String (okWrong) + "/" + juce::String (nWrong));
        check (okSkip == nSkip, label + juce::String::fromUTF8 ("：漏弹判为 Miss ") + juce::String (okSkip) + "/" + juce::String (nSkip));
        check (okLegato >= nLegato * 8 / 10, label + juce::String::fromUTF8 ("：击弦（不拨弦）判中 ") + juce::String (okLegato) + "/" + juce::String (nLegato));
        check (std::abs (bias) <= 10.0 && sd <= 10.0,
               label + juce::String::fromUTF8 ("：时间误差 平均 ") + juce::String (bias, 1) + " ms，" + juce::String::fromUTF8 ("标准差 ") + juce::String (sd, 1) + " ms");
        const auto st = js->computeStats();
        std::printf ("     统计：Perfect %d  Good %d  错音 %d  Miss %d  命中率 %.0f%%  最大连击 %d  多余起音 %d\n",
                     st.perfect, st.good, st.wrong, st.miss, st.accuracy() * 100.0f, js->bestCombo.load(), js->extraOnsets.load());
    }

    std::printf ("\n== 11b. 推弦 / 点弦 / 晚一点的击弦\n");
    {
        using namespace judgetest;
        // 4 小节 90 BPM：二分音符推全音 ×4，推½音 ×2，拨 + 击弦（击弦晚 45 ms）×4，点弦 ×2
        RawScore raw;
        raw.initialTempo = 90.0;
        RawTrack t;
        t.tuning = { 64, 59, 55, 50, 45, 40 };
        auto beat = [] (double d, std::vector<RawNote> ns) { RawBeat b; b.duration = d; b.notes = std::move (ns); return b; };
        auto bendNote = [] (int s, int f, float semis) { RawNote n; n.string = s; n.fret = f; n.bend = semis; n.bendEnd = semis; n.bendPeakPos = 0.3f; return n; };
        std::vector<std::vector<RawBeat>> bars;
        bars.push_back ({ beat (2.0, { bendNote (1, 8, 2.0f) }), beat (2.0, { bendNote (2, 7, 2.0f) }) });
        bars.push_back ({ beat (2.0, { bendNote (1, 10, 2.0f) }), beat (2.0, { bendNote (2, 9, 1.0f) }) });
        // RawNote 的 hammerPull 跟 GP 一样标在起点音上
        bars.push_back ({ beat (0.5, { note (2, 5, true) }), beat (0.5, { note (2, 7) }), beat (0.5, { note (1, 5, true) }), beat (0.5, { note (1, 8) }),
                          beat (0.5, { note (2, 5, true) }), beat (0.5, { note (2, 7) }), beat (1.0, { note (0, 5) }) });
        RawNote tap; tap.string = 0; tap.fret = 12; tap.tapped = true;
        bars.push_back ({ beat (1.0, { note (0, 5) }), beat (1.0, { tap }), beat (1.0, { note (0, 7) }), beat (1.0, { tap }) });
        for (auto& b : bars)
        {
            raw.masterBars.push_back ({});
            RawBar bar; bar.voices.push_back ({ b }); t.bars.push_back (bar);
        }
        raw.tracks.push_back (t);
        auto song = std::shared_ptr<const Song> (buildSong (raw).release());
        auto js = std::make_shared<JudgeSession> (song, 0);
        const auto& notes = song->tracks[0].notes;

        int bendEvents = 0;
        for (auto& ev : js->events) bendEvents += ev.bendPeakBeats >= 0.0 ? 1 : 0;
        check (bendEvents == 4, juce::String::fromUTF8 ("推弦音参与判定（") + juce::String (bendEvents) + "/4）");
        int tapLegato = 0;
        for (size_t k = 0; k < notes.size(); ++k)
            if (notes[k].tapped && js->events[(size_t) js->noteToEvent[k]].kind == JudgeEvent::legato) ++tapLegato;
        check (tapLegato == 2, juce::String::fromUTF8 ("点弦按不拨弦处理"));

        // 合成演奏：第 4 个推弦只推到½音（应该提示“差”）；击弦晚 45 ms
        const double total = song->lengthSeconds() + 1.0;
        std::vector<float> audio ((size_t) (total * sr), 0.0f);
        PluckSynth synth;
        synth.prepare (sr);
        struct Hit { int64_t at; PluckSynth::NoteOn on; };
        std::vector<Hit> hits;
        int bendIdx = 0;
        for (auto& n : notes)
        {
            PluckSynth::NoteOn on;
            on.midi = n.midi;
            on.hammer = n.hammerPull || n.tapped;
            on.velocity = on.hammer ? 0.5f : 0.85f;
            on.lengthSeconds = song->beatToSeconds (n.start + n.length) - song->beatToSeconds (n.start);
            if (n.bend > 0.0f)
            {
                on.bendSemitones = (bendIdx++ == 1) ? 1.0f : 2.0f;   // 第 2 个只推½音（谱上要全音）
                on.bendPeakPos = 0.3f;
            }
            const double late = n.hammerPull ? 0.045 : 0.0;
            hits.push_back ({ (int64_t) ((song->beatToSeconds (n.start) + late) * sr), on });
        }
        std::vector<float> l (block), r (block);
        size_t h = 0;
        for (int64_t pos = 0; pos < (int64_t) audio.size(); pos += block)
        {
            const int n = (int) juce::jmin ((int64_t) block, (int64_t) audio.size() - pos);
            while (h < hits.size() && hits[h].at < pos + n)
            {
                auto on = hits[h].on;
                on.delaySamples = (int) juce::jmax ((int64_t) 0, hits[h].at - pos);
                synth.noteOn (on);
                ++h;
            }
            std::fill (l.begin(), l.end(), 0.0f); std::fill (r.begin(), r.end(), 0.0f);
            synth.render (l.data(), r.data(), n);
            for (int i = 0; i < n; ++i) audio[(size_t) (pos + i)] = 0.5f * (l[(size_t) i] + r[(size_t) i]);
        }
        AudioEngine engine;
        setupEngine (engine, song, js, 0.0f);
        runEngine (engine, audio);

        int bendHit = 0, legatoHit = 0, legatoN = 0;
        std::vector<float> reached;
        for (size_t e = 0; e < js->events.size(); ++e)
        {
            const auto v = js->verdictOf ((int) e);
            const bool hit = v == Verdict::perfect || v == Verdict::good;
            if (js->events[e].bendPeakBeats >= 0.0) { bendHit += hit; reached.push_back (js->bendReachedOf ((int) e)); }
            if (js->events[e].kind == JudgeEvent::legato) { ++legatoN; legatoHit += hit; }
        }
        check (bendHit == 4, juce::String::fromUTF8 ("推弦的音判中 ") + juce::String (bendHit) + "/4");
        juce::String rs;
        for (auto x : reached) rs << juce::String (x, 2) << " ";
        check (reached.size() == 4 && std::abs (reached[0] - 2.0f) < 0.35f && std::abs (reached[1] - 1.0f) < 0.35f
                   && std::abs (reached[2] - 2.0f) < 0.35f && std::abs (reached[3] - 2.0f) < 0.35f,
               juce::String::fromUTF8 ("推弦最高点测出推了几个半音：") + rs + juce::String::fromUTF8 ("（应为 2 1 2 2）"));
        check (legatoN == 5, juce::String::fromUTF8 ("击弦 3 个 + 点弦 2 个按不拨弦判（") + juce::String (legatoN) + "）");
        check (legatoHit >= legatoN - 1, juce::String::fromUTF8 ("晚 45 ms 的击弦 / 点弦判中 ") + juce::String (legatoHit) + "/" + juce::String (legatoN));
    }

    std::printf ("\n== 12. 等待模式\n");
    {
        using namespace judgetest;
        auto song = makeExerciseSong();
        auto js = std::make_shared<JudgeSession> (song, 0);
        AudioEngine engine;
        setupEngine (engine, song, js, 0.0f);
        auto& judge = engine.getJudge();
        judge.setWaitMode (true);
        judge.processPending();
        auto& tp = engine.getTabPlayer();

        PluckSynth synth;
        synth.prepare (sr);
        const auto& notes = song->tracks[0].notes;
        std::vector<float> in (block), l (block), r (block), sl (block), sr2 (block);
        int played = 0, wrongOnce = 0, wrongFlashes = 0;
        uint32_t lastSeq = 0;
        double stuckSince = -1.0, maxBeatWhileStuck = 0.0;
        bool overran = false;
        const int maxBlocks = (int) (120.0 * sr / block);
        int blocksRun = 0;
        for (; blocksRun < maxBlocks && tp.getPosition() < song->lengthBeats - 1.0e-6; ++blocksRun)
        {
            const double now = blocksRun * (double) block / sr;
            // 找当前卡住的事件：第一个还没判过的
            int gate = -1;
            for (size_t e = 0; e < js->events.size(); ++e)
                if (js->verdictOf ((int) e) == Verdict::pending) { gate = (int) e; break; }
            if (gate >= 0)
            {
                const auto& ev = js->events[(size_t) gate];
                if (tp.getPosition() > ev.beat + 1.0e-6) overran = true;
                if (tp.getPosition() >= ev.beat - 1.0e-6)
                {
                    if (stuckSince < 0.0) stuckSince = now;
                    if (now - stuckSince > 0.3 && played == gate)
                    {
                        // 第 3 个事件先弹错一次，0.3 秒后再弹对
                        const bool wrong = gate == 2 && wrongOnce == 0;
                        if (wrong) wrongOnce = 1;
                        for (int k = ev.firstNote; k < ev.firstNote + ev.numNotes; ++k)
                        {
                            PluckSynth::NoteOn on;
                            on.midi = notes[(size_t) k].midi + (wrong ? 2 : 0);
                            on.hammer = notes[(size_t) k].hammerPull;
                            on.velocity = on.hammer ? 0.6f : 0.85f;
                            on.lengthSeconds = 1.0;
                            synth.noteOn (on);
                        }
                        if (wrong) stuckSince = now; else { ++played; stuckSince = -1.0; }
                    }
                }
                maxBeatWhileStuck = juce::jmax (maxBeatWhileStuck, tp.getPosition());
            }
            std::fill (sl.begin(), sl.end(), 0.0f); std::fill (sr2.begin(), sr2.end(), 0.0f);
            synth.render (sl.data(), sr2.data(), block);
            for (int i = 0; i < block; ++i) in[(size_t) i] = 0.5f * (sl[(size_t) i] + sr2[(size_t) i]);
            engine.processOffline (in.data(), l.data(), r.data(), block);
            judge.processPending();
            if (js->lastSeq.load() != lastSeq)
            {
                lastSeq = js->lastSeq.load();
                if (js->lastVerdict.load() == (uint8_t) Verdict::wrongNote) ++wrongFlashes;
            }
        }
        const auto st = js->computeStats();
        check (! overran, juce::String::fromUTF8 ("没弹对之前谱子不会往前走"));
        check (st.perfect == (int) js->events.size(),
               juce::String::fromUTF8 ("全部音符最终判中 ") + juce::String (st.perfect) + "/" + juce::String ((int) js->events.size()));
        check (wrongFlashes >= 1 && st.wrong == 0, juce::String::fromUTF8 ("弹错时提示“错音”，但可以重弹（提示 ") + juce::String (wrongFlashes) + juce::String::fromUTF8 (" 次）"));
        check (tp.getPosition() >= song->lengthBeats - 1.0e-6,
               juce::String::fromUTF8 ("弹完整首（用时 ") + juce::String (blocksRun * (double) block / sr, 1) + juce::String::fromUTF8 (" 秒）"));
    }

    std::printf ("\n== 13. 判定：A-B 循环每遍重新计分\n");
    {
        using namespace judgetest;
        auto song = makeExerciseSong();
        auto js = std::make_shared<JudgeSession> (song, 0);
        std::vector<Plan> plan (js->events.size());
        const auto audio = perform (*song, *js, plan, 0.0);      // 全对
        AudioEngine engine;
        setupEngine (engine, song, js, 0.0f);
        engine.getTabPlayer().setLoop (0.0, 8.0, true);         // 第 1–2 小节
        // 循环 3 遍需要的音频：前 8 拍的演奏重复 3 遍
        const size_t loopLen = (size_t) (song->beatToSeconds (8.0) * sr);
        std::vector<float> in;
        for (int k = 0; k < 3; ++k) in.insert (in.end(), audio.begin(), audio.begin() + (long) loopLen);
        runEngine (engine, in);
        check (js->passes.load() >= 2 && js->lastPassAccuracy.load() > 0.95f,
               juce::String::fromUTF8 ("循环了 ") + juce::String (js->passes.load()) + juce::String::fromUTF8 (" 遍，上一遍命中率 ")
                   + juce::String (js->lastPassAccuracy.load() * 100.0f, 0) + "%");
    }

    std::printf ("\n== 13b. 循环：上一遍弹错，这一遍弹对，标记要跟着刷新\n");
    for (float latency : { 0.0f, 30.0f })
    {
        using namespace judgetest;
        auto song = makeExerciseSong();
        auto js = std::make_shared<JudgeSession> (song, 0);
        std::vector<Plan> wrong (js->events.size()), right (js->events.size());
        for (auto& p : wrong) p.kind = 1;
        const auto bad = perform (*song, *js, wrong, latency);
        const auto good = perform (*song, *js, right, latency);
        AudioEngine engine;
        setupEngine (engine, song, js, latency);
        engine.getTabPlayer().setLoop (0.0, 8.0, true);
        const size_t loopLen = (size_t) (song->beatToSeconds (8.0) * sr);
        std::vector<float> in (bad.begin(), bad.begin() + (long) loopLen);          // 第 1 遍全错
        for (int k = 0; k < 2; ++k)                                                  // 第 2、3 遍全对
            in.insert (in.end(), good.begin(), good.begin() + (long) loopLen);
        runEngine (engine, in);
        int wrongNow = 0, judgedNow = 0;
        for (size_t e = 0; e < js->events.size(); ++e)
            if (js->events[e].beat < 8.0 && js->verdictOf ((int) e) != Verdict::pending)
            {
                ++judgedNow;
                wrongNow += js->verdictOf ((int) e) != Verdict::perfect && js->verdictOf ((int) e) != Verdict::good;
            }
        const auto label = juce::String::fromUTF8 ("延迟 ") + juce::String (juce::roundToInt (latency)) + " ms";
        check (js->passes.load() == 2 && js->lastPassAccuracy.load() >= 0.85f,
               label + juce::String::fromUTF8 ("：第 2 遍（弹对）命中率 ") + juce::String (juce::roundToInt (js->lastPassAccuracy.load() * 100.0f)) + "%");
        check (judgedNow >= 6 && wrongNow <= 1,
               label + juce::String::fromUTF8 ("：第 3 遍谱面上的错误标记 ") + juce::String (wrongNow) + "/" + juce::String (judgedNow));
    }

    if (argc > 3)
    {
        std::printf ("\n== 14. 判定：真实谱子（整首，每 10 个音弹错 1 个）\n");
        using namespace judgetest;
        juce::String err;
        auto loaded = loadSongFile (juce::File (argv[3]), err);
        if (loaded != nullptr)
        {
            std::shared_ptr<const Song> song (loaded.release());
            const int t = song->defaultTrack();
            // 只取这一轨，组成新歌
            auto single = std::make_shared<Song> (*song);
            single->tracks = { song->tracks[(size_t) t] };
            std::shared_ptr<const Song> s1 = single;
            auto js = std::make_shared<JudgeSession> (s1, 0);
            std::vector<Plan> plan (js->events.size());
            for (size_t e = 0; e < plan.size(); ++e)
                if (e % 10 == 5 && js->events[e].kind == JudgeEvent::picked)
                    plan[e].kind = 1;       // 每 10 个弹错 1 个（高半音）
            const double limitBeat = s1->lengthBeats + 1.0;
            auto audio = perform (*s1, *js, plan, 0.0);
            AudioEngine engine;
            setupEngine (engine, s1, js, 0.0f);
            runEngine (engine, audio);
            const auto st = js->computeStats (0.0, limitBeat - 1.0);
            if (std::getenv ("JUDGE_DEBUG") != nullptr)
                for (size_t e = 0; e < js->events.size(); ++e)
                    if (js->verdictOf ((int) e) == Verdict::wrongNote)
                    {
                        const auto& ev = js->events[e];
                        const double gap = e + 1 < js->events.size() ? (s1->beatToSeconds (js->events[e + 1].beat) - s1->beatToSeconds (ev.beat)) * 1000.0 : 999.0;
                        const double prevGap = e > 0 ? (s1->beatToSeconds (ev.beat) - s1->beatToSeconds (js->events[e - 1].beat)) * 1000.0 : 999.0;
                        std::printf ("     wrong e=%d kind=%d n=%d midi=%d,%d,%d prevGap=%.0f gap=%.0f\n", (int) e, (int) ev.kind, ev.numPitches,
                                     ev.midi[0], ev.numPitches > 1 ? ev.midi[1] : 0, ev.numPitches > 2 ? ev.midi[2] : 0, prevGap, gap);
                    }
            int legato = 0, legatoHit = 0;
            for (size_t e = 0; e < js->events.size(); ++e)
                if (js->events[e].beat < limitBeat - 1.0 && js->events[e].kind == JudgeEvent::legato)
                {
                    ++legato;
                    const auto v = js->verdictOf ((int) e);
                    legatoHit += (v == Verdict::perfect || v == Verdict::good);
                }
            int nWrong = 0, caught = 0, rightN = 0, rightHit = 0;
            for (size_t e = 0; e < plan.size(); ++e)
            {
                const auto v = js->verdictOf ((int) e);
                if (plan[e].kind == 1) { ++nWrong; caught += v == Verdict::wrongNote; }
                else { ++rightN; rightHit += (v == Verdict::perfect || v == Verdict::good); }
            }
            check (rightHit >= rightN * 95 / 100, juce::String::fromUTF8 ("弹对的音判中 ") + juce::String (rightHit) + "/" + juce::String (rightN));
            check (caught >= nWrong * 85 / 100, juce::String::fromUTF8 ("弹错（高半音）的抓到 ") + juce::String (caught) + "/" + juce::String (nWrong));
            check (st.accuracy() >= 0.80f, juce::String::fromUTF8 ("总命中率 ") + juce::String (st.accuracy() * 100.0f, 0) + "%  (Perfect "
                   + juce::String (st.perfect) + " Good " + juce::String (st.good) + juce::String::fromUTF8 (" 错音 ") + juce::String (st.wrong)
                   + " Miss " + juce::String (st.miss) + juce::String::fromUTF8 ("，其中击勾弦 ") + juce::String (legatoHit) + "/" + juce::String (legato) + ")");
        }
    }

    std::printf ("\n== 16. 箱头 / 过载 / 失真的各个型号（同一段吉他，看音量和是否正常）\n");
    {
        struct Case { const char* id; const char* param; int count; const char* extra; };
        const Case cases[] = { { "amp", "voicing", 11, "gain=5" }, { "overdrive", "model", 6, "drive=18" }, { "distortion", "model", 3, "gain=34" } };
        for (auto& c : cases)
        {
            float minDb = 100.0f, maxDb = -100.0f;
            for (int m = 0; m < c.count; ++m)
            {
                AudioEngine engine;
                engine.prepareForOffline (sr, block);
                engine.setOutputGainDb (0.0f);
                EffectChain chain (engine);
                auto slot = chain.createBuiltin (c.id);
                auto* fx = dynamic_cast<BuiltinEffect*> (&slot->getProcessor());
                fx->setParam (c.param, (float) m);
                chain.insert (slot);
                run (engine, guitar, l, r);
                const auto st = stats (l, r, (size_t) (0.05 * sr));
                const float d = juce::Decibels::gainToDecibels (st.rms, -120.0f);
                minDb = juce::jmin (minDb, d); maxDb = juce::jmax (maxDb, d);
                check (st.finite && st.peak > 0.005f && st.peak < 4.0f,
                       juce::String (c.id) + " " + fx->getName() + "  RMS " + juce::String (d, 1) + " dB  " + juce::String::fromUTF8 ("峰值 ") + db (st.peak));
                chain.clear();
                engine.processOffline (guitar.data(), l.data(), r.data(), block * 4);
                chain.collectGarbage();
            }
            check (maxDb - minDb < 14.0f, juce::String (c.id) + juce::String::fromUTF8 (" 各型号音量差 ") + juce::String (maxDb - minDb, 1) + " dB");
        }
    }

    std::printf ("\n== 17. 经典音色预设（第 2 版新增）\n");
    {
        const bool haveLibrary = EffectChain::getToneLibrary().getChildFile ("NAM").isDirectory();
        for (auto& p : DefaultPresets::listV2)
        {
            const auto name = juce::String::fromUTF8 (p[0]);
            auto xml = juce::parseXML (juce::String::fromUTF8 (p[1]));
            if (xml == nullptr) { check (false, name + " XML"); continue; }
            if (name.startsWith (juce::String::fromUTF8 ("真实采样")) && ! haveLibrary) continue;
            AudioEngine engine;
            engine.prepareForOffline (sr, block);
            engine.setOutputGainDb (0.0f);
            EffectChain chain (engine);
            juce::StringArray problems;
            chain.loadFromXml (*xml, problems);
            for (int k = 0; k < 6; ++k) { engine.processOffline (guitar.data(), l.data(), r.data(), block); chain.collectGarbage(); }
            run (engine, guitar, l, r);
            const auto st = stats (l, r, (size_t) (0.05 * sr));
            const float d = juce::Decibels::gainToDecibels (st.rms, -120.0f);
            check (problems.isEmpty() && st.finite && d > -36.0f && d < -6.0f && st.peak < 1.0f,
                   name + "  RMS " + juce::String (d, 1) + " dB  " + juce::String::fromUTF8 ("峰值 ") + db (st.peak)
                       + (problems.isEmpty() ? juce::String() : "  " + problems.joinIntoString ("; ")));
            chain.clear();
            engine.processOffline (guitar.data(), l.data(), r.data(), block * 4);
            chain.collectGarbage();
        }
        if (! haveLibrary) std::printf ("     （测试程序旁边没有音色库，跳过“真实采样”预设）\n");
    }

    std::printf ("\n== 17b. 先锋 / 后摇 / 迷幻 / 后朋克 / 怪异 / 贝斯预设（第 3 版新增）\n");
    {
        juce::StringArray names;
        auto checkList = [&] (auto& list)
        {
        for (auto& p : list)
        {
            const auto name = juce::String::fromUTF8 (p[0]);
            check (! names.contains (name) && ! name.containsAnyOf ("/\\:*?\"<>|"), name + juce::String::fromUTF8 (" 文件名可用"));
            names.add (name);
            auto xml = juce::parseXML (juce::String::fromUTF8 (p[1]));
            if (xml == nullptr) { check (false, name + " XML"); continue; }

            // 每个参数名都要是这个效果器真有的（写错了会被悄悄忽略）
            juce::StringArray bad;
            for (auto* slot : xml->getChildWithTagNameIterator ("Slot"))
            {
                auto fx = createBuiltinEffect (slot->getStringAttribute ("id"));
                if (fx == nullptr) { bad.add ("?" + slot->getStringAttribute ("id")); continue; }
                juce::StringArray ids;
                for (auto* prm : fx->getParameters())
                    if (auto* r = dynamic_cast<juce::RangedAudioParameter*> (prm)) ids.add (r->getParameterID());
                if (auto* ps = slot->getChildByName ("Params"))
                    for (int a = 0; a < ps->getNumAttributes(); ++a)
                        if (! ids.contains (ps->getAttributeName (a)))
                            bad.add (slot->getStringAttribute ("id") + "." + ps->getAttributeName (a));
            }

            AudioEngine engine;
            engine.prepareForOffline (sr, block);
            engine.setOutputGainDb (0.0f);
            EffectChain chain (engine);
            juce::StringArray problems;
            chain.loadFromXml (*xml, problems);
            for (int k = 0; k < 6; ++k) { engine.processOffline (guitar.data(), l.data(), r.data(), block); chain.collectGarbage(); }
            run (engine, guitar, l, r);
            const auto st = stats (l, r, (size_t) (0.05 * sr));
            const float d = juce::Decibels::gainToDecibels (st.rms, -120.0f);
            check (problems.isEmpty() && bad.isEmpty() && st.finite && d > -36.0f && d < -6.0f && st.peak < 1.0f,
                   name + "  RMS " + juce::String (d, 1) + " dB  " + juce::String::fromUTF8 ("峰值 ") + db (st.peak)
                       + (bad.isEmpty() ? juce::String() : juce::String::fromUTF8 ("  参数名不对：") + bad.joinIntoString (", "))
                       + (problems.isEmpty() ? juce::String() : "  " + problems.joinIntoString ("; ")));
            chain.clear();
            engine.processOffline (guitar.data(), l.data(), r.data(), block * 4);
            chain.collectGarbage();
        }
        };
        checkList (DefaultPresets::listV3);
        std::printf ("  -- Gervana 预设\n");
        checkList (DefaultPresets::listGervana);
        checkList (DefaultPresets::listGervana2);

        // 吉他变贝斯：弹 A 弦空弦（110 Hz），出来的基音应该在 55 Hz
        for (int idx : { 18, 19 })
        {
            const auto name = juce::String::fromUTF8 (DefaultPresets::listV3[idx][0]);
            auto xml = juce::parseXML (juce::String::fromUTF8 (DefaultPresets::listV3[idx][1]));
            AudioEngine engine;
            engine.prepareForOffline (sr, block);
            engine.setOutputGainDb (0.0f);
            EffectChain chain (engine);
            juce::StringArray problems;
            chain.loadFromXml (*xml, problems);
            const int n = (int) (1.5 * sr);
            std::vector<float> in ((size_t) n), ol ((size_t) n), orr ((size_t) n);
            for (int i = 0; i < n; ++i)
            {
                const double t = i / sr;
                float v = 0.0f;
                for (int h = 1; h <= 8; ++h) v += (float) (std::sin (2.0 * juce::MathConstants<double>::pi * 110.0 * h * t) / h);
                in[(size_t) i] = 0.12f * v * (float) std::exp (-t * 1.2);
            }
            for (int k = 0; k < 6; ++k) { std::vector<float> z ((size_t) block), a ((size_t) block), b ((size_t) block); engine.processOffline (z.data(), a.data(), b.data(), block); chain.collectGarbage(); }
            for (int pos = 0; pos + block <= n; pos += block)
                engine.processOffline (in.data() + pos, ol.data() + pos, orr.data() + pos, block);
            // 0.4–1.2 秒这段：55 Hz（低八度基音）要是 30–250 Hz 里最强的，且比 110 Hz 强
            const int s0 = (int) (0.4 * sr), s1 = (int) (1.2 * sr);
            auto energyAt = [&] (double f)
            {
                double re = 0.0, im = 0.0;
                for (int i = s0; i < s1; ++i)
                {
                    const double ph = 2.0 * juce::MathConstants<double>::pi * f * i / sr;
                    re += ol[(size_t) i] * std::cos (ph); im += ol[(size_t) i] * std::sin (ph);
                }
                return re * re + im * im;
            };
            double bestF = 0.0, bestE = 0.0;
            for (double f = 30.0; f <= 250.0; f += 1.0)
                if (const double e = energyAt (f); e > bestE) { bestE = e; bestF = f; }
            const double rel = 10.0 * std::log10 (energyAt (55.0) / juce::jmax (1e-12, energyAt (110.0)));
            check (std::abs (bestF - 55.0) < 3.0, name + juce::String::fromUTF8 ("：弹 110 Hz，最强在 ") + juce::String (bestF, 0)
                       + juce::String::fromUTF8 (" Hz，55 Hz 比 110 Hz ") + juce::String (rel, 1) + " dB");
        }
    }

    std::printf ("\n== 17c. Gervana 效果器：每个拨档组合都要正常出声、音量别差太多\n");
    {
        for (auto& info : getBuiltinEffectList())
        {
            if (! Gervana::isGervana (info.id)) continue;
            auto probe = createBuiltinEffect (info.id);
            std::vector<juce::AudioParameterChoice*> chs;
            std::vector<juce::AudioParameterBool*> bools;
            for (auto* prm : probe->getParameters())
            {
                if (auto* c = dynamic_cast<juce::AudioParameterChoice*> (prm)) chs.push_back (c);
                else if (auto* bp = dynamic_cast<juce::AudioParameterBool*> (prm)) bools.push_back (bp);
            }
            // 所有拨档（选择 + 开关）的组合
            int combos = 1;
            for (auto* c : chs) combos *= c->choices.size();
            combos <<= (int) bools.size();
            float minDb = 100.0f, maxDb = -100.0f;
            bool allOk = true;
            juce::String worst;
            for (int k = 0; k < combos; ++k)
            {
                AudioEngine engine;
                engine.prepareForOffline (sr, block);
                engine.setOutputGainDb (0.0f);
                EffectChain chain (engine);
                auto slot = chain.createBuiltin (info.id);
                auto* fx = dynamic_cast<BuiltinEffect*> (&slot->getProcessor());
                int rest = k;
                juce::String desc;
                for (auto* c : chs)
                {
                    const int v = rest % c->choices.size(); rest /= c->choices.size();
                    fx->setParam (c->getParameterID(), (float) v);
                    desc << c->choices[v] << "/";
                }
                for (auto* bp : bools)
                {
                    const int v = rest % 2; rest /= 2;
                    fx->setParam (bp->getParameterID(), (float) v);
                    desc << bp->getName (16) << (v ? "+" : "-") << "/";
                }
                chain.insert (slot);
                run (engine, guitar, l, r);
                const auto st = stats (l, r, (size_t) (0.05 * sr));
                const float d = juce::Decibels::gainToDecibels (st.rms, -120.0f);
                if (! (st.finite && st.peak < 1.5f && d > -40.0f)) { allOk = false; worst = desc + " RMS " + juce::String (d, 1); }
                if (d < minDb) minDb = d;
                if (d > maxDb) maxDb = d;
                chain.clear();
                engine.processOffline (guitar.data(), l.data(), r.data(), block * 4);
                chain.collectGarbage();
            }
            check (allOk && maxDb - minDb < 16.0f,
                   info.name + "  " + juce::String (combos) + juce::String::fromUTF8 (" 种组合，RMS ")
                       + juce::String (minDb, 1) + " ~ " + juce::String (maxDb, 1) + " dB" + (allOk ? juce::String() : "  " + worst));
        }

        // 预设分类：内置预设都要落在固定分类里，Gervana 排第一
        juce::StringArray stray;
        auto cat = [&] (auto& list) { for (auto& p : list) if (PresetBar::categoryOf (T (p[0])) == T ("我的预设")) stray.add (T (p[0])); };
        cat (DefaultPresets::list); cat (DefaultPresets::listV2); cat (DefaultPresets::listV3); cat (DefaultPresets::listGervana); cat (DefaultPresets::listGervana2);
        check (stray.isEmpty() && PresetBar::categoryOrder()[0] == "Gervana"
                   && PresetBar::categoryOf (T ("我自己的音色")) == T ("我的预设"),
               juce::String::fromUTF8 ("预设分类（Gervana 在最前）") + (stray.isEmpty() ? juce::String() : "  " + stray.joinIntoString (", ")));
    }

    std::printf ("\n== 17k. Gervana 辛亥：延迟回声的位置、两个模块分别开关、余音\n");
    {
        // 一个脉冲进去，看 2 秒输出
        auto impulse = [&] (std::function<void (BuiltinEffect&)> set, std::vector<float>& out)
        {
            auto fx = createBuiltinEffect ("gv_xinhai");
            set (*fx);
            fx->setPlayConfigDetails (2, 2, sr, block);
            fx->prepareToPlay (sr, block);
            juce::MidiBuffer midi;
            const int total = (int) (2.0 * sr);
            out.assign ((size_t) total, 0.0f);
            for (int pos = 0; pos < total; pos += block)
            {
                const int n = juce::jmin (block, total - pos);
                juce::AudioBuffer<float> b (2, n);
                b.clear();
                if (pos == 0) { b.setSample (0, 0, 1.0f); b.setSample (1, 0, 1.0f); }
                fx->processBlock (b, midi);
                for (int i = 0; i < n; ++i) out[(size_t) (pos + i)] = b.getSample (0, i);
            }
        };
        auto energy = [&] (const std::vector<float>& v, double a, double b2)
        {
            double e = 0.0;
            for (int i = (int) (a * sr); i < (int) (b2 * sr) && i < (int) v.size(); ++i) e += v[(size_t) i] * v[(size_t) i];
            return e;
        };
        std::vector<float> dOnly, rOnly, both, none;
        impulse ([] (BuiltinEffect& f) { f.setParam ("reverbOn", 0.0f); f.setParam ("time", 300.0f); f.setParam ("feedback", 0.4f);
                                         f.setParam ("level", 0.6f); f.setParam ("depth", 0.0f); }, dOnly);
        // 回声：最大值应该在 300 ms 附近
        int peak = (int) (0.05 * sr);
        for (int i = (int) (0.05 * sr); i < (int) (0.5 * sr); ++i) if (std::abs (dOnly[(size_t) i]) > std::abs (dOnly[(size_t) peak])) peak = i;
        const double echoMs = peak * 1000.0 / sr;
        const double second = energy (dOnly, 0.58, 0.64), gap = energy (dOnly, 0.35, 0.55);
        check (std::abs (echoMs - 300.0) < 6.0 && second > gap * 20.0,
               juce::String::fromUTF8 ("延迟：第一次回声 ") + juce::String (echoMs, 1) + juce::String::fromUTF8 (" ms（300），反馈有第二次回声"));
        impulse ([] (BuiltinEffect& f) { f.setParam ("delayOn", 0.0f); f.setParam ("decay", 7.0f); f.setParam ("mix", 0.5f); }, rOnly);
        const double tail = energy (rOnly, 0.1, 1.0);
        check (tail > 1.0e-3, juce::String::fromUTF8 ("只开混响：有混响尾巴  ") + juce::String (tail, 4));
        impulse ([] (BuiltinEffect& f) { f.setParam ("delayOn", 0.0f); f.setParam ("reverbOn", 0.0f); }, none);
        check (energy (none, 0.02, 2.0) < 1.0e-8 && std::abs (none[0] - 1.0f) < 1.0e-3,
               juce::String::fromUTF8 ("两个模块都关：只剩干声"));
        impulse ([] (BuiltinEffect& f) { f.setParam ("decay", 10.0f); f.setParam ("mix", 1.0f); f.setParam ("feedback", 0.92f);
                                         f.setParam ("level", 1.0f); f.setParam ("depth", 1.0f); f.setParam ("rate", 6.0f); }, both);
        float mx = 0.0f; bool fin = true;
        for (auto v : both) { mx = juce::jmax (mx, std::abs (v)); fin = fin && std::isfinite (v); }
        check (fin && mx < 2.0f, juce::String::fromUTF8 ("全部开满：不爆、不发散  峰值 ") + juce::String (mx, 2));
    }

    std::printf ("\n== 17d. 指板音阶：每个根音 × 每种音阶 × 每个把位\n");
    {
        using namespace ScaleTheory;
        int checked = 0;
        juce::StringArray bad;
        for (int fam = 0; fam < 4; ++fam)
            for (int minor = 0; minor < 2; ++minor)
                for (int mt = 0; mt < 3; ++mt)
                    for (int mode = 0; mode < 7; ++mode)
                    {
                        if (fam == 3 && (minor || mt)) continue;           // 教会调式不分大小调
                        if (fam != 3 && mode) continue;
                        if (fam != 2 && mt) continue;
                        if (fam == 2 && ! minor && mt) continue;
                        for (int root = 0; root < 12; ++root)
                        {
                            Selection s; s.root = root; s.family = (Family) fam; s.minor = minor; s.minorType = (MinorType) mt; s.mode = (Mode) mode;
                            const auto sc = build (s);
                            const int n = numPositions (sc);
                            std::set<int> covered;
                            for (int k = 0; k < n; ++k)
                            {
                                const auto pos = position (root, sc, k);
                                ++checked;
                                bool ok = pos.size() >= 10;
                                int perString[6] {};
                                for (size_t i = 0; i < pos.size(); ++i)
                                {
                                    const auto& p = pos[i];
                                    ok = ok && p.fret >= 0 && p.fret <= maxFret && inScale (p.midi, root, sc) && openMidi[p.string] + p.fret == p.midi;
                                    if (i > 0) ok = ok && p.midi > pos[i - 1].midi;
                                    ++perString[p.string];
                                    covered.insert (((p.midi - root) % 12 + 12) % 12);
                                }
                                const auto span = fretSpan (pos);
                                ok = ok && span.getLength() <= 6;                 // 一只手按得到
                                for (int st = 0; st < 6; ++st) ok = ok && perString[st] >= 1 && perString[st] <= 4;
                                if (! ok) bad.add (sc.name + T (" 把位 ") + juce::String (k + 1));
                            }
                            if ((int) covered.size() != (int) sc.intervals.size()) bad.add (sc.name + T (" 有音没出现在任何把位里"));
                        }
                    }
        check (bad.isEmpty(), juce::String (checked) + T (" 个把位：每个都在音阶里、从低到高、一只手按得到（跨度 ≤ 6 品）")
                                  + (bad.isEmpty() ? juce::String() : "  " + bad.joinIntoString (", ").substring (0, 300)));

        // 几个有标准答案的
        Selection am; am.root = 9; am.family = Family::pentatonic; am.minor = true;
        auto box1 = position (9, build (am), 0);
        juce::String s1; for (auto& p : box1) s1 << p.fret << ",";
        check (s1 == "5,8,5,7,5,7,5,7,5,8,5,8,", T ("A 小调五声第 1 把位 = 5/8 5/7 5/7 5/7 5/8 5/8：") + s1);
        am.family = Family::blues;
        auto b1 = position (9, build (am), 0);
        bool a6 = false, g8 = false;
        for (auto& p : b1) { a6 |= p.string == 1 && p.fret == 6; g8 |= p.string == 3 && p.fret == 8; }
        check (a6 && g8 && numPositions (build (am)) == 5 && spell (63, 9, build (am), false) == "Eb",
               T ("A 小调布鲁斯：5 个把位，第 1 把位的蓝调音在 A 弦 6 品、G 弦 8 品，写作 Eb"));
        Selection fl; fl.root = 5; fl.family = Family::modes; fl.mode = Mode::lydian;
        auto fsc = build (fl);
        juce::String d; for (int iv : fsc.intervals) d << degreeName (iv, fsc) << " ";
        check (d == "1 2 3 #4 5 6 7 " && relativeHint (fl).contains ("C"), T ("F 利底亚：") + d + relativeHint (fl));
        Selection hm; hm.root = 9; hm.family = Family::sevenNote; hm.minor = true; hm.minorType = MinorType::harmonic;
        juce::String n2; for (int iv : build (hm).intervals) n2 << noteName (9 + iv, preferFlats (hm)) << " ";
        check (n2 == "A B C D E F G# ", T ("A 和声小调：") + n2);
        Selection dm; dm.root = 2; dm.family = Family::sevenNote; dm.minor = true;
        juce::String n3; for (int iv : build (dm).intervals) n3 << noteName (2 + iv, preferFlats (dm)) << " ";
        check (n3 == "D E F G A Bb C ", T ("D 自然小调用降号：") + n3);

        // 高音弦识别：中等音量（峰值 0.08）拨 1、2 弦，0.6 秒里认对的帧要够多
        for (int str : { 4, 5 })
        {
            int ok = 0, total = 0;
            for (int fret : { 0, 3, 5, 7, 10, 12 })
            {
                const int midi = openMidi[str] + fret;
                PluckSynth syn; syn.prepare (sr);
                PluckSynth::NoteOn on; on.midi = midi; on.velocity = 0.9f; on.lengthSeconds = 1.5;
                syn.noteOn (on);
                const int n = (int) (0.8 * sr);
                std::vector<float> l ((size_t) n), r ((size_t) n);
                syn.render (l.data(), r.data(), n);
                float pk = 0; for (float v : l) pk = juce::jmax (pk, std::abs (v));
                for (auto& v : l) v = v / pk * 0.08f;
                PitchDetector pd;
                for (double t = 0.05; t < 0.64; t += 1.0 / 30.0)
                {
                    const auto res = pd.detectGuitar (l.data() + (int) (t * sr) - 2048, 2048, sr);
                    const int m = res.frequency > 0.0f && res.clarity > 0.8f && res.rmsDb > -66.0f
                                      ? juce::roundToInt (69.0 + 12.0 * std::log2 (res.frequency / 440.0)) : -1;
                    ++total; if (m == midi) ++ok;
                }
            }
            check (ok * 100 >= total * 80, juce::String (6 - str) + T (" 弦中等音量：认对 ") + juce::String (100 * ok / total) + "% 的帧（≥ 80%）");
        }

        // 配鼓：每种音阶都有推荐，推荐的鼓点套到鼓机上，风格 / 速度 / 加花都对
        {
            juce::StringArray badRec;
            const auto& gs = ScalesPanel::grooves();
            for (int fam = 0; fam < 4; ++fam)
                for (int minor = 0; minor < 2; ++minor)
                    for (int mt = 0; mt < 3; ++mt)
                        for (int mode = 0; mode < 7; ++mode)
                        {
                            Selection sx; sx.family = (Family) fam; sx.minor = minor; sx.minorType = (MinorType) mt; sx.mode = (Mode) mode;
                            const int rec = ScalesPanel::recommendedGroove (sx);
                            if (! juce::isPositiveAndBelow (rec, (int) gs.size())) badRec.add (build (sx).name);
                        }
            for (auto& gr : gs)
                if (! juce::isPositiveAndBelow (gr.style, (int) getDrumStyles().size()) || getDrumStyles()[(size_t) gr.style].clickOnly)
                    badRec.add (T (gr.name));
            Selection dor; dor.family = Family::modes; dor.mode = Mode::dorian;
            Selection mb; mb.family = Family::blues; mb.minor = true;
            const bool sensible = getDrumStyles()[(size_t) gs[(size_t) ScalesPanel::recommendedGroove (mb)].style].name.contains ("Shuffle")
                               && getDrumStyles()[(size_t) gs[(size_t) ScalesPanel::recommendedGroove (dor)].style].name == T ("放克");

            DrumMachine dm;
            juce::PropertiesFile::Options o; o.applicationName = "LianqinTests";
            juce::PropertiesFile props (juce::File::getSpecialLocation (juce::File::tempDirectory).getChildFile ("groove_test.settings"), o);
            DrumPanel dp (dm, props);
            const auto& g3 = gs[3];
            dp.applyGroove (g3.style, g3.bpm, g3.swing, g3.fillEvery, g3.chorus);
            const bool applied = dm.getStyle() == g3.style && std::abs (dm.getBpm() - g3.bpm) < 0.5f && dm.getFillEvery() == g3.fillEvery;
            check (badRec.isEmpty() && sensible && applied,
                   juce::String ((int) gs.size()) + T (" 套配鼓；每种音阶都有推荐（小调布鲁斯→Shuffle，多利亚→放克）；套到鼓机上风格 / 速度 / 加花正确")
                       + (badRec.isEmpty() ? juce::String() : "  " + badRec.joinIntoString (", ")));
        }

        // 试听音：引擎里推一个音，要能听到 110 Hz（A2）
        AudioEngine engine;
        engine.prepareForOffline (sr, block);
        std::vector<float> z ((size_t) block), ol ((size_t) block), orr ((size_t) block), all;
        engine.previewNote (45, 0.9f, 1.0);
        for (int b = 0; b < (int) (0.6 * sr) / block; ++b)
        {
            engine.processOffline (z.data(), ol.data(), orr.data(), block);
            all.insert (all.end(), ol.begin(), ol.end());
        }
        float peak = 0.0f; for (float v : all) peak = juce::jmax (peak, std::abs (v));
        PitchDetector pd;
        const auto res = pd.detect (all.data() + (int) (0.15 * sr), 4096, sr);
        check (peak > 0.05f && std::abs (res.frequency - 110.0f) < 2.0f,
               T ("指板试听音：峰值 ") + db (peak) + T ("，音高 ") + juce::String (res.frequency, 1) + " Hz");
    }

    std::printf ("\n== 17e. 指板认音训练\n");
    {
        NoteQuiz q (7);
        NoteQuiz::Range r; r.fretLo = 0; r.fretHi = 12; r.stringMask = 0x03;   // 6、5 弦，0–12 品
        q.setRange (r);
        check (q.spotsOf (7).size() == 2 && q.spotsOf (4).size() == 3,
               juce::String::fromUTF8 ("6、5 弦 0–12 品：G 有 2 个位置（6 弦 3 品、5 弦 10 品），E 有 3 个（6 弦 0、12 品，5 弦 7 品）"));
        // 看位置说音名
        q.setType (NoteQuiz::Type::nameTheSpot);
        bool allInRange = true;
        int prevKey = -1, repeats = 0;
        for (int i = 0; i < 200; ++i)
        {
            q.next (i * 1000.0);
            const auto sp = q.askedSpot();
            allInRange = allInRange && q.inRange (sp.string, sp.fret);
            repeats += (sp.string * 100 + sp.fret == prevKey);
            prevKey = sp.string * 100 + sp.fret;
            const int pc = sp.midi() % 12;
            q.answerName (i % 4 == 0 ? (pc + 1) % 12 : pc, i * 1000.0 + 1500.0);
        }
        const auto& st = q.getStats();
        check (allInRange && repeats == 0, juce::String::fromUTF8 ("出的题都在范围里，不连着出同一个位置"));
        check (st.asked == 200 && st.correct == 150 && st.wrong == 50 && std::abs (st.avgSeconds() - 1.5) < 0.01,
               juce::String::fromUTF8 ("统计：200 题对 150、平均 1.5 秒（") + juce::String (st.correct) + ", " + juce::String (st.avgSeconds(), 2) + ")");
        check (q.weakestNotes (false).isNotEmpty(), juce::String::fromUTF8 ("记下最容易错的音：") + q.weakestNotes (false));
        // 看音名找位置：弹出来
        q.resetStats();
        q.setType (NoteQuiz::Type::findTheNote);
        NoteQuiz::Range all; all.fretLo = 0; all.fretHi = 12; all.stringMask = 0x3f;
        q.setRange (all);
        q.next (0.0);
        const int pc = q.askedPitchClass();
        const auto targets = q.targets();
        check (targets.size() >= 4, juce::String::fromUTF8 ("全指板 0–12 品，一个音至少有 4 个位置（") + juce::String ((int) targets.size()) + ")");
        NoteQuiz::Outcome last = NoteQuiz::Outcome::none;
        for (auto& t : targets) last = q.answerPlayed (t.midi(), 2000.0);
        // 同一个音高在两根弦上（比如 5 弦 5 品 = 6 弦 10 品）：每弹一次标一个
        check (last == NoteQuiz::Outcome::correct && q.getStats().correct == 1, juce::String::fromUTF8 ("把每个位置弹一遍：全部找到，判对"));
        q.next (3000.0);
        q.answerPlayed (ScaleTheory::openMidi[0] + ((q.askedPitchClass() + 1 - 4 + 24) % 12), 3100.0);   // 先弹错一个
        for (auto& t : q.targets()) q.answerSpot (t.string, t.fret, 4000.0);
        check (q.getStats().correct == 1 && q.getStats().wrong == 1, juce::String::fromUTF8 ("中间弹错过：找全了也算错一题"));
        // 只练自然音
        NoteQuiz::Range nat = all; nat.naturalsOnly = true;
        q.setRange (nat);
        bool onlyNat = true;
        for (int i = 0; i < 100; ++i) { q.next (i); const int p2 = q.askedPitchClass(); onlyNat = onlyNat && (p2 == 0 || p2 == 2 || p2 == 4 || p2 == 5 || p2 == 7 || p2 == 9 || p2 == 11); }
        check (onlyNat, juce::String::fromUTF8 ("只练自然音时不出升降音"));
        juce::ignoreUnused (pc);
    }

    std::printf ("\n== 17f. 吉他和弦库：每个根音 × 每种和弦的每个指法都要对\n");
    {
        int total = 0, bad = 0, missing = 0;
        for (int root = 0; root < 12; ++root)
            for (int q = 0; q < Chords::numQualities; ++q)
            {
                const auto vs = Chords::voicings (root, (Chords::Quality) q);
                if (vs.empty()) { ++missing; std::printf ("     没有指法：%s\n", Chords::name (root, (Chords::Quality) q).toRawUTF8()); }
                for (auto& v : vs)
                {
                    ++total;
                    const bool span = v.highestFret() - v.lowestFret() <= 4;
                    if (! Chords::matches (v, root, (Chords::Quality) q) || ! span)
                    {
                        ++bad;
                        juce::String fr;
                        for (int f : v.frets) fr << (f < 0 ? juce::String ("x") : juce::String (f));
                        std::printf ("     不对：%s %s [%s]\n", Chords::name (root, (Chords::Quality) q).toRawUTF8(), v.shape.toRawUTF8(), fr.toRawUTF8());
                    }
                }
            }
        check (bad == 0 && missing == 0, juce::String::fromUTF8 ("和弦指法 ") + juce::String (total) + juce::String::fromUTF8 (" 个全部正确（音对、跨度不超过 5 品）"));
        const auto c = Chords::voicings (0, Chords::Quality::major);
        check (! c.empty() && c.front().shape == juce::String::fromUTF8 ("开放和弦") && c.front().frets == std::array<int, 6> { -1, 3, 2, 0, 1, 0 },
               juce::String::fromUTF8 ("C 大三的第一个指法是开放和弦 x32010"));
        const auto d = Chords::diatonic (7, false, false);
        juce::String ds;
        for (auto& x : d) ds << x.roman << ":" << Chords::name (x.root, x.quality) << " ";
        check (ds.trim() == juce::String::fromUTF8 ("I:G ii:Am iii:Bm IV:C V:D vi:Em vii°:F#dim"), juce::String::fromUTF8 ("G 大调顺阶和弦：") + ds);
        const auto am = Chords::diatonic (9, true, true);
        juce::String as;
        for (auto& x : am) as << Chords::name (x.root, x.quality) << " ";
        check (as.trim() == "Am7 Bm7b5 Cmaj7 Dm7 Em7 Fmaj7 G7", juce::String::fromUTF8 ("A 小调顺阶七和弦：") + as);

        // 听和弦：合成一个 C（x32010），第 2 弦（B 弦，1 品 C）故意没响
        {
            const auto v = Chords::voicings (0, Chords::Quality::major).front();
            PluckSynth synth;
            synth.prepare (sr);
            for (int s = 0; s < 6; ++s)
            {
                if (v.frets[(size_t) s] < 0 || s == 4) continue;
                PluckSynth::NoteOn on;
                on.midi = Chords::standardTuning[(size_t) s] + v.frets[(size_t) s];
                on.velocity = 0.7f;
                on.lengthSeconds = 2.0;
                on.delaySamples = s * 400;
                synth.noteOn (on);
            }
            std::vector<float> l ((size_t) sr), r ((size_t) sr), mono ((size_t) sr);
            synth.render (l.data(), r.data(), (int) sr);
            for (size_t i = 0; i < mono.size(); ++i) mono[i] = 0.5f * (l[i] + r[i]);
            juce::dsp::FFT fft (14);
            std::vector<float> work;
            const auto st = ChordPanel::analyse (mono.data() + 4000, 8192, sr, v, fft, work);
            juce::String ss;
            for (auto x : st) ss << (int) x;
            // B 弦的 C4 正好是 5 弦 C3 的 2 次泛音：分不出来，只能说“说不准”（3），不能判成响了（1）
            check (st[0] == 0 && st[1] == 1 && st[2] == 1 && st[3] == 1 && st[4] != 1,
                   juce::String::fromUTF8 ("扫 C 和弦、B 弦没响：B 弦不会被当成响了（") + ss + ")");
        }
        // 每根弦都响 / 换几个和弦、几种没响的弦
        {
            struct Case { int root; Chords::Quality q; int silent; };
            int ok = 0, total = 0;
            juce::String fails;
            for (auto c : { Case { 0, Chords::Quality::major, -1 }, Case { 7, Chords::Quality::major, -1 }, Case { 9, Chords::Quality::minor, -1 },
                            Case { 4, Chords::Quality::major, -1 }, Case { 2, Chords::Quality::major, -1 },
                            Case { 7, Chords::Quality::major, 5 }, Case { 9, Chords::Quality::minor, 2 }, Case { 4, Chords::Quality::major, 3 },
                            Case { 2, Chords::Quality::major, 4 }, Case { 4, Chords::Quality::minor, 5 }, Case { 9, Chords::Quality::major, 1 } })
            {
                const auto v = Chords::voicings (c.root, c.q).front();
                PluckSynth synth;
                synth.prepare (sr);
                juce::Random rnd (c.root * 31 + c.silent);
                for (int s = 0; s < 6; ++s)
                {
                    if (v.frets[(size_t) s] < 0 || s == c.silent) continue;
                    PluckSynth::NoteOn on;
                    on.midi = Chords::standardTuning[(size_t) s] + v.frets[(size_t) s];
                    on.velocity = 0.55f + 0.3f * rnd.nextFloat();
                    on.lengthSeconds = 2.0;
                    on.delaySamples = s * 350;
                    synth.noteOn (on);
                }
                std::vector<float> l ((size_t) sr), r ((size_t) sr), mono ((size_t) sr);
                synth.render (l.data(), r.data(), (int) sr);
                for (size_t i = 0; i < mono.size(); ++i) mono[i] = 0.5f * (l[i] + r[i]);
                juce::dsp::FFT fft (14);
                std::vector<float> work;
                const auto st = ChordPanel::analyse (mono.data() + 4000, 8192, sr, v, fft, work);
                bool good = true;
                for (int s = 0; s < 6; ++s)
                {
                    const int want = v.frets[(size_t) s] < 0 ? 0 : (s == c.silent ? 2 : 1);
                    const int got = st[(size_t) s];
                    // 3 = 说不准：只要求没响的弦不能判成“响了”，响的弦不能判成“没响”
                    if (got == 3 ? (want == 0) : (got != want && ! (want == 2 && got == 3))) good = false;
                    if (want == 1 && got == 2) good = false;
                    if (want == 2 && got == 1) good = false;
                }
                ++total; ok += good ? 1 : 0;
                if (! good)
                {
                    juce::String ss;
                    for (auto x : st) ss << (int) x;
                    fails << Chords::name (c.root, c.q) << "(" << c.silent << "):" << ss << " ";
                }
            }
            check (ok >= total - 1, juce::String::fromUTF8 ("几个和弦、几种没响的弦：判对 ") + juce::String (ok) + "/" + juce::String (total) + "  " + fails);
        }
    }

    std::printf ("\n== 17g. 音频扒谱（合成一段旋律 + 伴奏和弦，扒出来对比）\n");
    {
        // 96 BPM，8 小节：A 小调五声的旋律（四分、八分，有一个推弦、一个击弦），伴奏每小节一个和弦
        const double bpm = 96.0, beat = 60.0 / bpm;
        struct M { double b, len; int midi; float bend; bool hammer; };
        std::vector<M> mel;
        const int line[] = { 69, 72, 74, 76, 74, 72, 69, 67, 69, 72, 74, 79, 76, 74, 72, 74,
                             76, 79, 81, 79, 76, 74, 72, 69 };
        double b = 0.0;
        for (int i = 0; i < 24; ++i)
        {
            const double len = (i % 4 == 3) ? 1.0 : 0.5;
            mel.push_back ({ b, len, line[i], 0.0f, false });
            b += len;
        }
        mel.push_back ({ b, 2.0, 74, 2.0f, false }); b += 2.0;          // 推全音（D → E）
        mel.push_back ({ b, 0.5, 69, 0.0f, false }); b += 0.5;
        mel.push_back ({ b, 0.5, 71, 0.0f, true }); b += 0.5;           // 击弦 A → B
        mel.push_back ({ b, 1.0, 72, 0.0f, false }); b += 1.0;
        mel.push_back ({ b, 2.0, 69, 0.0f, false }); b += 2.0;
        const double lead = 0.5;                                        // 前面空半秒
        const double totalSec = lead + 8 * 4 * beat + 1.0;
        const int sr44 = 44100;
        juce::AudioBuffer<float> audio (2, (int) (totalSec * sr44));
        audio.clear();
        PluckSynth leadSynth, padSynth;
        leadSynth.prepare (sr44); padSynth.prepare (sr44);
        struct Ev { int64_t at; PluckSynth::NoteOn on; bool pad; };
        std::vector<Ev> evs;
        for (auto& m : mel)
        {
            PluckSynth::NoteOn on;
            on.midi = m.midi; on.velocity = m.hammer ? 0.6f : 0.9f; on.hammer = m.hammer;
            on.lengthSeconds = m.len * beat * 0.95;
            on.bendSemitones = m.bend; on.bendPeakPos = 0.3f;
            evs.push_back ({ (int64_t) ((lead + m.b * beat) * sr44), on, false });
        }
        // 伴奏：Am C G Am Dm F C E7（每小节一个，扫弦，小一点声）
        const int chordRoots[] = { 9, 0, 7, 9, 2, 5, 0, 4 };
        const Chords::Quality chordQ[] = { Chords::Quality::minor, Chords::Quality::major, Chords::Quality::major, Chords::Quality::minor,
                                           Chords::Quality::minor, Chords::Quality::major, Chords::Quality::major, Chords::Quality::dom7 };
        for (int bar = 0; bar < 8; ++bar)
        {
            const auto v = Chords::voicings (chordRoots[bar], chordQ[bar]).front();
            int k = 0;
            for (int m : v.midiNotes())
            {
                for (int rep = 0; rep < 2; ++rep)
                {
                    PluckSynth::NoteOn on;
                    on.midi = m; on.velocity = 0.35f; on.lengthSeconds = 2.0 * beat;
                    evs.push_back ({ (int64_t) ((lead + (bar * 4 + rep * 2) * beat) * sr44) + k * 300, on, true });
                }
                ++k;
            }
        }
        std::sort (evs.begin(), evs.end(), [] (const Ev& a, const Ev& c) { return a.at < c.at; });
        {
            std::vector<float> l (256), r (256), pl (256), pr (256);
            size_t e = 0;
            for (int pos = 0; pos < audio.getNumSamples(); pos += 256)
            {
                const int n = juce::jmin (256, audio.getNumSamples() - pos);
                while (e < evs.size() && evs[e].at < pos + n)
                {
                    auto on = evs[e].on;
                    on.delaySamples = (int) juce::jmax ((int64_t) 0, evs[e].at - pos);
                    (evs[e].pad ? padSynth : leadSynth).noteOn (on);
                    ++e;
                }
                std::fill (l.begin(), l.end(), 0.0f); std::fill (r.begin(), r.end(), 0.0f);
                std::fill (pl.begin(), pl.end(), 0.0f); std::fill (pr.begin(), pr.end(), 0.0f);
                leadSynth.render (l.data(), r.data(), n);
                padSynth.render (pl.data(), pr.data(), n);
                for (int i = 0; i < n; ++i)
                {
                    const float ld = 0.5f * (l[(size_t) i] + r[(size_t) i]), pd = 0.5f * (pl[(size_t) i] + pr[(size_t) i]);
                    if (juce::SystemStats::getEnvironmentVariable ("A2T_PADONLY", {}).isNotEmpty()) { audio.setSample (0, pos + i, pd); audio.setSample (1, pos + i, pd); continue; }
                    audio.setSample (0, pos + i, 0.9f * ld + 0.35f * pd);     // 旋律偏左
                    audio.setSample (1, pos + i, 0.25f * ld + 0.8f * pd);     // 伴奏偏右
                }
            }
        }

        for (auto src : { AudioToTab::Source::mix, AudioToTab::Source::left })
        {
            AudioToTab::Options o;
            o.source = src;
            o.title = "Test";
            o.mode = AudioToTab::Options::Mode::melody;     // 这一节测老的单音算法
            const double t0 = juce::Time::getMillisecondCounterHiRes();
            const auto res = AudioToTab::transcribe (audio, sr44, o);
            const double ms = juce::Time::getMillisecondCounterHiRes() - t0;
            const auto label = juce::String::fromUTF8 (src == AudioToTab::Source::mix ? "混音：" : "左声道：");
            check (res.song != nullptr, label + juce::String::fromUTF8 ("生成谱子") + res.error);
            if (res.song == nullptr) continue;
            // 和真值比：起音差 70 ms 以内、音高一样
            int hit = 0;
            for (auto& m : mel)
            {
                const double t = lead + m.b * beat;
                for (auto& d : res.notes)
                    if (std::abs (d.start - t) < 0.07 && d.midi == m.midi) { ++hit; break; }
            }
            if (juce::SystemStats::getEnvironmentVariable ("A2T_DEBUG", {}).isNotEmpty())
            {
                for (auto& d : res.notes)
                {
                    bool truth = false;
                    for (auto& m : mel) if (std::abs (d.start - (lead + m.b * beat)) < 0.07 && d.midi == m.midi) truth = true;
                    std::printf ("      %s %.3f-%.3f midi %d bend %.1f leg %d str %.2f\n", truth ? "  " : "XX", d.start, d.end, d.midi, d.bend, (int) d.legato, d.strength);
                }
                for (auto& c : res.chords) std::printf ("      chord %.2f %s\n", c.start, Chords::name (c.root, (Chords::Quality) c.quality).toRawUTF8());
            }
            const float recall = (float) hit / (float) mel.size();
            // 准确率只看旋律那一段（旋律弹完以后只剩伴奏，扒出伴奏的音是正常的）
            int inSpan = 0;
            const double melEnd = lead + (mel.back().b + mel.back().len) * beat;
            for (auto& d : res.notes) if (d.start < melEnd - 0.05) ++inSpan;
            const float precision = inSpan == 0 ? 0.0f : (float) hit / (float) inSpan;
            check (std::abs (res.bpm - bpm) < 2.0 || std::abs (res.bpm - bpm * 2.0) < 4.0 || std::abs (res.bpm - bpm / 2.0) < 1.0,
                   label + juce::String::fromUTF8 ("速度 ") + juce::String (res.bpm, 1) + juce::String::fromUTF8 (" BPM（应为 96）"));
            check (recall >= 0.8f && precision >= 0.7f,
                   label + juce::String::fromUTF8 ("旋律：找到 ") + juce::String (hit) + "/" + juce::String ((int) mel.size())
                       + juce::String::fromUTF8 (" 个音，旋律那段扒出 ") + juce::String (inSpan) + juce::String::fromUTF8 (" 个（用时 ")
                       + juce::String (ms / 1000.0, 1) + juce::String::fromUTF8 (" 秒）"));
            bool bendFound = false;
            for (auto& d : res.notes) if (d.midi == 74 && d.bend >= 1.5f) bendFound = true;
            check (bendFound, label + juce::String::fromUTF8 ("认出推弦（D 推全音）"));
            // 和弦：每小节第一拍
            int chordOk = 0;
            for (int bar = 0; bar < 8; ++bar)
            {
                const double t = lead + bar * 4 * beat + beat * 0.5;
                int found = -1, foundQ = -1;
                for (auto& c : res.chords) if (c.start <= t + 1.0e-6) { found = c.root; foundQ = c.quality; }
                const int wantQ = (int) chordQ[bar] == (int) Chords::Quality::dom7 ? (int) Chords::Quality::dom7 : (int) chordQ[bar];
                if (found == chordRoots[bar] && (foundQ == wantQ || (wantQ == (int) Chords::Quality::dom7 && foundQ == (int) Chords::Quality::major))) ++chordOk;
            }
            if (src == AudioToTab::Source::mix)
                check (chordOk >= 6, label + juce::String::fromUTF8 ("和弦：8 个小节对了 ") + juce::String (chordOk));
            // 写成 GP3 再读回来
            const auto f = juce::File::getSpecialLocation (juce::File::tempDirectory).getChildFile ("lianqin_a2t.gp3");
            juce::String err;
            const bool wrote = AudioToTab::writeGp3 (res.raw, f, err);
            auto back = wrote ? loadSongFile (f, err) : nullptr;
            check (back != nullptr && back->tracks.size() == 1 && back->tracks[0].notes.size() == res.song->tracks[0].notes.size()
                       && back->tracks[0].chords.size() == res.song->tracks[0].chords.size(),
                   label + juce::String::fromUTF8 ("写成 GP3 再读回来一致（") + juce::String (back != nullptr ? (int) back->tracks[0].notes.size() : -1)
                       + " / " + juce::String ((int) res.song->tracks[0].notes.size()) + juce::String::fromUTF8 (" 个音）") + err);
            f.deleteFile();
        }
    }

    std::printf ("\n== 17h. AI 扒谱（Basic Pitch 复音识别 + 分轨）\n");
    {
        juce::String why;
        if (! BasicPitch::isAvailable (why))
            std::printf ("     （跳过：%s）\n", why.toRawUTF8());
        else
        {
            // 100 BPM，8 小节：左声道扫和弦（Am C G Em，每拍一下），右声道单音旋律，中间贝斯根音
            const double bpm = 100.0, beat = 60.0 / bpm, lead = 0.5;
            const int sr44 = 44100;
            juce::AudioBuffer<float> audio (2, (int) ((lead + 32 * beat + 1.5) * sr44));
            audio.clear();
            PluckSynth padS, leadS, bassS;
            padS.prepare (sr44); leadS.prepare (sr44); bassS.prepare (sr44);
            struct Ev { int64_t at; PluckSynth::NoteOn on; int who; };
            std::vector<Ev> evs;
            const int roots[] = { 9, 0, 7, 4 };
            const Chords::Quality qs[] = { Chords::Quality::minor, Chords::Quality::major, Chords::Quality::major, Chords::Quality::minor };
            int chordNotes = 0;
            for (int bar = 0; bar < 8; ++bar)
            {
                const auto v = Chords::voicings (roots[bar % 4], qs[bar % 4]).front();
                for (int bt = 0; bt < 4; bt += 2)
                {
                    int k = 0;
                    for (int m : v.midiNotes())
                    {
                        PluckSynth::NoteOn on; on.midi = m; on.velocity = 0.6f; on.lengthSeconds = beat * 1.9;
                        evs.push_back ({ (int64_t) ((lead + (bar * 4 + bt) * beat) * sr44) + k * 250, on, 0 });
                        ++k; ++chordNotes;
                    }
                }
                PluckSynth::NoteOn b; b.midi = 28 + ((roots[bar % 4] - 4 + 12) % 12); b.velocity = 0.9f; b.lengthSeconds = beat * 3.8; b.bass = true;
                evs.push_back ({ (int64_t) ((lead + bar * 4 * beat) * sr44), b, 2 });
            }
            const int mel[] = { 72, 74, 76, 79, 77, 76, 74, 72 };
            for (int i = 0; i < 32; ++i)
            {
                PluckSynth::NoteOn on; on.midi = mel[i % 8] + (i / 8 % 2 == 0 ? 0 : -3); on.velocity = 0.9f; on.lengthSeconds = beat * 0.9;
                evs.push_back ({ (int64_t) ((lead + i * beat + beat * 0.5) * sr44), on, 1 });
            }
            std::sort (evs.begin(), evs.end(), [] (const Ev& a, const Ev& c) { return a.at < c.at; });
            std::vector<float> bl (256), br (256);
            size_t e = 0;
            for (int pos = 0; pos < audio.getNumSamples(); pos += 256)
            {
                const int n = juce::jmin (256, audio.getNumSamples() - pos);
                while (e < evs.size() && evs[e].at < pos + n)
                {
                    auto on = evs[e].on; on.delaySamples = (int) juce::jmax ((int64_t) 0, evs[e].at - pos);
                    (evs[e].who == 0 ? padS : evs[e].who == 1 ? leadS : bassS).noteOn (on);
                    ++e;
                }
                float pd[256], ld[256], bd[256];
                for (auto* sy : { &padS, &leadS, &bassS })
                {
                    std::fill (bl.begin(), bl.end(), 0.0f); std::fill (br.begin(), br.end(), 0.0f);
                    sy->render (bl.data(), br.data(), n);
                    float* dst = sy == &padS ? pd : sy == &leadS ? ld : bd;
                    for (int i = 0; i < n; ++i) dst[i] = 0.5f * (bl[(size_t) i] + br[(size_t) i]);
                }
                for (int i = 0; i < n; ++i)
                {
                    audio.setSample (0, pos + i, 0.8f * pd[i] + 0.15f * ld[i] + 0.5f * bd[i]);
                    audio.setSample (1, pos + i, 0.15f * pd[i] + 0.8f * ld[i] + 0.5f * bd[i]);
                }
            }
            AudioToTab::Options o;
            o.title = "AI test";
            const double t0 = juce::Time::getMillisecondCounterHiRes();
            auto res = AudioToTab::transcribe (audio, sr44, o);
            const double secs = (juce::Time::getMillisecondCounterHiRes() - t0) / 1000.0;
            check (res.song != nullptr && res.usedAi, juce::String::fromUTF8 ("AI 扒谱出结果（") + juce::String (secs, 1) + juce::String::fromUTF8 (" 秒）：") + res.summary + res.error);
            if (res.song != nullptr)
            {
                int chordTrack = -1, leadTrack = -1, bassTrack = -1;
                for (int i = 0; i < (int) res.song->tracks.size(); ++i)
                {
                    const auto& t = res.song->tracks[(size_t) i];
                    if (t.isBass()) bassTrack = i;
                    else if (t.name.contains (juce::String::fromUTF8 ("节奏"))) chordTrack = i;
                    else if (t.name.contains (juce::String::fromUTF8 ("主音"))) leadTrack = i;
                    std::printf ("     音轨 %s：%d 个音\n", t.name.toRawUTF8(), (int) t.notes.size());
                    if (std::getenv ("A2T_DUMP") != nullptr)
                    {
                        for (size_t q = 0; q < t.notes.size() && q < 40; ++q)
                            std::printf ("%.3f:%d ", t.notes[q].start, t.notes[q].midi);
                        std::printf ("\n");
                        if (i == 0) { juce::WavAudioFormat wf; auto out = juce::File ("/tmp/claude-0/ai_test.wav"); out.deleteFile();
                            if (auto w = std::unique_ptr<juce::AudioFormatWriter> (wf.createWriterFor (new juce::FileOutputStream (out), sr44, 2, 16, {}, 0))) w->writeFromAudioSampleBuffer (audio, 0, audio.getNumSamples()); }
                    }
                }
                check (chordTrack >= 0 && leadTrack >= 0 && bassTrack >= 0, juce::String::fromUTF8 ("分出节奏 / 主音 / 贝斯三条音轨：") + res.summary);
                if (chordTrack >= 0)
                {
                    // 节奏吉他里同时开始的音（和弦）
                    const auto& ns = res.song->tracks[(size_t) chordTrack].notes;
                    int groups = 0, big = 0;
                    for (size_t i = 0; i < ns.size(); )
                    {
                        size_t j = i; while (j < ns.size() && std::abs (ns[j].start - ns[i].start) < 1.0e-6) ++j;
                        ++groups; if (j - i >= 3) ++big; i = j;
                    }
                    check (big >= 10, juce::String::fromUTF8 ("节奏吉他扒成和弦（三个音以上的组 ") + juce::String (big) + "/" + juce::String (groups) + ")");
                    // 和弦名
                    int ok = 0;
                    for (int bar = 0; bar < 8; ++bar)
                    {
                        const double t = lead + (bar * 4 + 1) * beat;
                        int found = -1, fq = -1;
                        for (auto& c : res.chords) if (c.start <= t + 1.0e-6) { found = c.root; fq = c.quality; }
                        ok += (found == roots[bar % 4] && fq == (int) qs[bar % 4]) ? 1 : 0;
                    }
                    check (ok >= 6, juce::String::fromUTF8 ("和弦名 8 小节对了 ") + juce::String (ok) + juce::String::fromUTF8 ("（") + juce::String (res.bpm, 1) + " BPM, " + juce::String (res.firstBeatSeconds, 3) + ")");
                    if (ok < 6) for (auto& c : res.chords) std::printf ("       %.2f %s\n", c.start, Chords::name (c.root, (Chords::Quality) c.quality).toRawUTF8());
                }
                if (leadTrack >= 0)
                {
                    int hit = 0;
                    for (int i = 0; i < 32; ++i)
                    {
                        const double t = lead + i * beat + beat * 0.5;
                        const int m = mel[i % 8] + (i / 8 % 2 == 0 ? 0 : -3);
                        for (auto& n : res.song->tracks[(size_t) leadTrack].notes)
                            if (std::abs (res.song->beatToSeconds (n.start) - (t - res.firstBeatSeconds)) < 0.1 && n.midi == m) { ++hit; break; }
                    }
                    check (hit >= 24, juce::String::fromUTF8 ("主音吉他的旋律对了 ") + juce::String (hit) + "/32");
                }
                if (bassTrack >= 0)
                {
                    const auto& bt = res.song->tracks[(size_t) bassTrack];
                    check (bt.stringCount() == 4 && bt.notes.size() >= 6, juce::String::fromUTF8 ("贝斯音轨是 4 弦（") + juce::String ((int) bt.notes.size()) + juce::String::fromUTF8 (" 个音）"));
                }
                const auto f = juce::File::getSpecialLocation (juce::File::tempDirectory).getChildFile ("lianqin_ai.gp3");
                juce::String err;
                const bool wrote = AudioToTab::writeGp3 (res.raw, f, err);
                auto back = wrote ? loadSongFile (f, err) : nullptr;
                bool same = back != nullptr && back->tracks.size() == res.song->tracks.size();
                for (size_t i = 0; same && i < back->tracks.size(); ++i)
                    same = back->tracks[i].notes.size() == res.song->tracks[i].notes.size() && back->tracks[i].stringCount() == res.song->tracks[i].stringCount();
                check (same, juce::String::fromUTF8 ("多音轨（含 4 弦贝斯）写成 GP3 再读回来一致") + err);
                f.deleteFile();
            }
        }
    }

    std::printf ("\n== 17i. 原曲同步播放（谱子走带带着原曲走，放慢音高不变）\n");
    {
        using namespace judgetest;
        auto song = makeExerciseSong();        // 100 BPM，每拍 0.6 秒
        const double off = 1.0;
        // 原曲：44.1 kHz，每拍一个短促的“嘀”（谱子第 k 拍在原曲 off + 0.6k 秒）
        const int csr = 44100;
        juce::AudioBuffer<float> clickAudio (2, csr * 24);
        clickAudio.clear();
        for (int k = 0; k < 34; ++k)
        {
            const int at = (int) ((off + 0.6 * k) * csr);
            for (int i = 0; i < 1500 && at + i < clickAudio.getNumSamples(); ++i)
            {
                const float v = 0.8f * std::exp (-i / 300.0f) * std::sin (6.2831853f * 1000.0f * i / csr);
                clickAudio.setSample (0, at + i, v); clickAudio.setSample (1, at + i, v);
            }
        }
        auto writeWav = [] (const juce::AudioBuffer<float>& b, int rate, const juce::File& f)
        {
            f.deleteFile();
            juce::WavAudioFormat wf;
            std::unique_ptr<juce::AudioFormatWriter> w (wf.createWriterFor (new juce::FileOutputStream (f), rate, 2, 24, {}, 0));
            return w != nullptr && w->writeFromAudioSampleBuffer (b, 0, b.getNumSamples());
        };
        const auto tmp = juce::File::getSpecialLocation (juce::File::tempDirectory);
        const auto clickWav = tmp.getChildFile ("lianqin_orig_click.wav");
        writeWav (clickAudio, csr, clickWav);

        // 跑引擎：记下输出和每块谱子位置；返回输出里每个“嘀”出现时谱子在第几拍
        struct Run { std::vector<double> onsetBeats, onsetSecs; std::vector<float> out; };
        auto run = [&] (float speed, double startBeat, double seconds, double loopA, double loopB, const juce::File& wav, bool countIn)
        {
            Run res;
            AudioEngine engine;
            engine.prepareForOffline (sr, block);
            engine.setOutputGainDb (-60.0f);
            auto& tp = engine.getTabPlayer();
            tp.setSong (song); tp.setTrack (0); tp.setCountIn (countIn); tp.setDemoOn (false); tp.setBackingVolumeDb (-60.0f);
            tp.setSpeed (speed);
            if (loopB > loopA) tp.setLoop (loopA, loopB, true);
            tp.seek (startBeat);
            juce::String err;
            auto& o = engine.getOriginal();
            o.loadNow (wav, err);
            o.setFollowOffset (off); o.setFollowRate (1.0); o.setGainDb (0.0f);
            tp.setPlaying (true);
            const int total = (int) (seconds * sr);
            std::vector<float> in ((size_t) block, 0.0f), l ((size_t) block), r ((size_t) block);
            int quiet = 100000;
            bool armed = true;
            for (int pos = 0; pos < total; pos += block)
            {
                std::fill (l.begin(), l.end(), 0.0f); std::fill (r.begin(), r.end(), 0.0f);
                engine.processOffline (in.data(), l.data(), r.data(), block);
                const auto& bp = tp.getLastBlockPosition();
                for (int i = 0; i < block; ++i)
                {
                    const float v = std::abs (l[(size_t) i]);
                    res.out.push_back (l[(size_t) i]);
                    if (quiet > (int) (0.1 * sr)) armed = true;
                    if (v > 0.15f && armed)
                    {
                        armed = false;
                        double beat = bp.beat + i * bp.beatsPerSample;
                        if (bp.wrapOffset >= 0 && i >= bp.wrapOffset) beat = bp.wrapBeat + (i - bp.wrapOffset) * bp.beatsPerSample;
                        res.onsetBeats.push_back (bp.rolling ? beat : -1.0);
                        res.onsetSecs.push_back ((pos + i) / sr);
                    }
                    quiet = v < 0.02f ? quiet + 1 : 0;
                }
            }
            return res;
        };
        auto beatErrMs = [] (const Run& r, float speed, int& count)
        {
            double worst = 0.0; count = 0;
            for (double b : r.onsetBeats)
            {
                if (b < 0.0) continue;
                ++count;
                worst = juce::jmax (worst, std::abs (b - std::round (b)) * 600.0 / speed);    // 换算成原曲里的毫秒
            }
            return worst;
        };
        {
            auto r = run (1.0f, 0.0, 8.0, 0, 0, clickWav, false);
            int n = 0; const double e = beatErrMs (r, 1.0f, n);
            check (n >= 12 && e < 3.0, juce::String::fromUTF8 ("原速：原曲的拍子和谱子对上（") + juce::String (n) + juce::String::fromUTF8 (" 拍，最大偏差 ") + juce::String (e, 1) + " ms)");
        }
        {
            auto r = run (0.5f, 2.0, 10.0, 0, 0, clickWav, false);
            int n = 0; const double e = beatErrMs (r, 0.5f, n);
            check (n >= 7 && e < 16.0, juce::String::fromUTF8 ("放慢到 50%：还是对得上（") + juce::String (n) + juce::String::fromUTF8 (" 拍，最大偏差 ") + juce::String (e, 1) + juce::String::fromUTF8 (" ms）"));
            bool spacing = r.onsetSecs.size() >= 3;
            for (size_t i = 1; i + 1 < r.onsetSecs.size(); ++i) spacing = spacing && std::abs ((r.onsetSecs[i + 1] - r.onsetSecs[i]) - 1.2) < 0.03;
            check (spacing, juce::String::fromUTF8 ("50% 时拍子间隔变成 1.2 秒"));
        }
        {
            auto r = run (0.75f, 4.0, 9.0, 4.0, 8.0, clickWav, false);
            int n = 0; const double e = beatErrMs (r, 0.75f, n);
            bool inLoop = n > 0;
            for (double b : r.onsetBeats) if (b >= 0.0) inLoop = inLoop && b > 3.9 && b < 8.0;
            check (n >= 8 && inLoop && e < 16.0, juce::String::fromUTF8 ("A-B 循环（第 4–8 拍，75%）跳回去原曲也跟着跳（") + juce::String (n) + juce::String::fromUTF8 (" 拍，偏差 ") + juce::String (e, 1) + " ms)");
        }
        {
            // 预备拍：先放一小节，原曲从第 0 拍前一小节开始（第 0 拍在原曲 1.0 秒，所以开头 1 秒内有前奏也会响）
            auto r = run (1.0f, 0.0, 5.0, 0, 0, clickWav, true);
            double first = -1.0;     // 预备拍的四下“哒”（0、0.6、1.2、1.8 秒）是鼓机的，跳过
            for (double t : r.onsetSecs) if (t > 2.1) { first = t; break; }
            check (std::abs (first - 2.4) < 0.01, juce::String::fromUTF8 ("有预备拍时原曲第 1 拍正好落在预备拍之后（") + juce::String (first, 3) + juce::String::fromUTF8 (" 秒）"));
        }
        {
            // 音高不变：440 Hz 正弦放慢一半，数过零点
            juce::AudioBuffer<float> sine (2, csr * 30);
            for (int i = 0; i < sine.getNumSamples(); ++i)
            {
                const float v = 0.5f * std::sin (6.2831853f * 440.0f * i / csr);
                sine.setSample (0, i, v); sine.setSample (1, i, v);
            }
            const auto sineWav = tmp.getChildFile ("lianqin_orig_sine.wav");
            writeWav (sine, csr, sineWav);
            auto r = run (0.5f, 0.0, 4.0, 0, 0, sineWav, false);
            int zc = 0;
            const size_t a = (size_t) (1.0 * sr), b = (size_t) (3.0 * sr);
            float worstJump = 0.0f, lvlMin = 1.0f, lvlMax = 0.0f;
            for (size_t i = a; i < b; ++i)
            {
                if ((r.out[i - 1] < 0.0f) != (r.out[i] < 0.0f)) ++zc;
                worstJump = juce::jmax (worstJump, std::abs (r.out[i] - r.out[i - 1]));
            }
            for (size_t c = a; c + 480 < b; c += 480)
            {
                float pk = 0.0f;
                for (size_t i = c; i < c + 480; ++i) pk = juce::jmax (pk, std::abs (r.out[i]));
                lvlMin = juce::jmin (lvlMin, pk); lvlMax = juce::jmax (lvlMax, pk);
            }
            const double hz = zc / 2.0 / 2.0;
            check (std::abs (hz - 440.0) < 3.0, juce::String::fromUTF8 ("放慢到 50% 音高不变：") + juce::String (hz, 1) + " Hz");
            const float maxStep = 0.5f * 6.2831853f * 440.0f / (float) sr * 1.3f;
            check (worstJump < maxStep && lvlMin > 0.42f && lvlMax < 0.58f,
                   juce::String::fromUTF8 ("拉伸没有爆音、音量不忽大忽小（相邻采样最大跳变 ") + juce::String (worstJump, 3)
                   + juce::String::fromUTF8 ("，包络 ") + juce::String (lvlMin, 2) + "–" + juce::String (lvlMax, 2) + ")");
            sineWav.deleteFile();
        }
        {
            // 对齐信息存在谱子旁边，读回来一样；搬了家（绝对路径失效）就在谱子旁边找同名音频
            const auto dir = tmp.getChildFile ("lianqin_sync_test");
            dir.deleteRecursively(); dir.createDirectory();
            const auto tab = dir.getChildFile ("song.gp3");
            tab.replaceWithText ("x");
            const auto audio = dir.getChildFile ("song.wav");
            clickWav.copyFileTo (audio);
            juce::PropertiesFile::Options po; po.applicationName = "LianqinTests";
            juce::PropertiesFile props (dir.getChildFile ("t.settings"), po);
            OriginalSync os; os.audio = audio; os.offset = 1.234; os.rate = 0.9975; os.gainDb = -3.0f; os.on = false;
            OriginalSync::saveFor (tab, os, props);
            auto back = OriginalSync::loadFor (tab, props);
            check (back.audio == audio && std::abs (back.offset - 1.234) < 1.0e-9 && std::abs (back.rate - 0.9975) < 1.0e-9 && back.gainDb == -3.0f && ! back.on,
                   juce::String::fromUTF8 ("原曲对齐信息存盘再读回一致"));
            const auto moved = tmp.getChildFile ("lianqin_sync_moved");
            moved.deleteRecursively();
            dir.moveFileTo (moved);
            auto back2 = OriginalSync::loadFor (moved.getChildFile ("song.gp3"), props);
            check (back2.audio == moved.getChildFile ("song.wav"), juce::String::fromUTF8 ("文件夹搬家后还能找到原曲"));
            moved.deleteRecursively();
        }
        clickWav.deleteFile();
    }

    std::printf ("\n== 17j. 六线谱改谱（改品位、换弦、删除、加音、和弦、撤销，存 GP3 再读回）\n");
    {
        using namespace judgetest;
        auto song = makeExerciseSong();
        TabEditor ed;
        ed.begin (song, 0);
        const auto& n0 = song->tracks[0].notes[0];
        ed.select (n0.start, n0.string, false);
        const size_t count0 = song->tracks[0].notes.size();
        check (ed.typeDigit (7, 1000.0) && ed.current()->tracks[0].notes[0].fret == 7
               && ed.current()->tracks[0].notes[0].midi == song->tracks[0].tuning[(size_t) n0.string] + 7, juce::String::fromUTF8 ("数字键改品位，音高跟着变"));
        ed.typeDigit (1, 3000.0); ed.typeDigit (2, 3300.0);
        check (ed.current()->tracks[0].notes[0].fret == 12, juce::String::fromUTF8 ("两位数品位（1、2 → 12 品）"));
        const int midiBefore = ed.current()->tracks[0].notes[0].midi;
        const bool moved = ed.moveSelectedToString (-1);
        const auto& m0 = ed.current()->tracks[0].notes[(size_t) ed.selectedIndices().front()];
        check (moved && m0.string == n0.string - 1 && m0.midi == midiBefore, juce::String::fromUTF8 ("换到相邻的弦，音高不变（品位 ") + juce::String (m0.fret) + ")");
        check (ed.deleteSelected() && ed.current()->tracks[0].notes.size() == count0 - 1, juce::String::fromUTF8 ("删除音符"));
        check (ed.undo() && ed.current()->tracks[0].notes.size() == count0 && ed.redo() && ed.current()->tracks[0].notes.size() == count0 - 1,
               juce::String::fromUTF8 ("撤销 / 重做"));
        ed.undo();
        // 空白处加一个音：第 1 小节第 1.5 拍、2 弦
        ed.select (1.5, 1, false);
        const bool added = ed.noteAt (1.5, 1) < 0 && ed.typeDigit (5, 9000.0);
        const int ni = ed.noteAt (1.5, 1);
        check (added && ni >= 0 && ed.current()->tracks[0].notes.size() == count0 + 1 && ed.current()->tracks[0].notes[(size_t) ni].fret == 5,
               juce::String::fromUTF8 ("空白处输入数字 = 加一个音"));
        check (ed.setLength (8.0) && [&] { const auto& n = ed.current()->tracks[0].notes[(size_t) ed.noteAt (1.5, 1)];
                                           for (auto& o : ed.current()->tracks[0].notes) if (o.string == 1 && o.start > 1.5 + 1e-6 && o.start < 1.5 + n.length - 1e-6) return false; return true; }(),
               juce::String::fromUTF8 ("拉长时值不会盖住同一根弦的下一个音"));
        check (ed.setChordAt (0.0, 9, (int) Chords::Quality::minor) && ed.chordAt (0.0) >= 0
               && ed.current()->tracks[0].chordDiagrams[(size_t) ed.current()->tracks[0].chords[(size_t) ed.chordAt (0.0)].diagram].name == "Am",
               juce::String::fromUTF8 ("设和弦 Am"));
        // 同一根弦上第二个音标击弦（前一个音会被拉长连过来）
        int hi = -1;
        {
            const auto& ns = ed.current()->tracks[0].notes;
            for (int i = 0; i < (int) ns.size() && hi < 0; ++i)
                for (int j = 0; j < i; ++j) if (ns[(size_t) j].string == ns[(size_t) i].string && ! ns[(size_t) i].hammerPull) { hi = i; break; }
        }
        const double hb = ed.current()->tracks[0].notes[(size_t) hi].start; const int hs = ed.current()->tracks[0].notes[(size_t) hi].string;
        ed.select (hb, hs, false);
        check (ed.toggleHammer() && ed.current()->tracks[0].notes[(size_t) ed.noteAt (hb, hs)].hammerPull, juce::String::fromUTF8 ("标击弦"));
        // 存 GP3 再读回：音符、和弦都在
        const auto f = juce::File::getSpecialLocation (juce::File::tempDirectory).getChildFile ("lianqin_edit.gp3");
        juce::String err;
        const auto edited = ed.current();
        const bool wrote = AudioToTab::writeGp3 (songToRaw (*edited), f, err);
        auto back = wrote ? loadSongFile (f, err) : nullptr;
        bool same = back != nullptr && back->tracks[0].notes.size() == edited->tracks[0].notes.size();
        for (size_t i = 0; same && i < edited->tracks[0].notes.size(); ++i)
        {
            const auto& a = edited->tracks[0].notes[i]; const auto& b = back->tracks[0].notes[i];
            same = std::abs (a.start - b.start) < 1e-6 && std::abs (a.length - b.length) < 0.03 && a.string == b.string && a.fret == b.fret && a.hammerPull == b.hammerPull;
            if (! same) std::printf ("     第 %d 个音：%.3f/%.3f s%d f%d %s → %.3f/%.3f s%d f%d %s\n", (int) i, a.start, a.length, a.string, a.fret, a.hammerPull ? "H" : "",
                                     b.start, b.length, b.string, b.fret, b.hammerPull ? "H" : "");
        }
        if (back != nullptr && back->tracks[0].notes.size() != edited->tracks[0].notes.size()) std::printf ("     音数 %d → %d\n", (int) edited->tracks[0].notes.size(), (int) back->tracks[0].notes.size());
        check (same, juce::String::fromUTF8 ("改过的谱存成 GP3 再读回来一样") + err);
        check (back != nullptr && ! back->tracks[0].chords.empty() && back->tracks[0].chordDiagrams[(size_t) back->tracks[0].chords[0].diagram].name == "Am",
               juce::String::fromUTF8 ("和弦也存进去了"));
        f.deleteFile();
        // 三连音、速度变化、附点也能写
        {
            RawScore raw; raw.title = "tuplet"; raw.initialTempo = 90.0;
            RawTrack t; t.name = "G"; t.tuning = { 64, 59, 55, 50, 45, 40 };
            for (int b = 0; b < 2; ++b)
            {
                RawMasterBar mb; if (b == 1) mb.tempos.push_back ({ 0.0, 140.0 });
                raw.masterBars.push_back (mb);
                RawBar bar; RawVoice v;
                for (int k = 0; k < 6; ++k) { RawBeat bt; bt.duration = 1.0 / 3.0; RawNote rn; rn.string = 2; rn.fret = k; bt.notes.push_back (rn); v.beats.push_back (bt); }
                RawBeat dotted; dotted.duration = 1.5; RawNote rn; rn.string = 1; rn.fret = 3; dotted.notes.push_back (rn); v.beats.push_back (dotted);
                RawBeat rest; rest.duration = 0.5; v.beats.push_back (rest);
                bar.voices.push_back (v); t.bars.push_back (bar);
            }
            raw.tracks.push_back (t);
            auto s0 = buildSong (raw);
            const bool w2 = AudioToTab::writeGp3 (songToRaw (*s0), f, err);
            auto s1 = w2 ? loadSongFile (f, err) : nullptr;
            bool ok = s1 != nullptr && s1->tracks[0].notes.size() == s0->tracks[0].notes.size() && std::abs (s1->lengthSeconds() - s0->lengthSeconds()) < 0.01;
            for (size_t i = 0; ok && i < s0->tracks[0].notes.size(); ++i)
                ok = std::abs (s1->tracks[0].notes[i].start - s0->tracks[0].notes[i].start) < 1e-6;
            check (ok, juce::String::fromUTF8 ("三连音、附点、中途变速存 GP3 一致（") + juce::String (s1 != nullptr ? s1->lengthSeconds() : 0.0, 3) + " / " + juce::String (s0->lengthSeconds(), 3) + ")");
            f.deleteFile();
        }
    }

    std::printf ("\n== 18. 录音和回放（回放时谱子要对上，判定结果应该一样）\n");
    {
        using namespace judgetest;
        auto song = makeExerciseSong();
        auto js = std::make_shared<JudgeSession> (song, 0);
        std::vector<Plan> plan (js->events.size());
        juce::Random rnd (11);
        for (size_t e = 0; e < plan.size(); ++e)
        {
            plan[e].kind = (e % 10 == 3) ? 1 : (e % 10 == 7 ? 2 : 0);
            if (js->events[e].kind == JudgeEvent::legato) plan[e].kind = (e % 10 == 7) ? 2 : 0;
            plan[e].offsetMs = js->events[e].kind == JudgeEvent::legato ? 0.0f : (rnd.nextFloat() - 0.5f) * 60.0f;
        }
        const auto perf = perform (*song, *js, plan, 0.0);

        // 第一次：边弹边录。先录 0.5 秒空白，再开始放谱子
        AudioEngine engine;
        setupEngine (engine, song, js, 0.0f);
        auto& tp = engine.getTabPlayer();
        tp.setPlaying (false);
        auto& rec = engine.getRecorder();
        Recorder::Info info;
        info.songTitle = "Judge test";
        juce::String err;
        const bool started = rec.startRecording (info, err);
        const int lead = 188 * block;
        std::vector<float> silence ((size_t) lead, 0.0f), l ((size_t) lead), r ((size_t) lead);
        engine.processOffline (silence.data(), l.data(), r.data(), lead);
        engine.getJudge().processPending();
        tp.setPlaying (true);
        runEngine (engine, perf);
        const auto wav = rec.stopRecording();
        const auto saved = Recorder::Info::loadFor (wav);
        std::vector<int> firstRun (js->events.size());
        for (size_t e = 0; e < js->events.size(); ++e) firstRun[e] = (int) js->verdictOf ((int) e);

        juce::AudioFormatManager fm;
        fm.registerBasicFormats();
        std::unique_ptr<juce::AudioFormatReader> reader (fm.createReaderFor (wav));
        float maxErr = 0.0f;
        if (reader != nullptr)
        {
            juce::AudioBuffer<float> back (1, (int) reader->lengthInSamples);
            reader->read (&back, 0, (int) reader->lengthInSamples, 0, true, false);
            for (int i = 0; i < juce::jmin ((int) perf.size(), back.getNumSamples() - lead); ++i)
                maxErr = juce::jmax (maxErr, std::abs (back.getSample (0, lead + i) - juce::jlimit (-1.0f, 1.0f, perf[(size_t) i])));   // 声卡输入本来就在 ±1 以内
        }
        check (started && reader != nullptr && reader->lengthInSamples == (juce::int64) (lead + perf.size()),
               juce::String::fromUTF8 ("录成 WAV：") + wav.getFileName() + "  " + juce::String (reader != nullptr ? reader->lengthInSamples : 0)
                   + juce::String::fromUTF8 (" 个采样") + (err.isNotEmpty() ? "  " + err : juce::String()));
        float peak = 0.0f;
        for (auto x : perf) peak = juce::jmax (peak, std::abs (x));
        check (maxErr < 1.0e-5f, juce::String::fromUTF8 ("录下的就是输入的干信号（最大误差 ") + juce::String (maxErr, 7) + juce::String::fromUTF8 ("，合成演奏峰值 ") + juce::String (peak, 2) + ")");
        check (saved.synced && saved.syncSample == lead && std::abs (saved.syncBeat) < 1.0e-9,
               juce::String::fromUTF8 ("记下了谱子开始的位置：第 ") + juce::String (saved.syncSample) + juce::String::fromUTF8 (" 个采样，第 ") + juce::String (saved.syncBeat, 2) + juce::String::fromUTF8 (" 拍"));

        // 第二次：回放（输入全是静音，录音代替吉他），谱子自己在同一个采样点开始
        auto js2 = std::make_shared<JudgeSession> (song, 0);
        AudioEngine engine2;
        setupEngine (engine2, song, js2, 0.0f);
        engine2.getTabPlayer().setPlaying (false);
        engine2.getTabPlayer().seek (saved.syncBeat);
        const bool replayStarted = engine2.getRecorder().startPlayback (wav, err);
        std::vector<float> quiet ((size_t) (lead + perf.size()), 0.0f);
        runEngine (engine2, quiet);
        int same = 0;
        for (size_t e = 0; e < js2->events.size(); ++e) same += (int) js2->verdictOf ((int) e) == firstRun[e];
        check (replayStarted && same >= (int) js2->events.size() - 1,
               juce::String::fromUTF8 ("回放判定和现场一致：") + juce::String (same) + "/" + juce::String ((int) js2->events.size()));
        check (! engine2.getRecorder().isPlayingBack(), juce::String::fromUTF8 ("回放到结尾自动停"));
        wav.deleteFile();
        wav.withFileExtension ("json").deleteFile();
    }

    std::printf ("\n== 18b. 五轨循环录音\n");
    {
        AudioEngine engine;
        engine.prepareForOffline (sr, block);
        auto& lp = engine.getLooper();
        check (lp.allocate(), T ("分配 5 轨 × 30 秒缓冲"));
        std::vector<float> in ((size_t) block), ol ((size_t) block), orr ((size_t) block);
        double phase = 0.0;
        auto runFor = [&] (double seconds, double freq, float amp, std::vector<float>* capture = nullptr)
        {
            const int blocks = (int) std::lround (seconds * sr / block);
            for (int b = 0; b < blocks; ++b)
            {
                for (int i = 0; i < block; ++i)
                {
                    in[(size_t) i] = freq > 0.0 ? amp * (float) std::sin (phase) : 0.0f;
                    phase += juce::MathConstants<double>::twoPi * freq / sr;
                }
                engine.processOffline (in.data(), ol.data(), orr.data(), block);
                if (capture != nullptr) capture->insert (capture->end(), ol.begin(), ol.end());
                lp.maintenance();
            }
        };
        using S = Looper::State;

        // 第 1 轨：录 1 秒 220 Hz，再按一下定长度
        lp.pressTrack (0);
        runFor (0.01, 0, 0);
        const bool recStarted = lp.getState (0) == S::recording;
        runFor (1.0, 220.0, 0.3f);
        lp.pressTrack (0);
        runFor (0.01, 0, 0);
        const int L = lp.getLoopLength();
        check (recStarted && lp.getState (0) == S::playing && std::abs (L - (int) sr) <= 5 * block,
               T ("第 1 轨：按一下开始录，再按一下定长度 ") + juce::String (L / sr, 3) + T (" 秒，自动开始循环"));

        // 不弹琴，输出里应该是循环回放的 220 Hz
        std::vector<float> outBuf;
        runFor (0.5, 0, 0, &outBuf);
        PitchDetector pd;
        auto res = pd.detect (outBuf.data() + 4000, 4096, sr);
        check (std::abs (res.frequency - 220.0f) < 2.0f, T ("不弹的时候放出来的是录好的循环：") + juce::String (res.frequency, 1) + " Hz");

        // 第 2 轨：按下后录满一圈自动转播放
        lp.pressTrack (1);
        runFor (0.01, 0, 0);
        const bool t2rec = lp.getState (1) == S::recording;
        runFor (L / sr + 0.05, 330.0, 0.3f);
        check (t2rec && lp.getState (1) == S::playing && lp.hasAudio (1), T ("第 2 轨：录满一圈自动转成播放"));

        // 两轨一起放：频谱里要同时有 220 和 330
        outBuf.clear();
        runFor (0.6, 0, 0, &outBuf);
        auto energy = [&] (double f)
        {
            double re = 0, im = 0;
            for (int i = 0; i < 16384; ++i) { const double ph = juce::MathConstants<double>::twoPi * f * i / sr; re += outBuf[(size_t) i] * std::cos (ph); im += outBuf[(size_t) i] * std::sin (ph); }
            return std::sqrt (re * re + im * im) / 8192.0;
        };
        const double e220 = energy (220.0), e330 = energy (330.0), e500 = energy (500.0);
        check (e220 > 0.05 && e330 > 0.05 && e500 < 0.02, T ("两轨叠在一起放：220 Hz ") + juce::String (e220, 3) + T ("，330 Hz ") + juce::String (e330, 3));

        // 静音第 2 轨
        lp.setMuted (1, true);
        outBuf.clear();
        runFor (0.6, 0, 0, &outBuf);
        check (energy (330.0) < 0.01 && energy (220.0) > 0.05, T ("静音第 2 轨后只剩第 1 轨"));
        lp.setMuted (1, false);

        // 叠录第 1 轨：加一个 440
        lp.pressTrack (0);
        runFor (0.01, 0, 0);
        const bool dub = lp.getState (0) == S::overdubbing;
        runFor (L / sr, 440.0, 0.2f);
        lp.pressTrack (0);
        runFor (0.01, 0, 0);
        outBuf.clear();
        runFor (0.6, 0, 0, &outBuf);
        check (dub && lp.getState (0) == S::playing && energy (440.0) > 0.04 && energy (220.0) > 0.05,
               T ("叠录：第 1 轨原来的 220 Hz 还在，叠上了 440 Hz"));

        // 循环接缝处不爆音：找最大的样本跳变
        float maxJump = 0.0f;
        for (size_t i = 1; i < outBuf.size(); ++i) maxJump = juce::jmax (maxJump, std::abs (outBuf[i] - outBuf[i - 1]));
        check (maxJump < 0.12f, T ("循环接缝处没有爆音：最大相邻跳变 ") + juce::String (maxJump, 3));

        // 导出混音
        const auto mix = lp.renderMix();
        check (mix.getNumSamples() == L && mix.getMagnitude (0, 0, L) > 0.1f, T ("导出用的混音：一圈 ") + juce::String (mix.getNumSamples()) + T (" 个采样"));

        // 清除第 2 轨 → 空、缓冲被界面线程清零；再录还能录
        lp.clearTrack (1);
        runFor (0.05, 0, 0);
        const bool cleared = lp.getState (1) == S::empty && ! lp.hasAudio (1) && lp.getLoopLength() == L;
        lp.pressTrack (1);
        runFor (0.05, 0, 0);
        check (cleared && lp.getState (1) == S::recording, T ("清除第 2 轨后循环长度不变，还能重新录"));

        // 全部清除
        lp.clearAll();
        runFor (0.05, 0, 0);
        bool allEmpty = lp.getLoopLength() == 0;
        for (int t = 0; t < Looper::numTracks; ++t) allEmpty = allEmpty && lp.getState (t) == S::empty;
        check (allEmpty, T ("全部清除"));

        // 跟鼓机对齐：120 BPM 4/4，一小节 2 秒；录 3.3 秒 → 取整成 2 小节（4 秒），而且等到小节第一拍才开始录
        auto& drums = engine.getDrums();
        drums.setStyle (0);
        drums.setBpm (120.0f);
        drums.setCountIn (false);
        drums.setVolumeDb (-60.0f);
        drums.setPlaying (true);
        lp.setSyncToDrums (true);
        runFor (0.5, 0, 0);
        lp.pressTrack (0);
        runFor (0.02, 0, 0);
        const bool armed = lp.getState (0) == S::armed;
        runFor (2.0, 0, 0);                   // 最多等一小节
        const bool started = lp.getState (0) == S::recording;
        runFor (3.3 - 0.02, 220.0, 0.3f);
        lp.pressTrack (0);
        runFor (0.02, 0, 0);
        check (armed && started && lp.getLoopLength() == (int) std::lround (4.0 * sr),
               T ("跟鼓机对齐：先等小节第一拍，长度取整到 2 小节（") + juce::String (lp.getLoopLength() / sr, 3) + T (" 秒）"));
        drums.setPlaying (false);
    }

    std::printf ("\n== 18c. 音频伴奏（导入 WAV、播放、A-B 循环、变速、换文件）\n");
    {
        const auto dir = juce::File::getSpecialLocation (juce::File::tempDirectory).getChildFile ("lianqin_backing_test");
        dir.createDirectory();
        const auto wav = dir.getChildFile ("b.wav");
        {
            juce::AudioBuffer<float> b (1, 22050 * 4);      // 4 秒，单声道 22.05 kHz，第 2 秒开始是 880 Hz
            for (int i = 0; i < b.getNumSamples(); ++i)
                b.setSample (0, i, 0.5f * (float) std::sin (2.0 * juce::MathConstants<double>::pi * (i < 22050 * 2 ? 440.0 : 880.0) * i / 22050.0));
            wav.deleteFile();
            juce::WavAudioFormat fmt;
            if (auto os = wav.createOutputStream())
                if (auto w = std::unique_ptr<juce::AudioFormatWriter> (fmt.createWriterFor (os.get(), 22050.0, 1, 16, {}, 0)))
                {
                    os.release();
                    w->writeFromAudioSampleBuffer (b, 0, b.getNumSamples());
                }
        }
        BackingTrack bt;
        bt.setDeviceSampleRate (48000.0);
        juce::String err;
        check (bt.loadNow (wav, err) && bt.getClip() != nullptr && std::abs (bt.getClip()->lengthSeconds() - 4.0) < 0.01,
               juce::String::fromUTF8 ("载入单声道 22.05 kHz WAV（") + err + ")");
        juce::String bad;
        check (! bt.loadNow (dir.getChildFile ("nope.mp3"), bad) && bad.isNotEmpty() && bt.getClip() != nullptr,
               juce::String::fromUTF8 ("打不开的文件给出原因、不影响现在的伴奏：") + bad);
        bt.setGainDb (0.0f);
        std::vector<float> l (480), r (480);
        auto run = [&] (double seconds)
        {
            float pk = 0.0f;
            for (int k = 0; k < (int) (seconds * 100); ++k)
            {
                std::fill (l.begin(), l.end(), 0.0f); std::fill (r.begin(), r.end(), 0.0f);
                bt.process (l.data(), r.data(), 480);
                for (int i = 0; i < 480; ++i) pk = juce::jmax (pk, std::abs (l[(size_t) i]));
            }
            return pk;
        };
        check (run (0.2) < 1.0e-6f, juce::String::fromUTF8 ("没按播放时没声音"));
        bt.setPlaying (true);
        const float pk = run (1.0);
        check (pk > 0.4f && pk < 0.6f && std::abs (bt.getPositionSeconds() - 1.0) < 0.02,
               juce::String::fromUTF8 ("播放 1 秒：电平 ") + juce::String (pk, 2) + juce::String::fromUTF8 ("，位置 ") + juce::String (bt.getPositionSeconds(), 3) + " s");
        // 频率对不对（采样率换算）：数过零点
        {
            std::fill (l.begin(), l.end(), 0.0f); std::fill (r.begin(), r.end(), 0.0f);
            bt.process (l.data(), r.data(), 480);
            int zc = 0;
            for (int i = 1; i < 480; ++i) zc += (l[(size_t) i - 1] < 0.0f) != (l[(size_t) i] < 0.0f);
            check (std::abs (zc - 8.8) <= 1.5, juce::String::fromUTF8 ("44.1/22.05 kHz 换算到 48 kHz 音高正确（10 ms 里过零 ") + juce::String (zc) + juce::String::fromUTF8 (" 次，应约 8.8）"));
        }
        bt.setLoopRange (2.5, 3.0);
        bt.seekSeconds (2.5);
        run (1.3);
        const double p = bt.getPositionSeconds();
        check (p >= 2.5 && p <= 3.0, juce::String::fromUTF8 ("A-B 循环一直在 2.5–3.0 秒里转（现在 ") + juce::String (p, 2) + " s)");
        bt.clearLoopRange();
        bt.setLoopWhole (false);
        bt.setSpeed (0.5f);
        bt.seekSeconds (3.5);
        run (0.5);
        check (std::abs (bt.getPositionSeconds() - 3.75) < 0.02, juce::String::fromUTF8 ("半速：0.5 秒走 0.25 秒（") + juce::String (bt.getPositionSeconds(), 3) + ")");
        run (1.0);
        check (! bt.isPlaying(), juce::String::fromUTF8 ("不循环时放完自动停"));
        bt.setSpeed (1.0f);
        bt.setLoopWhole (true);
        bt.seekSeconds (3.9);
        bt.setPlaying (true);
        run (0.3);
        check (bt.isPlaying() && bt.getPositionSeconds() < 0.3, juce::String::fromUTF8 ("整首循环：放完回到开头"));
        // 播放中换文件：旧片段等音频线程走过以后才释放
        check (bt.loadNow (wav, err), juce::String::fromUTF8 ("播放中换一个文件"));
        run (0.05);
        bt.collectGarbage();
        check (! bt.isPlaying(), juce::String::fromUTF8 ("换文件后先停下"));
        dir.deleteRecursively();
    }

    std::printf ("\n== 19. 速度阶梯 / 练习记录\n");
    {
        SpeedTrainer t;
        t.enabled = true; t.start = 0.6f; t.step = 0.1f; t.target = 0.8f; t.passesPerStep = 2; t.needAccuracy = 0.9f;
        t.restart();
        const bool a = ! t.onPass (0.95f);            // 第 1 遍过
        const bool b = t.onPass (0.92f);              // 第 2 遍过 -> 70%
        const bool c = ! t.onPass (0.80f);            // 没达标，重新数
        const bool d = ! t.onPass (0.95f) && t.onPass (0.95f);   // 再过两遍 -> 80%
        const bool e = t.finished() && ! t.onPass (1.0f);
        check (a && b && c && d && e && std::abs (t.current - 0.8f) < 1.0e-4f,
               juce::String::fromUTF8 ("命中率够才提速、不够重新数、到目标停：") + juce::String (juce::roundToInt (t.current * 100.0f)) + "%");
        SpeedTrainer t2; t2.enabled = true; t2.start = 0.5f; t2.step = 0.25f; t2.target = 1.0f; t2.passesPerStep = 1; t2.restart();
        t2.onPass (-1.0f); t2.onPass (-1.0f);
        check (std::abs (t2.current - 1.0f) < 1.0e-4f, juce::String::fromUTF8 ("没开判定时只数遍数"));

        const auto f = juce::File::createTempFile ("json");
        {
            PracticeLog pl (f);
            pl.addTime ("C:/tabs/a.gp5", "Song A", 90.0);
            pl.addTime ("C:/tabs/a.gp5", "Song A", 30.0);
            pl.addTime ("C:/tabs/b.gp5", "Song B", 60.0);
            pl.addPass ("C:/tabs/a.gp5", "Song A", 0.8f, 1.0f);
            pl.addPass ("C:/tabs/a.gp5", "Song A", 0.95f, 0.8f);   // 慢速的不算“原速最好”
            pl.save();
        }
        PracticeLog back (f);
        const auto& songs = back.getSongs();
        const bool ok = songs.size() == 2 && std::abs (songs[0].seconds - 120.0) < 1.0 && songs[0].sessions == 1
                        && songs[0].passes.size() == 2 && std::abs (songs[0].best - 0.8f) < 1.0e-3f
                        && std::abs (back.secondsOnDay (juce::Time::getCurrentTime()) - 180.0) < 1.0 && back.streakDays() == 1;
        check (ok, juce::String::fromUTF8 ("练习记录存盘再读回：今天 ") + juce::String (back.secondsOnDay (juce::Time::getCurrentTime()), 0)
                   + juce::String::fromUTF8 (" 秒，连续 ") + juce::String (back.streakDays()) + juce::String::fromUTF8 (" 天"));
        f.deleteFile();
    }

    if (argc > 3)
    {
        std::printf ("\n== 15. 全部音轨合奏 + 混音\n");
        juce::String err;
        auto loaded = loadSongFile (juce::File (argv[3]), err);
        if (loaded != nullptr)
        {
            std::shared_ptr<const Song> song (loaded.release());
            auto rms = [&] (int track, bool demo, std::function<void (TabPlayer&)> mixFn)
            {
                AudioEngine engine;
                engine.prepareForOffline (sr, block);
                engine.setOutputGainDb (-60.0f);
                auto& tp = engine.getTabPlayer();
                tp.setSong (song);
                tp.setTrack (track);
                tp.setCountIn (false);
                tp.setDemoOn (demo);
                tp.setBackingVolumeDb (0.0f);
                if (mixFn) mixFn (tp);
                tp.seek (song->bars[(size_t) juce::jmin ((int) song->bars.size() - 1, 20)].start);
                tp.setPlaying (true);
                std::vector<float> in ((size_t) (sr * 4.0), 0.0f), l (in.size()), r (in.size());
                engine.processOffline (in.data(), l.data(), r.data(), (int) in.size());
                double sum = 0.0;
                for (size_t i = (size_t) (sr * 0.5); i < l.size(); ++i) sum += (double) l[i] * l[i] + (double) r[i] * r[i];
                return juce::Decibels::gainToDecibels ((float) std::sqrt (sum / (2.0 * (l.size() - sr * 0.5))), -120.0f);
            };
            const float all = rms (-1, false, nullptr);
            const float allMuted = rms (-1, false, [&] (TabPlayer& tp) { for (size_t t = 0; t < song->tracks.size(); ++t) tp.setTrackGain ((int) t, 0.0f); });
            const int dt = song->defaultTrack();
            const float oneSolo = rms (-1, false, [&] (TabPlayer& tp) { for (size_t t = 0; t < song->tracks.size(); ++t) tp.setTrackGain ((int) t, (int) t == dt ? 1.0f : 0.0f); });
            check (all > -50.0f, juce::String::fromUTF8 ("合奏模式（示范音关着）所有音轨都在响：") + juce::String (all, 1) + " dB");
            check (allMuted < -90.0f, juce::String::fromUTF8 ("全部静音后没有声音：") + juce::String (allMuted, 1) + " dB");
            check (oneSolo > -60.0f && oneSolo < all, juce::String::fromUTF8 ("只留一条音轨时声音变小：") + juce::String (oneSolo, 1) + " dB");
            check (JudgeSession (song, -1).events.empty(), juce::String::fromUTF8 ("合奏模式不判定"));
        }
    }

    std::printf ("\n%s：%d 项失败\n", failures == 0 ? "全部通过" : "有失败", failures);
    return failures == 0 ? 0 : 1;
}
