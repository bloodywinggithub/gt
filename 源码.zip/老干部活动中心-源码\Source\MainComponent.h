#pragma once

#include <juce_audio_utils/juce_audio_utils.h>
#include "AudioEngine.h"
#include "PitchDetector.h"
#include "ui/ScalesPanel.h"
#include "Widgets.h"
#include "fx/EffectChain.h"
#include "ui/PedalBoard.h"
#include "ui/PresetBar.h"
#include "ui/DrumPanel.h"
#include "ui/LooperPanel.h"
#include "ui/BackingPanel.h"
#include "ui/ChordPanel.h"
#include "ui/PetView.h"
#include "ui/PedalEditor.h"
#include "ui/PracticePanel.h"
#include "ui/StatsView.h"

class MainComponent : public juce::Component,
                      public juce::FileDragAndDropTarget,
                      private juce::ChangeListener,
                      private juce::Timer
{
public:
    MainComponent();
    ~MainComponent() override;

    void paint (juce::Graphics&) override;
    void resized() override;
    bool keyPressed (const juce::KeyPress&) override;

    bool isInterestedInFileDrag (const juce::StringArray& files) override;
    void filesDropped (const juce::StringArray& files, int x, int y) override;

    enum class View { tone, practice, stats, scales, chords };
    void setView (View v);
    PracticePanel& getPracticePanel()    { return *practicePanel; }
    void showDockTab (int t)             { setDockTab (t); }     // 截图 / 测试用
    PetView& getPet()                    { return pet; }
    ChordPanel& getChordPanel()          { return *chordPanel; }
    ScalesPanel& getScalesPanel()        { return *scalesPanel; }
    AudioEngine& getEngine()             { return engine; }

private:
    void changeListenerCallback (juce::ChangeBroadcaster*) override;
    void timerCallback() override;

    void openAudioSettings();
    void showPedalEditor (EffectSlotPtr slot);
    void closePedalEditor();
    void openPluginManager();
    void refreshInputChannelList();
    void refreshStatus();
    void saveSettings();

    juce::ApplicationProperties appProperties;
    juce::AudioDeviceManager deviceManager;
    AudioEngine engine;
    EffectChain chain { engine };
    PitchDetector pitchDetector;
    std::vector<float> tunerBuffer;
    juce::Array<int> channelForComboId;

    juce::Label titleLabel, authorLabel, statusLabel, latencyLabel, hintLabel;
    juce::TextButton settingsButton;
    juce::Label channelLabel, inputGainLabel, outputGainLabel;
    juce::ComboBox channelBox;
    juce::Slider inputGainSlider, outputGainSlider;
    juce::ToggleButton monitorToggle;
    LevelMeter inputMeter, outputMeter;
    TunerDisplay tuner;

    std::unique_ptr<PresetBar> presetBar;
    std::unique_ptr<PedalBoard> pedalBoard;
    std::unique_ptr<DrumPanel> drumPanel;
    // 音色页 / 指板音阶页下面的停靠栏：鼓机 / 五轨循环 / 音频伴奏 三选一
    std::unique_ptr<LooperPanel> dockLooper;
    std::unique_ptr<BackingPanel> backingPanel;
    juce::TextButton dockDrumsButton, dockLoopButton, dockBackingButton;
    int dockTab = 0;          // 0 鼓机，1 循环，2 伴奏
    void setDockTab (int t);
    void updateDockVisibility();
    std::unique_ptr<PedalEditorOverlay> pedalOverlay;
    std::unique_ptr<PracticePanel> practicePanel;
    juce::TextButton toneViewButton, practiceViewButton, scalesViewButton, chordsViewButton, statsViewButton;
    std::unique_ptr<ScalesPanel> scalesPanel;
    std::unique_ptr<ChordPanel> chordPanel;
    PracticeLog practiceLog { PracticeLog::defaultFile() };
    std::unique_ptr<StatsView> statsView;
    PetView pet;
    uint32_t petSeenSeq = 0;
    const JudgeSession* petSession = nullptr;
    int petLastComboShown = 0;
    void feedPet (float inputPeak);
    View view = View::tone;
    juce::Label chainLabel;

    juce::Rectangle<int> leftPanel, fxPanel, drumPanelArea, practiceArea;
    int frameCounter = 0;
    bool chainDirty = false;

    juce::TooltipWindow tooltips { this, 600 };

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (MainComponent)
};
