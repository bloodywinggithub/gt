#pragma once

#include <juce_gui_basics/juce_gui_basics.h>

// 谱库：把“吉他谱”文件夹（包括单独下载的谱库包解压进来的子文件夹）里的 Guitar Pro 谱子
// 列出来，可以按分类（第一层文件夹）筛选、输入歌名 / 歌手搜索，双击打开。
class TabLibraryBox : public juce::Component,
                      private juce::ListBoxModel,
                      private juce::TextEditor::Listener
{
public:
    struct Entry { juce::File file; juce::String name, folder, category, searchKey; };

    TabLibraryBox (juce::Array<juce::File> roots, juce::String lastCategory);

    std::function<void (const juce::File&)> onOpen;
    std::function<void (const juce::String&)> onCategoryChanged;

    static std::vector<Entry> scan (const juce::Array<juce::File>& roots);
    int getNumMatches() const                { return (int) matches.size(); }
    int getNumEntries() const                { return (int) entries.size(); }
    void setFilter (const juce::String& text);   // 测试用

    void paint (juce::Graphics&) override;
    void resized() override;

private:
    int getNumRows() override                { return (int) matches.size(); }
    void paintListBoxItem (int row, juce::Graphics&, int w, int h, bool selected) override;
    void listBoxItemDoubleClicked (int row, const juce::MouseEvent&) override;
    void returnKeyPressed (int row) override;
    void textEditorTextChanged (juce::TextEditor&) override;
    void textEditorReturnKeyPressed (juce::TextEditor&) override;
    void refilter();

    juce::Array<juce::File> roots;
    std::vector<Entry> entries;
    std::vector<int> matches;
    juce::Label title, hint;
    juce::TextEditor search;
    juce::ComboBox category;
    juce::ListBox list { {}, this };
    juce::TextButton openFolderButton, openButton;
    juce::StringArray categories;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (TabLibraryBox)
};
