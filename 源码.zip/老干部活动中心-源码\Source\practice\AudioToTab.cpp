#include "AudioToTab.h"
#include "ChordLibrary.h"
#include "Text.h"
#include <juce_dsp/juce_dsp.h>
#include <cmath>
#include <numeric>
#include <map>

#if JUCE_WINDOWS
 #include <windows.h>
#elif JUCE_MAC
 #include <CoreFoundation/CoreFoundation.h>
#endif

namespace
{
    constexpr double analysisRate = 22050.0;
    constexpr int frameLen = 2048;
    constexpr int fftOrder = 12;            // 4096 点（补零）
    constexpr int hop = 256;                // ≈ 11.6 ms
    constexpr int binsPerSemi = 5;          // 音高格子：20 音分
    const std::array<int, 6> stdTuning { 64, 59, 55, 50, 45, 40 };   // [0] = 1 弦

    double midiHz (double m) { return 440.0 * std::pow (2.0, (m - 69.0) / 12.0); }

    float percentile (std::vector<float> v, float p)
    {
        if (v.empty()) return 0.0f;
        const size_t k = (size_t) juce::jlimit (0, (int) v.size() - 1, (int) (p * (float) (v.size() - 1)));
        std::nth_element (v.begin(), v.begin() + (long) k, v.end());
        return v[k];
    }

    bool report (const AudioToTab::Options& o, float p, const char* stage)
    {
        return ! o.progress || o.progress (p, T (stage));
    }
}

// =============================================================================
std::vector<float> AudioToTab::mixdown (const juce::AudioBuffer<float>& audio, double sr, Source src, double target,
                                        double startSec, double endSec)
{
    const int total = audio.getNumSamples();
    const int s0 = juce::jlimit (0, total, (int) (startSec * sr));
    const int s1 = endSec > startSec ? juce::jlimit (s0, total, (int) (endSec * sr)) : total;
    const int n = s1 - s0;
    std::vector<float> mono ((size_t) juce::jmax (0, n));
    const float* l = audio.getReadPointer (0);
    const float* r = audio.getReadPointer (juce::jmin (1, audio.getNumChannels() - 1));
    for (int i = 0; i < n; ++i)
    {
        const float a = l[s0 + i], b = r[s0 + i];
        switch (src)
        {
            case Source::mix:   mono[(size_t) i] = 0.5f * (a + b); break;
            case Source::left:  mono[(size_t) i] = a; break;
            case Source::right: mono[(size_t) i] = b; break;
            case Source::side:  mono[(size_t) i] = 0.5f * (a - b); break;
        }
    }
    if (std::abs (sr - target) < 1.0)
        return mono;
    const double ratio = sr / target;
    std::vector<float> out ((size_t) ((double) n / ratio));
    juce::LagrangeInterpolator interp;
    interp.process (ratio, mono.data(), out.data(), (int) out.size(), (int) mono.size(), 0);
    return out;
}

// =============================================================================
double AudioToTab::estimateTempo (const std::vector<float>& env, double fps, double& firstBeat)
{
    const int n = (int) env.size();
    firstBeat = 0.0;
    if (n < (int) (fps * 4.0)) return 120.0;
    std::vector<float> e (env);
    const float mean = std::accumulate (e.begin(), e.end(), 0.0f) / (float) n;
    for (auto& x : e) x = juce::jmax (0.0f, x - mean);

    auto ac = [&] (double lag)
    {
        // 小数延迟：线性插值
        double sum = 0.0;
        const int L = (int) lag;
        const double f = lag - L;
        for (int i = 0; i + L + 1 < n; ++i)
            sum += e[(size_t) i] * (e[(size_t) (i + L)] * (1.0 - f) + e[(size_t) (i + L + 1)] * f);
        return sum;
    };
    double bestLag = fps * 0.5, bestScore = -1.0;
    for (double bpm = 60.0; bpm <= 200.0; bpm += 0.5)
    {
        const double lag = fps * 60.0 / bpm;
        // 偏好 80–140 BPM（常见的拍），同时看两倍、一半的周期
        const double w = std::exp (-0.5 * std::pow (std::log2 (bpm / 110.0) / 0.9, 2.0));
        const double sc = w * (ac (lag) + 0.5 * ac (lag * 2.0) + 0.25 * ac (lag * 4.0));
        if (sc > bestScore) { bestScore = sc; bestLag = lag; }
    }
    // 相位：拍点上的起音能量最大
    double bestPhase = 0.0, bestSum = -1.0;
    for (double ph = 0.0; ph < bestLag; ph += 0.5)
    {
        double sum = 0.0;
        for (double t = ph; t < n - 1; t += bestLag)
        {
            const int i = (int) t;
            sum += e[(size_t) i] * (1.0 - (t - i)) + e[(size_t) i + 1] * (t - i);
        }
        if (sum > bestSum) { bestSum = sum; bestPhase = ph; }
    }
    firstBeat = bestPhase / fps;
    return 60.0 * fps / bestLag;
}

std::vector<double> AudioToTab::trackBeats (const std::vector<float>& env, double fps, double bpm, double tightness)
{
    std::vector<double> beats;
    const int n = (int) env.size();
    const double period = fps * 60.0 / juce::jlimit (30.0, 300.0, bpm);
    if (n < (int) (period * 3.0)) return beats;
    // 起音曲线：去均值、除以标准差，再用很窄的高斯平滑一下
    std::vector<double> o ((size_t) n);
    double mean = 0.0, var = 0.0;
    for (auto x : env) mean += x;
    mean /= n;
    for (auto x : env) var += (x - mean) * (x - mean);
    const double sd = std::sqrt (var / n) + 1.0e-9;
    const int hw = juce::jmax (1, (int) std::round (period / 32.0));
    for (int t = 0; t < n; ++t)
    {
        double acc = 0.0, wsum = 0.0;
        for (int k = -2 * hw; k <= 2 * hw; ++k)
        {
            const int i = t + k;
            if (i < 0 || i >= n) continue;
            const double w = std::exp (-0.5 * (k * k) / (double) (hw * hw));
            acc += w * (env[(size_t) i] - mean) / sd;
            wsum += w;
        }
        o[(size_t) t] = acc / wsum;
    }
    // C[t] = o[t] + max_{p} (C[p] − 紧度 × log²((t−p)/周期))
    std::vector<double> C ((size_t) n);
    std::vector<int> back ((size_t) n, -1);
    const int lo = (int) std::round (period * 0.5), hi = (int) std::round (period * 2.0);
    for (int t = 0; t < n; ++t)
    {
        double best = -1.0e30; int arg = -1;
        for (int d = lo; d <= hi; ++d)
        {
            const int p = t - d;
            if (p < 0) break;
            const double lg = std::log ((double) d / period);
            const double v = C[(size_t) p] - tightness * lg * lg;
            if (v > best) { best = v; arg = p; }
        }
        C[(size_t) t] = o[(size_t) t] + (arg >= 0 ? juce::jmax (0.0, best) : 0.0);
        back[(size_t) t] = arg >= 0 && best > 0.0 ? arg : -1;
    }
    // 从最后一个周期里分最高的那一点往回找
    int t = n - 1;
    double best = -1.0e30;
    for (int i = juce::jmax (0, n - (int) period); i < n; ++i)
        if (C[(size_t) i] > best) { best = C[(size_t) i]; t = i; }
    std::vector<int> frames;
    while (t >= 0) { frames.push_back (t); t = back[(size_t) t]; }
    std::reverse (frames.begin(), frames.end());
    for (int f : frames)
    {
        // 抛物线插值：比一帧（11.6 ms）更细一点
        double x = f;
        if (f > 0 && f < n - 1)
        {
            const double a = o[(size_t) f - 1], b = o[(size_t) f], c = o[(size_t) f + 1];
            const double den = a - 2.0 * b + c;
            if (std::abs (den) > 1.0e-9) x += juce::jlimit (-0.5, 0.5, 0.5 * (a - c) / den);
        }
        beats.push_back (x / fps);
    }
    return beats;
}

// =============================================================================
std::vector<AudioToTab::Fingered> AudioToTab::fingering (const std::vector<int>& midi, const std::vector<double>& starts,
                                                         const std::vector<bool>& bends, int capo)
{
    const int n = (int) midi.size();
    std::vector<Fingered> out ((size_t) n);
    if (n == 0) return out;
    constexpr int maxFret = 19;
    struct Cand { int string, fret; };
    std::vector<std::vector<Cand>> cands ((size_t) n);
    for (int i = 0; i < n; ++i)
    {
        for (int s = 0; s < 6; ++s)
        {
            const int f = midi[(size_t) i] - stdTuning[(size_t) s] - capo;
            if (f >= 0 && f <= maxFret) cands[(size_t) i].push_back ({ s, f });
        }
        if (cands[(size_t) i].empty())
        {
            // 超出吉他音域：折到最近的八度
            int m = midi[(size_t) i];
            while (m - capo < 40) m += 12;
            while (m - capo > 64 + maxFret) m -= 12;
            for (int s = 0; s < 6; ++s)
            {
                const int f = m - stdTuning[(size_t) s] - capo;
                if (f >= 0 && f <= maxFret) cands[(size_t) i].push_back ({ s, f });
            }
        }
    }
    auto own = [&] (int i, const Cand& c)
    {
        float cost = 0.0f;
        if (c.fret > 12) cost += 0.35f * (float) (c.fret - 12);
        if (c.fret == 0 && bends[(size_t) i]) cost += 50.0f;           // 空弦推不了
        if (c.fret > 0 && c.fret < 5) cost -= 0.1f;                    // 低把位稍微优先
        return cost;
    };
    // 状态：候选位置；“手的位置” = 按着的品（空弦不改变手的位置）
    std::vector<std::vector<float>> cost ((size_t) n);
    std::vector<std::vector<int>> back ((size_t) n), hand ((size_t) n);
    for (int i = 0; i < n; ++i)
    {
        const auto& cs = cands[(size_t) i];
        cost[(size_t) i].assign (cs.size(), 1.0e9f);
        back[(size_t) i].assign (cs.size(), -1);
        hand[(size_t) i].assign (cs.size(), 0);
        for (size_t k = 0; k < cs.size(); ++k)
        {
            if (cs.empty()) break;
            if (i == 0 || cands[(size_t) i - 1].empty())
            {
                cost[(size_t) i][k] = own (i, cs[k]);
                hand[(size_t) i][k] = cs[k].fret > 0 ? cs[k].fret : 3;
                continue;
            }
            const double gap = starts[(size_t) i] - starts[(size_t) i - 1];
            const float moveW = gap > 1.0 ? 0.15f : (gap > 0.4 ? 0.5f : 1.0f);   // 隔得久，换把位便宜
            const auto& ps = cands[(size_t) i - 1];
            for (size_t j = 0; j < ps.size(); ++j)
            {
                const int h = hand[(size_t) i - 1][j];
                float c = cost[(size_t) i - 1][j] + own (i, cs[k]);
                if (cs[k].fret > 0)
                {
                    const int d = std::abs (cs[k].fret - h);
                    c += moveW * (0.25f * (float) d + (d > 3 ? 1.2f * (float) (d - 3) : 0.0f));
                }
                c += 0.12f * (float) std::abs (cs[k].string - ps[j].string);
                if (cs[k].string == ps[j].string && gap < 0.08) c += 0.3f;   // 很快的音别挤在同一根弦上来回
                if (c < cost[(size_t) i][k])
                {
                    cost[(size_t) i][k] = c;
                    back[(size_t) i][k] = (int) j;
                    hand[(size_t) i][k] = cs[k].fret > 0 ? cs[k].fret : h;
                }
            }
        }
    }
    // 回溯
    int k = -1;
    float best = 1.0e9f;
    for (size_t j = 0; j < cost.back().size(); ++j)
        if (cost.back()[j] < best) { best = cost.back()[j]; k = (int) j; }
    for (int i = n - 1; i >= 0; --i)
    {
        if (k < 0 || cands[(size_t) i].empty())
        {
            out[(size_t) i] = { 5, juce::jmax (0, midi[(size_t) i] - 40 - capo) };
            k = -1;
            if (i > 0)
            {
                best = 1.0e9f;
                for (size_t j = 0; j < cost[(size_t) i - 1].size(); ++j)
                    if (cost[(size_t) i - 1][j] < best) { best = cost[(size_t) i - 1][j]; k = (int) j; }
            }
            continue;
        }
        out[(size_t) i] = { cands[(size_t) i][(size_t) k].string, cands[(size_t) i][(size_t) k].fret };
        k = back[(size_t) i][(size_t) k];
    }
    return out;
}

// =============================================================================
AudioToTab::Result AudioToTab::transcribe (const juce::AudioBuffer<float>& audio, double sr, const Options& opt)
{
    if (opt.useAi && opt.mode != Options::Mode::melody)
    {
        auto r = transcribePoly (audio, sr, opt);
        if (r.song != nullptr || r.cancelled || (r.error.isNotEmpty() && ! r.error.startsWith ("#fallback")))
            return r;
        auto m = transcribeMelody (audio, sr, opt);
        if (m.song != nullptr)
            m.summary = T ("没有找到 AI 识别模块（") + r.error.fromFirstOccurrenceOf ("#fallback ", false, false)
                      + T ("），用的是单音算法：只扒主旋律。") + m.summary;
        return m;
    }
    return transcribeMelody (audio, sr, opt);
}

AudioToTab::Result AudioToTab::transcribeMelody (const juce::AudioBuffer<float>& audio, double sr, const Options& opt)
{
    Result res;
    if (audio.getNumSamples() < (int) (sr * 1.0) || sr <= 0.0)
    {
        res.error = T ("音频太短了（至少要 1 秒）");
        return res;
    }
    if (! report (opt, 0.02f, "准备音频…")) { res.cancelled = true; return res; }
    const double offset = juce::jmax (0.0, opt.startSeconds);
    auto x = mixdown (audio, sr, opt.source, analysisRate, opt.startSeconds, opt.endSeconds);
    const int numFrames = (int) x.size() > frameLen ? 1 + ((int) x.size() - frameLen) / hop : 0;
    if (numFrames < 20)
    {
        res.error = T ("选的这一段太短了");
        return res;
    }

    // ---- 1. 逐帧频谱：谐波和显著度、起音、色度 ----------------------------------------
    juce::dsp::FFT fft (fftOrder);
    const int N = fft.getSize();
    const double binHz = analysisRate / N;
    std::vector<float> win ((size_t) frameLen);
    for (int i = 0; i < frameLen; ++i) win[(size_t) i] = 0.5f - 0.5f * std::cos (juce::MathConstants<float>::twoPi * (float) i / (float) frameLen);

    const int lo = juce::jlimit (28, 100, opt.lowestMidi) * binsPerSemi;
    const int hi = juce::jlimit (lo / binsPerSemi + 6, 108, opt.highestMidi) * binsPerSemi;
    const int states = hi - lo + 1;
    std::vector<float> sal ((size_t) numFrames * (size_t) states);
    std::vector<float> frameMax ((size_t) numFrames), energy ((size_t) numFrames), flux ((size_t) numFrames);
    std::vector<std::array<float, 12>> chroma ((size_t) numFrames), bassChroma ((size_t) numFrames);
    std::vector<float> buf ((size_t) N * 2), spec ((size_t) N / 2), prevLog ((size_t) N / 2, 0.0f);

    // 每个候选音高的谐波在频谱上的位置（预先算好）
    constexpr int numHarm = 8;
    std::vector<std::array<float, numHarm>> harmBin ((size_t) states);
    for (int c = 0; c < states; ++c)
    {
        const double f0 = midiHz ((double) (lo + c) / binsPerSemi);
        for (int h = 0; h < numHarm; ++h)
        {
            const double f = f0 * (h + 1);
            harmBin[(size_t) c][(size_t) h] = f < analysisRate * 0.45 ? (float) (f / binHz) : -1.0f;
        }
    }
    std::vector<int> binPc ((size_t) N / 2, -1);
    std::vector<bool> binBass ((size_t) N / 2, false);
    for (int k = 1; k < N / 2; ++k)
    {
        const double f = k * binHz;
        if (f < 60.0 || f > 2200.0) continue;
        const int m = juce::roundToInt (69.0 + 12.0 * std::log2 (f / 440.0));
        binPc[(size_t) k] = ((m % 12) + 12) % 12;
        binBass[(size_t) k] = f < 260.0;
    }

    for (int t = 0; t < numFrames; ++t)
    {
        if ((t & 255) == 0 && ! report (opt, 0.05f + 0.45f * (float) t / (float) numFrames, "分析频谱…"))
        {
            res.cancelled = true;
            return res;
        }
        std::fill (buf.begin(), buf.end(), 0.0f);
        const float* src = x.data() + (size_t) t * hop;
        for (int i = 0; i < frameLen; ++i) buf[(size_t) i] = src[i] * win[(size_t) i];
        fft.performFrequencyOnlyForwardTransform (buf.data(), true);
        float e = 0.0f, fl = 0.0f;
        for (int k = 0; k < N / 2; ++k)
        {
            const float m = buf[(size_t) k];
            spec[(size_t) k] = std::sqrt (m);                  // 压缩一下动态
            const double f = k * binHz;
            if (f > 60.0 && f < 4000.0) e += m * m;
            const float lg = std::log1p (100.0f * m);
            if (f > 40.0) fl += juce::jmax (0.0f, lg - prevLog[(size_t) k]);
            prevLog[(size_t) k] = lg;
            if (binPc[(size_t) k] >= 0)
            {
                chroma[(size_t) t][(size_t) binPc[(size_t) k]] += m * m;
                if (binBass[(size_t) k]) bassChroma[(size_t) t][(size_t) binPc[(size_t) k]] += m * m;
            }
        }
        energy[(size_t) t] = 10.0f * std::log10 (e + 1.0e-12f);
        flux[(size_t) t] = fl;

        auto at = [&] (float b)
        {
            const int k = (int) b;
            if (k < 1 || k + 1 >= N / 2) return 0.0f;
            return juce::jmax (spec[(size_t) k], spec[(size_t) k + 1]);
        };
        float mx = 0.0f;
        float* row = sal.data() + (size_t) t * states;
        for (int c = 0; c < states; ++c)
        {
            float sum = 0.0f, w = 1.0f;
            for (int h = 0; h < numHarm; ++h)
            {
                const float b = harmBin[(size_t) c][(size_t) h];
                if (b < 0.0f) break;
                sum += w * at (b);
                w *= 0.84f;
            }
            // 压一下“半个基频”的假峰：真基频处必须有能量
            sum *= 0.55f + 0.45f * juce::jmin (1.0f, at (harmBin[(size_t) c][0]) / (0.2f * sum + 1.0e-9f));
            // 主旋律一般是最高的那个声部：音越高稍微加一点分（两个八度约 +20%）
            sum *= 1.0f + 0.0085f * (float) c / (float) binsPerSemi;
            row[c] = sum;
            mx = juce::jmax (mx, sum);
        }
        frameMax[(size_t) t] = mx;
    }

    // ---- 2. 找主旋律：Viterbi --------------------------------------------------------
    if (! report (opt, 0.52f, "找主旋律…")) { res.cancelled = true; return res; }
    const float eRef = percentile (energy, 0.95f);
    const float salRef = percentile (frameMax, 0.9f);
    const int UV = states;                                  // 不发声状态
    std::vector<float> prev ((size_t) states + 1, 0.0f), cur ((size_t) states + 1);
    std::vector<int16_t> bp ((size_t) numFrames * (size_t) (states + 1));
    for (int t = 0; t < numFrames; ++t)
    {
        const float* row = sal.data() + (size_t) t * states;
        const bool loud = energy[(size_t) t] > eRef - 32.0f;
        const float rel = salRef > 0.0f ? frameMax[(size_t) t] / salRef : 0.0f;
        const float voicedCost = loud ? 0.0f : 4.0f;
        const float uvCost = loud ? juce::jlimit (0.0f, 4.0f, 6.0f * (rel - 0.12f)) : 0.0f;
        float globalMin = 1.0e9f; int globalArg = 0;
        for (int c = 0; c < states; ++c) if (prev[(size_t) c] < globalMin) { globalMin = prev[(size_t) c]; globalArg = c; }
        for (int c = 0; c < states; ++c)
        {
            const float em = voicedCost - std::log ((row[c] + 1.0e-6f) / (frameMax[(size_t) t] + 1.0e-6f) + 0.02f);
            float best = prev[(size_t) UV] + 1.5f;
            int arg = UV;
            for (int d = -3; d <= 3; ++d)
            {
                const int pc = c + d;
                if (pc < 0 || pc >= states) continue;
                const float tc = prev[(size_t) pc] + (std::abs (d) <= 1 ? 0.0f : 0.35f * (float) std::abs (d));
                if (tc < best) { best = tc; arg = pc; }
            }
            if (globalMin + 2.2f < best) { best = globalMin + 2.2f; arg = globalArg; }
            cur[(size_t) c] = best + em;
            bp[(size_t) t * (size_t) (states + 1) + (size_t) c] = (int16_t) arg;
        }
        {
            float best = prev[(size_t) UV]; int arg = UV;
            if (globalMin + 1.5f < best) { best = globalMin + 1.5f; arg = globalArg; }
            cur[(size_t) UV] = best + uvCost;
            bp[(size_t) t * (size_t) (states + 1) + (size_t) UV] = (int16_t) arg;
        }
        // 归一化，防止数越来越大
        const float m0 = *std::min_element (cur.begin(), cur.end());
        for (auto& v : cur) v -= m0;
        std::swap (prev, cur);
    }
    std::vector<int> path ((size_t) numFrames);
    {
        int s = (int) (std::min_element (prev.begin(), prev.end()) - prev.begin());
        for (int t = numFrames - 1; t >= 0; --t)
        {
            path[(size_t) t] = s;
            s = bp[(size_t) t * (size_t) (states + 1) + (size_t) s];
        }
    }
    std::vector<float> pitch ((size_t) numFrames, -1.0f);      // MIDI（带小数），-1 = 不发声
    for (int t = 0; t < numFrames; ++t)
        if (path[(size_t) t] != UV) pitch[(size_t) t] = (float) (lo + path[(size_t) t]) / (float) binsPerSemi;

    // ---- 3. 起音 + 切音 -------------------------------------------------------------
    if (! report (opt, 0.62f, "切分音符…")) { res.cancelled = true; return res; }
    std::vector<bool> onset ((size_t) numFrames, false);
    for (int t = 2; t < numFrames - 2; ++t)
    {
        float med = 0.0f;
        {
            std::vector<float> w;
            for (int k = juce::jmax (0, t - 10); k <= juce::jmin (numFrames - 1, t + 10); ++k) w.push_back (flux[(size_t) k]);
            med = percentile (w, 0.5f);
        }
        if (flux[(size_t) t] > med * 1.6f + 0.02f * percentile (flux, 0.99f) && flux[(size_t) t] >= flux[(size_t) t - 1] && flux[(size_t) t] >= flux[(size_t) t + 1])
            onset[(size_t) t] = true;
    }
    for (int t = 1; t < numFrames; ++t)          // 起音之间至少隔 45 ms
        if (onset[(size_t) t])
            for (int k = t + 1; k < juce::jmin (numFrames, t + 4); ++k) onset[(size_t) k] = false;

    const double fps = analysisRate / hop;
    const double frameSec = 1.0 / fps;
    const double latency = (frameLen * 0.5) / analysisRate;       // 帧的中心
    struct Seg { int a, b; bool startsWithOnset; };
    std::vector<Seg> segs;
    {
        int start = -1;
        bool startOn = false;
        for (int t = 0; t <= numFrames; ++t)
        {
            const bool voiced = t < numFrames && pitch[(size_t) t] > 0.0f;
            bool cut = ! voiced;
            if (voiced && start >= 0 && t - start >= 3)
            {
                if (onset[(size_t) t]) cut = true;
                // 音高突然跳了（不是慢慢滑过去）
                const float d = pitch[(size_t) t] - pitch[(size_t) t - 1];
                const float d2 = t >= 2 && pitch[(size_t) t - 2] > 0.0f ? pitch[(size_t) t - 1] - pitch[(size_t) t - 2] : 0.0f;
                if (std::abs (d) > 0.7f && std::abs (d2) < 0.35f) cut = true;
            }
            if (cut && start >= 0)
            {
                segs.push_back ({ start, t, startOn });
                start = -1;
            }
            if (voiced && start < 0)
            {
                start = t;
                startOn = false;
                for (int k = juce::jmax (0, t - 2); k <= juce::jmin (numFrames - 1, t + 1); ++k) startOn = startOn || onset[(size_t) k];
            }
        }
    }

    std::vector<DetectedNote> notes;
    for (auto& sg : segs)
    {
        const int len = sg.b - sg.a;
        if (len < 6) continue;                              // 太短（< 70 ms）：多半是杂音
        // 音的基准音高：前 40% 里的中位数
        std::vector<float> head;
        for (int t = sg.a; t < sg.a + juce::jmax (2, len * 2 / 5); ++t) head.push_back (pitch[(size_t) t]);
        const float base = percentile (head, 0.5f);
        const int midi = juce::roundToInt (base);
        float mx = 0.0f; int mxAt = sg.a;
        for (int t = sg.a; t < sg.b; ++t)
            if (pitch[(size_t) t] - (float) midi > mx) { mx = pitch[(size_t) t] - (float) midi; mxAt = t; }
        DetectedNote dn;
        dn.start = offset + sg.a * frameSec + latency * 0.5;
        dn.end = offset + sg.b * frameSec + latency * 0.5;
        dn.midi = midi;
        // 真推弦是慢慢推上去的：中间要经过一些“半推”的音高；直接跳上去的是别的声部
        int between = 0;
        for (int t = sg.a; t < sg.b; ++t)
        {
            const float d = pitch[(size_t) t] - (float) midi;
            if (d > 0.3f && d < mx - 0.3f) ++between;
        }
        if (mx > 0.7f && len >= 8 && between >= 2)
        {
            dn.bend = juce::jlimit (0.5f, 3.0f, std::round (mx * 2.0f) / 2.0f);
            dn.bendPeak = (float) (mxAt - sg.a) / (float) len;
            dn.release = pitch[(size_t) sg.b - 1] - (float) midi < mx * 0.4f;
        }
        float st = 0.0f;
        for (int t = sg.a; t < sg.b; ++t) st += frameMax[(size_t) t];
        dn.strength = st / (float) len;
        dn.legato = ! sg.startsWithOnset;
        notes.push_back (dn);
    }
    // 同一个音被切开（中间没有起音）：合起来
    for (size_t i = 1; i < notes.size(); )
    {
        auto& p = notes[i - 1];
        auto& q = notes[i];
        if (q.midi == p.midi && q.legato && q.start - p.end < 0.05 && p.bend == 0.0f && q.bend == 0.0f)
        {
            p.end = q.end;
            notes.erase (notes.begin() + (long) i);
        }
        else ++i;
    }
    // 没有起音、和前一个音差得很远（超过 7 个半音）：不像击勾弦，多半是旋律停了以后露出来的伴奏 → 去掉
    for (size_t i = 1; i < notes.size(); )
    {
        if (notes[i].legato && std::abs (notes[i].midi - notes[i - 1].midi) > 7 && notes[i].end - notes[i].start < 0.5)
            notes.erase (notes.begin() + (long) i);
        else ++i;
    }
    // 第一个音没有前一个音，不可能是击弦
    if (! notes.empty()) notes.front().legato = false;
    for (size_t i = 1; i < notes.size(); ++i)
        if (notes[i].start - notes[i - 1].end > 0.08) notes[i].legato = false;
    if (notes.empty())
    {
        res.error = T ("没有找到清楚的单音旋律。可以换个声道（左 / 右 / 侧边）或者选一段 Solo 再试");
        return res;
    }
    res.notes = notes;

    // ---- 4. 速度、拍点 ----------------------------------------------------------------
    if (! report (opt, 0.72f, "估计速度…")) { res.cancelled = true; return res; }
    double firstBeat = 0.0;
    double bpm = estimateTempo (flux, fps, firstBeat);
    if (opt.bpm > 0.0)
    {
        bpm = opt.bpm;
        // 手动给了速度：只找相位
        const double lag = fps * 60.0 / bpm;
        double bestPhase = 0.0, bestSum = -1.0;
        for (double ph = 0.0; ph < lag; ph += 0.5)
        {
            double sum = 0.0;
            for (double t = ph; t < numFrames - 1; t += lag) sum += flux[(size_t) t];
            if (sum > bestSum) { bestSum = sum; bestPhase = ph; }
        }
        firstBeat = bestPhase / fps;
    }
    const double beatSec = 60.0 / bpm;
    firstBeat = offset + firstBeat + latency * 0.5;
    // 把第一拍挪到第一个音之前
    while (firstBeat > notes.front().start - beatSec * 0.25) firstBeat -= beatSec;
    // 强拍：每 4 拍里起音能量最大的那一拍当小节第一拍
    {
        std::array<double, 4> acc {};
        for (int t = 0; t < numFrames; ++t)
        {
            const double bt = (offset + t * frameSec + latency * 0.5 - firstBeat) / beatSec;
            const double frac = bt - std::round (bt);
            if (std::abs (frac) < 0.12) acc[(size_t) (((int) std::round (bt) % 4) + 4) % 4] += flux[(size_t) t];
        }
        const int down = (int) (std::max_element (acc.begin(), acc.end()) - acc.begin());
        firstBeat += down * beatSec;
        while (firstBeat > notes.front().start - beatSec * 0.25) firstBeat -= 4.0 * beatSec;
    }
    res.bpm = bpm;
    res.firstBeatSeconds = firstBeat;
    res.syncRate = std::round (bpm) / juce::jmax (1.0, bpm);

    // ---- 5. 和弦（每拍） ---------------------------------------------------------------
    const double lastEnd = notes.back().end;
    const int totalBeats = juce::jmax (4, (int) std::ceil ((lastEnd - firstBeat) / beatSec / 4.0) * 4);
    std::vector<int> beatChord ((size_t) totalBeats, -1);          // root * 3 + 类型（0 大三 1 小三 2 属七），-1 = 没有
    if (opt.chords)
    {
        if (! report (opt, 0.8f, "识别和弦…")) { res.cancelled = true; return res; }
        // 重新算一遍色度：去掉主旋律的谐波（不然旋律音会把和弦带偏），低频（伴奏、贝斯）权重大一些
        for (int t = 0; t < numFrames; ++t)
        {
            if ((t & 511) == 0 && ! report (opt, 0.8f + 0.06f * (float) t / (float) numFrames, "识别和弦…")) { res.cancelled = true; return res; }
            std::fill (buf.begin(), buf.end(), 0.0f);
            const float* src = x.data() + (size_t) t * hop;
            for (int i = 0; i < frameLen; ++i) buf[(size_t) i] = src[i] * win[(size_t) i];
            fft.performFrequencyOnlyForwardTransform (buf.data(), true);
            // 只有旋律在高音区（D4 以上，一般是独奏 / 主旋律）时才减掉它；低的“旋律”可能就是和弦的根音
            if (pitch[(size_t) t] >= 62.0f)
            {
                const double f0 = midiHz (pitch[(size_t) t]);
                for (int h = 1; h <= 8; ++h)
                {
                    const int k0 = (int) std::floor (f0 * h * 0.97 / binHz), k1 = (int) std::ceil (f0 * h * 1.03 / binHz);
                    for (int k = juce::jmax (0, k0); k <= juce::jmin (N / 2 - 1, k1); ++k) buf[(size_t) k] = 0.0f;
                }
            }
            auto& c = chroma[(size_t) t];
            auto& bc = bassChroma[(size_t) t];
            c.fill (0.0f); bc.fill (0.0f);
            // 多音高估计（一个个找出来，找到一个就把它的泛音从频谱里减掉），这样泛音不会被当成和弦音
            for (int k = 0; k < N / 2; ++k) buf[(size_t) k] = std::sqrt (buf[(size_t) k]);
            float first = 0.0f;
            int lowest = 999;
            for (int iter = 0; iter < 5; ++iter)
            {
                float best = 0.0f; int bestM = -1;
                for (int m = 36; m <= 76; ++m)
                {
                    const double f0 = midiHz (m);
                    float sum = 0.0f, w = 1.0f;
                    for (int h = 1; h <= 8; ++h)
                    {
                        const double f = f0 * h;
                        if (f > analysisRate * 0.45) break;
                        const int k0 = juce::jmax (1, (int) std::floor (f * 0.985 / binHz)), k1 = juce::jmin (N / 2 - 1, (int) std::ceil (f * 1.015 / binHz));
                        float pk = 0.0f;
                        for (int k = k0; k <= k1; ++k) pk = juce::jmax (pk, buf[(size_t) k]);
                        sum += w * pk;
                        w *= 0.8f;
                    }
                    // 基频本身要有峰（不然是“虚的”低音）
                    const int kf = (int) std::round (f0 / binHz);
                    const float fund = juce::jmax (buf[(size_t) juce::jmax (1, kf - 1)], buf[(size_t) kf], buf[(size_t) juce::jmin (N / 2 - 1, kf + 1)]);
                    sum *= juce::jmin (1.0f, 0.3f + fund / (0.25f * sum + 1.0e-9f));
                    if (sum > best) { best = sum; bestM = m; }
                }
                if (bestM < 0 || best < 1.0e-6f || (iter > 0 && best < first * 0.3f)) break;
                if (iter == 0) first = best;
                c[(size_t) (bestM % 12)] += best;
                lowest = juce::jmin (lowest, bestM);
                const double f0 = midiHz (bestM);
                for (int h = 1; h <= 12; ++h)
                {
                    const double f = f0 * h;
                    const int k0 = (int) std::floor (f * 0.98 / binHz), k1 = (int) std::ceil (f * 1.02 / binHz);
                    for (int k = juce::jmax (1, k0); k <= juce::jmin (N / 2 - 1, k1); ++k) buf[(size_t) k] *= 0.15f;
                }
            }
            if (lowest < 999) bc[(size_t) (lowest % 12)] += first;
        }
        struct Tpl { int type; std::array<float, 12> w; };
        std::vector<Tpl> tpls;
        auto make = [&] (int type, std::initializer_list<std::pair<int, float>> iv)
        {
            for (int r = 0; r < 12; ++r)
            {
                Tpl t; t.type = r * 3 + type; t.w.fill (0.0f);
                for (auto& p : iv) t.w[(size_t) ((r + p.first) % 12)] = p.second;
                float n2 = 0.0f; for (auto v : t.w) n2 += v * v;
                for (auto& v : t.w) v /= std::sqrt (n2);
                tpls.push_back (t);
            }
        };
        make (0, { { 0, 1.0f }, { 4, 0.8f }, { 7, 0.8f } });
        make (1, { { 0, 1.0f }, { 3, 0.8f }, { 7, 0.8f } });
        make (2, { { 0, 1.0f }, { 4, 0.75f }, { 7, 0.75f }, { 10, 0.6f } });
        const int T = (int) tpls.size();
        std::vector<std::vector<float>> score ((size_t) totalBeats, std::vector<float> ((size_t) T + 1, 0.0f));
        for (int b = 0; b < totalBeats; ++b)
        {
            std::array<float, 12> c {}, bass {};
            const double t0 = firstBeat + b * beatSec, t1 = t0 + beatSec;
            float e = 0.0f;
            for (int t = juce::jmax (0, (int) ((t0 - offset) * fps)); t < juce::jmin (numFrames, (int) ((t1 - offset) * fps)); ++t)
                for (int k = 0; k < 12; ++k) { c[(size_t) k] += chroma[(size_t) t][(size_t) k]; bass[(size_t) k] += bassChroma[(size_t) t][(size_t) k]; }
            for (auto v : c) e += v;
            float n2 = 0.0f; for (auto v : c) n2 += v * v;
            const float nrm = std::sqrt (n2) + 1.0e-12f;
            const int bassPc = (int) (std::max_element (bass.begin(), bass.end()) - bass.begin());
            for (int k = 0; k < T; ++k)
            {
                float dot = 0.0f;
                for (int p = 0; p < 12; ++p) dot += tpls[(size_t) k].w[(size_t) p] * c[(size_t) p] / nrm;
                if (tpls[(size_t) k].type / 3 == bassPc) dot += 0.12f;
                score[(size_t) b][(size_t) k] = dot;
            }
            score[(size_t) b][(size_t) T] = e < 1.0e-9f ? 1.0f : 0.55f;        // “没有和弦”
        }
        // 平滑：换和弦要付一点代价
        std::vector<std::vector<float>> acc ((size_t) totalBeats, std::vector<float> ((size_t) T + 1));
        std::vector<std::vector<int>> arg ((size_t) totalBeats, std::vector<int> ((size_t) T + 1));
        for (int k = 0; k <= T; ++k) acc[0][(size_t) k] = score[0][(size_t) k];
        for (int b = 1; b < totalBeats; ++b)
        {
            int bestK = 0; float bestV = -1e9f;
            for (int k = 0; k <= T; ++k) if (acc[(size_t) b - 1][(size_t) k] > bestV) { bestV = acc[(size_t) b - 1][(size_t) k]; bestK = k; }
            for (int k = 0; k <= T; ++k)
            {
                const float stay = acc[(size_t) b - 1][(size_t) k];
                const float change = bestV - 0.2f;
                acc[(size_t) b][(size_t) k] = juce::jmax (stay, change) + score[(size_t) b][(size_t) k];
                arg[(size_t) b][(size_t) k] = stay >= change ? k : bestK;
            }
        }
        int k = 0; float bv = -1e9f;
        for (int j = 0; j <= T; ++j) if (acc.back()[(size_t) j] > bv) { bv = acc.back()[(size_t) j]; k = j; }
        for (int b = totalBeats - 1; b >= 0; --b)
        {
            beatChord[(size_t) b] = k == T ? -1 : tpls[(size_t) k].type;
            k = arg[(size_t) b][(size_t) k];
        }
        for (int b = 0; b < totalBeats; ++b)
            if (b == 0 || beatChord[(size_t) b] != beatChord[(size_t) b - 1])
                if (beatChord[(size_t) b] >= 0)
                    res.chords.push_back ({ firstBeat + b * beatSec, beatChord[(size_t) b] / 3,
                                            beatChord[(size_t) b] % 3 == 0 ? (int) Chords::Quality::major
                                          : beatChord[(size_t) b] % 3 == 1 ? (int) Chords::Quality::minor : (int) Chords::Quality::dom7 });
    }

    // ---- 6. 量化 -----------------------------------------------------------------------
    if (! report (opt, 0.88f, "排指法、量化…")) { res.cancelled = true; return res; }
    const int grid = opt.grid >= 4 ? 4 : 2;
    const int totalSlots = totalBeats * grid;
    struct QNote { int a, b; int idx; };
    std::vector<QNote> qn;
    for (int i = 0; i < (int) notes.size(); ++i)
    {
        int a = (int) std::round ((notes[(size_t) i].start - firstBeat) / beatSec * grid);
        int b = (int) std::round ((notes[(size_t) i].end - firstBeat) / beatSec * grid);
        a = juce::jlimit (0, totalSlots - 1, a);
        b = juce::jlimit (a + 1, totalSlots, b);
        if (! qn.empty() && a <= qn.back().a)
        {
            // 挤到同一格：留更响的那个
            if (notes[(size_t) i].strength > notes[(size_t) qn.back().idx].strength) qn.back() = { qn.back().a, b, i };
            continue;
        }
        if (! qn.empty() && qn.back().b > a) qn.back().b = a;        // 单音：前一个音在这里结束
        qn.push_back ({ a, b, i });
    }

    // 指法
    std::vector<int> midis; std::vector<double> starts; std::vector<bool> bends;
    for (auto& q : qn) { midis.push_back (notes[(size_t) q.idx].midi); starts.push_back (notes[(size_t) q.idx].start); bends.push_back (notes[(size_t) q.idx].bend > 0.0f); }
    const auto fing = fingering (midis, starts, bends, opt.capo);

    // ---- 7. 写成 RawScore（按格子切成拍；和弦换的地方、小节线把长音切开用连音线接上）----
    RawScore raw;
    raw.title = opt.title.isNotEmpty() ? opt.title : T ("扒谱");
    raw.artist = T ("老干部活动中心 · 音频扒谱");
    raw.format = "AudioToTab";
    raw.initialTempo = std::round (bpm);
    RawTrack track;
    track.name = T ("主旋律");
    track.tuning = { 64, 59, 55, 50, 45, 40 };
    track.capo = opt.capo;
    track.program = 29;
    std::map<int, int> diagramOf;     // beatChord 值 -> chordDiagrams 下标
    auto diagramFor = [&] (int code)
    {
        if (auto it = diagramOf.find (code); it != diagramOf.end()) return it->second;
        const int root = code / 3;
        const auto q = code % 3 == 0 ? Chords::Quality::major : code % 3 == 1 ? Chords::Quality::minor : Chords::Quality::dom7;
        ChordDiagram d;
        d.name = Chords::name (root, q, false);
        const auto vs = Chords::voicings (root, q);
        if (! vs.empty())
            for (int s = 5; s >= 0; --s) d.frets.push_back (vs.front().frets[(size_t) s]);     // 谱里 [0] = 1 弦
        track.chordDiagrams.push_back (d);
        diagramOf[code] = (int) track.chordDiagrams.size() - 1;
        return diagramOf[code];
    };

    std::vector<int> slotNote ((size_t) totalSlots, -1);
    for (int i = 0; i < (int) qn.size(); ++i)
        for (int s = qn[(size_t) i].a; s < qn[(size_t) i].b; ++s) slotNote[(size_t) s] = i;
    const int barSlots = 4 * grid;
    for (int bar = 0; bar < totalBeats / 4; ++bar)
    {
        RawMasterBar mb;
        if (bar == 0) mb.tempos.push_back ({ 0.0, std::round (bpm) });
        raw.masterBars.push_back (mb);
        RawBar rb;
        RawVoice voice;
        int s = bar * barSlots;
        const int end = s + barSlots;
        while (s < end)
        {
            const int note = slotNote[(size_t) s];
            const bool chordChange = opt.chords && s % grid == 0
                                     && (s == 0 || beatChord[(size_t) (s / grid)] != beatChord[(size_t) (s / grid - 1)] || s == bar * barSlots);
            int e = s + 1;
            while (e < end && slotNote[(size_t) e] == note
                   && ! (note >= 0 && qn[(size_t) note].a == e)
                   && ! (opt.chords && e % grid == 0 && beatChord[(size_t) (e / grid)] != beatChord[(size_t) (e / grid - 1)]))
                ++e;
            RawBeat beat;
            beat.duration = (double) (e - s) / grid;
            if (chordChange && beatChord[(size_t) (s / grid)] >= 0)
            {
                // 小节开头总是标一下当前和弦；拍上换和弦时也标
                const int code = beatChord[(size_t) (s / grid)];
                const bool sameAsPrev = s > 0 && s == bar * barSlots && beatChord[(size_t) (s / grid - 1)] == code;
                if (! sameAsPrev || s == 0) beat.chord = diagramFor (code);
            }
            if (note >= 0)
            {
                const auto& q = qn[(size_t) note];
                const auto& dn = notes[(size_t) q.idx];
                RawNote rn;
                rn.string = fing[(size_t) note].string;
                rn.fret = fing[(size_t) note].fret;
                rn.tieDestination = q.a != s;
                if (! rn.tieDestination && dn.bend > 0.0f)
                {
                    rn.bend = dn.bend;
                    rn.bendStart = 0.0f;
                    rn.bendPeakPos = juce::jlimit (0.1f, 1.0f, dn.bendPeak);
                    rn.bendReleasePos = dn.release ? juce::jmin (1.0f, rn.bendPeakPos + 0.15f) : 1.0f;
                    rn.bendEnd = dn.release ? 0.0f : dn.bend;
                    rn.bendEndPos = 1.0f;
                }
                beat.notes.push_back (rn);
            }
            voice.beats.push_back (beat);
            s = e;
        }
        rb.voices.push_back (voice);
        track.bars.push_back (rb);
    }
    // 击弦 / 勾弦：GP 的习惯是标在起点音上（连音线接出来的后半截不算，标在开头那一截）
    {
        RawNote* prevStart = nullptr;
        int idx = -1;
        for (auto& bar : track.bars)
            for (auto& beat : bar.voices[0].beats)
                for (auto& rn : beat.notes)
                {
                    if (rn.tieDestination) continue;
                    ++idx;
                    if (prevStart != nullptr && idx < (int) qn.size())
                    {
                        const auto& dn = notes[(size_t) qn[(size_t) idx].idx];
                        const bool contiguous = idx > 0 && qn[(size_t) idx - 1].b == qn[(size_t) idx].a;
                        if (dn.legato && contiguous && prevStart->string == rn.string && prevStart->fret != rn.fret)
                            prevStart->hammerPull = true;
                    }
                    prevStart = &rn;
                }
    }
    raw.tracks.push_back (std::move (track));

    res.song = std::shared_ptr<Song> (buildSong (raw).release());
    res.raw = std::move (raw);
    res.summary << T ("单音主旋律 ") << (int) qn.size() << T (" 个音");
    report (opt, 1.0f, "完成");
    return res;
}

// =============================================================================
// Guitar Pro 3 写出
namespace
{
    class Gp3Writer
    {
    public:
        juce::MemoryOutputStream out;
        void byte (int v)     { out.writeByte ((char) (uint8_t) v); }
        void i32 (int v)      { out.writeInt (v); }          // 小端
        void boolean (bool b) { byte (b ? 1 : 0); }
        static juce::MemoryBlock encode (const juce::String& s)
        {
            // Guitar Pro 3 的字符串是本地代码页：Windows 上写 GBK（中文 Guitar Pro / TuxGuitar 显示正常），
            // 其他系统写 UTF-8（本程序两种都认）
           #if JUCE_WINDOWS
            const auto w = s.toWideCharPointer();
            const int n = WideCharToMultiByte (936, 0, w, -1, nullptr, 0, nullptr, nullptr);
            if (n > 1)
            {
                juce::MemoryBlock mb ((size_t) n);
                WideCharToMultiByte (936, 0, w, -1, static_cast<char*> (mb.getData()), n, nullptr, nullptr);
                mb.setSize ((size_t) n - 1);
                return mb;
            }
           #elif JUCE_MAC
            if (auto cf = s.toCFString())
            {
                CFIndex used = 0;
                const CFRange all = CFRangeMake (0, CFStringGetLength (cf));
                CFStringGetBytes (cf, all, kCFStringEncodingGB_18030_2000, '?', false, nullptr, 0, &used);
                juce::MemoryBlock mb ((size_t) juce::jmax ((CFIndex) 1, used));
                CFStringGetBytes (cf, all, kCFStringEncodingGB_18030_2000, '?', false, static_cast<UInt8*> (mb.getData()), used, &used);
                CFRelease (cf);
                mb.setSize ((size_t) used);
                return mb;
            }
           #endif
            return juce::MemoryBlock (s.toRawUTF8(), s.getNumBytesAsUTF8());
        }
        void strByteLen (const juce::String& s, int len)
        {
            auto mb = encode (s);
            const int n = juce::jmin ((int) mb.getSize(), len, 255);
            byte (n);
            out.write (mb.getData(), (size_t) n);
            for (int i = n; i < len; ++i) byte (0);
        }
        void strIntByte (const juce::String& s)
        {
            auto mb = encode (s);
            const int n = juce::jmin ((int) mb.getSize(), 255);
            i32 (n + 1);
            byte (n);
            out.write (mb.getData(), (size_t) n);
        }
    };

    // 把一个时值（拍）拆成 GP 能写的时值（全、二分、四分、八分、十六分、三十二分，可以带附点；也可以是三连音）
    struct DurPart { int code; bool dot; int tuplet; };
    // 以 1/48 拍为单位做“凑零钱”：用最少的段数拼出这个时值（三连音稍微贵一点，能不用就不用）
    std::vector<DurPart> splitDuration (double beats)
    {
        static const struct { int units; int code; bool dot; int tuplet; } table[] = {
            { 288, -2, true, 0 }, { 192, -2, false, 0 }, { 144, -1, true, 0 }, { 96, -1, false, 0 }, { 72, 0, true, 0 },
            { 64, -1, false, 3 }, { 48, 0, false, 0 }, { 36, 1, true, 0 }, { 32, 0, false, 3 }, { 24, 1, false, 0 },
            { 18, 2, true, 0 }, { 16, 1, false, 3 }, { 12, 2, false, 0 }, { 9, 3, true, 0 }, { 8, 2, false, 3 },
            { 6, 3, false, 0 }, { 4, 3, false, 3 }, { 3, 4, false, 0 } };
        const int n = juce::jlimit (1, 4096, (int) std::lround (beats * 48.0));
        std::vector<int> cost ((size_t) n + 1, 1 << 28), pick ((size_t) n + 1, -1);
        cost[0] = 0;
        for (int v = 1; v <= n; ++v)
            for (int k = 0; k < (int) (sizeof (table) / sizeof (table[0])); ++k)
            {
                const int u = table[k].units;
                if (u > v || cost[(size_t) (v - u)] >= (1 << 28)) continue;
                const int c = cost[(size_t) (v - u)] + (table[k].tuplet ? 3 : 2);
                if (c < cost[(size_t) v]) { cost[(size_t) v] = c; pick[(size_t) v] = k; }
            }
        std::vector<DurPart> parts;
        int v = n;
        if (pick[(size_t) v] < 0) { parts.push_back ({ 3, false, 0 }); return parts; }    // 凑不出来（比 1/64 还碎）
        while (v > 0)
        {
            const auto& t = table[pick[(size_t) v]];
            parts.push_back ({ t.code, t.dot, t.tuplet });
            v -= t.units;
        }
        // 长的放前面
        std::stable_sort (parts.begin(), parts.end(), [] (const DurPart& x, const DurPart& y) { return x.code < y.code; });
        return parts;
    }
}

bool AudioToTab::writeGp3 (const RawScore& score, const juce::File& file, juce::String& error)
{
    if (score.tracks.empty()) { error = T ("没有音轨"); return false; }
    Gp3Writer w;
    w.strByteLen ("FICHIER GUITAR PRO v3.00", 30);
    w.strIntByte (score.title);
    w.strIntByte ({});                       // 副标题
    w.strIntByte (score.artist);
    w.strIntByte ({});                       // 专辑
    w.strIntByte ({});                       // 作词
    w.strIntByte ({});                       // 版权
    w.strIntByte (T ("老干部活动中心"));     // 制谱
    w.strIntByte ({});                       // 说明
    w.i32 (0);                               // 注释行数
    w.boolean (false);                       // 三连音感觉
    w.i32 ((int) std::round (score.initialTempo));
    w.i32 (0);                               // 调号
    for (int port = 0; port < 4; ++port)
        for (int ch = 0; ch < 16; ++ch)
        {
            const int t = port * 16 + ch;
            w.i32 (t < (int) score.tracks.size() ? score.tracks[(size_t) t].program : 25);
            w.byte (13); w.byte (8); w.byte (0); w.byte (0); w.byte (0); w.byte (0);
            w.byte (0); w.byte (0);
        }
    const int bars = (int) score.masterBars.size();
    w.i32 (bars);
    w.i32 ((int) score.tracks.size());
    for (int b = 0; b < bars; ++b)
    {
        const auto& mb = score.masterBars[(size_t) b];
        const bool sig = b == 0 || mb.numerator != score.masterBars[(size_t) b - 1].numerator
                         || mb.denominator != score.masterBars[(size_t) b - 1].denominator;
        int flags = sig ? 0x03 : 0;
        if (mb.section.isNotEmpty()) flags |= 0x20;
        w.byte (flags);
        if (sig) { w.byte (mb.numerator); w.byte (mb.denominator); }
        if (mb.section.isNotEmpty()) { w.strIntByte (mb.section); w.byte (0); w.byte (0); w.byte (0); w.byte (0); }
    }
    for (size_t t = 0; t < score.tracks.size(); ++t)
    {
        const auto& tr = score.tracks[t];
        w.byte (tr.percussion ? 0x01 : 0);
        w.strByteLen (tr.name, 40);
        w.i32 ((int) tr.tuning.size());
        for (int i = 0; i < 7; ++i) w.i32 (i < (int) tr.tuning.size() ? tr.tuning[(size_t) i] : 0);
        w.i32 (1);                         // 端口
        w.i32 ((int) t + 1);               // 通道
        w.i32 ((int) t + 2);               // 效果通道
        w.i32 (24);                        // 品数
        w.i32 (tr.capo);
        w.i32 (0xff0000);                  // 颜色
    }
    for (int b = 0; b < bars; ++b)
        for (size_t t = 0; t < score.tracks.size(); ++t)
        {
            const auto& tr = score.tracks[t];
            // 一个小节：先把每个拍按 GP 时值拆开（拆出来的后半截用连音线）
            struct Out { int code; bool dot; int tuplet; const RawBeat* beat; bool tie; bool first; int tempo; };
            std::vector<Out> outs;
            const auto& mbar = score.masterBars[(size_t) b];
            const double barLen = 4.0 * mbar.numerator / juce::jmax (1, mbar.denominator);
            size_t nextTempo = 0;
            double cursor = 0.0;
            if (b < (int) tr.bars.size() && ! tr.bars[(size_t) b].voices.empty())
                for (auto& beat : tr.bars[(size_t) b].voices[0].beats)
                {
                    if (beat.grace) continue;
                    const auto parts = splitDuration (beat.duration);
                    for (size_t p = 0; p < parts.size(); ++p)
                    {
                        // 速度变化：写在第一条音轨、落在这个位置的拍上
                        int tempo = -1;
                        if (t == 0 && p == 0)
                            while (nextTempo < mbar.tempos.size() && mbar.tempos[nextTempo].ratio * barLen <= cursor + 1.0e-6)
                            {
                                const bool initial = b == 0 && mbar.tempos[nextTempo].ratio <= 1.0e-6
                                                     && std::abs (mbar.tempos[nextTempo].bpm - score.initialTempo) < 0.5;
                                if (! initial) tempo = (int) std::round (mbar.tempos[nextTempo].bpm);
                                ++nextTempo;
                            }
                        outs.push_back ({ parts[p].code, parts[p].dot, parts[p].tuplet, &beat, p > 0, p == 0, tempo });
                    }
                    cursor += beat.duration;
                }
            if (outs.empty())
            {
                static RawBeat rest;
                rest.duration = 4.0;
                int tempo = -1;
                if (t == 0) for (auto& tp : mbar.tempos) if (! (b == 0 && tp.ratio <= 1.0e-6 && std::abs (tp.bpm - score.initialTempo) < 0.5)) tempo = (int) std::round (tp.bpm);
                outs.push_back ({ -2, false, 0, &rest, false, true, tempo });
            }
            w.i32 ((int) outs.size());
            for (auto& o : outs)
            {
                const auto& beat = *o.beat;
                const bool restBeat = beat.notes.empty();
                const bool hasChord = o.first && beat.chord >= 0 && beat.chord < (int) tr.chordDiagrams.size();
                bool vib = false, harm = false;
                for (auto& n : beat.notes) { vib = vib || n.vibrato; harm = harm || n.harmonic; }
                const bool beatFx = (vib || harm) && ! o.tie;
                int flags = (o.dot ? 0x01 : 0) | (hasChord ? 0x02 : 0) | (beatFx ? 0x08 : 0) | (o.tempo > 0 ? 0x10 : 0)
                          | (o.tuplet > 0 ? 0x20 : 0) | (restBeat ? 0x40 : 0);
                w.byte (flags);
                if (restBeat) w.byte (0x02);
                w.byte (o.code);
                if (o.tuplet > 0) w.i32 (o.tuplet);
                if (hasChord)
                {
                    const auto& d = tr.chordDiagrams[(size_t) beat.chord];
                    w.byte (0);                        // 老格式
                    w.strIntByte (d.name);
                    int first = 0;
                    for (int f : d.frets) if (f > 0) first = first == 0 ? f : juce::jmin (first, f);
                    const bool diagram = d.hasDiagram() && d.frets.size() == 6;
                    w.i32 (diagram ? juce::jmax (1, first) : 0);
                    if (diagram)
                        for (int s = 0; s < 6; ++s) w.i32 (d.frets[(size_t) s]);
                }
                if (beatFx) w.byte ((vib ? 0x01 : 0) | (harm ? 0x04 : 0));
                if (o.tempo > 0)
                {
                    w.byte (0xff);                                   // 音色不变
                    for (int k = 0; k < 6; ++k) w.byte (0xff);       // 音量、声像、合唱、混响、相位、颤音：不变
                    w.i32 (o.tempo);
                    w.byte (0);                                      // 速度立刻变
                }
                int stringFlags = 0;
                for (auto& n : beat.notes)
                    if (juce::isPositiveAndBelow (n.string, 7)) stringFlags |= 1 << (6 - n.string);
                w.byte (stringFlags);
                for (int i = 6; i >= 0; --i)
                {
                    if ((stringFlags & (1 << i)) == 0) continue;
                    const RawNote* n = nullptr;
                    for (auto& x : beat.notes) if (x.string == 6 - i) n = &x;
                    const bool tie = o.tie || n->tieDestination;
                    const bool fx = ! tie && (n->bend > 0.0f || n->hammerPull || n->slideOut || n->letRing);
                    w.byte (0x20 | (fx ? 0x08 : 0) | (n->dead ? 0 : 0));
                    w.byte (n->dead ? 3 : (tie ? 2 : 1));
                    w.byte (juce::jlimit (0, 99, n->fret));
                    if (fx)
                    {
                        int ef = 0;
                        if (n->bend > 0.0f) ef |= 0x01;
                        if (n->hammerPull) ef |= 0x02;
                        if (n->slideOut) ef |= 0x04;
                        if (n->letRing) ef |= 0x08;
                        w.byte (ef);
                        if (n->bend > 0.0f)
                        {
                            // 推弦曲线：位置 0–60，音高 50 = 1 个半音
                            std::vector<std::pair<int, int>> pts;
                            pts.push_back ({ 0, (int) std::round (n->bendStart * 50.0f) });
                            pts.push_back ({ (int) std::round (n->bendPeakPos * 60.0f), (int) std::round (n->bend * 50.0f) });
                            if (n->bendEnd < n->bend - 0.01f)
                            {
                                pts.push_back ({ (int) std::round (juce::jmax (n->bendPeakPos, n->bendReleasePos) * 60.0f), (int) std::round (n->bend * 50.0f) });
                                pts.push_back ({ (int) std::round (juce::jmax (n->bendReleasePos, n->bendEndPos) * 60.0f), (int) std::round (n->bendEnd * 50.0f) });
                            }
                            else
                                pts.push_back ({ 60, (int) std::round (n->bend * 50.0f) });
                            w.byte (n->bendEnd < n->bend - 0.01f ? 2 : 1);       // 1 推弦，2 推弦放回
                            w.i32 ((int) std::round (n->bend * 50.0f));
                            w.i32 ((int) pts.size());
                            for (auto& p : pts) { w.i32 (juce::jlimit (0, 60, p.first)); w.i32 (p.second); w.byte (0); }
                        }
                    }
                }
            }
        }

    if (! file.getParentDirectory().createDirectory().wasOk())
    {
        error = T ("建不了文件夹：") + file.getParentDirectory().getFullPathName();
        return false;
    }
    if (! file.replaceWithData (w.out.getData(), w.out.getDataSize()))
    {
        error = T ("写不了文件：") + file.getFullPathName();
        return false;
    }
    return true;
}
