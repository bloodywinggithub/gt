#pragma once

#include <juce_audio_basics/juce_audio_basics.h>
#include <array>
#include <atomic>
#include <vector>

class DrumMachine;

// 五轨循环录音（Looper）。录的是“你听到的吉他”（效果器之后、吉他音量之前），立体声。
//   第 1 轨定循环长度：按一下开始录，再按一下结束并开始循环；
//   第 2–5 轨按一下从当前位置开始录，正好录满一圈自动转成播放（中途再按一下提前结束）；
//   正在播放的轨再按录音 = 叠录（overdub），再按一下结束叠录。
//   可选“跟鼓机对齐”：鼓机在走时，第 1 轨从下一小节的第一拍开始录，长度取整到整小节。
// 线程：界面线程只发请求 / 读状态；音频线程处理请求、读写缓冲。缓冲在界面线程预先分配。
class Looper
{
public:
    static constexpr int numTracks = 5;
    static constexpr double maxSeconds = 30.0;

    enum class State { empty, armed, recording, playing, overdubbing };

    // ---- 界面线程 ---------------------------------------------------------------
    void setSampleRate (double sr);       // 设备停着的时候调（AudioEngine::prepareInternal）
    bool allocate();                      // 第一次打开循环录音时分配缓冲（约 30 秒 × 5 轨）
    bool isAllocated() const              { return ready.load (std::memory_order_acquire); }

    void pressTrack (int t)               { if (juce::isPositiveAndBelow (t, numTracks)) tracks[(size_t) t].pressed.store (true); }
    void clearTrack (int t)               { if (juce::isPositiveAndBelow (t, numTracks)) tracks[(size_t) t].clearReq.store (true); }
    void clearAll()                       { clearAllReq.store (true); }
    void setPlaying (bool p)              { playReq.store (p ? 1 : 2); }
    void setMuted (int t, bool m)         { if (juce::isPositiveAndBelow (t, numTracks)) tracks[(size_t) t].muted.store (m); }
    void setTrackGainDb (int t, float db) { if (juce::isPositiveAndBelow (t, numTracks)) tracks[(size_t) t].gainDb.store (db); }
    void setSyncToDrums (bool s)          { syncToDrums.store (s); }
    void setMasterGainDb (float db)       { masterGainDb.store (db); }

    State getState (int t) const          { return (State) tracks[(size_t) t].state.load(); }
    bool  isMuted (int t) const           { return tracks[(size_t) t].muted.load(); }
    bool  hasAudio (int t) const          { return tracks[(size_t) t].hasAudio.load(); }
    bool  isPlaying() const               { return playing.load(); }
    int   getLoopLength() const           { return loopLength.load(); }    // 采样数，0 = 还没定
    int   getPosition() const             { return position.load(); }
    int   getRecordedSoFar() const        { return masterRecorded.load(); } // 第 1 轨正在录时已录的长度
    double getSampleRate() const          { return sampleRate; }
    float getTrackPeak (int t)            { return tracks[(size_t) t].peak.exchange (0.0f); }

    // 界面线程定时调用：把清掉的轨的缓冲清零（放在界面线程做，音频线程不卡）
    void maintenance();

    // 把所有有声音的轨混成一个立体声缓冲（导出 WAV 用），按各轨音量和静音
    juce::AudioBuffer<float> renderMix() const;

    // ---- 音频线程 ---------------------------------------------------------------
    // in：这一块的吉他（效果器之后）；out：叠加循环播放；drums 用来对齐小节
    void process (const float* inL, const float* inR, float* outL, float* outR, int n, const DrumMachine& drums) noexcept;

private:
    struct Track
    {
        std::array<std::vector<float>, 2> buffer;
        std::atomic<int> state { (int) State::empty };
        std::atomic<bool> pressed { false }, clearReq { false }, muted { false }, hasAudio { false };
        std::atomic<bool> zeroPending { false };   // 清掉了，等界面线程把缓冲清零；清零之前不能开始录
        std::atomic<float> gainDb { 0.0f }, peak { 0.0f };
        int recordedThisPass = 0;     // 第 2–5 轨：这一圈已经录了多少
        float gain = 1.0f;            // 平滑后的增益
    };

    void handleRequests (const DrumMachine& drums) noexcept;
    void finishMaster (const DrumMachine& drums) noexcept;
    void finishPass (Track& t) noexcept;
    void declick (Track& t, int start, int len) noexcept;
    int  barSamples (const DrumMachine& drums) const noexcept;

    std::array<Track, numTracks> tracks;
    double sampleRate = 48000.0;
    int capacity = 0;

    std::atomic<bool> ready { false };
    std::atomic<int> loopLength { 0 }, position { 0 }, masterRecorded { 0 };
    std::atomic<bool> playing { false }, clearAllReq { false }, syncToDrums { true };
    std::atomic<int> playReq { 0 };   // 1 = 播放，2 = 停
    std::atomic<float> masterGainDb { 0.0f };
    int lastDrumBeat = -1;
    bool armedWaitsForBar = false;
};
