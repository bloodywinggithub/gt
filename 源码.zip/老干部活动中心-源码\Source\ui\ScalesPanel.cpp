#include "ScalesPanel.h"
#include "AudioEngine.h"
#include "Text.h"

using namespace ScaleTheory;

namespace
{
    const juce::Colour panelColour  { 0xff222222 };
    const juce::Colour rootColour   { 0xffe5484d };
    const juce::Colour toneColour   { 0xff3b82f6 };
    const juce::Colour blueColour   { 0xffa855f7 };
    const juce::Colour playedColour { 0xfff2f21e };
    const juce::Colour targetColour { 0xff3cdc78 };
    const juce::Colour mutedText    { 0xff9a9a9a };

    void styleLabel (juce::Label& l, float size, juce::Colour c = juce::Colours::white, bool bold = false)
    {
        l.setFont (juce::FontOptions (size, bold ? juce::Font::bold : juce::Font::plain));
        l.setColour (juce::Label::textColourId, c);
    }

    int midiFromHz (float hz) { return juce::roundToInt (69.0 + 12.0 * std::log2 (hz / 440.0)); }
}

// =============================================================================
// Fretboard
juce::Rectangle<float> Fretboard::boardArea() const
{
    // 左边留弦名和空弦列，下面留品号
    return getLocalBounds().toFloat().withTrimmedLeft (64.0f).withTrimmedRight (14.0f).withTrimmedTop (14.0f).withTrimmedBottom (30.0f);
}

float Fretboard::fretX (int fret) const
{
    const auto b = boardArea();
    return b.getX() + b.getWidth() * (float) fret / (float) maxFret;   // fret 号 = 第几根品丝
}

juce::Point<float> Fretboard::centreOf (int string, int fret) const
{
    const auto b = boardArea();
    const int n = numStrings();
    const float gap = b.getHeight() / (float) juce::jmax (1, n - 1);
    const float y = b.getY() + (float) (n - 1 - string) * gap;   // 1 弦（最细）在最上面
    const float x = fret == 0 ? b.getX() - 22.0f : (fretX (fret - 1) + fretX (fret)) * 0.5f;
    return { x, y };
}

void Fretboard::setScale (int r, const Scale& sc, bool f)
{
    root = r; scale = sc; flats = f;
    repaint();
}

void Fretboard::setPosition (const std::vector<Spot>& s, bool whole)
{
    spots = s; wholeNeck = whole;
    repaint();
}

void Fretboard::setTarget (int midi, int string, int fret)
{
    targetMidi = midi; targetString = string; targetFret = fret;
    repaint();
}

void Fretboard::paint (juce::Graphics& g)
{
    const auto b = boardArea();

    // 指板木头 + 品丝
    g.setColour (juce::Colour (0xff2b211b));
    g.fillRoundedRectangle (b.expanded (0.0f, 12.0f), 4.0f);
    g.setColour (juce::Colour (0xffd8d2c4));
    g.fillRect (b.getX() - 3.0f, b.getY() - 12.0f, 5.0f, b.getHeight() + 24.0f);      // 琴枕
    for (int f = 1; f <= maxFret; ++f)
    {
        g.setColour (juce::Colour (0xff8d8a83));
        g.fillRect (fretX (f) - 1.0f, b.getY() - 12.0f, 2.0f, b.getHeight() + 24.0f);
    }

    // 品位标记
    g.setColour (juce::Colour (0xff4a3d33));
    for (int f : { 3, 5, 7, 9, 15, 17, 19, 21 })
    {
        const float x = (fretX (f - 1) + fretX (f)) * 0.5f;
        g.fillEllipse (x - 6.0f, b.getCentreY() - 6.0f, 12.0f, 12.0f);
    }
    {
        const float x = (fretX (11) + fretX (12)) * 0.5f;
        g.fillEllipse (x - 6.0f, b.getY() + b.getHeight() * 0.3f - 6.0f, 12.0f, 12.0f);
        g.fillEllipse (x - 6.0f, b.getY() + b.getHeight() * 0.7f - 6.0f, 12.0f, 12.0f);
    }

    // 品号
    g.setColour (mutedText);
    g.setFont (juce::FontOptions (12.0f));
    for (int f = 0; f <= maxFret; ++f)
    {
        const auto c = centreOf (0, f);
        const bool marked = f == 0 || f == 3 || f == 5 || f == 7 || f == 9 || f == 12 || f == 15 || f == 17 || f == 19 || f == 21;
        g.setColour (marked ? juce::Colour (0xffcfcfcf) : mutedText.withAlpha (0.6f));
        g.drawText (juce::String (f), juce::Rectangle<float> (c.x - 14.0f, b.getBottom() + 12.0f, 28.0f, 16.0f), juce::Justification::centred);
    }

    // 弦 + 弦名
    static const char* pcNames[] = { "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B" };
    for (int s = 0; s < numStrings(); ++s)
    {
        const float y = centreOf (s, 1).y;
        g.setColour (juce::Colour (0xffc9c4b8).withAlpha (0.85f));
        const float th = juce::jlimit (0.9f, 4.5f, 0.9f + 0.1f * (float) (64 - openMidi[s]));      // 弦粗细按音高
        g.fillRect (b.getX() - 40.0f, y - th * 0.5f, b.getWidth() + 40.0f, th);
        g.setColour (mutedText);
        g.setFont (juce::FontOptions (13.0f, juce::Font::bold));
        juce::String sn = pcNames[openMidi[s] % 12];
        if (s == numStrings() - 1 && ! currentInstrument().bass && sn == "E") sn = "e";
        g.drawText (sn, juce::Rectangle<float> (2.0f, y - 9.0f, 22.0f, 18.0f), juce::Justification::centred);
    }

    // 当前把位的范围：淡色底框
    if (! quizMode && ! wholeNeck && ! spots.empty())
    {
        const auto span = fretSpan (spots);
        const float x0 = span.getStart() == 0 ? b.getX() - 40.0f : fretX (span.getStart() - 1) + 2.0f;
        const float x1 = fretX (juce::jmax (1, span.getEnd())) - 2.0f;
        g.setColour (juce::Colours::white.withAlpha (0.07f));
        g.fillRoundedRectangle (juce::Rectangle<float> (x0, b.getY() - 12.0f, x1 - x0, b.getHeight() + 24.0f), 6.0f);
    }

    if (quizMode)
    {
        paintQuiz (g, juce::jlimit (8.0f, 13.0f, (fretX (1) - fretX (0)) * 0.36f));
        return;
    }

    auto isSpot = [this] (int s, int f)
    {
        for (auto& p : spots) if (p.string == s && p.fret == f) return true;
        return false;
    };
    auto isBlue = [this] (int midi)
    {
        const int iv = ((midi - root) % 12 + 12) % 12;
        return std::find (scale.blueNotes.begin(), scale.blueNotes.end(), iv) != scale.blueNotes.end();
    };

    const float r = juce::jlimit (8.0f, 13.0f, (fretX (1) - fretX (0)) * 0.36f);
    const bool flash = juce::Time::getMillisecondCounterHiRes() < flashUntil;

    for (int s = 0; s < numStrings(); ++s)
        for (int f = 0; f <= maxFret; ++f)
        {
            const int midi = openMidi[s] + f;
            if (! inScale (midi, root, scale)) continue;
            const bool active = wholeNeck || isSpot (s, f);
            const int iv = ((midi - root) % 12 + 12) % 12;
            juce::Colour c = iv == 0 ? rootColour : isBlue (midi) ? blueColour : toneColour;
            const auto p = centreOf (s, f);
            auto circle = juce::Rectangle<float> (p.x - r, p.y - r, r * 2.0f, r * 2.0f);

            if (! active)
            {
                g.setColour (c.withAlpha (0.22f));
                g.fillEllipse (circle.reduced (2.0f));
                continue;
            }
            g.setColour (c);
            g.fillEllipse (circle);
            if (iv == 0)
            {
                g.setColour (juce::Colours::white.withAlpha (0.85f));
                g.drawEllipse (circle.reduced (1.0f), 1.6f);
            }
            juce::String text;
            if (labels == Labels::noteNames) text = spell (midi, root, scale, flats);
            else if (labels == Labels::degrees) text = degreeName (iv, scale);
            if (text.isNotEmpty())
            {
                g.setColour (juce::Colours::white);
                g.setFont (juce::FontOptions (text.length() > 2 ? 10.0f : 11.5f, juce::Font::bold));
                g.drawText (text, circle, juce::Justification::centred);
            }
        }

    // 要弹的那个位置（绿圈）
    if (targetMidi >= 0 && targetString >= 0)
    {
        const auto p = centreOf (targetString, targetFret);
        const float rr = r + 5.0f;
        g.setColour ((flash && flashGood ? targetColour.brighter (0.4f) : targetColour));
        g.drawEllipse (p.x - rr, p.y - rr, rr * 2.0f, rr * 2.0f, 3.5f);
    }

    // 你正在弹的音：所有能弹出这个音的位置都套黄圈；不在音阶里的画成灰点
    if (playedMidi >= 0)
    {
        const bool ok = inScale (playedMidi, root, scale);
        for (int s = 0; s < numStrings(); ++s)
        {
            const int f = playedMidi - openMidi[s];
            if (f < 0 || f > maxFret) continue;
            const auto p = centreOf (s, f);
            const float rr = r + 2.5f;
            if (! ok)
            {
                g.setColour (juce::Colour (0xff6b6b6b));
                g.fillEllipse (p.x - r, p.y - r, r * 2.0f, r * 2.0f);
                g.setColour (juce::Colours::white);
                g.setFont (juce::FontOptions (11.0f, juce::Font::bold));
                g.drawText (noteName (playedMidi, flats), juce::Rectangle<float> (p.x - r, p.y - r, r * 2.0f, r * 2.0f), juce::Justification::centred);
            }
            g.setColour (ok ? playedColour : juce::Colour (0xffff6b5a));
            g.drawEllipse (p.x - rr, p.y - rr, rr * 2.0f, rr * 2.0f, 3.0f);
        }
    }
}

void Fretboard::mouseDown (const juce::MouseEvent& e)
{
    // 找最近的格子，点一下听这个音
    int bestS = -1, bestF = -1;
    float bestD = 1.0e9f;
    for (int s = 0; s < numStrings(); ++s)
        for (int f = 0; f <= maxFret; ++f)
        {
            const float d = centreOf (s, f).getDistanceFrom (e.position);
            if (d < bestD) { bestD = d; bestS = s; bestF = f; }
        }
    if (bestS < 0 || bestD >= 26.0f) return;
    if (quizMode) { if (onSpotClicked) onSpotClicked (bestS, bestF); return; }
    if (onNoteClicked)
        onNoteClicked (openMidi[bestS] + bestF);
}

void Fretboard::paintQuiz (juce::Graphics& g, float r)
{
    const auto b = boardArea();
    // 范围外压暗
    for (int s = 0; s < numStrings(); ++s)
    {
        const float y = centreOf (s, 1).y;
        const float half = b.getHeight() / (float) juce::jmax (2, 2 * (numStrings() - 1));
        for (int f = 0; f <= maxFret; ++f)
        {
            const bool in = (quizRange.stringMask & (1u << s)) != 0 && f >= quizRange.fretLo && f <= quizRange.fretHi;
            if (in) continue;
            const float x0 = f == 0 ? b.getX() - 44.0f : fretX (f - 1);
            const float x1 = f == 0 ? b.getX() - 2.0f : fretX (f);
            g.setColour (juce::Colours::black.withAlpha (0.45f));
            g.fillRect (juce::Rectangle<float>::leftTopRightBottom (x0, y - half, x1, y + half));
        }
    }
    // 范围框
    {
        const float x0 = quizRange.fretLo == 0 ? b.getX() - 44.0f : fretX (quizRange.fretLo - 1);
        const float x1 = fretX (juce::jmax (1, quizRange.fretHi));
        g.setColour (juce::Colour (0xffffd166).withAlpha (0.5f));
        g.drawRoundedRectangle (juce::Rectangle<float> (x0, b.getY() - 12.0f, x1 - x0, b.getHeight() + 24.0f), 6.0f, 1.5f);
    }
    const double now = juce::Time::getMillisecondCounterHiRes();
    for (auto& m : quizMarks)
    {
        const auto p = centreOf (m.string, m.fret);
        float rr = r + 2.0f;
        if (m.pulse) rr += 2.5f * (float) (0.5 + 0.5 * std::sin (now * 0.008));
        g.setColour (m.colour);
        g.fillEllipse (p.x - rr, p.y - rr, rr * 2.0f, rr * 2.0f);
        g.setColour (juce::Colours::white.withAlpha (0.9f));
        g.drawEllipse (p.x - rr, p.y - rr, rr * 2.0f, rr * 2.0f, 1.6f);
        if (m.text.isNotEmpty())
        {
            g.setColour (juce::Colours::white);
            g.setFont (juce::FontOptions (m.text.length() > 2 ? 10.5f : 13.0f, juce::Font::bold));
            g.drawText (m.text, juce::Rectangle<float> (p.x - rr, p.y - rr, rr * 2.0f, rr * 2.0f), juce::Justification::centred);
        }
    }
}

// =============================================================================
// 配鼓：适合各种音阶即兴的鼓点（鼓机风格序号：0 摇滚 1 流行 2 慢歌 3 放克 4 迪斯科 5 朋克 6 金属
//        7 蓝调 Shuffle 8 雷鬼 9 爵士 Swing 10 华尔兹 3/4）
const std::vector<ScalesPanel::Groove>& ScalesPanel::grooves()
{
    static const std::vector<Groove> g {
        { "摇滚四四拍 · 100",          "小调五声",               0, 100.0f, 0.0f,  4, false },
        { "硬摇滚副歌 · 128",          "小调五声、混合利底亚",   0, 128.0f, 0.0f,  4, true  },
        { "慢 Shuffle · 72",           "小调布鲁斯",             7,  72.0f, 0.0f,  4, false },
        { "快 Shuffle · 112",          "大调布鲁斯、混合利底亚", 7, 112.0f, 0.0f,  4, true  },
        { "放克十六分 · 98",           "多利亚",                 3,  98.0f, 12.0f, 4, false },
        { "迪斯科 · 116",              "多利亚、混合利底亚",     4, 116.0f, 0.0f,  8, false },
        { "流行 · 96",                 "大调、大调五声",         1,  96.0f, 0.0f,  4, false },
        { "朋克 · 170",                "大调五声",               5, 170.0f, 0.0f,  8, true  },
        { "慢歌 · 70",                 "自然小调、利底亚",       2,  70.0f, 0.0f,  8, false },
        { "雷鬼 · 76",                 "小调五声、多利亚",       8,  76.0f, 20.0f, 8, false },
        { "爵士 Swing · 140",          "旋律小调、多利亚",       9, 140.0f, 0.0f,  4, false },
        { "金属 · 150",                "和声小调、弗里几亚",     6, 150.0f, 0.0f,  4, true  },
        { "金属慢速重型 · 100",        "洛克里亚、弗里几亚",     6, 100.0f, 0.0f,  4, false },
        { "华尔兹 3/4 · 120",          "和声小调",               10, 120.0f, 0.0f, 0, false },
    };
    return g;
}

int ScalesPanel::recommendedGroove (const Selection& s)
{
    switch (s.family)
    {
        case Family::pentatonic: return s.minor ? 0 : 6;
        case Family::blues:      return s.minor ? 2 : 3;
        case Family::sevenNote:
            if (! s.minor) return 6;
            return s.minorType == MinorType::natural ? 8 : s.minorType == MinorType::harmonic ? 11 : 10;
        case Family::modes:
        default:
            switch (s.mode)
            {
                case Mode::ionian:     return 6;
                case Mode::dorian:     return 4;
                case Mode::phrygian:   return 11;
                case Mode::lydian:     return 8;
                case Mode::mixolydian: return 3;
                case Mode::aeolian:    return 8;
                case Mode::locrian:    return 12;
            }
    }
    return 0;
}

void ScalesPanel::refreshGrooveBox()
{
    const int rec = recommendedGroove (sel);
    const int keep = grooveBox.getSelectedId();
    grooveBox.clear (juce::dontSendNotification);
    const auto& g = grooves();
    for (int i = 0; i < (int) g.size(); ++i)
        grooveBox.addItem ((i == rec ? juce::String::fromUTF8 ("\xe2\x98\x85 ") : juce::String ("    "))
                               + T (g[(size_t) i].name) + T ("  （") + T (g[(size_t) i].fits) + T ("）"), i + 1);
    grooveBox.setSelectedId (keep, juce::dontSendNotification);
    grooveBox.setTextWhenNothingSelected (juce::String::fromUTF8 ("\xe2\x98\x85 ") + T ("推荐：") + T (g[(size_t) rec].name));
    grooveButton.setTooltip (T ("给“") + scale.name + T ("”配推荐鼓点：") + T (g[(size_t) rec].name));
}

void ScalesPanel::applyGroove (int index)
{
    const auto& g = grooves();
    if (! juce::isPositiveAndBelow (index, (int) g.size())) return;
    const auto& gr = g[(size_t) index];
    if (onApplyGroove)
        onApplyGroove (gr.style, gr.bpm, gr.swing, gr.fillEvery, gr.chorus);
    grooveBox.setSelectedId (index + 1, juce::dontSendNotification);
    // 示范速度也跟上鼓（每拍一个音太快时用一半）
    bpmSlider.setValue (gr.bpm > 150.0f ? gr.bpm / 2.0f : gr.bpm);
}

// =============================================================================
// ScalesPanel
ScalesPanel::ScalesPanel (AudioEngine& e, juce::PropertiesFile& s) : engine (e), settings (s)
{
    // 读设置
    sel.root = juce::jlimit (0, 11, settings.getIntValue ("scaleRoot", 9));
    sel.family = (Family) juce::jlimit (0, 3, settings.getIntValue ("scaleFamily", 0));
    sel.minor = settings.getBoolValue ("scaleMinor", true);
    sel.minorType = (MinorType) juce::jlimit (0, 2, settings.getIntValue ("scaleMinorType", 0));
    sel.mode = (Mode) juce::jlimit (0, 6, settings.getIntValue ("scaleMode", 1));
    positionIndex = juce::jmax (0, settings.getIntValue ("scalePosition", 1));

    auto addLabel = [this] (juce::Label& l, const char* text)
    {
        l.setText (T (text), juce::dontSendNotification);
        styleLabel (l, 14.0f, mutedText);
        addAndMakeVisible (l);
    };
    addLabel (rootLabel, "根音");
    addLabel (familyLabel, "音阶");
    addLabel (positionLabel, "把位");
    addLabel (labelsLabel, "显示");
    addLabel (speedLabel, "速度");
    addLabel (grooveLabel, "配鼓");

    // 乐器：吉他 / 贝斯（指板的弦数、调弦、把位都跟着变）
    for (int i = 0; i < (int) instruments().size(); ++i) instrumentBox.addItem (instruments()[(size_t) i].name, i + 1);
    {
        const int idx = juce::jlimit (0, (int) instruments().size() - 1, settings.getIntValue ("scaleInstrument", 0));
        currentInstrument() = instruments()[(size_t) idx];
        instrumentBox.setSelectedItemIndex (idx, juce::dontSendNotification);
    }
    instrumentBox.setTooltip (T ("换成贝斯：指板变成 4 / 5 根弦，把位、认音训练都按贝斯来"));
    instrumentBox.onChange = [this]
    {
        const int idx = juce::jmax (0, instrumentBox.getSelectedItemIndex());
        currentInstrument() = instruments()[(size_t) idx];
        settings.setValue ("scaleInstrument", idx);
        stopDemo();
        if (following) { followButton.setToggleState (false, juce::dontSendNotification); setFollow (false); }
        if (trainer != nullptr) trainer->refreshInstrument();
        rebuild();
        board.repaint();
    };
    addAndMakeVisible (instrumentBox);

    grooveBox.onChange = [this] { applyGroove (grooveBox.getSelectedId() - 1); };
    grooveBox.setTooltip (T ("选一套鼓点，下面的鼓机会换成它；按 D 开始 / 停止鼓机"));
    addAndMakeVisible (grooveBox);
    grooveButton.setButtonText (T ("按音阶配鼓"));
    grooveButton.setColour (juce::TextButton::buttonColourId, juce::Colour (0xff2f6fdb));
    grooveButton.onClick = [this] { applyGroove (recommendedGroove (sel)); };
    addAndMakeVisible (grooveButton);

    rootBox.addItemList (rootNames(), 1);
    rootBox.setSelectedItemIndex (sel.root, juce::dontSendNotification);
    rootBox.onChange = [this] { sel.root = rootBox.getSelectedItemIndex(); rebuild(); };
    addAndMakeVisible (rootBox);

    familyBox.addItemList ({ T ("五声音阶"), T ("布鲁斯音阶"), T ("七声音阶（大调 / 小调）"), T ("教会调式") }, 1);
    familyBox.setSelectedItemIndex ((int) sel.family, juce::dontSendNotification);
    familyBox.onChange = [this] { sel.family = (Family) familyBox.getSelectedItemIndex(); positionIndex = juce::jmin (positionIndex, 1); rebuild(); };
    addAndMakeVisible (familyBox);

    majorButton.setButtonText (T ("大调"));
    minorButton.setButtonText (T ("小调"));
    for (auto* b : { &majorButton, &minorButton })
    {
        b->setClickingTogglesState (true);
        b->setRadioGroupId (2101);
        b->setColour (juce::TextButton::buttonOnColourId, juce::Colour (0xff2f6fdb));
        addAndMakeVisible (*b);
    }
    majorButton.setConnectedEdges (juce::Button::ConnectedOnRight);
    minorButton.setConnectedEdges (juce::Button::ConnectedOnLeft);
    majorButton.onClick = [this] { if (majorButton.getToggleState()) { sel.minor = false; rebuild(); } };
    minorButton.onClick = [this] { if (minorButton.getToggleState()) { sel.minor = true; rebuild(); } };

    minorTypeBox.addItemList ({ T ("自然小调"), T ("和声小调"), T ("旋律小调") }, 1);
    minorTypeBox.setSelectedItemIndex ((int) sel.minorType, juce::dontSendNotification);
    minorTypeBox.onChange = [this] { sel.minorType = (MinorType) minorTypeBox.getSelectedItemIndex(); rebuild(); };
    addChildComponent (minorTypeBox);

    for (int m = 0; m < 7; ++m)
        modeBox.addItem (modeName ((Mode) m), m + 1);
    modeBox.setSelectedItemIndex ((int) sel.mode, juce::dontSendNotification);
    modeBox.onChange = [this] { sel.mode = (Mode) modeBox.getSelectedItemIndex(); rebuild(); };
    addChildComponent (modeBox);

    prevPosButton.setButtonText (juce::String::fromUTF8 ("\xe2\x97\x80"));
    nextPosButton.setButtonText (juce::String::fromUTF8 ("\xe2\x96\xb6"));
    prevPosButton.setTooltip (T ("上一个把位（←）"));
    nextPosButton.setTooltip (T ("下一个把位（→）"));
    prevPosButton.onClick = [this] { stepPosition (-1); };
    nextPosButton.onClick = [this] { stepPosition (1); };
    addAndMakeVisible (prevPosButton);
    addAndMakeVisible (nextPosButton);
    positionBox.onChange = [this]
    {
        positionIndex = juce::jmax (0, positionBox.getSelectedId() - 1);
        rebuild();
    };
    addAndMakeVisible (positionBox);

    labelsBox.addItemList ({ T ("音名"), T ("级数"), T ("不显示") }, 1);
    labelsBox.setSelectedItemIndex (juce::jlimit (0, 2, settings.getIntValue ("scaleLabels", 0)), juce::dontSendNotification);
    labelsBox.onChange = [this] { board.setLabels ((Fretboard::Labels) labelsBox.getSelectedItemIndex()); saveSettings(); };
    addAndMakeVisible (labelsBox);
    board.setLabels ((Fretboard::Labels) labelsBox.getSelectedItemIndex());

    playButton.setButtonText (juce::String::fromUTF8 ("\xe2\x96\xb6 ") + T ("示范"));
    playButton.setColour (juce::TextButton::buttonColourId, juce::Colour (0xff2e9e4f));
    playButton.setTooltip (T ("按当前把位弹一遍音阶（空格）"));
    playButton.onClick = [this] { demoPlaying ? stopDemo() : startDemo(); };
    addAndMakeVisible (playButton);

    directionBox.addItemList ({ T ("上行"), T ("下行"), T ("上行再下行") }, 1);
    directionBox.setSelectedItemIndex (juce::jlimit (0, 2, settings.getIntValue ("scaleDirection", 2)), juce::dontSendNotification);
    directionBox.onChange = [this] { saveSettings(); if (following) setFollow (true); };
    addAndMakeVisible (directionBox);

    bpmSlider.setSliderStyle (juce::Slider::LinearHorizontal);
    bpmSlider.setTextBoxStyle (juce::Slider::TextBoxRight, false, 78, 22);
    bpmSlider.setRange (40.0, 240.0, 1.0);
    bpmSlider.setTextValueSuffix (" BPM");
    bpmSlider.setValue (settings.getDoubleValue ("scaleBpm", 90.0), juce::dontSendNotification);
    bpmSlider.setTooltip (T ("示范速度（每拍一个音）"));
    bpmSlider.onValueChange = [this] { saveSettings(); };
    addAndMakeVisible (bpmSlider);

    loopToggle.setButtonText (T ("循环"));
    loopToggle.setToggleState (settings.getBoolValue ("scaleLoop", false), juce::dontSendNotification);
    loopToggle.onClick = [this] { saveSettings(); };
    addAndMakeVisible (loopToggle);

    followButton.setButtonText (T ("跟弹练习"));
    followButton.setClickingTogglesState (true);
    followButton.setColour (juce::TextButton::buttonOnColourId, juce::Colour (0xffd97a1f));
    followButton.setTooltip (T ("绿圈是下一个要弹的音，弹对了自动跳到下一个"));
    followButton.onClick = [this] { setFollow (followButton.getToggleState()); };
    addAndMakeVisible (followButton);

    board.onNoteClicked = [this] (int midi) { engine.previewNote (midi, 0.8f, 1.2); };
    addAndMakeVisible (board);

    trainer = std::make_unique<NoteTrainer> (board, engine, settings);
    trainer->onPetEvent = [this] (int e, int c) { if (onPetEvent) onPetEvent (e, c); };
    addChildComponent (*trainer);
    quizButton.setButtonText (T ("认音训练"));
    quizButton.setClickingTogglesState (true);
    quizButton.setColour (juce::TextButton::buttonOnColourId, juce::Colour (0xffb45309));
    quizButton.setTooltip (T ("指板认音训练：看位置说音名 / 看音名找位置，按弦、按品格范围出题，统计正确率和反应时间（Q）"));
    quizButton.onClick = [this] { setQuiz (quizButton.getToggleState()); };
    addAndMakeVisible (quizButton);

    setWantsKeyboardFocus (true);
    rebuild();
    startTimerHz (60);
}

ScalesPanel::~ScalesPanel()
{
    stopTimer();
}

void ScalesPanel::saveSettings()
{
    settings.setValue ("scaleRoot", sel.root);
    settings.setValue ("scaleFamily", (int) sel.family);
    settings.setValue ("scaleMinor", sel.minor);
    settings.setValue ("scaleMinorType", (int) sel.minorType);
    settings.setValue ("scaleMode", (int) sel.mode);
    settings.setValue ("scalePosition", positionIndex);
    settings.setValue ("scaleLabels", labelsBox.getSelectedItemIndex());
    settings.setValue ("scaleDirection", directionBox.getSelectedItemIndex());
    settings.setValue ("scaleBpm", bpmSlider.getValue());
    settings.setValue ("scaleLoop", loopToggle.getToggleState());
}

void ScalesPanel::selectForSnapshot (int r, int family, bool minor, int minorType, int mode, int position)
{
    sel.root = r; sel.family = (Family) family; sel.minor = minor; sel.minorType = (MinorType) minorType; sel.mode = (Mode) mode;
    positionIndex = position;
    rootBox.setSelectedItemIndex (r, juce::dontSendNotification);
    familyBox.setSelectedItemIndex (family, juce::dontSendNotification);
    minorTypeBox.setSelectedItemIndex (minorType, juce::dontSendNotification);
    modeBox.setSelectedItemIndex (mode, juce::dontSendNotification);
    rebuild();
}

void ScalesPanel::rebuild()
{
    stopDemo();
    scale = build (sel);
    const bool flats = preferFlats (sel);
    const bool hasMajMin = sel.family != Family::modes;
    majorButton.setVisible (hasMajMin);
    minorButton.setVisible (hasMajMin);
    majorButton.setToggleState (! sel.minor, juce::dontSendNotification);
    minorButton.setToggleState (sel.minor, juce::dontSendNotification);
    minorTypeBox.setVisible (sel.family == Family::sevenNote && sel.minor);
    modeBox.setVisible (sel.family == Family::modes);

    refreshPositionBox();
    refreshGrooveBox();
    board.setScale (sel.root, scale, flats);
    board.setPosition (currentSpots(), positionIndex == 0);
    board.setTarget (-1, -1, -1);

    // 说明文字
    titleText = scale.name;
    formulaText = T ("级数  ");
    notesText = T ("音名  ");
    for (int iv : scale.intervals)
    {
        formulaText << degreeName (iv, scale) << "   ";
        notesText << spell (sel.root + iv, sel.root, scale, flats) << "   ";
    }
    relativeText = relativeHint (sel);
    descText = scale.description;

    if (following) setFollow (true);
    saveSettings();
    resized();
    repaint();
}

void ScalesPanel::refreshPositionBox()
{
    positionBox.clear (juce::dontSendNotification);
    positionBox.addItem (T ("全指板"), 1);
    const int n = numPositions (scale);
    for (int k = 0; k < n; ++k)
    {
        const auto span = fretSpan (position (sel.root, scale, k));
        positionBox.addItem (T ("把位 ") + juce::String (k + 1) + T ("（") + juce::String (span.getStart()) + "–"
                                 + juce::String (span.getEnd()) + T (" 品）"), k + 2);
    }
    positionIndex = juce::jlimit (0, n, positionIndex);
    positionBox.setSelectedId (positionIndex + 1, juce::dontSendNotification);
}

std::vector<Spot> ScalesPanel::currentSpots() const
{
    if (positionIndex > 0)
        return position (sel.root, scale, positionIndex - 1);
    // 全指板：示范 / 跟弹用把位 1
    return position (sel.root, scale, 0);
}

std::vector<Spot> ScalesPanel::sequence() const
{
    auto up = currentSpots();
    std::sort (up.begin(), up.end(), [] (const Spot& a, const Spot& b) { return a.midi < b.midi; });
    const int dir = directionBox.getSelectedItemIndex();
    if (dir == 0) return up;
    std::vector<Spot> down (up.rbegin(), up.rend());
    if (dir == 1) return down;
    auto both = up;
    both.insert (both.end(), down.begin() + 1, down.end());     // 最高音不重复
    return both;
}

void ScalesPanel::stepPosition (int delta)
{
    const int n = numPositions (scale);
    positionIndex = ((positionIndex - 1 + delta) % n + n) % n + 1;   // 在把位 1..n 之间循环
    rebuild();
}

// ---- 示范 ------------------------------------------------------------------------
void ScalesPanel::startDemo()
{
    if (following) { followButton.setToggleState (false, juce::dontSendNotification); setFollow (false); }
    demoSeq = sequence();
    if (demoSeq.empty()) return;
    demoIndex = 0;
    demoNextMs = juce::Time::getMillisecondCounterHiRes() + 60.0;
    demoPlaying = true;
    playButton.setButtonText (juce::String::fromUTF8 ("\xe2\x96\xa0 ") + T ("停止"));
}

void ScalesPanel::stopDemo()
{
    if (! demoPlaying) return;
    demoPlaying = false;
    engine.stopPreview();
    board.setTarget (-1, -1, -1);
    playButton.setButtonText (juce::String::fromUTF8 ("\xe2\x96\xb6 ") + T ("示范"));
}

void ScalesPanel::setQuiz (bool on)
{
    quizButton.setToggleState (on, juce::dontSendNotification);
    if (on)
    {
        stopDemo();
        if (following) { followButton.setToggleState (false, juce::dontSendNotification); setFollow (false); }
        trainer->setVisible (true);
        trainer->start();
    }
    else
    {
        trainer->stop();
        trainer->setVisible (false);
    }
    for (auto* c : std::initializer_list<juce::Component*> { &playButton, &followButton, &directionBox, &loopToggle, &bpmSlider, &speedLabel })
        c->setEnabled (! on);
    resized();
    repaint();
}

void ScalesPanel::stopAll()
{
    if (trainer != nullptr && trainer->isRunning()) setQuiz (false);
    stopDemo();
    if (following) { followButton.setToggleState (false, juce::dontSendNotification); setFollow (false); }
}

void ScalesPanel::timerCallback()
{
    if (! demoPlaying) return;
    const double now = juce::Time::getMillisecondCounterHiRes();
    if (now < demoNextMs) return;

    if (demoIndex >= demoSeq.size())
    {
        if (! loopToggle.getToggleState()) { stopDemo(); return; }
        demoIndex = 0;
    }
    const auto& sp = demoSeq[demoIndex++];
    const double beatMs = 60000.0 / bpmSlider.getValue();
    engine.previewNote (sp.midi, 0.85f, beatMs / 1000.0 * 1.6);
    board.setTarget (sp.midi, sp.string, sp.fret);
    demoNextMs += beatMs;
    if (demoNextMs < now) demoNextMs = now + beatMs;            // 卡顿后别连发
}

// ---- 跟弹 / 听音 ---------------------------------------------------------------------
void ScalesPanel::setFollow (bool on)
{
    following = on;
    if (on)
    {
        stopDemo();
        followSeq = sequence();
        followIndex = 0;
        lastAcceptedMidi = -1;
        stableMidi = -1; stableFrames = 0;
        followStartMs = juce::Time::getMillisecondCounterHiRes();
        followRounds = 0;
        if (! followSeq.empty())
            board.setTarget (followSeq[0].midi, followSeq[0].string, followSeq[0].fret);
        followText = T ("弹绿圈里的音：") + noteName (followSeq.empty() ? 0 : followSeq[0].midi, preferFlats (sel), true)
                   + T ("，弹对了自动跳到下一个");
    }
    else
    {
        board.setTarget (-1, -1, -1);
        followText = {};
    }
    repaint (followArea);
}

void ScalesPanel::setDetectedPitch (const PitchDetector::Result& r)
{
    // 门槛跟着底噪走：底噪慢慢往下贴、往上爬得更慢（弹琴时不会被当成底噪）
    if (r.rmsDb > -100.0f)
        noiseFloorDb += (r.rmsDb < noiseFloorDb ? 0.3f : 0.004f) * (r.rmsDb - noiseFloorDb);
    const float gateDb = juce::jlimit (-72.0f, -45.0f, noiseFloorDb + 9.0f);
    const bool valid = r.frequency > 0.0f && r.clarity > 0.8f && r.rmsDb > gateDb;
    const int midi = valid ? midiFromHz (r.frequency) : -1;
    board.setPlayed (midi, valid);

    // “你弹的音”
    juce::String text;
    juce::Colour col = mutedText;
    if (valid)
    {
        const double cents = 1200.0 * std::log2 (r.frequency / (440.0 * std::pow (2.0, (midi - 69) / 12.0)));
        const bool ok = inScale (midi, sel.root, scale);
        text = noteName (midi, preferFlats (sel), true) + "  " + (ok ? T ("在音阶里  ") + degreeName (midi - sel.root, scale) + T (" 级")
                                                                     : T ("不在这个音阶里"));
        if (std::abs (cents) > 15.0) text << "   (" << (cents > 0 ? "+" : "") << juce::roundToInt (cents) << T (" 音分") << ")";
        col = ok ? playedColour : juce::Colour (0xffff6b5a);
    }
    if (text != playedText || col != playedTextColour)
    {
        playedText = text;
        playedTextColour = col;
        repaint (infoArea);
    }

    if (trainer != nullptr && trainer->isRunning())
    {
        if (midi == stableMidi) ++stableFrames; else { stableMidi = midi; stableFrames = 1; }
        if (stableFrames == 2 || midi < 0) trainer->setDetectedNote (midi);
        return;
    }

    if (! following || followSeq.empty()) return;

    // 同一个音连续 2 帧才算；和上一个接受的音一样时，要先松开（换音或静音）再算
    if (midi == stableMidi) ++stableFrames; else { stableMidi = midi; stableFrames = 1; }
    if (midi < 0) lastAcceptedMidi = -1;
    const auto& target = followSeq[followIndex];
    if (stableFrames >= 2 && midi == target.midi && midi != lastAcceptedMidi)
    {
        lastAcceptedMidi = midi;
        board.setFlash (true);
        if (onPetEvent) onPetEvent (followIndex + 1 >= followSeq.size() ? 0 : 1, (int) followIndex + 1);
        if (++followIndex >= followSeq.size())
        {
            ++followRounds;
            const double secs = (juce::Time::getMillisecondCounterHiRes() - followStartMs) / 1000.0;
            followIndex = 0;
            followText = T ("完成第 ") + juce::String (followRounds) + T (" 遍！平均每遍 ")
                       + juce::String (secs / followRounds, 1) + T (" 秒，接着来");
        }
        else
        {
            followText = T ("第 ") + juce::String ((int) followIndex + 1) + " / " + juce::String ((int) followSeq.size())
                       + T (" 个音：") + noteName (followSeq[followIndex].midi, preferFlats (sel), true);
            if (followRounds > 0) followText << T ("    已完成 ") << followRounds << T (" 遍");
        }
        const auto& next = followSeq[followIndex];
        board.setTarget (next.midi, next.string, next.fret);
        repaint (followArea);
    }
}

bool ScalesPanel::keyPressed (const juce::KeyPress& key)
{
    if (key.getTextCharacter() == 'q' || key.getTextCharacter() == 'Q') { setQuiz (! trainer->isRunning()); return true; }
    if (trainer->isRunning()) return trainer->keyPressed (key);
    if (key == juce::KeyPress::spaceKey)       { demoPlaying ? stopDemo() : startDemo(); return true; }
    if (key == juce::KeyPress::leftKey)        { stepPosition (-1); return true; }
    if (key == juce::KeyPress::rightKey)       { stepPosition (1); return true; }
    if (key == juce::KeyPress::upKey)          { sel.root = (sel.root + 1) % 12; rootBox.setSelectedItemIndex (sel.root, juce::dontSendNotification); rebuild(); return true; }
    if (key == juce::KeyPress::downKey)        { sel.root = (sel.root + 11) % 12; rootBox.setSelectedItemIndex (sel.root, juce::dontSendNotification); rebuild(); return true; }
    if (key.getTextCharacter() == 'f' || key.getTextCharacter() == 'F')
    {
        followButton.setToggleState (! following, juce::dontSendNotification);
        setFollow (! following);
        return true;
    }
    return false;
}

// ---- 布局 ----------------------------------------------------------------------------
// 指板音阶页下面放了鼓机，高度不够时（< 620）用紧凑排版：说明压成两行，“你弹的音”压成一条
static bool isCompact (const juce::Component& c) { return c.getHeight() < 620; }

void ScalesPanel::paint (juce::Graphics& g)
{
    const bool compact = isCompact (*this);
    auto controls = getLocalBounds().removeFromTop (138);
    g.setColour (panelColour);
    g.fillRoundedRectangle (controls.toFloat(), 10.0f);
    if (trainer != nullptr && trainer->isRunning())
    {
        g.fillRoundedRectangle (board.getBounds().toFloat().expanded (0.0f, 4.0f), 10.0f);
        return;
    }
    g.fillRoundedRectangle (infoArea.toFloat(), 10.0f);
    g.fillRoundedRectangle (board.getBounds().toFloat().expanded (0.0f, 4.0f), 10.0f);
    g.fillRoundedRectangle (followArea.toFloat(), 10.0f);

    auto drawLegend = [&g, this] (juce::Rectangle<int> legend)
    {
        auto item = [&g, &legend] (juce::Colour c, const juce::String& t)
        {
            auto a = legend.removeFromRight (juce::GlyphArrangement::getStringWidthInt (juce::FontOptions (13.0f), t) + 30);
            g.setColour (c);
            g.fillEllipse ((float) a.getX(), (float) a.getCentreY() - 6.0f, 12.0f, 12.0f);
            g.setColour (mutedText);
            g.setFont (juce::FontOptions (13.0f));
            g.drawText (t, a.withTrimmedLeft (17), juce::Justification::centredLeft);
        };
        item (playedColour, T ("你弹的"));
        if (! scale.blueNotes.empty()) item (blueColour, T ("蓝调音"));
        item (toneColour, T ("音阶音"));
        item (rootColour, T ("根音"));
    };

    const juce::String hint = T ("点“跟弹练习”：绿圈是下一个要弹的音，弹对了自动跳到下一个。点指板上的音可以试听。");

    if (compact)
    {
        // 说明：第一行 名字 + 级数 + 音名，第二行 关系调 + 用法
        auto r = infoArea.reduced (16, 8);
        auto line1 = r.removeFromTop (26);
        g.setColour (juce::Colours::white);
        g.setFont (juce::FontOptions (19.0f, juce::Font::bold));
        const int tw = juce::GlyphArrangement::getStringWidthInt (juce::FontOptions (19.0f, juce::Font::bold), titleText) + 24;
        g.drawText (titleText, line1.removeFromLeft (tw), juce::Justification::centredLeft);
        g.setFont (juce::FontOptions (15.0f, juce::Font::bold));
        g.setColour (juce::Colour (0xff9cc4ff));
        const int fw = juce::GlyphArrangement::getStringWidthInt (juce::FontOptions (15.0f, juce::Font::bold), formulaText) + 16;
        g.drawText (formulaText, line1.removeFromLeft (fw), juce::Justification::centredLeft);
        g.setColour (juce::Colours::white.withAlpha (0.9f));
        g.drawText (notesText, line1, juce::Justification::centredLeft, true);
        g.setFont (juce::FontOptions (13.0f));
        g.setColour (mutedText);
        g.drawText (relativeText + T ("。") + descText, r.removeFromTop (20), juce::Justification::centredLeft, true);

        // 一条：你弹的音 | 跟弹进度 / 提示 | 图例
        auto f = followArea.reduced (16, 0);
        auto played = f.removeFromLeft (300);
        g.setFont (juce::FontOptions (18.0f, juce::Font::bold));
        g.setColour (playedText.isEmpty() ? mutedText.withAlpha (0.6f) : playedTextColour);
        g.drawText (playedText.isEmpty() ? T ("你弹的音会显示在这里") : playedText, played, juce::Justification::centredLeft, true);
        drawLegend (f.removeFromRight (300));
        g.setFont (juce::FontOptions (14.0f, following ? juce::Font::bold : juce::Font::plain));
        g.setColour (following ? targetColour : mutedText);
        g.drawFittedText (following ? followText : hint, f.reduced (8, 0), juce::Justification::centredLeft, 2, 0.85f);
        return;
    }

    // ---- 宽松排版 ----
    auto r = infoArea.reduced (18, 12);
    auto top = r.removeFromTop (30);
    g.setColour (juce::Colours::white);
    g.setFont (juce::FontOptions (22.0f, juce::Font::bold));
    g.drawText (titleText, top.removeFromLeft (360), juce::Justification::centredLeft);
    drawLegend (top);
    r.removeFromTop (4);
    g.setFont (juce::FontOptions (15.0f, juce::Font::bold));
    g.setColour (juce::Colour (0xff9cc4ff));
    g.drawText (formulaText, r.removeFromTop (22), juce::Justification::centredLeft);
    g.setColour (juce::Colours::white.withAlpha (0.9f));
    g.drawText (notesText, r.removeFromTop (22), juce::Justification::centredLeft);
    g.setFont (juce::FontOptions (13.5f));
    g.setColour (mutedText);
    g.drawText (relativeText + T ("。") + descText, r.removeFromTop (20), juce::Justification::centredLeft, true);

    auto f = followArea.reduced (18, 12);
    g.setFont (juce::FontOptions (13.0f));
    g.setColour (mutedText);
    g.drawText (T ("你弹的音"), f.removeFromTop (18), juce::Justification::centredLeft);
    g.setFont (juce::FontOptions (24.0f, juce::Font::bold));
    g.setColour (playedText.isEmpty() ? mutedText.withAlpha (0.6f) : playedTextColour);
    g.drawText (playedText.isEmpty() ? T ("（弹一个音试试）") : playedText, f.removeFromTop (34), juce::Justification::centredLeft);
    f.removeFromTop (6);
    g.setFont (juce::FontOptions (15.0f, following ? juce::Font::bold : juce::Font::plain));
    g.setColour (following ? targetColour : mutedText);
    g.drawText (following ? followText : hint, f.removeFromTop (22), juce::Justification::centredLeft, true);
    g.setFont (juce::FontOptions (12.5f));
    g.setColour (mutedText.withAlpha (0.8f));
    g.drawText (T ("快捷键：空格 示范 / 停止    ← → 换把位    ↑ ↓ 换根音    F 跟弹练习    D 鼓机"), f.removeFromBottom (18), juce::Justification::centredLeft);
}

void ScalesPanel::resized()
{
    auto area = getLocalBounds();
    auto controls = area.removeFromTop (138).reduced (16, 12);

    auto row1 = controls.removeFromTop (32);
    rootLabel.setBounds (row1.removeFromLeft (40));
    rootBox.setBounds (row1.removeFromLeft (96));
    row1.removeFromLeft (18);
    familyLabel.setBounds (row1.removeFromLeft (40));
    familyBox.setBounds (row1.removeFromLeft (200));
    row1.removeFromLeft (12);
    if (majorButton.isVisible())
    {
        majorButton.setBounds (row1.removeFromLeft (60));
        minorButton.setBounds (row1.removeFromLeft (60));
        row1.removeFromLeft (12);
    }
    instrumentBox.setBounds (row1.removeFromRight (110));
    row1.removeFromRight (10);
    if (minorTypeBox.isVisible()) minorTypeBox.setBounds (row1.removeFromLeft (120));
    if (modeBox.isVisible())      modeBox.setBounds (row1.removeFromLeft (210));

    controls.removeFromTop (8);
    auto row2 = controls.removeFromTop (32);
    positionLabel.setBounds (row2.removeFromLeft (40));
    prevPosButton.setBounds (row2.removeFromLeft (34));
    row2.removeFromLeft (4);
    positionBox.setBounds (row2.removeFromLeft (180));
    row2.removeFromLeft (4);
    nextPosButton.setBounds (row2.removeFromLeft (34));
    row2.removeFromLeft (16);
    labelsLabel.setBounds (row2.removeFromLeft (40));
    labelsBox.setBounds (row2.removeFromLeft (90));
    row2.removeFromLeft (16);
    grooveLabel.setBounds (row2.removeFromLeft (40));
    grooveButton.setBounds (row2.removeFromRight (100));
    row2.removeFromRight (6);
    grooveBox.setBounds (row2);

    controls.removeFromTop (8);
    auto row3 = controls.removeFromTop (32);
    playButton.setBounds (row3.removeFromLeft (96));
    row3.removeFromLeft (10);
    directionBox.setBounds (row3.removeFromLeft (128));
    row3.removeFromLeft (16);
    speedLabel.setBounds (row3.removeFromLeft (40));
    bpmSlider.setBounds (row3.removeFromLeft (240));
    row3.removeFromLeft (10);
    loopToggle.setBounds (row3.removeFromLeft (70));
    followButton.setBounds (row3.removeFromRight (110));
    row3.removeFromRight (8);
    quizButton.setBounds (row3.removeFromRight (100));

    const bool compact = isCompact (*this);
    if (trainer != nullptr && trainer->isRunning())
    {
        area.removeFromTop (compact ? 8 : 10);
        trainer->setBounds (area.removeFromTop (compact ? 108 : 132));
        area.removeFromTop (compact ? 8 : 10);
        board.setBounds (area.reduced (0, 4));
        return;
    }
    area.removeFromTop (compact ? 8 : 10);
    infoArea = area.removeFromTop (compact ? 62 : 128);
    area.removeFromTop (compact ? 8 : 10);
    followArea = compact ? area.removeFromBottom (44)
                         : area.removeFromBottom (juce::jlimit (110, 150, area.getHeight() - 290));
    area.removeFromBottom (compact ? 8 : 10);
    board.setBounds (area.reduced (0, 4));
}

// =============================================================================
// 认音训练
namespace
{
    const char* pcNames[] = { "C", "C#/Db", "D", "D#/Eb", "E", "F", "F#/Gb", "G", "G#/Ab", "A", "A#/Bb", "B" };
    const juce::Colour quizAsk   { 0xfff59e0b };
    const juce::Colour quizGood  { 0xff22c55e };
    const juce::Colour quizBad   { 0xffef4444 };
    const juce::Colour quizFound { 0xff3b82f6 };
    // 练哪几根弦：位 0 = 最粗的弦。名字按现在的乐器（6 弦吉他 / 4 弦贝斯…）现算
    uint8_t stringPresetMask (int i, int n)
    {
        const uint8_t all = (uint8_t) ((1 << n) - 1);
        switch (i)
        {
            case 0: return all;
            case 1: return 0x01;
            case 2: return 0x02;
            case 3: return 0x03;
            case 4: return 0x04;
            case 5: return 0x08 & all ? 0x08 : 0x04;
            case 6: return (uint8_t) (all & ~((1 << juce::jmax (0, n - 3)) - 1));     // 最细的三根
            default: return 0x07 & all;                                                // 最粗的三根
        }
    }
    juce::String stringPresetName (int i, int n)
    {
        const auto m = stringPresetMask (i, n);
        if (i == 0) return T ("全部 ") + juce::String (n) + T (" 根弦");
        juce::StringArray parts;
        for (int b = 0; b < n; ++b) if (m & (1 << b)) parts.add (juce::String (n - b));
        if (parts.size() == 1) return T ("只练 ") + parts[0] + T (" 弦");
        if (parts.size() == 2) return parts[0] + T (" 弦 + ") + parts[1] + T (" 弦");
        return parts[parts.size() - 1] + "–" + parts[0] + T (" 弦");
    }
    constexpr int numStringPresets = 8;
    struct FretPreset { const char* name; int lo, hi; };
    const FretPreset fretPresets[] = { { "0–5 品（开放把位）", 0, 5 }, { "0–12 品", 0, 12 }, { "5–12 品", 5, 12 }, { "12–17 品", 12, 17 }, { "0–17 品（全）", 0, 17 } };
}

NoteTrainer::NoteTrainer (Fretboard& b, AudioEngine& e, juce::PropertiesFile& s) : board (b), engine (e), settings (s)
{
    typeBox.addItemList ({ T ("看位置说音名"), T ("看音名找位置") }, 1);
    typeBox.setSelectedItemIndex (juce::jlimit (0, 1, settings.getIntValue ("quizType", 0)), juce::dontSendNotification);
    typeBox.setTooltip (T ("看位置说音名：指板上亮一个位置，点出它是什么音（或按键盘 C D E F G A B，Shift = 升半音）\n"
                           "看音名找位置：给一个音名，把范围里它所有的位置都弹出来（或者在指板上点出来）"));
    typeBox.onChange = [this] { settings.setValue ("quizType", typeBox.getSelectedItemIndex()); applyRange(); quiz.resetStats(); ask(); };
    addAndMakeVisible (typeBox);

    refreshInstrument();
    stringsBox.setSelectedItemIndex (juce::jlimit (0, numStringPresets - 1, settings.getIntValue ("quizStrings", 3)), juce::dontSendNotification);
    stringsBox.onChange = [this] { settings.setValue ("quizStrings", stringsBox.getSelectedItemIndex()); applyRange(); ask(); };
    addAndMakeVisible (stringsBox);
    for (int i = 0; i < (int) std::size (fretPresets); ++i) fretsBox.addItem (T (fretPresets[i].name), i + 1);
    fretsBox.setSelectedItemIndex (juce::jlimit (0, (int) std::size (fretPresets) - 1, settings.getIntValue ("quizFrets", 1)), juce::dontSendNotification);
    fretsBox.onChange = [this] { settings.setValue ("quizFrets", fretsBox.getSelectedItemIndex()); applyRange(); ask(); };
    addAndMakeVisible (fretsBox);

    naturalsToggle.setButtonText (T ("只练自然音"));
    naturalsToggle.setTooltip (T ("只出 C D E F G A B，不出升降音（刚开始练时用）"));
    naturalsToggle.setToggleState (settings.getBoolValue ("quizNaturals", false), juce::dontSendNotification);
    naturalsToggle.onClick = [this] { settings.setValue ("quizNaturals", naturalsToggle.getToggleState()); applyRange(); ask(); };
    addAndMakeVisible (naturalsToggle);
    soundToggle.setButtonText (T ("答对放音"));
    soundToggle.setToggleState (settings.getBoolValue ("quizSound", true), juce::dontSendNotification);
    soundToggle.onClick = [this] { settings.setValue ("quizSound", soundToggle.getToggleState()); };
    addAndMakeVisible (soundToggle);

    resetButton.setButtonText (T ("重新计分"));
    resetButton.onClick = [this] { quiz.resetStats(); ask(); repaint(); };
    addAndMakeVisible (resetButton);
    skipButton.setButtonText (T ("跳过 / 下一题"));
    skipButton.setTooltip (T ("空格"));
    skipButton.onClick = [this] { ask(); };
    addAndMakeVisible (skipButton);

    for (int pc = 0; pc < 12; ++pc)
    {
        auto& nb = nameButtons[(size_t) pc];
        nb.setButtonText (pcNames[pc]);
        const bool natural = juce::String (pcNames[pc]).length() == 1;
        nb.setColour (juce::TextButton::buttonColourId, natural ? juce::Colour (0xff3a3f46) : juce::Colour (0xff23262b));
        nb.onClick = [this, pc] { handle (quiz.answerName (pc, juce::Time::getMillisecondCounterHiRes())); };
        addChildComponent (nb);
    }

    board.onSpotClicked = [this] (int s, int f)
    {
        if (! running) return;
        if (quiz.getType() == NoteQuiz::Type::findTheNote)
            handle (quiz.answerSpot (s, f, juce::Time::getMillisecondCounterHiRes()));
        else
            engine.previewNote (ScaleTheory::openMidi[s] + f, 0.8f, 1.0);
    };
    applyRange();
}

NoteTrainer::~NoteTrainer()
{
    board.onSpotClicked = nullptr;
}

void NoteTrainer::applyRange()
{
    NoteQuiz::Range r;
    const uint8_t mask = stringPresetMask (juce::jlimit (0, numStringPresets - 1, stringsBox.getSelectedItemIndex()), numStrings());
    const auto& fp = fretPresets[juce::jlimit (0, (int) std::size (fretPresets) - 1, fretsBox.getSelectedItemIndex())];
    r.stringMask = mask;
    r.fretLo = fp.lo;
    r.fretHi = fp.hi;
    r.naturalsOnly = naturalsToggle.getToggleState();
    quiz.setRange (r);
    quiz.setType (typeBox.getSelectedItemIndex() == 1 ? NoteQuiz::Type::findTheNote : NoteQuiz::Type::nameTheSpot);
    if (running) board.setQuizMode (true, r);
    const bool names = quiz.getType() == NoteQuiz::Type::nameTheSpot;
    for (int pc = 0; pc < 12; ++pc)
    {
        const bool natural = juce::String (pcNames[pc]).length() == 1;
        nameButtons[(size_t) pc].setVisible (names && (natural || ! r.naturalsOnly));
    }
    resized();
}

void NoteTrainer::refreshInstrument()
{
    const int sel = juce::jmax (0, stringsBox.getSelectedItemIndex());
    stringsBox.clear (juce::dontSendNotification);
    for (int i = 0; i < numStringPresets; ++i) stringsBox.addItem (stringPresetName (i, numStrings()), i + 1);
    stringsBox.setSelectedItemIndex (sel, juce::dontSendNotification);
    applyRange();
    if (running) ask();
}

void NoteTrainer::start()
{
    running = true;
    applyRange();
    board.setQuizMode (true, quiz.getRange());
    ask();
    startTimerHz (30);
}

void NoteTrainer::stop()
{
    running = false;
    stopTimer();
    saveBest();
    board.setQuizMarks ({});
    board.setQuizMode (false, quiz.getRange());
}

void NoteTrainer::saveBest()
{
    const int best = quiz.getStats().bestStreak;
    if (best > settings.getIntValue ("quizBestStreak", 0))
        settings.setValue ("quizBestStreak", best);
}

void NoteTrainer::ask()
{
    quiz.next (juce::Time::getMillisecondCounterHiRes());
    nextAt = 0.0;
    lastPlayed = -1;
    if (quiz.getType() == NoteQuiz::Type::nameTheSpot)
        feedback = T ("橙色圆点是什么音？");
    else
        feedback = T ("把范围里所有的 ") + juce::String (pcNames[quiz.askedPitchClass()]) + T (" 都找出来：弹出来，或者在指板上点");
    feedbackColour = juce::Colours::white;
    showMarks (false);
    repaint();
}

void NoteTrainer::showMarks (bool reveal)
{
    std::vector<Fretboard::QuizMark> marks;
    if (quiz.getType() == NoteQuiz::Type::nameTheSpot)
    {
        const auto sp = quiz.askedSpot();
        Fretboard::QuizMark m;
        m.string = sp.string; m.fret = sp.fret;
        m.colour = reveal ? (feedbackColour == quizBad ? quizBad : quizGood) : quizAsk;
        m.text = reveal ? ScaleTheory::noteName (sp.midi(), flats) : juce::String ("?");
        m.pulse = ! reveal;
        marks.push_back (m);
    }
    else
    {
        const auto& t = quiz.targets();
        const auto& f = quiz.found();
        for (size_t i = 0; i < t.size(); ++i)
            if (f[i] || reveal)
            {
                Fretboard::QuizMark m;
                m.string = t[i].string; m.fret = t[i].fret;
                m.colour = f[i] ? quizFound : quizBad.withAlpha (0.8f);
                m.text = ScaleTheory::noteName (t[i].midi(), flats);
                marks.push_back (m);
            }
    }
    board.setQuizMarks (std::move (marks));
}

void NoteTrainer::handle (NoteQuiz::Outcome o)
{
    if (o == NoteQuiz::Outcome::none) return;
    const double now = juce::Time::getMillisecondCounterHiRes();
    const auto& st = quiz.getStats();
    if (quiz.getType() == NoteQuiz::Type::nameTheSpot)
    {
        const auto sp = quiz.askedSpot();
        if (o == NoteQuiz::Outcome::correct)
        {
            feedback = T ("对！") + ScaleTheory::noteName (sp.midi(), flats) + T ("（") + juce::String (numStrings() - sp.string) + T (" 弦 ")
                     + juce::String (sp.fret) + T (" 品）");
            feedbackColour = quizGood;
            nextAt = now + 650.0;
        }
        else
        {
            feedback = T ("不对，是 ") + juce::String (pcNames[quiz.askedPitchClass()]);
            feedbackColour = quizBad;
            nextAt = now + 1500.0;
        }
        if (soundToggle.getToggleState()) engine.previewNote (sp.midi(), 0.8f, 1.0);
        showMarks (true);
    }
    else
    {
        if (o == NoteQuiz::Outcome::partial)
        {
            int n = 0;
            for (bool b : quiz.found()) n += b ? 1 : 0;
            feedback = T ("找到 ") + juce::String (n) + " / " + juce::String ((int) quiz.targets().size()) + T ("，继续");
            feedbackColour = quizFound;
        }
        else if (o == NoteQuiz::Outcome::wrong && ! quiz.isAnswered())
        {
            feedback = T ("那不是 ") + juce::String (pcNames[quiz.askedPitchClass()]) + T ("，再找找");
            feedbackColour = quizBad;
        }
        else
        {
            const bool ok = o == NoteQuiz::Outcome::correct;
            feedback = ok ? T ("全找到了！") : T ("找全了，不过中间点错过");
            feedbackColour = ok ? quizGood : juce::Colour (0xfff59e0b);
            nextAt = now + 900.0;
        }
        showMarks (false);
    }
    if (st.bestStreak > settings.getIntValue ("quizBestStreak", 0)) saveBest();
    if (onPetEvent)
    {
        if (o == NoteQuiz::Outcome::correct)
            onPetEvent (st.streak > 0 && st.streak % 10 == 0 ? 6 : (st.streak >= 3 ? 0 : 1), st.streak);   // 连对 10 = 连击，连对 3 个以上 = 完美
        else if (o == NoteQuiz::Outcome::wrong)
            onPetEvent (2, 0);
    }
    repaint();
}

void NoteTrainer::setDetectedNote (int midi)
{
    if (! running || quiz.getType() != NoteQuiz::Type::findTheNote) return;
    if (midi == lastPlayed) return;
    lastPlayed = midi;
    if (midi < 0) return;
    handle (quiz.answerPlayed (midi, juce::Time::getMillisecondCounterHiRes()));
}

void NoteTrainer::timerCallback()
{
    if (nextAt > 0.0 && juce::Time::getMillisecondCounterHiRes() >= nextAt)
        ask();
    board.repaint();     // 题目圆点一闪一闪
}

bool NoteTrainer::keyPressed (const juce::KeyPress& key)
{
    if (! running) return false;
    if (key == juce::KeyPress::spaceKey) { ask(); return true; }
    const auto c = juce::CharacterFunctions::toUpperCase (key.getTextCharacter());
    const int base = c == 'C' ? 0 : c == 'D' ? 2 : c == 'E' ? 4 : c == 'F' ? 5 : c == 'G' ? 7 : c == 'A' ? 9 : c == 'B' ? 11 : -1;
    if (base >= 0 && quiz.getType() == NoteQuiz::Type::nameTheSpot)
    {
        const int pc = (base + (key.getModifiers().isShiftDown() ? 1 : 0)) % 12;
        handle (quiz.answerName (pc, juce::Time::getMillisecondCounterHiRes()));
        return true;
    }
    return false;
}

void NoteTrainer::paint (juce::Graphics& g)
{
    g.setColour (panelColour);
    g.fillRoundedRectangle (getLocalBounds().toFloat(), 10.0f);

    g.setColour (feedbackColour);
    g.setFont (juce::FontOptions (questionArea.getHeight() > 40 ? 24.0f : 19.0f, juce::Font::bold));
    g.drawFittedText (feedback, questionArea, juce::Justification::centredLeft, 1, 0.8f);

    const auto& st = quiz.getStats();
    juce::String line;
    line << T ("答题 ") << st.asked << T ("   正确率 ") << (st.asked > 0 ? juce::String (juce::roundToInt (st.accuracy() * 100.0f)) + "%" : juce::String ("--"))
         << T ("   平均 ") << (st.correct > 0 ? juce::String (st.avgSeconds(), 1) + T (" 秒") : juce::String ("--"))
         << T ("   连对 ") << st.streak << T ("（最高 ") << juce::jmax (st.bestStreak, settings.getIntValue ("quizBestStreak", 0)) << T ("）");
    const auto weak = quiz.weakestNotes (flats);
    g.setFont (juce::FontOptions (13.5f));
    g.setColour (mutedText);
    auto sa = statsArea;
    g.drawText (line, sa.removeFromTop (sa.getHeight() / 2), juce::Justification::centredRight, true);
    if (weak.isNotEmpty())
        g.drawText (T ("最容易错：") + weak, sa, juce::Justification::centredRight, true);
}

void NoteTrainer::resized()
{
    auto r = getLocalBounds().reduced (14, 8);
    auto row1 = r.removeFromTop (28);
    typeBox.setBounds (row1.removeFromLeft (150));
    row1.removeFromLeft (8);
    stringsBox.setBounds (row1.removeFromLeft (150));
    row1.removeFromLeft (8);
    fretsBox.setBounds (row1.removeFromLeft (160));
    row1.removeFromLeft (10);
    naturalsToggle.setBounds (row1.removeFromLeft (110));
    soundToggle.setBounds (row1.removeFromLeft (96));
    resetButton.setBounds (row1.removeFromRight (84));
    row1.removeFromRight (6);
    skipButton.setBounds (row1.removeFromRight (124));
    r.removeFromTop (6);

    const bool names = quiz.getType() == NoteQuiz::Type::nameTheSpot;
    if (names)
    {
        auto row3 = r.removeFromBottom (juce::jmin (34, r.getHeight() / 2));
        int visible = 0;
        for (auto& b : nameButtons) visible += b.isVisible() ? 1 : 0;
        const int w = row3.getWidth() / juce::jmax (1, visible);
        for (auto& b : nameButtons)
            if (b.isVisible())
                b.setBounds (row3.removeFromLeft (w).reduced (2, 0));
        r.removeFromBottom (4);
    }
    statsArea = r.removeFromRight (juce::jmin (430, r.getWidth() / 2));
    questionArea = r;
}
