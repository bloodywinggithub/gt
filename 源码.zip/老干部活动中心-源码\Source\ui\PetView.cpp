#include "PetView.h"
#include "AppPaths.h"
#include "Text.h"
#include "BinaryData.h"
#include <cmath>
#include <map>

namespace
{

    constexpr float pi = juce::MathConstants<float>::pi;

    const char* const poseFiles[] = { "normal", "miss", "good", "perfect", "wrong", "early", "late", "combo" };

    const juce::StringArray& lines (const char* key)
    {
        static std::map<juce::String, juce::StringArray> m = {
            { "perfect", { T ("嗯，这一下还行。"), T ("早这样不就好了。"), T ("勉强及格。"), T ("别得意，下一个。"), T ("这才是你该有的水平。") } },
            { "good",    { T ("凑合。"), T ("差一点就对了。"), T ("就这？"), T ("还能更准。") } },
            { "early",   { T ("急着下课？"), T ("抢拍了，数拍子！"), T ("谁让你先弹的？") } },
            { "late",    { T ("慢了，没吃饭？"), T ("拖拍了，跟上！"), T ("节拍器是摆设吗？") } },
            { "wrong",   { T ("这也能错？"), T ("……你认真的？"), T ("音都按不准？"), T ("再错一次试试。") } },
            { "miss",    { T ("人呢？"), T ("漏了，眼睛看谱！"), T ("发什么呆？") } },
            { "combo",   { T ("哼，有点样子了。"), T ("别停，继续。"), T ("这才叫练琴。") } },
            { "cheer",   { T ("总算像点样了。"), T ("今天这遍我认了。") } },
            { "bored",   { T ("表都看三遍了。"), T ("还练不练？"), T ("琴是摆着看的？") } },
            { "sleepy",  { T ("唉……"), T ("我就看着你不练。") } },
            { "poke",    { T ("戳我干嘛？练琴！"), T ("手放回琴上。"), T ("少摸鱼。"), T ("看我没用，看谱。") } },
            { "back",    { T ("还知道回来。"), T ("开始吧，别磨蹭。") } },
        };
        return m[key];
    }
}

const char* PetView::poseName (Pose p) { return poseFiles[(int) p]; }

void PetView::Spring::step (float dt, float k, float damping)
{
    const float a = k * (target - value) - damping * velocity;
    velocity += a * dt;
    value += velocity * dt;
}

PetView::PetView()
{
    // 先找程序旁边的 音色库\桌宠\*.png（可以自己换图），没有就用程序里自带的
    const auto dir = AppPaths::appFolder()
                         .getChildFile (T ("音色库")).getChildFile (T ("桌宠"));
    for (int i = 0; i < 8; ++i)
    {
        const auto f = dir.getChildFile (juce::String (poseFiles[i]) + ".png");
        if (f.existsAsFile())
            images[(size_t) i] = juce::ImageFileFormat::loadFrom (f);
        if (images[(size_t) i].isNull())
        {
            int size = 0;
            const juce::String res = juce::String (poseFiles[i]) + "_png";
            if (const char* data = BinaryData::getNamedResource (res.toRawUTF8(), size))
                images[(size_t) i] = juce::ImageCache::getFromMemory (data, size);
        }
    }
    scale.value = scale.target = 1.0f;
    setInterceptsMouseClicks (true, false);
    lastActivity = now();
    nextIdleAction = now() + 4.0;
}

PetView::~PetView() { stopTimer(); }

double PetView::now() const
{
    return frozenTime >= 0.0 ? frozenTime : juce::Time::getMillisecondCounterHiRes() / 1000.0;
}

juce::Image& PetView::image (Pose p)
{
    auto& img = images[(size_t) p];
    return img.isValid() ? img : images[0];
}

void PetView::setEnabled (bool on)
{
    enabled = on;
    if (onEnabledChanged) onEnabledChanged (on);
    repaint();
}

void PetView::visibilityChanged()
{
    if (isVisible() && frozenTime < 0.0) startTimerHz (60); else stopTimer();
}

void PetView::kick (float s, float r, float y)
{
    scale.velocity += s;
    rotation.velocity += r;
    lift.velocity += y;
}

void PetView::setPose (Pose p, double hold, const juce::String& text, int priority)
{
    const double t = now();
    // 判定来得很密：低优先级的别把刚换上的动作顶掉（至少显示 0.5 秒）
    if (priority < currentPriority && t < poseSince + 0.5 && t < holdUntil)
        return;
    if (p != current)
    {
        previous = current;
        current = p;
        poseSince = t;
    }
    holdUntil = t + hold;
    currentPriority = priority;
    if (text.isNotEmpty())
    {
        bubble = text;
        bubbleUntil = t + juce::jmax (1.2, hold);
    }
}

void PetView::react (Event e, int combo, const juce::String& detail)
{
    if (! enabled) return;
    const double t = now();
    const bool wasBored = idleStage > 0;
    lastActivity = t;
    idleStage = 0;
    auto pick = [this] (const char* key) { const auto& l = lines (key); return l[(int) (rand01() * (float) l.size()) % l.size()]; };
    auto withDetail = [&] (juce::String s) { return detail.isNotEmpty() ? s + "  " + detail : s; };
    const bool fresh = t - poseSince > 0.35;        // 很快的一串判定，动作只“弹”一下

    switch (e)
    {
        case Event::perfect:
            setPose (Pose::perfect, 1.4, pick ("perfect"), 3);
            bubbleColour = juce::Colour (0xffffd166);
            if (fresh) kick (0.9f, 0.0f, -260.0f);
            for (int i = 0; i < 5; ++i)
            {
                const float side = i % 2 == 0 ? -1.0f : 1.0f;      // 从头两边往外蹦
                particles.push_back ({ 0.5f + side * (0.28f + rand01() * 0.12f), 0.08f + rand01() * 0.25f, side * (0.15f + rand01() * 0.2f), -0.2f - rand01() * 0.2f,
                                       0.0f, 0.7f + rand01() * 0.4f, 6.0f + rand01() * 5.0f, 1, rand01() * 6.0f });
            }
            break;
        case Event::good:
            setPose (Pose::good, 1.1, pick ("good"), 1);
            bubbleColour = juce::Colour (0xff86efac);
            if (fresh) kick (0.3f, -40.0f, -90.0f);
            break;
        case Event::early:
            setPose (Pose::early, 1.3, withDetail (pick ("early")), 2);
            bubbleColour = juce::Colour (0xff93c5fd);
            if (fresh) kick (0.0f, -70.0f, -60.0f);
            break;
        case Event::late:
            setPose (Pose::late, 1.3, withDetail (pick ("late")), 2);
            bubbleColour = juce::Colour (0xfffdba74);
            if (fresh) kick (0.0f, 70.0f, 40.0f);
            break;
        case Event::wrong:
            setPose (Pose::wrong, 1.6, pick ("wrong"), 4);
            bubbleColour = juce::Colour (0xfffca5a5);
            if (fresh) kick (-0.3f, 160.0f, 30.0f);      // 摇头
            particles.push_back ({ 0.78f, 0.22f, 0.0f, 0.12f, 0.0f, 1.0f, 9.0f, 3, 0.0f });   // 汗珠
            break;
        case Event::miss:
            setPose (Pose::miss, 1.6, pick ("miss"), 4);
            bubbleColour = juce::Colour (0xffd1d5db);
            if (fresh) kick (-0.4f, 0.0f, 120.0f);       // 往下一沉
            break;
        case Event::combo:
            setPose (Pose::combo, 2.2, combo > 0 ? T ("连击 ") + juce::String (combo) + T ("，别松懈。") : pick ("combo"), 5);
            bubbleColour = juce::Colour (0xfff0abfc);
            kick (1.4f, -60.0f, -420.0f);
            for (int i = 0; i < 8; ++i)
                particles.push_back ({ 0.72f + rand01() * 0.2f, 0.45f + rand01() * 0.15f, 0.05f + rand01() * 0.2f, -0.35f - rand01() * 0.25f,
                                       0.0f, 1.2f + rand01() * 0.6f, 11.0f + rand01() * 5.0f, 2, (rand01() - 0.5f) * 2.0f });
            break;
        case Event::cheer:
            setPose (Pose::good, 1.2, wasBored ? pick ("back") : pick ("cheer"), 1);
            bubbleColour = juce::Colour (0xff86efac);
            kick (0.4f, 0.0f, -150.0f);
            break;
    }
    repaint();
}

void PetView::setActivity (float inputPeak, bool drumsPlaying, int drumBeat, float bpm)
{
    const double t = now();
    // 弹琴的能量：快起慢落
    const float lvl = juce::jlimit (0.0f, 1.0f, inputPeak * 3.0f);
    bobEnv += (lvl > bobEnv ? 0.35f : 0.02f) * (lvl - bobEnv);
    if (lvl > 0.08f || drumsPlaying)
    {
        if (idleStage > 0 && t - lastActivity > 20.0)
            react (Event::cheer);
        lastActivity = t;
        idleStage = 0;
    }
    beatInterval = 60.0f / juce::jmax (40.0f, bpm);
    if (drumsPlaying && drumBeat != lastDrumBeat && drumBeat >= 0)
    {
        lastBeatTime = t;
        kick (0.0f, (drumBeat % 2 == 0 ? -1.0f : 1.0f) * 18.0f, drumBeat == 0 ? -110.0f : -60.0f);   // 跟拍子点头
    }
    lastDrumBeat = drumsPlaying ? drumBeat : -1;
}

void PetView::timerCallback()
{
    const double t = now();
    const float dt = (float) juce::jlimit (0.001, 0.05, t - lastFrame);
    lastFrame = t;

    // 判定动作放完：回到待机
    if (current != Pose::normal && t > holdUntil && idleStage != 2)
    {
        previous = current;
        current = Pose::normal;
        poseSince = t;
        currentPriority = 0;
    }

    // 等久了：看表 → 托腮发呆
    const double idleFor = t - lastActivity;
    if (idleStage == 0 && idleFor > 30.0)
    {
        idleStage = 1;
        nextIdleAction = t;
    }
    if (idleStage == 1 && idleFor > 75.0)
    {
        idleStage = 2;
        previous = current; current = Pose::wrong; poseSince = t; holdUntil = 1.0e12;
        bubble = lines ("sleepy")[(int) (rand01() * 2.0f) % 2]; bubbleUntil = t + 3.0; bubbleColour = juce::Colour (0xffd1d5db);
    }

    // 待机小动作
    if (t >= nextIdleAction && t > holdUntil)
    {
        const float r = rand01();
        if (idleStage == 1)
        {
            // 不耐烦地看表
            setPose (Pose::miss, 2.4, r < 0.5f ? lines ("bored")[(int) (rand01() * 3.0f) % 3] : juce::String(), 0);
            bubbleColour = juce::Colour (0xffd1d5db);
            kick (0.0f, 30.0f, 40.0f);
            nextIdleAction = t + 10.0 + rand01() * 8.0;
        }
        else if (idleStage == 0)
        {
            if (r < 0.35f)      kick (0.0f, -55.0f, -70.0f);          // 抬杯子抿一口
            else if (r < 0.65f) rotation.target = (rand01() < 0.5f ? -1.0f : 1.0f) * (2.0f + rand01() * 2.0f);   // 歪头一会儿
            else if (r < 0.85f) kick (0.25f, 0.0f, -160.0f);          // 小跳一下
            else                kick (-0.15f, 25.0f, 30.0f);          // 叹口气
            nextIdleAction = t + 4.0 + rand01() * 7.0;
        }
        else
        {
            kick (0.0f, 0.0f, 25.0f);                                // 发呆时偶尔点一下头（打瞌睡）
            nextIdleAction = t + 5.0 + rand01() * 5.0;
        }
    }
    if (std::abs (rotation.target) > 0.01f && rand01() < dt * 0.4f)
        rotation.target = 0.0f;                                      // 歪头一会儿就回正

    scale.step (dt, 120.0f, 11.0f);
    rotation.step (dt, 90.0f, 10.0f);
    lift.step (dt, 150.0f, 13.0f);
    scale.target = 1.0f;
    lift.target = idleStage == 2 ? 6.0f : 0.0f;

    // 粒子：咖啡热气（只在端着咖啡的待机动作里）、发呆时的 z
    if (current == Pose::normal && t - lastSteam > 0.28)
    {
        lastSteam = t;
        particles.push_back ({ 0.25f + (rand01() - 0.5f) * 0.05f, 0.67f, (rand01() - 0.5f) * 0.02f, -0.06f, 0.0f, 1.6f + rand01() * 0.6f,
                               7.0f + rand01() * 4.0f, 0, rand01() * 6.0f });
    }
    if (idleStage == 2 && t - lastSteam > 1.3)
    {
        lastSteam = t;
        particles.push_back ({ 0.72f, 0.2f, 0.05f, -0.06f, 0.0f, 2.6f, 10.0f + rand01() * 4.0f, 4, 0.0f });
    }
    for (auto& p : particles)
    {
        if (p.kind == 0 && current != Pose::normal) p.life += dt * 4.0f;     // 放下杯子了：热气很快散掉
        p.life += dt;
        p.x += p.vx * dt;
        p.y += p.vy * dt;
        if (p.kind == 0) p.x += 0.012f * std::sin ((p.life + p.spin) * 4.0f) * dt * 6.0f;
        if (p.kind == 1 || p.kind == 2) p.vy += 0.15f * dt;
        if (p.kind == 3) p.vy += 0.25f * dt;
    }
    particles.erase (std::remove_if (particles.begin(), particles.end(), [] (const Particle& p) { return p.life >= p.maxLife; }), particles.end());
    if (particles.size() > 80) particles.erase (particles.begin(), particles.begin() + (long) (particles.size() - 80));

    // 跟着弹琴的能量点头
    headBob = bobEnv * std::sin ((float) t * 2.0f * pi / juce::jmax (0.25f, beatInterval));
    repaint();
}

void PetView::paint (juce::Graphics& g)
{
    if (! enabled)
    {
        g.setColour (juce::Colour (0xff9a9a9a));
        g.setFont (juce::FontOptions (12.5f));
        g.drawText (T ("显示桌宠 ▸"), getLocalBounds().reduced (6, 0), juce::Justification::centredLeft);
        return;
    }
    const double t = now();
    auto area = getLocalBounds().toFloat().reduced (4.0f);
    const auto& base = images[0];
    if (base.isNull()) return;

    // 图片区域：底边对齐，上面留出气泡的位置
    const float aspect = (float) base.getWidth() / (float) base.getHeight();
    float h = juce::jmin (area.getHeight() - 8.0f, (area.getWidth() - 4.0f) / aspect);
    float w = h * aspect;
    const juce::Rectangle<float> imgArea (area.getCentreX() - w * 0.5f, area.getBottom() - h, w, h);

    // 呼吸 + 慢慢摇晃 + 弹簧 + 点头
    const float breathe = std::sin ((float) t * 2.0f * pi / 3.6f);
    const float sway = 0.9f * std::sin ((float) t * 2.0f * pi / 7.3f) + 0.4f * std::sin ((float) t * 2.0f * pi / 2.9f + 1.0f);
    const float sy = scale.value * (1.0f + 0.013f * breathe) + 0.02f * headBob * headBob;
    const float sx = scale.value * (1.0f - 0.006f * breathe);
    const float rot = (sway + rotation.value + 2.5f * headBob) * pi / 180.0f;
    const float dy = lift.value - 3.0f * std::abs (headBob);
    const float ax = imgArea.getCentreX(), ay = imgArea.getBottom();
    const auto xf = juce::AffineTransform::translation (-ax, -ay).scaled (sx, sy).rotated (rot).translated (ax, ay + dy);

    // 地上的影子
    g.setColour (juce::Colours::black.withAlpha (0.35f));
    g.fillEllipse (ax - w * 0.36f * sx, ay - 7.0f, w * 0.72f * sx, 12.0f);

    auto drawPose = [&] (Pose p, float alpha)
    {
        if (alpha <= 0.001f) return;
        auto& img = image (p);
        const auto place = juce::RectanglePlacement (juce::RectanglePlacement::centred | juce::RectanglePlacement::yBottom)
                               .getTransformToFit (img.getBounds().toFloat(), imgArea);
        g.setOpacity (alpha);
        g.drawImageTransformed (img, place.followedBy (xf), false);
    };
    const float fade = (float) juce::jlimit (0.0, 1.0, (t - poseSince) / 0.18);
    if (fade < 1.0f) drawPose (previous, 1.0f - fade);
    drawPose (current, fade);
    g.setOpacity (1.0f);

    // 身体下沿是平的：用面板颜色渐隐掉
    if (! fadeColour.isTransparent())
    {
        const float fh = h * 0.14f;
        juce::ColourGradient gr (fadeColour.withAlpha (0.0f), 0.0f, ay - fh, fadeColour, 0.0f, ay + 2.0f, false);
        g.setGradientFill (gr);
        g.fillRect (imgArea.getX() - 20.0f, ay - fh, w + 40.0f, fh + 6.0f + juce::jmax (0.0f, dy));
    }

    // 粒子
    for (auto& p : particles)
    {
        const float a = 1.0f - p.life / p.maxLife;
        const juce::Point<float> c (imgArea.getX() + p.x * w, imgArea.getY() + p.y * h + dy);
        switch (p.kind)
        {
            case 0:     // 热气
            {
                // 一缕缕往上飘、越来越淡越宽
                const float grow = 1.0f + p.life * 0.8f;
                g.setColour (juce::Colours::white.withAlpha (0.16f * a * juce::jmin (1.0f, p.life * 2.5f)));
                g.fillEllipse (c.x - p.size * 0.35f * grow, c.y - p.size * grow, p.size * 0.7f * grow, p.size * 2.0f * grow);
            }
                break;
            case 1:     // 星星
            {
                juce::Path star;
                star.addStar (c, 4, p.size * 0.35f, p.size, p.spin + p.life * 3.0f);
                g.setColour (juce::Colour (0xffffd166).withAlpha (a));
                g.fillPath (star);
                break;
            }
            case 2:     // 音符
                g.setColour (juce::Colour (0xfff0abfc).withAlpha (a));
                g.setFont (juce::FontOptions (p.size * 1.6f, juce::Font::bold));
                g.drawText (juce::String::fromUTF8 (p.spin > 0.0f ? "\xe2\x99\xaa" : "\xe2\x99\xab"),
                            juce::Rectangle<float> (c.x - p.size, c.y - p.size, p.size * 2.0f, p.size * 2.0f), juce::Justification::centred);
                break;
            case 3:     // 汗珠
            {
                juce::Path drop;
                drop.startNewSubPath (c.x, c.y - p.size);
                drop.quadraticTo (c.x + p.size * 0.7f, c.y, c.x, c.y + p.size * 0.5f);
                drop.quadraticTo (c.x - p.size * 0.7f, c.y, c.x, c.y - p.size);
                g.setColour (juce::Colour (0xff93c5fd).withAlpha (a));
                g.fillPath (drop);
                break;
            }
            case 4:     // z
                g.setColour (juce::Colours::white.withAlpha (0.7f * a));
                g.setFont (juce::FontOptions (p.size, juce::Font::bold));
                g.drawText ("z", juce::Rectangle<float> (c.x - p.size, c.y - p.size, p.size * 2.0f, p.size * 2.0f), juce::Justification::centred);
                break;
            default: break;
        }
    }

    // 气泡
    if (bubble.isNotEmpty() && t < bubbleUntil)
    {
        const float a = (float) juce::jlimit (0.0, 1.0, juce::jmin ((bubbleUntil - t) / 0.3, 1.0));
        const juce::FontOptions font (14.0f, juce::Font::bold);
        const float tw = juce::jmin (area.getWidth() - 12.0f, juce::GlyphArrangement::getStringWidth (font, bubble) + 22.0f);
        auto r = juce::Rectangle<float> (area.getX() + 4.0f, area.getY() + 2.0f, tw, 28.0f);
        juce::Path p;
        p.addRoundedRectangle (r, 12.0f);
        p.startNewSubPath (r.getCentreX() + 8.0f, r.getBottom() - 1.0f);
        p.lineTo (r.getCentreX() + 22.0f, r.getBottom() + 12.0f);
        p.lineTo (r.getCentreX() + 22.0f, r.getBottom() - 1.0f);
        p.closeSubPath();
        g.setColour (juce::Colours::black.withAlpha (0.35f * a));
        g.fillPath (p, juce::AffineTransform::translation (0.0f, 2.0f));
        g.setColour (bubbleColour.withAlpha (a));
        g.fillPath (p);
        g.setColour (juce::Colour (0xff1f2937).withAlpha (a));
        g.setFont (font);
        g.drawFittedText (bubble, r.reduced (8.0f, 2.0f).toNearestInt(), juce::Justification::centred, 1, 0.75f);
    }
}

void PetView::mouseDown (const juce::MouseEvent& e)
{
    if (! enabled) { setEnabled (true); react (Event::cheer); return; }
    if (e.mods.isPopupMenu())
    {
        juce::PopupMenu m;
        m.addItem (1, T ("隐藏桌宠"));
        m.showMenuAsync (juce::PopupMenu::Options().withTargetComponent (this), [this] (int r) { if (r == 1) setEnabled (false); });
        return;
    }
    const auto& l = lines ("poke");
    setPose (rand01() < 0.5f ? Pose::good : Pose::early, 1.2, l[(int) (rand01() * (float) l.size()) % l.size()], 1);
    bubbleColour = juce::Colours::white;
    kick (0.5f, (rand01() - 0.5f) * 120.0f, -200.0f);
    lastActivity = now();
    idleStage = 0;
}
