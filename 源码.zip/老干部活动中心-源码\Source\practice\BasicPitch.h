#pragma once

#include <juce_core/juce_core.h>
#include <functional>
#include <vector>

// 复音音符识别：Spotify Basic Pitch 模型（Apache-2.0，约 230 KB，编在程序里），
// 用 ONNX Runtime（MIT）推理。ONNX Runtime 是程序旁边的 onnxruntime.dll，运行时才去加载：
// 没有这个文件也能正常编译和运行，只是扒谱退回到老的单音算法。
//
// 输入：22050 Hz 单声道。输出：每帧（约 11.6 ms）88 个琴键的“正在响”“起音”概率，和 1/3 半音精度的音高轮廓。
class BasicPitch
{
public:
    static constexpr double sampleRate = 22050.0;
    static constexpr int hop = 256;
    static constexpr int keys = 88;           // A0 (21) .. C8 (108)
    static constexpr int contourBins = 264;   // 每半音 3 格

    struct Output
    {
        int frames = 0;
        std::vector<float> note, onset, contour;     // frames × 88 / 88 / 264
        float noteAt (int t, int k) const    { return note[(size_t) t * keys + (size_t) k]; }
        float onsetAt (int t, int k) const   { return onset[(size_t) t * keys + (size_t) k]; }
        float contourAt (int t, int b) const { return contour[(size_t) t * contourBins + (size_t) b]; }
    };

    struct Note
    {
        double start = 0.0, end = 0.0;       // 秒
        int midi = 60;
        float amplitude = 0.0f;
        float bend = 0.0f;                   // 音里往上推得最高的半音数（来自音高轮廓）
        float bendPeak = 0.5f;               // 最高点在音里的位置 0..1
        bool release = false;                // 推上去又回来了
    };

    // ONNX Runtime 能不能用（找 onnxruntime.dll / libonnxruntime.so）；不能用时 why 写原因
    static bool isAvailable (juce::String& why);
    static juce::File runtimeLocation();

    // 推理（可能要几秒到十几秒）；progress 返回 false 取消
    static bool run (const std::vector<float>& mono22k, Output& out, juce::String& error,
                     std::function<bool (float)> progress = {});

    // 后处理：把概率图变成音符（Basic Pitch 原版的阈值和“melodia”补全）
    struct NoteParams
    {
        float onsetThreshold = 0.5f, frameThreshold = 0.3f;
        int minNoteFrames = 11;              // 约 128 ms
        int lowestMidi = 21, highestMidi = 108;
        bool melodiaTrick = true;
    };
    static std::vector<Note> notes (const Output& out, const NoteParams& p);
    static double frameToSeconds (int frame);
};
