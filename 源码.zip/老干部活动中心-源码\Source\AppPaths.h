#pragma once

#include <juce_core/juce_core.h>

// 程序自带的文件（音色库、音色预设、默认设置、吉他谱……）放在哪：
//   Windows / Linux：程序（.exe）旁边
//   Mac：LianqinHost.app/Contents/Resources 里（打包时放进去，整个 .app 拖到“应用程序”就能用）；
//        没有的话再看 .app 旁边（开发时直接从 build 文件夹运行）
namespace AppPaths
{
    inline juce::File appFolder()
    {
       #if JUCE_MAC
        const auto app = juce::File::getSpecialLocation (juce::File::currentApplicationFile);
        const auto res = app.getChildFile ("Contents").getChildFile ("Resources");
        for (auto name : { "音色库", "音色预设", "默认设置", "吉他谱" })
            if (res.getChildFile (juce::String::fromUTF8 (name)).isDirectory())
                return res;
        return app.getParentDirectory();
       #else
        return juce::File::getSpecialLocation (juce::File::currentExecutableFile).getParentDirectory();
       #endif
    }
}
