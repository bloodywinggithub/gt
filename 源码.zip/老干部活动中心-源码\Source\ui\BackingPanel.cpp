#include "BackingPanel.h"
#include "Text.h"

namespace
{
    const juce::Colour panelColour { 0xff222222 };
    const juce::Colour mutedText   { 0xff9a9a9a };
    const juce::Colour waveColour  { 0xff3fb6a8 };
    const juce::Colour loopColour  { 0xff38a35a };

    juce::String mmss (double s)
    {
        const int t = (int) std::floor (juce::jmax (0.0, s));
        return juce::String (t / 60) + ":" + juce::String (t % 60).paddedLeft ('0', 2);
    }

    void styleSlider (juce::Slider& s, double lo, double hi, double step, double value, const juce::String& suffix)
    {
        s.setSliderStyle (juce::Slider::LinearHorizontal);
        s.setTextBoxStyle (juce::Slider::TextBoxRight, false, 64, 22);
        s.setRange (lo, hi, step);
        s.setValue (value, juce::dontSendNotification);
        s.setTextValueSuffix (suffix);
    }
}

BackingPanel::BackingPanel (BackingTrack& t, juce::PropertiesFile& s) : track (t), settings (s)
{
    title.setText (T ("音频伴奏"), juce::dontSendNotification);
    title.setFont (juce::FontOptions (16.0f, juce::Font::bold));
    title.setColour (juce::Label::textColourId, juce::Colours::white);
    addAndMakeVisible (title);

    nameLabel.setFont (juce::FontOptions (13.0f, juce::Font::bold));
    nameLabel.setColour (juce::Label::textColourId, juce::Colour (0xff9cc4ff));
    nameLabel.setMinimumHorizontalScale (0.7f);
    addAndMakeVisible (nameLabel);
    timeLabel.setFont (juce::FontOptions (13.0f));
    timeLabel.setColour (juce::Label::textColourId, juce::Colours::white);
    timeLabel.setJustificationType (juce::Justification::centredRight);
    addAndMakeVisible (timeLabel);
    hint.setFont (juce::FontOptions (12.0f));
    hint.setColour (juce::Label::textColourId, mutedText);
    addAndMakeVisible (hint);

    importButton.setButtonText (T ("导入伴奏…"));
    importButton.setTooltip (T ("选一个音频文件当伴奏（WAV / MP3 / FLAC / OGG / AIFF，Windows 上还能用 M4A）；也可以直接把文件拖到这里"));
    importButton.onClick = [this] { chooseFile(); };
    addAndMakeVisible (importButton);

    playButton.onClick = [this] { togglePlay(); };
    playButton.setColour (juce::TextButton::buttonColourId, juce::Colour (0xff2e7d32));
    addAndMakeVisible (playButton);
    rewindButton.setButtonText (juce::String::fromUTF8 ("\xe2\x8f\xae"));
    rewindButton.setTooltip (T ("回到开头（有 A-B 循环时回到 A）"));
    rewindButton.onClick = [this] { track.seekSeconds (track.hasLoopRange() ? track.getLoopA() : 0.0); };
    addAndMakeVisible (rewindButton);

    aButton.setButtonText ("A");
    aButton.setTooltip (T ("把现在的位置设为循环起点（也可以直接在波形上拖一段）"));
    aButton.onClick = [this]
    {
        const double p = track.getPositionSeconds();
        const double b = track.hasLoopRange() ? track.getLoopB() : (track.getClip() != nullptr ? track.getClip()->lengthSeconds() : p + 4.0);
        track.setLoopRange (p, juce::jmax (p + 0.5, b));
    };
    addAndMakeVisible (aButton);
    bButton.setButtonText ("B");
    bButton.setTooltip (T ("把现在的位置设为循环终点"));
    bButton.onClick = [this]
    {
        const double p = track.getPositionSeconds();
        const double a = track.hasLoopRange() ? track.getLoopA() : 0.0;
        if (p > a + 0.3) { track.setLoopRange (a, p); track.seekSeconds (a); }
    };
    addAndMakeVisible (bButton);
    clearLoopButton.setButtonText (T ("取消 A-B"));
    clearLoopButton.onClick = [this] { track.clearLoopRange(); };
    addAndMakeVisible (clearLoopButton);

    loopToggle.setButtonText (T ("整首循环"));
    loopToggle.setToggleState (settings.getBoolValue ("backingLoop", true), juce::dontSendNotification);
    loopToggle.onClick = [this]
    {
        track.setLoopWhole (loopToggle.getToggleState());
        settings.setValue ("backingLoop", loopToggle.getToggleState());
    };
    track.setLoopWhole (loopToggle.getToggleState());
    addAndMakeVisible (loopToggle);

    speedLabel.setText (T ("变速"), juce::dontSendNotification);
    speedLabel.setTooltip (T ("放慢 / 加快伴奏（像磁带一样，音调也会跟着变）"));
    volumeLabel.setText (T ("音量"), juce::dontSendNotification);
    for (auto* l : { &speedLabel, &volumeLabel })
    {
        l->setFont (juce::FontOptions (13.0f));
        l->setColour (juce::Label::textColourId, mutedText);
        addAndMakeVisible (*l);
    }
    styleSlider (speedSlider, 50.0, 150.0, 1.0, settings.getDoubleValue ("backingSpeed", 100.0), "%");
    speedSlider.setDoubleClickReturnValue (true, 100.0);
    speedSlider.onValueChange = [this]
    {
        track.setSpeed ((float) speedSlider.getValue() / 100.0f);
        settings.setValue ("backingSpeed", speedSlider.getValue());
    };
    track.setSpeed ((float) speedSlider.getValue() / 100.0f);
    styleSlider (volumeSlider, -40.0, 6.0, 0.5, settings.getDoubleValue ("backingDb", -6.0), " dB");
    volumeSlider.setDoubleClickReturnValue (true, -6.0);
    volumeSlider.onValueChange = [this]
    {
        track.setGainDb ((float) volumeSlider.getValue());
        settings.setValue ("backingDb", volumeSlider.getValue());
    };
    track.setGainDb ((float) volumeSlider.getValue());
    addAndMakeVisible (speedSlider);
    addAndMakeVisible (volumeSlider);

    track.onLoaded = [this]
    {
        if (track.getClip() == nullptr)
            hint.setText (track.getLastError(), juce::dontSendNotification);
        else
        {
            settings.setValue ("backingFile", track.getClip()->file.getFullPathName());
            hint.setText (T ("点波形跳转，在波形上拖一段 = A-B 循环；空格 / P 播放暂停"), juce::dontSendNotification);
        }
        refresh();
        repaint();
    };

    // 上次用的伴奏：自动载入（后台解码，不卡界面）
    const juce::File last (settings.getValue ("backingFile"));
    if (track.getClip() == nullptr && ! track.isLoading() && last.existsAsFile())
        track.loadAsync (last);
    hint.setText (T ("导入一首歌或伴奏（也可以把音频文件拖到这里），跟着它弹；伴奏不过效果器"), juce::dontSendNotification);
    refresh();
}

BackingPanel::~BackingPanel()
{
    track.onLoaded = nullptr;
}

void BackingPanel::chooseFile()
{
    const juce::File last (settings.getValue ("backingFile"));
    chooser = std::make_unique<juce::FileChooser> (T ("选择伴奏音频"),
                                                   last.existsAsFile() ? last.getParentDirectory() : juce::File::getSpecialLocation (juce::File::userMusicDirectory),
                                                   BackingTrack::supportedWildcard());
    chooser->launchAsync (juce::FileBrowserComponent::openMode | juce::FileBrowserComponent::canSelectFiles,
                          [this] (const juce::FileChooser& fc)
                          {
                              const auto f = fc.getResult();
                              if (f.existsAsFile()) load (f);
                          });
}

void BackingPanel::load (const juce::File& f)
{
    hint.setText (T ("正在读取 ") + f.getFileName() + T (" …"), juce::dontSendNotification);
    track.loadAsync (f);
    refresh();
}

void BackingPanel::togglePlay()
{
    if (track.getClip() == nullptr) { chooseFile(); return; }
    track.setPlaying (! track.isPlaying());
    refresh();
}

bool BackingPanel::handleKey (const juce::KeyPress& key)
{
    if (key.getTextCharacter() == 'p' || key.getTextCharacter() == 'P') { togglePlay(); return true; }
    if (key == juce::KeyPress::homeKey) { rewindButton.triggerClick(); return true; }
    return false;
}

void BackingPanel::visibilityChanged()
{
    if (isVisible()) { refresh(); startTimerHz (30); } else stopTimer();
}

void BackingPanel::timerCallback()
{
    track.collectGarbage();
    refresh();
    repaint (waveArea.expanded (2));
}

void BackingPanel::refresh()
{
    const auto* clip = track.getClip();
    playButton.setButtonText (track.isPlaying() ? T ("❚❚ 暂停") : T ("▶ 播放"));
    const bool has = clip != nullptr;
    for (auto* c : std::initializer_list<juce::Component*> { &playButton, &rewindButton, &aButton, &bButton, &clearLoopButton })
        c->setEnabled (has);
    clearLoopButton.setEnabled (has && track.hasLoopRange());
    if (track.isLoading())
        nameLabel.setText (T ("读取中…"), juce::dontSendNotification);
    else
        nameLabel.setText (has ? clip->name : T ("还没有伴奏"), juce::dontSendNotification);
    timeLabel.setText (has ? mmss (track.getPositionSeconds()) + " / " + mmss (clip->lengthSeconds()) : juce::String(),
                       juce::dontSendNotification);
}

void BackingPanel::paint (juce::Graphics& g)
{
    g.setColour (panelColour);
    g.fillRoundedRectangle (getLocalBounds().toFloat(), 10.0f);

    auto w = waveArea.toFloat();
    g.setColour (juce::Colour (0xff15181c));
    g.fillRoundedRectangle (w, 5.0f);
    if (dropHover)
    {
        g.setColour (waveColour);
        g.drawRoundedRectangle (w.reduced (1.0f), 5.0f, 2.0f);
    }

    const auto* clip = track.getClip();
    if (clip == nullptr || clip->peaks.empty())
    {
        g.setColour (mutedText);
        g.setFont (juce::FontOptions (13.0f));
        g.drawText (track.isLoading() ? T ("正在解码音频…") : T ("把 MP3 / WAV / FLAC 拖到这里，或者点“导入伴奏…”"),
                    waveArea, juce::Justification::centred);
        return;
    }

    const double len = juce::jmax (0.01, clip->lengthSeconds());
    auto xFor = [&] (double sec) { return w.getX() + (float) (sec / len) * w.getWidth(); };

    // A-B 段
    double a = track.getLoopA(), b = track.getLoopB();
    if (dragging) { a = juce::jmin (dragA, dragB); b = juce::jmax (dragA, dragB); }
    if (b > a)
    {
        g.setColour (loopColour.withAlpha (0.22f));
        g.fillRect (juce::Rectangle<float>::leftTopRightBottom (xFor (a), w.getY(), xFor (b), w.getBottom()));
        g.setColour (loopColour);
        g.fillRect (xFor (a) - 1.0f, w.getY(), 2.0f, w.getHeight());
        g.fillRect (xFor (b) - 1.0f, w.getY(), 2.0f, w.getHeight());
        g.setFont (juce::FontOptions (11.0f, juce::Font::bold));
        g.drawText ("A", juce::Rectangle<float> (xFor (a) + 3.0f, w.getY() + 2.0f, 12.0f, 12.0f), juce::Justification::centredLeft);
        g.drawText ("B", juce::Rectangle<float> (xFor (b) - 14.0f, w.getY() + 2.0f, 12.0f, 12.0f), juce::Justification::centredRight);
    }

    // 波形
    const float mid = w.getCentreY(), half = w.getHeight() * 0.45f;
    const int bins = BackingTrack::Clip::peakBins;
    const double pos = track.getPositionSeconds();
    const float px = xFor (pos);
    for (int x = 0; x < (int) w.getWidth(); ++x)
    {
        const int b0 = (int) ((int64_t) x * bins / (int) w.getWidth());
        const int b1 = juce::jmax (b0 + 1, (int) ((int64_t) (x + 1) * bins / (int) w.getWidth()));
        float lo = 0.0f, hi = 0.0f;
        for (int k = b0; k < b1 && k < bins; ++k)
        {
            lo = juce::jmin (lo, clip->peaks[(size_t) k * 2]);
            hi = juce::jmax (hi, clip->peaks[(size_t) k * 2 + 1]);
        }
        const float xx = w.getX() + (float) x;
        g.setColour (xx < px ? waveColour : waveColour.withAlpha (0.45f));
        g.fillRect (xx, mid - hi * half, 1.0f, juce::jmax (1.0f, (hi - lo) * half));
    }

    // 播放头
    g.setColour (juce::Colours::white);
    g.fillRect (px - 1.0f, w.getY(), 2.0f, w.getHeight());

    // 分钟刻度
    g.setColour (juce::Colours::white.withAlpha (0.35f));
    g.setFont (juce::FontOptions (10.0f));
    const double tick = len > 300.0 ? 60.0 : (len > 90.0 ? 30.0 : 10.0);
    for (double t = tick; t < len; t += tick)
        g.drawText (mmss (t), juce::Rectangle<float> (xFor (t) - 20.0f, w.getBottom() - 12.0f, 40.0f, 11.0f), juce::Justification::centred);
}

void BackingPanel::resized()
{
    auto r = getLocalBounds().reduced (12, 8);
    auto top = r.removeFromTop (26);
    title.setBounds (top.removeFromLeft (80));
    importButton.setBounds (top.removeFromLeft (96).reduced (0, 1));
    top.removeFromLeft (8);
    playButton.setBounds (top.removeFromLeft (82).reduced (0, 1));
    top.removeFromLeft (4);
    rewindButton.setBounds (top.removeFromLeft (34).reduced (0, 1));
    top.removeFromLeft (10);
    aButton.setBounds (top.removeFromLeft (28).reduced (0, 1));
    top.removeFromLeft (3);
    bButton.setBounds (top.removeFromLeft (28).reduced (0, 1));
    top.removeFromLeft (3);
    clearLoopButton.setBounds (top.removeFromLeft (72).reduced (0, 1));
    top.removeFromLeft (8);
    loopToggle.setBounds (top.removeFromLeft (90));
    timeLabel.setBounds (top.removeFromRight (110));
    nameLabel.setBounds (top);
    r.removeFromTop (6);

    auto bottom = r.removeFromBottom (24);
    hint.setBounds (bottom.removeFromLeft (bottom.getWidth() / 2));
    {
        auto half = bottom.removeFromLeft (bottom.getWidth() / 2);
        speedLabel.setBounds (half.removeFromLeft (36));
        speedSlider.setBounds (half.withTrimmedRight (8));
        volumeLabel.setBounds (bottom.removeFromLeft (36));
        volumeSlider.setBounds (bottom);
    }
    r.removeFromBottom (6);
    waveArea = r;
}

double BackingPanel::secondsAtX (float x) const
{
    const auto* clip = track.getClip();
    if (clip == nullptr) return 0.0;
    return juce::jlimit (0.0, clip->lengthSeconds(), (double) (x - (float) waveArea.getX()) / juce::jmax (1, waveArea.getWidth()) * clip->lengthSeconds());
}

void BackingPanel::mouseDown (const juce::MouseEvent& e)
{
    if (! waveArea.contains (e.getPosition()) || track.getClip() == nullptr) return;
    dragA = dragB = secondsAtX ((float) e.x);
    dragging = false;
}

void BackingPanel::mouseDrag (const juce::MouseEvent& e)
{
    if (! waveArea.contains (e.getMouseDownPosition()) || track.getClip() == nullptr) return;
    if (e.getDistanceFromDragStart() > 5)
    {
        dragging = true;
        dragB = secondsAtX ((float) e.x);
        repaint (waveArea);
    }
}

void BackingPanel::mouseUp (const juce::MouseEvent& e)
{
    if (! waveArea.contains (e.getMouseDownPosition()) || track.getClip() == nullptr) return;
    if (dragging)
    {
        dragging = false;
        const double a = juce::jmin (dragA, dragB), b = juce::jmax (dragA, dragB);
        if (b - a > 0.3)
        {
            track.setLoopRange (a, b);
            track.seekSeconds (a);
        }
    }
    else
    {
        track.seekSeconds (secondsAtX ((float) e.x));
    }
    refresh();
    repaint();
}

bool BackingPanel::isInterestedInFileDrag (const juce::StringArray& files)
{
    for (auto& f : files)
        if (juce::File (f).hasFileExtension ("wav;mp3;flac;ogg;aif;aiff;m4a;wma;aac"))
            return true;
    return false;
}

void BackingPanel::filesDropped (const juce::StringArray& files, int, int)
{
    dropHover = false;
    for (auto& f : files)
        if (juce::File (f).hasFileExtension ("wav;mp3;flac;ogg;aif;aiff;m4a;wma;aac"))
        {
            load (juce::File (f));
            break;
        }
    repaint();
}
